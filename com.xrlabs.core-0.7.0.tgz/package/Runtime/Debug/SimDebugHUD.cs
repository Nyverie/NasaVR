#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;
using XRLabs.Simulations;

namespace XRLabs.DebugTools
{
    /// <summary>
    /// IMGUI overlay expandido para debug del sistema de simulación.
    /// Ventanas arrastrables activadas con teclas de función:
    /// F1=Principal | F4=Saltar paso | F5=Hotspots | F6=Quiz | F7=Log de eventos
    /// </summary>
    public class SimDebugHUD : MonoBehaviour
    {
        // Window IDs (distintos al CoreSimulationDemoHUD que usa 12035)
        private const int WinIdMain     = 12100;
        private const int WinIdJump     = 12101;
        private const int WinIdHotspots = 12102;
        private const int WinIdQuiz     = 12103;
        private const int WinIdLog      = 12104;

        private bool _showMain     = true;
        private bool _showJump     = false;
        private bool _showHotspots = false;
        private bool _showQuiz     = false;
        private bool _showLog      = false;

        private Rect _rectMain     = new Rect(20,  20,  360, 200);
        private Rect _rectJump     = new Rect(20,  240, 240, 90);
        private Rect _rectHotspots = new Rect(400, 20,  300, 300);
        private Rect _rectQuiz     = new Rect(400, 340, 300, 140);
        private Rect _rectLog      = new Rect(20,  350, 500, 280);

        private string _jumpTargetText = "0";
        private Vector2 _logScrollPos;
        private Vector2 _hotspotScrollPos;

        // Cache temporal para lista de hotspots (evitar alloc en OnGUI)
        private List<string> _cachedHotspotIds;
        private float _hotspotCacheTime = -1f;
        private const float HotspotCacheInterval = 0.5f;

        private void Update()
        {
            if (InputKeyCompat.IsKeyDown(KeyCode.F1)) _showMain     = !_showMain;
            if (InputKeyCompat.IsKeyDown(KeyCode.F4)) _showJump     = !_showJump;
            if (InputKeyCompat.IsKeyDown(KeyCode.F5)) _showHotspots = !_showHotspots;
            if (InputKeyCompat.IsKeyDown(KeyCode.F6)) _showQuiz     = !_showQuiz;
            if (InputKeyCompat.IsKeyDown(KeyCode.F7)) _showLog      = !_showLog;
        }

        private void OnGUI()
        {
            if (_showMain)
                _rectMain = GUILayout.Window(WinIdMain, _rectMain, DrawMainWindow, "Sim Debugger  [F1]");

            if (_showJump)
                _rectJump = GUILayout.Window(WinIdJump, _rectJump, DrawJumpWindow, "Jump to Step  [F4]");

            if (_showHotspots && HotspotRegistry.Instance != null)
                _rectHotspots = GUILayout.Window(WinIdHotspots, _rectHotspots, DrawHotspotsWindow, "Hotspots  [F5]");

            if (_showQuiz && SimulationDebugger.Instance?.CaseController != null)
                _rectQuiz = GUILayout.Window(WinIdQuiz, _rectQuiz, DrawQuizWindow, "Quiz  [F6]");

            if (_showLog)
                _rectLog = GUILayout.Window(WinIdLog, _rectLog, DrawLogWindow, "Event Log  [F7]");
        }

        // ── Ventana Principal ───────────────────────────────────────────────────

        private void DrawMainWindow(int id)
        {
            var sim  = SimulationManager.Instance;
            var step = SimulationDebugger.Instance?.StepSystem;
            var score = ScoringSystem.Instance;

            // Teclas de ayuda rápida
            GUILayout.Label("F1=HUD  F2=Avanzar  F3=Reiniciar  F4=Saltar");
            GUILayout.Label("F5=Hotspots  F6=Quiz  F7=Log  Shift+1-9=Paso N");
            GUILayout.Space(4);

            if (sim == null)
            {
                GUILayout.Label("[!] SimulationManager no encontrado en escena.");
                GUI.DragWindow();
                return;
            }

            string mode    = sim.CurrentMode.ToString();
            bool running   = sim.IsSimulationRunning;
            float elapsed  = sim.ElapsedSimulationTime;
            int totalSteps = step != null ? step.TotalSteps : 0;
            int curIdx     = step != null ? step.CurrentStepIndex + 1 : 0;
            string stepId  = step?.CurrentStep?.stepId ?? "—";
            int curScore   = score != null ? score.CurrentScore : 0;

            GUILayout.BeginVertical("box");
            GUILayout.Label($"Modo: {mode}  |  Running: {running}  |  Tiempo: {elapsed:0.0}s");
            GUILayout.Label($"Paso: {curIdx} / {totalSteps}  |  ID: {stepId}");
            GUILayout.Label($"Score: {curScore}");
            GUILayout.EndVertical();

            GUILayout.Space(4);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("⏭ Saltar condición / Avanzar  (F2)"))
                SimulationDebugger.Instance?.ForceAdvanceCurrentStep();

            if (GUILayout.Button("↺ Reiniciar  (F3)"))
                SimulationDebugger.Instance?.RestartSimulation();
            GUILayout.EndHorizontal();

            GUI.DragWindow();
        }

        // ── Ventana Jump to Step ────────────────────────────────────────────────

        private void DrawJumpWindow(int id)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Paso (0-based):", GUILayout.Width(100));
            _jumpTargetText = GUILayout.TextField(_jumpTargetText, GUILayout.Width(60));
            GUILayout.EndHorizontal();

            GUILayout.Space(4);

            if (GUILayout.Button("Jump"))
            {
                if (int.TryParse(_jumpTargetText, out int target))
                    SimulationDebugger.Instance?.JumpToStep(target);
            }

            GUI.DragWindow();
        }

        // ── Ventana Hotspots ────────────────────────────────────────────────────

        private void DrawHotspotsWindow(int id)
        {
            var registry = HotspotRegistry.Instance;
            if (registry == null)
            {
                GUILayout.Label("HotspotRegistry no disponible.");
                GUI.DragWindow();
                return;
            }

            // Refrescar cache cada intervalo
            if (_cachedHotspotIds == null || Time.time - _hotspotCacheTime > HotspotCacheInterval)
            {
                _cachedHotspotIds = registry.DEBUG_GetAllHotspotIds();
                _hotspotCacheTime = Time.time;
            }

            if (_cachedHotspotIds.Count == 0)
            {
                GUILayout.Label("No hay hotspots registrados.");
                GUI.DragWindow();
                return;
            }

            GUILayout.Label($"Hotspots registrados: {_cachedHotspotIds.Count}");
            GUILayout.Space(4);

            _hotspotScrollPos = GUILayout.BeginScrollView(_hotspotScrollPos, GUILayout.Height(220));
            foreach (var hsId in _cachedHotspotIds)
            {
                bool touched = registry.IsHotspotTouched(hsId);
                GUILayout.BeginHorizontal();
                GUILayout.Label(touched ? "[v]" : "[ ]", GUILayout.Width(30));
                GUILayout.Label(hsId);
                if (!touched && GUILayout.Button("Touch", GUILayout.Width(60)))
                    SimulationDebugger.Instance?.SimulateHotspotTouch(hsId);
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();

            GUI.DragWindow();
        }

        // ── Ventana Quiz ────────────────────────────────────────────────────────

        private void DrawQuizWindow(int id)
        {
            var debugger = SimulationDebugger.Instance;
            var ctrl     = debugger?.CaseController;

            if (ctrl == null)
            {
                GUILayout.Label("CaseEvaluationController no disponible.");
                GUI.DragWindow();
                return;
            }

            if (ctrl.IsCaseCompleted)
            {
                GUILayout.Label("Caso completado.");
                GUI.DragWindow();
                return;
            }

            var caseData   = ctrl.DEBUG_CurrentCase;
            int qIdx       = ctrl.DEBUG_CurrentQuestionIndex;
            int attempts   = ctrl.DEBUG_AttemptsOnCurrentQuestion;
            int remaining  = 2 - attempts;

            string caseName = caseData != null ? $"Caso {caseData.caseNumber}: {caseData.failureName}" : "—";
            string qLabel   = qIdx switch
            {
                0 => "Q1: Tipo de falla",
                1 => "Q2: Causa",
                2 => "Q3: Recomendación",
                _ => $"Q{qIdx + 1}"
            };

            GUILayout.Label(caseName);
            GUILayout.Label($"{qLabel}  |  Intentos restantes: {remaining}");
            GUILayout.Space(4);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("[OK] Correcto"))
                debugger.AnswerQuizCorrect();

            if (GUILayout.Button("[X] Incorrecto"))
                debugger.AnswerQuizWrong();
            GUILayout.EndHorizontal();

            GUI.DragWindow();
        }

        // ── Ventana Event Log ───────────────────────────────────────────────────

        private void DrawLogWindow(int id)
        {
            var log = SimulationDebugger.Instance?.EventLog;

            if (log == null || log.Count == 0)
            {
                GUILayout.Label("Sin eventos registrados aún.");
                GUI.DragWindow();
                return;
            }

            GUILayout.Label($"Últimos eventos ({log.Count}):");
            GUILayout.Space(2);

            _logScrollPos = GUILayout.BeginScrollView(_logScrollPos, GUILayout.Height(220));
            // Mostrar del más reciente al más antiguo
            for (int i = log.Count - 1; i >= 0; i--)
                GUILayout.Label(log[i]);
            GUILayout.EndScrollView();

            GUI.DragWindow();
        }
    }
}
#endif
