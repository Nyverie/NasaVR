#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using XRLabs.Core;
using XRLabs.Simulations;
using SimMode = XRLabs.Core.SimulationMode;

namespace XRLabs.DebugTools
{
    /// <summary>
    /// Controlador central de debug para el sistema de simulación.
    /// Activo solo en Editor y Development Builds.
    /// Atajos: F2=Avanzar paso, F3=Reiniciar, Shift+1..9=Saltar a paso N.
    /// </summary>
    public class SimulationDebugger : MonoBehaviour
    {
        public static SimulationDebugger Instance { get; private set; }

        [Header("Core Systems (requeridos)")]
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private SimulationManager simulationManager;

        [Header("Sistemas opcionales")]
        [SerializeField] private ScoringSystem scoringSystem;
        [SerializeField] private HotspotRegistry hotspotRegistry;
        [SerializeField] private CaseEvaluationController caseEvaluationController;

        private const int MaxLogEntries = 20;
        private readonly List<string> _eventLog = new();
        private float _sessionStartTime;

        /// <summary>Log circular de los últimos 20 eventos de simulación.</summary>
        public IReadOnlyList<string> EventLog => _eventLog;

        /// <summary>Referencia al StepSystem para uso desde el HUD.</summary>
        public StepSystem StepSystem => stepSystem;

        /// <summary>Referencia al CaseEvaluationController para uso desde el HUD.</summary>
        public CaseEvaluationController CaseController => caseEvaluationController;

        /// <summary>Referencia al HotspotRegistry para uso desde el HUD.</summary>
        public HotspotRegistry HotspotRegistry => hotspotRegistry;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            _sessionStartTime = Time.time;

            // Suscribir en Awake para capturar OnSimulationStarted que dispara SimulationManager.Start()
            // (que corre en el mismo frame que nuestro Start, pero posiblemente antes en orden de componentes)
            if (simulationManager != null)
                SubscribeEvents();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            UnsubscribeEvents();
        }

        private void Start()
        {
            // Fallback a singletons si las referencias no fueron asignadas en el inspector
            if (simulationManager == null)
            {
                simulationManager = SimulationManager.Instance;
                SubscribeEvents(); // suscribir ahora si no se hizo en Awake
            }

            if (scoringSystem == null) scoringSystem = ScoringSystem.Instance;
            if (hotspotRegistry == null) hotspotRegistry = HotspotRegistry.Instance;

            AddLog("SimulationDebugger listo. F2=Avanzar, F3=Reiniciar, Shift+1-9=Saltar paso.");
        }

        private void SubscribeEvents()
        {
            if (simulationManager == null) return;
            simulationManager.OnSimulationStarted += HandleSimulationStarted;
            simulationManager.OnSimulationEnded += HandleSimulationEnded;
            simulationManager.OnStepStarted += HandleStepStarted;
            simulationManager.OnStepCompleted += HandleStepCompleted;
        }

        private void UnsubscribeEvents()
        {
            if (simulationManager == null) return;
            simulationManager.OnSimulationStarted -= HandleSimulationStarted;
            simulationManager.OnSimulationEnded -= HandleSimulationEnded;
            simulationManager.OnStepStarted -= HandleStepStarted;
            simulationManager.OnStepCompleted -= HandleStepCompleted;
        }

        private void HandleSimulationStarted(SimMode mode, int totalSteps)
        {
            AddLog($"SimulationStarted: {mode} | {totalSteps} pasos");
        }

        private void HandleSimulationEnded(int finalScore, float totalTime)
        {
            AddLog($"SimulationEnded: score={finalScore} | tiempo={totalTime:0.0}s");
        }

        private void HandleStepStarted(StepDefinition step, int stepIndex, int totalSteps)
        {
            AddLog($"StepStarted: {step?.stepId ?? "null"} [{stepIndex + 1}/{totalSteps}]");
        }

        private void HandleStepCompleted(StepDefinition step, int stepIndex, float elapsedTime, int score)
        {
            AddLog($"StepCompleted: {step?.stepId ?? "null"} (score: {score}, time: {elapsedTime:0.0}s)");
        }

        private void AddLog(string message)
        {
            float elapsed = Time.time - _sessionStartTime;
            string entry = $"[+{elapsed:0.0}s] {message}";
            _eventLog.Add(entry);
            if (_eventLog.Count > MaxLogEntries)
                _eventLog.RemoveAt(0);
            Debug.Log($"[SimDebug] {entry}");
        }

        private void Update()
        {
            if (InputKeyCompat.IsKeyDown(KeyCode.F2))
                ForceAdvanceCurrentStep();

            if (InputKeyCompat.IsKeyDown(KeyCode.F3))
                RestartSimulation();

            bool shiftHeld = InputKeyCompat.IsKeyHeld(KeyCode.LeftShift)
                          || InputKeyCompat.IsKeyHeld(KeyCode.RightShift);

            if (shiftHeld)
            {
                for (int i = 1; i <= 9; i++)
                {
                    if (InputKeyCompat.IsKeyDown(KeyCode.Alpha0 + i))
                    {
                        JumpToStep(i - 1);
                        break;
                    }
                }
            }
        }

        // ── Métodos públicos de control ─────────────────────────────────────────

        /// <summary>Fuerza completar el paso actual sin importar su condición.</summary>
        public void ForceAdvanceCurrentStep()
        {
            if (stepSystem == null) return;
            AddLog($"DEBUG ForceAdvance @ paso {stepSystem.CurrentStepIndex + 1}");
            stepSystem.DebugForceAdvanceCurrentStep();
        }

        /// <summary>Salta directamente a un paso por índice (0-based).</summary>
        public void JumpToStep(int index)
        {
            if (stepSystem == null) return;
            AddLog($"DEBUG JumpToStep({index})");
            stepSystem.DebugJumpToStep(index);
        }

        /// <summary>Simula el toque de un hotspot por ID.</summary>
        public void SimulateHotspotTouch(string hotspotId)
        {
            if (hotspotRegistry == null)
            {
                hotspotRegistry = HotspotRegistry.Instance;
                if (hotspotRegistry == null) return;
            }

            AddLog($"DEBUG SimulateHotspotTouch({hotspotId})");
            hotspotRegistry.DEBUG_SimulateTouch(hotspotId);
        }

        /// <summary>Responde la pregunta actual del quiz con la respuesta correcta.</summary>
        public void AnswerQuizCorrect()
        {
            if (caseEvaluationController == null) return;
            AddLog("DEBUG AnswerQuiz(correcto)");
            caseEvaluationController.DEBUG_SelectAnswer(true);
        }

        /// <summary>Responde la pregunta actual del quiz con una respuesta incorrecta.</summary>
        public void AnswerQuizWrong()
        {
            if (caseEvaluationController == null) return;
            AddLog("DEBUG AnswerQuiz(incorrecto)");
            caseEvaluationController.DEBUG_SelectAnswer(false);
        }

        /// <summary>Recarga la escena activa para reiniciar la simulación desde cero.</summary>
        public void RestartSimulation()
        {
            AddLog("DEBUG RestartSimulation");
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        /// <summary>Agrega una entrada al log de eventos desde código externo.</summary>
        public void LogEvent(string message) => AddLog(message);
    }
}
#endif
