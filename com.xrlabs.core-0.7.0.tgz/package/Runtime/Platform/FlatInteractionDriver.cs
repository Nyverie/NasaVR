using UnityEngine;
using UnityEngine.InputSystem;
using XRLabs.Interactions;

namespace XRLabs.Platform
{
    /// <summary>
    /// Driver de interacción para modo plano: traduce mouse/touch a los eventos del
    /// contrato InteractableBase — la lógica de simulación no distingue VR de flat.
    ///
    /// Mapeo (botón izquierdo / tap):
    /// - hover del pointer          → DriverHover/DriverUnhover
    /// - tap sobre TouchableHotspot → Touch() (respeta oneShot)
    /// - press sobre RotatableItem  → DriverSelect + drag rota el objeto
    /// - press/release sobre otros  → DriverSelect/DriverRelease; tap corto → DriverActivate
    ///
    /// v0.6 — arrastrar y mantener:
    /// - drag sobre un GrabbableItem (IDragSource) → lo mueve sobre un plano horizontal a su altura;
    ///   al soltar sobre una DropZone esta emite Dropped (igual que en VR). Un tap sigue siendo tap.
    /// - press sobre una SourcePile → carga la herramienta y la arrastra desde el primer pixel
    /// - press sobre una AimTool    → agarra + activa mientras dure el press y apunta con el rayo del puntero
    /// - press sobre un HoldButton  → agarra + activa mientras dure el press
    /// - drag sobre una ScrubSurface → frota con el recorrido del puntero sobre la superficie
    /// Colocar junto a la cámara del rig flat.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class FlatInteractionDriver : MonoBehaviour
    {
        [SerializeField] private float maxRayDistance = 10f;
        [SerializeField] private LayerMask interactionMask = ~0;
        [Tooltip("Grados de rotación por píxel de drag sobre un RotatableItem")]
        [SerializeField] private float dragRotationSensitivity = 0.4f;
        [Tooltip("Desplazamiento máximo (px) para que un press cuente como tap/activate")]
        [SerializeField] private float tapMaxDragPixels = 12f;

        [Tooltip("v0.6: permite arrastrar GrabbableItems/herramientas con el puntero.")]
        [SerializeField] private bool dragEnabled = true;

        private enum PressMode { Tap, Rotate, Drag, Aim, Hold, Scrub }

        private static readonly RaycastHit[] HitBuffer = new RaycastHit[32];

        private Camera _camera;
        private InteractableBase _hovered;
        private InteractableBase _pressed;
        private RotatableItem _rotating;
        private Vector2 _pressPosition;
        private float _accumulatedDragPixels;

        private PressMode _mode;
        private Plane _dragPlane;
        private Vector3 _dragOffset;
        private bool _dragging;
        private bool _dragFromStart;
        private Rigidbody _dragBody;
        private bool _dragBodyWasKinematic;
        private Vector3 _lastPlanePoint;
        private Coroutine _finishRoutine;
        private InteractableBase _pendingItem;
        private Rigidbody _pendingBody;
        private bool _pendingBodyWasKinematic;

        private void Awake()
        {
            _camera = GetComponent<Camera>();
        }

        private void OnDisable()
        {
            if (_finishRoutine != null) FinishPendingPress();
        }

        private void Update()
        {
            if (!TryGetPointer(out Vector2 position, out bool pressedThisFrame,
                    out bool isPressed, out bool releasedThisFrame, out Vector2 delta))
                return;

            HandlePointer(position, pressedThisFrame, isPressed, releasedThisFrame, delta);
        }

        /// <summary>
        /// Procesa un estado del puntero (mouse/touch). Update lo llama con el dispositivo real;
        /// es público para poder simularlo en pruebas.
        /// </summary>
        public void HandlePointer(Vector2 position, bool pressedThisFrame, bool isPressed,
            bool releasedThisFrame, Vector2 delta)
        {
            if (_camera == null) _camera = GetComponent<Camera>();

            UpdateHover(position, isPressed);

            if (pressedThisFrame) BeginPress(position);
            if (isPressed && _rotating != null && delta.sqrMagnitude > 0f) DragRotate(delta);
            if (isPressed) _accumulatedDragPixels += delta.magnitude;
            if (isPressed && _pressed != null) ContinuePress(position);
            if (releasedThisFrame) EndPress();
        }

        private bool TryGetPointer(out Vector2 position, out bool down, out bool held,
            out bool up, out Vector2 delta)
        {
            var touch = Touchscreen.current;
            if (touch != null && touch.primaryTouch.isInProgress)
            {
                position = touch.primaryTouch.position.ReadValue();
                down = touch.primaryTouch.press.wasPressedThisFrame;
                held = touch.primaryTouch.press.isPressed;
                up = touch.primaryTouch.press.wasReleasedThisFrame;
                delta = touch.primaryTouch.delta.ReadValue();
                return true;
            }

            var mouse = Mouse.current;
            if (mouse != null)
            {
                position = mouse.position.ReadValue();
                down = mouse.leftButton.wasPressedThisFrame;
                held = mouse.leftButton.isPressed;
                up = mouse.leftButton.wasReleasedThisFrame;
                delta = mouse.delta.ReadValue();
                return true;
            }

            position = default; down = held = up = false; delta = default;
            return false;
        }

        private InteractableBase RaycastInteractable(Vector2 screenPosition) =>
            RaycastInteractable(screenPosition, out _);

        private InteractableBase RaycastInteractable(Vector2 screenPosition, out RaycastHit hit)
        {
            hit = default;

            // Fuera del viewport 3D (ej: sobre el dock de UI) no hay interacción 3D
            if (!_camera.pixelRect.Contains(screenPosition))
                return null;

            Ray ray = _camera.ScreenPointToRay(screenPosition);
            int count = Physics.RaycastNonAlloc(ray, HitBuffer, maxRayDistance, interactionMask);
            System.Array.Sort(HitBuffer, 0, count, HitDistanceComparer.Instance);

            for (int i = 0; i < count; i++)
            {
                var interactable = HitBuffer[i].collider.GetComponentInParent<InteractableBase>();
                if (interactable != null)
                {
                    hit = HitBuffer[i];
                    return interactable;
                }

                // Un trigger sin interactuable (DropZone, volúmenes) no tapa lo que hay detrás.
                if (!HitBuffer[i].collider.isTrigger) return null;
            }
            return null;
        }

        private sealed class HitDistanceComparer : System.Collections.Generic.IComparer<RaycastHit>
        {
            public static readonly HitDistanceComparer Instance = new();
            public int Compare(RaycastHit a, RaycastHit b) => a.distance.CompareTo(b.distance);
        }

        private void UpdateHover(Vector2 position, bool isPressed)
        {
            if (isPressed) return; // durante un press no cambiamos el hover

            var current = RaycastInteractable(position);
            if (current == _hovered) return;

            if (_hovered != null) _hovered.DriverUnhover();
            _hovered = current;
            if (_hovered != null) _hovered.DriverHover();
        }

        private void BeginPress(Vector2 position)
        {
            if (_finishRoutine != null) FinishPendingPress();

            _pressed = RaycastInteractable(position, out RaycastHit hit);
            _pressPosition = position;
            _accumulatedDragPixels = 0f;
            _mode = PressMode.Tap;
            _dragging = false;
            _dragFromStart = false;

            if (_pressed == null) return;

            _pressed.DriverSelect();
            _rotating = _pressed as RotatableItem;

            if (_rotating != null)
            {
                _mode = PressMode.Rotate;
            }
            else if (_pressed is AimTool aim)
            {
                _mode = PressMode.Aim;
                aim.DriverActivate();
                aim.SetExternalRay(_camera.ScreenPointToRay(position));
            }
            else if (_pressed is HoldButton)
            {
                _mode = PressMode.Hold;
                _pressed.DriverActivate();
            }
            else if (_pressed is ScrubSurface)
            {
                _mode = PressMode.Scrub;
                _dragPlane = new Plane(hit.normal, hit.point);
                _lastPlanePoint = hit.point;
            }
            else if (dragEnabled && _pressed is IDragSource source && source.DragTarget != null)
            {
                PrepareDrag(source.DragTarget, position, snapToPointer: _pressed is SourcePile);
            }
            else if (dragEnabled && _pressed is SourcePile)
            {
                // Pila sin herramienta aún (no debería pasar: DriverSelect la crea).
                _mode = PressMode.Tap;
            }
        }

        private void PrepareDrag(Transform target, Vector2 position, bool snapToPointer)
        {
            _mode = PressMode.Drag;
            _dragFromStart = snapToPointer;
            _dragPlane = new Plane(Vector3.up, target.position);

            _dragOffset = Vector3.zero;
            if (!snapToPointer && TryPlanePoint(position, _dragPlane, out Vector3 point))
                _dragOffset = target.position - point;

            if (snapToPointer) BeginDragging(target, position);
        }

        private void BeginDragging(Transform target, Vector2 position)
        {
            _dragging = true;
            _dragBody = target.GetComponent<Rigidbody>();
            if (_dragBody != null)
            {
                _dragBodyWasKinematic = _dragBody.isKinematic;
                _dragBody.isKinematic = true;
            }
            MoveDragTarget(target, position);
        }

        private void MoveDragTarget(Transform target, Vector2 position)
        {
            if (TryPlanePoint(position, _dragPlane, out Vector3 point))
                target.position = point + _dragOffset;
        }

        private bool TryPlanePoint(Vector2 screenPosition, Plane plane, out Vector3 point)
        {
            Ray ray = _camera.ScreenPointToRay(screenPosition);
            if (plane.Raycast(ray, out float enter) && enter <= maxRayDistance * 4f)
            {
                point = ray.GetPoint(enter);
                return true;
            }
            point = default;
            return false;
        }

        private void ContinuePress(Vector2 position)
        {
            switch (_mode)
            {
                case PressMode.Aim:
                    ((AimTool)_pressed).SetExternalRay(_camera.ScreenPointToRay(position));
                    break;

                case PressMode.Scrub:
                    if (TryPlanePoint(position, _dragPlane, out Vector3 point))
                    {
                        ((ScrubSurface)_pressed).DriverScrub(point - _lastPlanePoint);
                        _lastPlanePoint = point;
                    }
                    break;

                case PressMode.Drag:
                    var target = (_pressed as IDragSource)?.DragTarget;
                    if (target == null) break;

                    if (!_dragging && _accumulatedDragPixels > tapMaxDragPixels)
                        BeginDragging(target, position);
                    else if (_dragging)
                        MoveDragTarget(target, position);
                    break;
            }
        }

        private void DragRotate(Vector2 delta)
        {
            // Drag horizontal gira sobre el eje Y del mundo; vertical sobre el eje X de la cámara
            _rotating.ApplyExternalRotation(Vector3.up, -delta.x * dragRotationSensitivity);
            _rotating.ApplyExternalRotation(_camera.transform.right, delta.y * dragRotationSensitivity);
        }

        private void EndPress()
        {
            if (_pressed == null) return;

            var pressed = _pressed;
            var mode = _mode;
            bool wasTap = _accumulatedDragPixels <= tapMaxDragPixels;
            bool wasDragging = _dragging;
            var dragBody = _dragBody;
            bool bodyWasKinematic = _dragBodyWasKinematic;

            _pressed = null;
            _rotating = null;
            _dragging = false;
            _dragBody = null;
            _mode = PressMode.Tap;

            switch (mode)
            {
                case PressMode.Aim:
                    var aim = (AimTool)pressed;
                    aim.ClearExternalRay();
                    aim.DriverDeactivate();
                    pressed.DriverRelease();
                    return;

                case PressMode.Hold:
                    pressed.DriverDeactivate();
                    pressed.DriverRelease();
                    return;

                case PressMode.Drag when wasDragging:
                    // Esperar un paso de física: la zona se entera del último movimiento (trigger)
                    // antes de recibir el release, así el soltado dentro de la zona es fiable.
                    _pendingItem = pressed;
                    _pendingBody = dragBody;
                    _pendingBodyWasKinematic = bodyWasKinematic;
                    _finishRoutine = StartCoroutine(FinishDragRelease());
                    return;
            }

            if (wasTap && mode != PressMode.Scrub)
            {
                if (pressed is TouchableHotspot hotspot)
                    hotspot.Touch();
                else if (!(pressed is SourcePile))
                    pressed.DriverActivate();
            }

            pressed.DriverRelease();
        }

        private System.Collections.IEnumerator FinishDragRelease()
        {
            yield return new WaitForFixedUpdate();
            yield return null;
            _finishRoutine = null;
            ReleasePending();
        }

        private void ReleasePending()
        {
            var item = _pendingItem;
            var body = _pendingBody;
            bool wasKinematic = _pendingBodyWasKinematic;
            _pendingItem = null;
            _pendingBody = null;
            ReleaseDragged(item, body, wasKinematic);
        }

        private void ReleaseDragged(InteractableBase item, Rigidbody body, bool wasKinematic)
        {
            if (item != null) item.DriverRelease();

            if (body != null)
            {
                body.isKinematic = wasKinematic;
                if (!wasKinematic)
                {
                    body.linearVelocity = Vector3.zero;
                    body.angularVelocity = Vector3.zero;
                }
            }
        }

        /// <summary>Si empieza otro press antes de terminar el release pendiente, ciérralo ya.</summary>
        private void FinishPendingPress()
        {
            StopCoroutine(_finishRoutine);
            _finishRoutine = null;
            ReleasePending();
        }
    }
}
