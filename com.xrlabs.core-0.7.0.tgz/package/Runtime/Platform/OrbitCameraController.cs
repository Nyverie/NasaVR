using UnityEngine;
using UnityEngine.InputSystem;

namespace XRLabs.Platform
{
    /// <summary>
    /// Cámara del modo plano: orbita alrededor de un punto de interés con drag
    /// (botón derecho del mouse o un dedo) y zoom con scroll/pinch.
    /// El botón/tap izquierdo queda libre para el FlatInteractionDriver.
    /// </summary>
    public class OrbitCameraController : MonoBehaviour
    {
        [Header("Objetivo")]
        [Tooltip("Punto alrededor del cual orbita. Nulo = posición inicial hacia adelante.")]
        [SerializeField] private Transform focusPoint;
        [SerializeField] private float distance = 1.5f;

        [Header("Sensibilidad")]
        [SerializeField] private float orbitSpeed = 0.25f;
        [SerializeField] private float zoomSpeed = 0.15f;
        [SerializeField] private float minDistance = 0.4f;
        [SerializeField] private float maxDistance = 5f;
        [SerializeField] private float minPitch = -20f;
        [SerializeField] private float maxPitch = 75f;

        private float _yaw;
        private float _pitch = 20f;
        private Vector3 _focus;
        private float _lastPinchDistance = -1f;

        private void Start()
        {
            _focus = focusPoint != null ? focusPoint.position : transform.position + transform.forward * distance;
            var toCamera = transform.position - _focus;
            if (toCamera.sqrMagnitude > 0.001f)
            {
                distance = toCamera.magnitude;
                _yaw = Mathf.Atan2(toCamera.x, toCamera.z) * Mathf.Rad2Deg;
                _pitch = Mathf.Asin(Mathf.Clamp(toCamera.y / distance, -1f, 1f)) * Mathf.Rad2Deg;
            }
            Apply();
        }

        private void Update()
        {
            HandleMouse();
            HandleTouch();
            Apply();
        }

        private void HandleMouse()
        {
            var mouse = Mouse.current;
            if (mouse == null) return;

            if (mouse.rightButton.isPressed)
            {
                Vector2 delta = mouse.delta.ReadValue();
                _yaw += delta.x * orbitSpeed;
                _pitch = Mathf.Clamp(_pitch - delta.y * orbitSpeed, minPitch, maxPitch);
            }

            float scroll = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(scroll) > 0.01f)
                distance = Mathf.Clamp(distance - scroll * zoomSpeed * 0.01f, minDistance, maxDistance);
        }

        private void HandleTouch()
        {
            var touchscreen = Touchscreen.current;
            if (touchscreen == null) return;

            int active = 0;
            foreach (var touch in touchscreen.touches)
                if (touch.isInProgress) active++;

            if (active == 1)
            {
                Vector2 delta = touchscreen.primaryTouch.delta.ReadValue();
                _yaw += delta.x * orbitSpeed;
                _pitch = Mathf.Clamp(_pitch - delta.y * orbitSpeed, minPitch, maxPitch);
                _lastPinchDistance = -1f;
            }
            else if (active >= 2)
            {
                Vector2 p0 = touchscreen.touches[0].position.ReadValue();
                Vector2 p1 = touchscreen.touches[1].position.ReadValue();
                float pinch = Vector2.Distance(p0, p1);

                if (_lastPinchDistance > 0f)
                    distance = Mathf.Clamp(distance - (pinch - _lastPinchDistance) * zoomSpeed * 0.01f,
                        minDistance, maxDistance);

                _lastPinchDistance = pinch;
            }
            else
            {
                _lastPinchDistance = -1f;
            }
        }

        private void Apply()
        {
            Quaternion rotation = Quaternion.Euler(_pitch, _yaw, 0f);
            transform.position = _focus + rotation * (Vector3.back * distance);
            transform.rotation = rotation;
        }

        /// <summary>Cambia el punto de interés (ej: al presentar un modelo nuevo).</summary>
        public void SetFocus(Transform target)
        {
            focusPoint = target;
            if (target != null) _focus = target.position;
        }
    }
}
