using UnityEngine;

namespace XRLabs.Platform
{
    /// <summary>
    /// Pone el HUD de la escena preparada donde la persona lo vea según la plataforma (lote del visor, 2026-10-17). En
    /// modo plano el canvas se queda como está (pantalla). En un visor un canvas de pantalla no existe: pasa a canvas del
    /// mundo, a <see cref="distance"/> metros delante de la cámara activa, un poco por debajo de la mirada, y la sigue con
    /// suavidad (solo el giro horizontal, para que no baile con la cabeza). El mismo SubtitlePanel y el mismo botón
    /// Comenzar sirven en los dos casos; el rayo de los mandos los alcanza por el TrackedDeviceGraphicRaycaster del canvas.
    /// </summary>
    [RequireComponent(typeof(Canvas))]
    public class HudPlacement : MonoBehaviour
    {
        // 2026-10-25, primera corrida en un Quest 3: con 1,4 m de ancho y 0,25 m por debajo de la mirada las letras se
        // veían «tan grandes y pegadas» que el dueño no distinguía qué era cada cosa. 1,1 m reduce todo el HUD un 21 % y
        // 0,2 m lo sube un poco hacia la mirada. SubtitleHudBuilder pasa a estos valores los HUD que aún traen los de antes.
        public const float DefaultWorldWidth = 1.1f;
        public const float DefaultDrop = 0.2f;
        public const float DefaultDistance = 1.3f;   // 2026-10-25, segunda tanda en el Quest 3: a 1,6 m el HUD se veía lejos y chico

        [SerializeField, Min(0.3f)] private float distance = DefaultDistance;
        [Tooltip("Metros por debajo de la altura de los ojos (positivo = más abajo).")]
        [SerializeField] private float drop = DefaultDrop;
        [Tooltip("Metros de ancho del canvas en el mundo (1920 px de referencia).")]
        [SerializeField, Min(0.2f)] private float worldWidth = DefaultWorldWidth;
        [SerializeField, Min(0.1f)] private float followSeconds = 0.35f;

        private Canvas _canvas;
        private bool _inWorld;
        private Vector3 _velocity;

        public bool IsInWorld => _inWorld;

        private void Awake()
        {
            _canvas = GetComponent<Canvas>();
        }

        private void Start()
        {
            if (!PlatformDetector.IsFlat) PlaceInWorld();
        }

        /// <summary>Pasa el canvas al mundo. Público para probarlo sin visor.</summary>
        public void PlaceInWorld()
        {
            if (_canvas == null) _canvas = GetComponent<Canvas>();
            _canvas.renderMode = RenderMode.WorldSpace;
            var rect = _canvas.GetComponent<RectTransform>();
            if (rect.sizeDelta.x < 1f) rect.sizeDelta = new Vector2(1920f, 1080f);
            float scale = worldWidth / rect.sizeDelta.x;
            rect.localScale = Vector3.one * scale;
            _inWorld = true;
            var cam = Camera.main;
            if (cam != null) Follow(cam, instant: true);
        }

        private void LateUpdate()
        {
            if (!_inWorld) return;
            var cam = Camera.main;
            if (cam != null) Follow(cam, instant: false);
        }

        private void Follow(Camera cam, bool instant)
        {
            var forward = Vector3.ProjectOnPlane(cam.transform.forward, Vector3.up);
            if (forward.sqrMagnitude < 1e-4f) forward = transform.forward;
            forward.Normalize();
            var target = cam.transform.position + forward * distance + Vector3.down * drop;
            transform.position = instant ? target : Vector3.SmoothDamp(transform.position, target, ref _velocity, followSeconds);
            transform.rotation = Quaternion.LookRotation(forward, Vector3.up);   // un canvas se lee mirando hacia +Z
        }
    }
}
