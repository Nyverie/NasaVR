using UnityEngine;

namespace XRLabs.Platform
{
    public enum FlatPanelMode
    {
        /// <summary>Se acopla a un slot del dock izquierdo (layout tablet/PC).</summary>
        DockTop,
        DockMiddle,
        DockBottom,
        /// <summary>Pantalla completa sobre la cámara (sin dock — ej: pantalla de resultados).</summary>
        ScreenSpaceFull,
        /// <summary>Se queda en el mundo 3D (labels sobre el modelo, billboards).</summary>
        KeepWorldSpace
    }

    /// <summary>
    /// Adapta un Canvas WorldSpace (diseñado para VR) al modo plano.
    /// Por defecto lo acopla al dock izquierdo de FlatScreenLayout — la UI queda
    /// a la izquierda y la interacción 3D a la derecha. En VR no hace nada.
    /// </summary>
    [RequireComponent(typeof(Canvas))]
    public class CanvasPlatformAdapter : MonoBehaviour
    {
        [SerializeField] private FlatPanelMode flatMode = FlatPanelMode.DockMiddle;

        [Tooltip("Solo para ScreenSpaceFull: distancia del plano del canvas a la cámara")]
        [SerializeField] private float planeDistance = 1f;

        private void Start()
        {
            if (!PlatformDetector.IsFlat || flatMode == FlatPanelMode.KeepWorldSpace)
                return;

            var canvas = GetComponent<Canvas>();

            switch (flatMode)
            {
                case FlatPanelMode.DockTop:
                case FlatPanelMode.DockMiddle:
                case FlatPanelMode.DockBottom:
                    if (FlatScreenLayout.Instance != null)
                    {
                        var slot = flatMode switch
                        {
                            FlatPanelMode.DockTop => DockSlot.Top,
                            FlatPanelMode.DockBottom => DockSlot.Bottom,
                            _ => DockSlot.Middle
                        };
                        FlatScreenLayout.Instance.Dock(canvas, slot);
                    }
                    else
                    {
                        ConvertToScreenSpace(canvas); // fallback sin layout
                    }
                    break;

                case FlatPanelMode.ScreenSpaceFull:
                    ConvertToScreenSpace(canvas);
                    break;
            }
        }

        private void ConvertToScreenSpace(Canvas canvas)
        {
            var cam = Camera.main;
            if (cam == null) return;

            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvas.worldCamera = cam;
            canvas.planeDistance = planeDistance;
        }
    }
}
