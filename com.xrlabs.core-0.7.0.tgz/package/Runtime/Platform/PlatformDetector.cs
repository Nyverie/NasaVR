using UnityEngine.XR;

namespace XRLabs.Platform
{
    public enum TargetPlatform
    {
        QuestVR,
        FlatDesktop,
        FlatTablet,
        AndroidXR
    }

    /// <summary>
    /// Decide en qué modo corre la app. Prioridad:
    /// 1. Define de build XRLABS_FLAT (builds flat dedicadas — recomendado en producción)
    /// 2. Runtime: si no hay device XR activo → flat (desktop o tablet según plataforma)
    /// </summary>
    public static class PlatformDetector
    {
        public static TargetPlatform Current
        {
            get
            {
#if XRLABS_FLAT
                return IsHandheld() ? TargetPlatform.FlatTablet : TargetPlatform.FlatDesktop;
#else
                if (XRSettings.isDeviceActive)
                {
#if XRLABS_ANDROIDXR
                    return TargetPlatform.AndroidXR; // define del paquete com.unity.xr.androidxr-openxr
#else
                    return TargetPlatform.QuestVR;
#endif
                }

                return IsHandheld() ? TargetPlatform.FlatTablet : TargetPlatform.FlatDesktop;
#endif
            }
        }

        public static bool IsFlat =>
            Current == TargetPlatform.FlatDesktop || Current == TargetPlatform.FlatTablet;

        private static bool IsHandheld() =>
            UnityEngine.SystemInfo.deviceType == UnityEngine.DeviceType.Handheld;
    }
}
