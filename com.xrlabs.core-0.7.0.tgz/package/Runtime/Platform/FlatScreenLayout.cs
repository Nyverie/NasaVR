using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Platform
{
    public enum DockSlot { Top, Middle, Bottom }

    /// <summary>
    /// Layout de pantalla del modo plano (tablet/PC): dock de UI a la izquierda,
    /// viewport 3D a la derecha. El Camera.rect recorta el render 3D a la franja
    /// derecha; los CanvasPlatformAdapter registran sus paneles en los slots del dock.
    /// Colocar en la raíz del rig flat.
    /// </summary>
    [DefaultExecutionOrder(-50)]
    public class FlatScreenLayout : MonoBehaviour
    {
        public static FlatScreenLayout Instance { get; private set; }

        [Header("Reparto de pantalla")]
        [Range(0.2f, 0.6f)]
        [Tooltip("Fracción del ancho reservada al dock de UI (izquierda)")]
        [SerializeField] private float dockWidthFraction = 0.35f;

        [SerializeField] private Camera worldCamera;
        [SerializeField] private Color dockBackground = new(0.05f, 0.09f, 0.13f, 1f);

        [Header("Slots (fracciones verticales del dock)")]
        [SerializeField] private Vector2 topSlot = new(0.64f, 0.99f);
        [SerializeField] private Vector2 middleSlot = new(0.26f, 0.62f);
        [SerializeField] private Vector2 bottomSlot = new(0.01f, 0.24f);

        private readonly RectTransform[] _slots = new RectTransform[3];

        private void Awake()
        {
            if (!PlatformDetector.IsFlat)
            {
                enabled = false;
                return;
            }

            Instance = this;

            if (worldCamera == null) worldCamera = GetComponentInChildren<Camera>(true);
            if (worldCamera != null)
                worldCamera.rect = new Rect(dockWidthFraction, 0f, 1f - dockWidthFraction, 1f);

            BuildDock();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        /// <summary>
        /// Re-parenta el canvas de un panel VR dentro de un slot del dock, escalado
        /// para caber. El panel conserva su layout interno y su lógica de show/hide.
        /// </summary>
        public void Dock(Canvas panelCanvas, DockSlot slot, bool scaleToFit = true)
        {
            if (panelCanvas == null) return;

            var target = _slots[(int)slot];
            var rt = panelCanvas.GetComponent<RectTransform>();

            rt.SetParent(target, false);
            Canvas.ForceUpdateCanvases();

            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition3D = Vector3.zero;
            rt.localRotation = Quaternion.identity;

            if (scaleToFit)
            {
                Vector2 size = rt.rect.size;
                if (size.x > 0.0001f && size.y > 0.0001f)
                {
                    float scale = Mathf.Min(target.rect.width / size.x, target.rect.height / size.y);
                    rt.localScale = Vector3.one * scale;
                }
            }
        }

        private void BuildDock()
        {
            var canvasGO = new GameObject("FlatDock",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGO.transform.SetParent(transform, false);

            var canvas = canvasGO.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;

            var scaler = canvasGO.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 1f; // match height: el dock mantiene proporción en tablets

            // Panel del dock (franja izquierda con fondo)
            var dock = new GameObject("Dock", typeof(RectTransform), typeof(Image));
            dock.transform.SetParent(canvasGO.transform, false);
            var dockRT = (RectTransform)dock.transform;
            dockRT.anchorMin = Vector2.zero;
            dockRT.anchorMax = new Vector2(dockWidthFraction, 1f);
            dockRT.offsetMin = dockRT.offsetMax = Vector2.zero;
            dock.GetComponent<Image>().color = dockBackground;

            _slots[(int)DockSlot.Top] = CreateSlot(dockRT, "Slot_Top", topSlot);
            _slots[(int)DockSlot.Middle] = CreateSlot(dockRT, "Slot_Middle", middleSlot);
            _slots[(int)DockSlot.Bottom] = CreateSlot(dockRT, "Slot_Bottom", bottomSlot);
        }

        private static RectTransform CreateSlot(RectTransform dock, string name, Vector2 verticalRange)
        {
            var slot = new GameObject(name, typeof(RectTransform));
            slot.transform.SetParent(dock, false);
            var rt = (RectTransform)slot.transform;
            rt.anchorMin = new Vector2(0.03f, verticalRange.x);
            rt.anchorMax = new Vector2(0.97f, verticalRange.y);
            rt.offsetMin = rt.offsetMax = Vector2.zero;
            return rt;
        }
    }
}
