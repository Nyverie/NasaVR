using UnityEngine;
using XRLabs.Core.Diagnostics;

namespace XRLabs.Platform
{
    /// <summary>
    /// Activa el rig correcto según la plataforma detectada. Colocar en la raíz de cada
    /// escena jugable con ambos rigs desactivados como hijos/referencias:
    /// - xrRigRoot: XR Origin completo (VR)
    /// - flatRigRoot: cámara con OrbitCameraController + FlatInteractionDriver
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class PlatformBootstrapper : MonoBehaviour
    {
        [SerializeField] private GameObject xrRigRoot;
        [SerializeField] private GameObject flatRigRoot;

        private void Awake()
        {
            bool flat = PlatformDetector.IsFlat;

            if (xrRigRoot != null) xrRigRoot.SetActive(!flat);
            if (flatRigRoot != null) flatRigRoot.SetActive(flat);

            if (flat && flatRigRoot == null)
                Log.Error("[Platform] Modo flat detectado pero no hay flatRigRoot asignado.");

            Log.Info($"[Platform] Modo: {PlatformDetector.Current}");
        }
    }
}
