using UnityEngine;

namespace XRLabs.Platform
{
    /// <summary>
    /// Aplica Fixed Foveated Rendering al iniciar la app.
    /// Requiere MetaXRFoveationFeature habilitado en OpenXR Settings (Android) — ya lo está.
    /// Colocar en el GameObject raíz de managers de la escena Menu (persiste vía plugin,
    /// no necesita DontDestroyOnLoad: el nivel FFR se mantiene entre escenas).
    /// </summary>
    public class FoveatedRenderingBootstrap : MonoBehaviour
    {
        // META_XR_SDK lo define el asmdef (versionDefines) solo si el proyecto
        // consumidor tiene com.meta.xr.sdk.core — el paquete no lo exige.
#if META_XR_SDK
        [Tooltip("Nivel de foveation fija. High reduce bastante el fill-rate periférico con impacto visual mínimo en Quest 3.")]
        [SerializeField] private OVRManager.FoveatedRenderingLevel level = OVRManager.FoveatedRenderingLevel.High;

        [Tooltip("Si está activo, el runtime baja el nivel automáticamente cuando la GPU tiene margen.")]
        [SerializeField] private bool useDynamicFoveation = true;

        private void Start()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            OVRManager.foveatedRenderingLevel = level;
            OVRManager.useDynamicFoveatedRendering = useDynamicFoveation;
            Debug.Log($"[FFR] Foveated rendering aplicado: level={level}, dynamic={useDynamicFoveation}");
#endif
        }
#else
        private void Start()
        {
            Debug.LogWarning("[FFR] Meta XR SDK no está en el proyecto — foveated rendering no aplicado.");
        }
#endif
    }
}
