using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Readers;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Turning;

namespace XRLabs.MenuXRI
{
    /// <summary>
    /// Seguro del giro por pasos (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md §1). En el Quest 3 el dueño dijo:
    /// «uso el mando para agarrar un objeto y al moverlo ligeramente ya estoy girando yo también». El agarre (gatillo lateral)
    /// y el giro (stick) viven en el mismo mando derecho, y además con un agarre lejano el stick empuja y acerca el objeto
    /// (acción <c>Manipulation</c> del <c>InteractionAttachController</c>): el mismo gesto giraba a la persona.
    ///
    /// XRI 3.3.1 no lo impide por sí solo: el <c>SnapTurnProvider</c> lee el stick sin mirar el estado de los interactores y
    /// el <c>LocomotionMediator</c> solo ordena proveedores; la muestra Starter Assets lo resuelve deshabilitando las acciones
    /// de locomoción mientras el rayo selecciona (<c>ControllerInputActionManager</c>). Aquí se hace lo mismo con tres guardas,
    /// sin tocar la acción compartida: mientras un interactor de la mano del giro tiene algo seleccionado, el proveedor lee
    /// cero; al soltar, el giro queda bloqueado hasta que el stick vuelve al centro (<see cref="RearmMagnitude"/>), para que
    /// el stick inclinado al soltar no gire de golpe; y fuera de eso el stick tiene que pasar de <see cref="TurnMagnitude"/>
    /// (0,75 según el informe de UX del 2026-10-31; la zona muerta de la acción es 0,5, la del <c>SectorInteraction</c> de XRI), así que un roce no gira.
    ///
    /// Corre antes que el proveedor (<c>DefaultExecutionOrder</c> por debajo de <c>k_LocomotionProviders</c>, −210, y ya en
    /// <c>OnEnable</c>: el test PlayMode encontró que con el orden −200 el proveedor giraba en el primer cuadro) y, cuando bloquea, pone la entrada derecha del proveedor
    /// en valor manual cero; cuando deja pasar, le devuelve su modo de antes. Lo agrega <c>XriRigBuilder</c> en la raíz del rig.
    /// </summary>
    [AddComponentMenu("XRLabs/Snap Turn Grab Guard")]
    [DefaultExecutionOrder(XRInteractionUpdateOrder.k_LocomotionProviders - 10)]   // antes que los proveedores (-210)
    [DisallowMultipleComponent]
    public class SnapTurnGrabGuard : MonoBehaviour
    {
        /// <summary>Magnitud del stick a partir de la cual gira (antes, la zona muerta de 0,5 de la acción).</summary>
        public const float DefaultTurnMagnitude = 0.75f;

        /// <summary>Magnitud por debajo de la cual el stick cuenta como «de vuelta al centro» tras un agarre.</summary>
        public const float DefaultRearmMagnitude = 0.25f;

        [SerializeField, Tooltip("El proveedor de giro por pasos que se guarda.")]
        private SnapTurnProvider snapTurn;

        [SerializeField, Tooltip("Los interactores de la mano del giro: mientras alguno tiene algo seleccionado, no se gira.")]
        private XRBaseInteractor[] handInteractors = new XRBaseInteractor[0];

        [SerializeField, Tooltip("El stick crudo de la mano del giro (XRI Right/Thumbstick), sin zona muerta.")]
        private XRInputValueReader<Vector2> stickInput = new XRInputValueReader<Vector2>("Right Thumbstick");

        [SerializeField, Range(0.5f, 0.95f)] private float turnMagnitude = DefaultTurnMagnitude;
        [SerializeField, Range(0.05f, 0.5f)] private float rearmMagnitude = DefaultRearmMagnitude;

        private bool _blocked;
        private bool _armed = true;
        private XRInputValueReader.InputSourceMode _savedMode;
        private Vector2 _savedManual;

        public SnapTurnProvider SnapTurn { get => snapTurn; set => snapTurn = value; }
        public XRBaseInteractor[] HandInteractors { get => handInteractors; set => handInteractors = value ?? new XRBaseInteractor[0]; }
        public XRInputValueReader<Vector2> StickInput { get => stickInput; set => stickInput = value; }
        public float TurnMagnitude { get => turnMagnitude; set => turnMagnitude = value; }
        public float RearmMagnitude { get => rearmMagnitude; set => rearmMagnitude = value; }

        /// <summary>Si en este cuadro el giro está bloqueado (agarre, sin volver al centro o stick bajo el umbral).</summary>
        public bool Blocked => _blocked;

        /// <summary>Si la mano del giro tiene algo seleccionado.</summary>
        public bool Holding
        {
            get
            {
                if (handInteractors == null) return false;
                foreach (var interactor in handInteractors)
                    if (interactor != null && interactor.isActiveAndEnabled && interactor.hasSelection) return true;
                return false;
            }
        }

        private void OnEnable()
        {
            stickInput?.EnableDirectActionIfModeUsed();
            Evaluate();   // desde el primer cuadro: el proveedor nunca lee el stick sin guarda
        }

        private void OnDisable()
        {
            stickInput?.DisableDirectActionIfModeUsed();
            SetBlocked(false);
        }

        private void Update() => Evaluate();

        private void Evaluate()
        {
            if (snapTurn == null) return;
            float magnitude = stickInput != null ? stickInput.ReadValue().magnitude : 0f;

            bool holding = Holding;
            if (holding) _armed = false;
            else if (!_armed && magnitude < rearmMagnitude) _armed = true;

            SetBlocked(holding || !_armed || magnitude < turnMagnitude);
        }

        private void SetBlocked(bool blocked)
        {
            if (snapTurn == null || blocked == _blocked) return;
            var input = snapTurn.rightHandTurnInput;
            if (input == null) { _blocked = blocked; return; }
            if (blocked)
            {
                _savedMode = input.inputSourceMode;
                _savedManual = input.manualValue;
                input.inputSourceMode = XRInputValueReader.InputSourceMode.ManualValue;
                input.manualValue = Vector2.zero;
            }
            else
            {
                input.inputSourceMode = _savedMode;
                input.manualValue = _savedManual;
            }
            _blocked = blocked;
        }
    }
}
