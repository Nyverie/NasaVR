using System.Collections.Generic;
using Unity.XR.CoreUtils;
using UnityEngine;
using UnityEngine.XR;

namespace XRLabs.MenuXRI
{
    /// <summary>
    /// Orienta el rig XRI hacia el rumbo del inicio en el casco (cuarto recorrido del visor, 2026-10-25 23:50: «todas las
    /// experiencias me aparecen detrás mío»). La escena preparada coloca la raíz del rig en el <c>inicio</c> de la colocación
    /// con su <c>giro</c>, pero en el visor la cámara trae el rumbo físico de la persona dentro de su espacio de seguimiento:
    /// si la persona está mirando hacia otro lado de su sala, la escena queda girada y lo importante queda a su espalda.
    ///
    /// En el primer cuadro con la cabeza seguida (dos cuadros después, para que el <c>TrackedPoseDriver</c> ya haya movido la
    /// cámara) gira el <c>XROrigin</c> alrededor de la cámara para que el rumbo de la cámara (su forward en el plano del suelo)
    /// sea el rumbo con que la raíz del rig quedó en la escena, y lo desplaza para que la cámara quede sobre el punto del
    /// inicio, a la altura que traiga. Lo repite cuando el usuario recentra (<c>XRInputSubsystem.trackingOriginUpdated</c>,
    /// el recentrado del sistema en el Quest): entonces conserva el punto donde estaba la persona, no la devuelve al inicio.
    /// Corre en el Menu XRI y en cada experiencia, porque va en la raíz del prefab del rig. En modo pantalla el rig está
    /// apagado (<c>PlatformBootstrapper</c>) y este componente no corre. Lo agrega <c>XriRigBuilder</c>.
    ///
    /// UX visor 2026-10-31 (Documentation~/decisiones-ux-visor.md §2): en el registro del Quest 3 el rig se reorientaba cada
    /// vez que el casco recuperaba el foco (giros de +49°, −52°, 3°, −6° en segundos), porque el runtime avisa un cambio de
    /// origen alrededor del cambio de foco (menú del sistema, quitarse y ponerse el casco). Ahora solo alinea en el primer
    /// cuadro seguido de cada escena y en un recentrado explícito: el aviso de <c>trackingOriginUpdated</c> que llega sin
    /// foco o dentro de <see cref="FocusGuardSeconds"/> después de recuperarlo se ignora y se cuenta en
    /// <see cref="IgnoredOriginUpdates"/>.
    /// </summary>
    [AddComponentMenu("XRLabs/Rig Heading Aligner")]
    [DisallowMultipleComponent]
    public class RigHeadingAligner : MonoBehaviour
    {
        /// <summary>Cuadros con la cabeza seguida antes de alinear (el primero puede traer la pose de antes).</summary>
        public const int TrackedFramesBeforeAlign = 2;

        /// <summary>
        /// Si espera a que la cabeza del visor esté seguida. Los tests lo apagan para alinear con una cámara simulada.
        /// </summary>
        public bool RequireHeadTracking { get; set; } = true;

        /// <summary>Cuántas veces se alineó desde que el componente despertó (para el registro y los tests).</summary>
        public int Alignments { get; private set; }

        /// <summary>El rumbo del inicio: el forward de la raíz del rig en el plano del suelo, tal como quedó en la escena.</summary>
        public Vector3 StartForward { get; private set; }

        /// <summary>El punto del inicio, a los pies.</summary>
        public Vector3 StartPosition { get; private set; }

        // UX visor 2026-10-31
        /// <summary>Segundos tras recuperar el foco en que un aviso de cambio de origen se toma como parte del cambio de foco.</summary>
        public const float DefaultFocusGuardSeconds = 2f;

        /// <summary>Ventana tras recuperar el foco en que no se realinea (ver la nota de la clase).</summary>
        public float FocusGuardSeconds { get; set; } = DefaultFocusGuardSeconds;

        /// <summary>El reloj de la ventana de foco (tiempo sin escala); los tests lo sustituyen.</summary>
        public System.Func<float> Clock { get; set; } = () => Time.unscaledTime;

        /// <summary>Avisos de cambio de origen ignorados por llegar con el cambio de foco.</summary>
        public int IgnoredOriginUpdates { get; private set; }

        /// <summary>Si la aplicación tiene el foco ahora (según el último <c>OnApplicationFocus</c>).</summary>
        public bool HasFocus => _focused;

        private bool _focused = true;
        private float _focusRegainedAt = float.NegativeInfinity;
        // fin UX visor 2026-10-31

        private static readonly List<XRInputSubsystem> Subsystems = new List<XRInputSubsystem>();
        private readonly List<XRInputSubsystem> _subscribed = new List<XRInputSubsystem>();

        private XROrigin _origin;
        private bool _pending = true;
        private int _trackedFrames;
        private Vector3 _anchor;        // el punto del suelo sobre el que debe quedar la cámara al alinear
        private Vector3 _lastCamera;    // dónde estaba la cámara en el último cuadro alineado (para el recentrado)
        private bool _hasLastCamera;

        private void Awake()
        {
            _origin = GetComponent<XROrigin>();
            StartPosition = transform.position;
            var forward = Vector3.ProjectOnPlane(transform.forward, transform.up);
            StartForward = forward.sqrMagnitude > 1e-6f ? forward.normalized : Vector3.forward;
            _anchor = StartPosition;
        }

        private void OnEnable()
        {
            _pending = true;
            _trackedFrames = 0;
            Subscribe();
        }

        private void OnDisable()
        {
            foreach (var subsystem in _subscribed)
                if (subsystem != null) subsystem.trackingOriginUpdated -= OnTrackingOriginUpdated;
            _subscribed.Clear();
        }

        private void LateUpdate()
        {
            if (_subscribed.Count == 0) Subscribe();   // el subsistema puede arrancar después que la escena
            if (_origin == null || _origin.Camera == null) return;

            if (!_pending)
            {
                _lastCamera = _origin.Camera.transform.position;
                _hasLastCamera = true;
                return;
            }

            if (RequireHeadTracking && !HeadTracked()) { _trackedFrames = 0; return; }
            if (++_trackedFrames < TrackedFramesBeforeAlign) return;
            if (Align()) _pending = false;
        }

        /// <summary>
        /// Gira el origen alrededor de la cámara hasta que su rumbo coincide con <see cref="StartForward"/> y lo desplaza para
        /// que la cámara quede sobre el punto de anclaje. Devuelve false si no hay cámara.
        /// </summary>
        public bool Align()
        {
            if (_origin == null) _origin = GetComponent<XROrigin>();
            if (_origin == null || _origin.Camera == null) return false;

            var camera = _origin.Camera.transform;
            var up = transform.up;
            var heading = Vector3.ProjectOnPlane(camera.forward, up);
            // Mirando al suelo el forward no da rumbo: la parte de arriba de la vista apunta hacia delante.
            if (heading.sqrMagnitude < 1e-4f) heading = Vector3.ProjectOnPlane(camera.up, up);
            if (heading.sqrMagnitude < 1e-6f) return false;

            float angle = Vector3.SignedAngle(heading, StartForward, up);
            _origin.RotateAroundCameraUsingOriginUp(angle);

            var target = _anchor + Vector3.Project(camera.position - _anchor, up);
            _origin.MoveCameraToWorldLocation(target);

            Alignments++;
            Debug.Log("[MenuXRI] " + name + ": rig orientado al rumbo del inicio (giro de " + angle.ToString("0") + "°).", this);
            return true;
        }

        private void OnTrackingOriginUpdated(XRInputSubsystem subsystem) => NotifyTrackingOriginUpdated();

        // UX visor 2026-10-31
        private void OnApplicationFocus(bool hasFocus) => NotifyFocusChanged(hasFocus);

        /// <summary>El foco de la aplicación cambió (lo llama <c>OnApplicationFocus</c>; los tests, a mano).</summary>
        public void NotifyFocusChanged(bool hasFocus)
        {
            if (hasFocus && !_focused) _focusRegainedAt = Clock();
            _focused = hasFocus;
        }

        /// <summary>
        /// El runtime avisó un cambio del origen de seguimiento. Es un recentrado (se realinea) salvo que llegue sin foco o
        /// dentro de <see cref="FocusGuardSeconds"/> tras recuperarlo: entonces es parte del cambio de foco y se ignora.
        /// Devuelve si lo tomó como recentrado.
        /// </summary>
        public bool NotifyTrackingOriginUpdated()
        {
            if (!_focused || Clock() - _focusRegainedAt < FocusGuardSeconds)
            {
                IgnoredOriginUpdates++;
                Debug.Log("[MenuXRI] " + name + ": aviso de cambio de origen con el cambio de foco; no se reorienta.", this);
                return false;
            }
            Recenter();
            return true;
        }

        /// <summary>Recentrado explícito: el rumbo vuelve al del inicio en el próximo cuadro seguido y la persona se queda donde estaba.</summary>
        public void Recenter()
        {
            if (_hasLastCamera) _anchor = _lastCamera;
            _pending = true;
            _trackedFrames = 0;
        }

        private void Subscribe()
        {
            Subsystems.Clear();
            SubsystemManager.GetSubsystems(Subsystems);
            foreach (var subsystem in Subsystems)
            {
                if (_subscribed.Contains(subsystem)) continue;
                subsystem.trackingOriginUpdated += OnTrackingOriginUpdated;
                _subscribed.Add(subsystem);
            }
        }

        private static bool HeadTracked()
        {
            var head = InputDevices.GetDeviceAtXRNode(XRNode.Head);
            return head.isValid && head.TryGetFeatureValue(CommonUsages.isTracked, out bool tracked) && tracked;
        }
    }
}
