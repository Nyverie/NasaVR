using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Inputs;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace XRLabs.MenuXRI
{
    /// <summary>
    /// Seguro del rig XRI ante el cambio de escena (auditoría del visor del 2026-10-18, punto 8 y corrección 6; 2026-10-25).
    /// El Menu XRI y cada experiencia preparada llevan su propia instancia del rig, y las dos comparten el mismo
    /// <c>.inputactions</c>. Si al pasar del Menu a la experiencia (o al volver) la escena vieja se descarga DESPUÉS de que el
    /// rig nuevo se encienda, tres cosas del rig nuevo quedan colgando de lo que se destruye:
    /// <list type="bullet">
    /// <item>el <c>InputActionManager</c> del rig viejo apaga el asset entero en su <c>OnDisable</c> (no lleva la cuenta de
    /// quién más lo usa): cabeza y mandos congelados, sin selección ni clic;</item>
    /// <item>el <c>NearFarInteractor</c> se registró en el <c>XRUIInputModule</c> del EventSystem viejo
    /// (<c>EventSystem.current</c> todavía era ese): el rayo deja de tocar la UI;</item>
    /// <item>los interactuables de la escena que se encendieron mientras el <c>XRInteractionManager</c> viejo vivía se
    /// registraron en él: el rayo no los ve.</item>
    /// </list>
    /// Con una carga Single, la de <c>SceneTransitionManager</c>, eso no pasa: medido en 6000.3.14f1 (<c>LoadScene</c>,
    /// <c>LoadSceneAsync</c> y <c>LoadSceneInPlayMode</c>), la escena vieja hace <c>OnDisable</c> y <c>OnDestroy</c> antes del
    /// <c>Awake</c> de la nueva. Este componente es el seguro para lo demás (una escena aditiva, otro flujo de carga).
    ///
    /// Al arrancar (<c>Start</c>) y cada vez que se descarga una escena (<c>SceneManager.sceneUnloaded</c>, que llega
    /// después de los <c>OnDisable</c> de esa escena), vuelve a encender las acciones de los <c>InputActionManager</c> del
    /// rig, vuelve a registrar en el EventSystem que queda los interactores del rig que perdieron su módulo de UI, y enlaza al
    /// gestor del rig los interactuables activos cuyo gestor ya no existe. Todo es idempotente: si nada quedó colgando, no
    /// cambia nada. No crea EventSystem ni gestores: usa los que hay (el del <c>[HUD]</c> en la experiencia, el <c>PCM</c> en
    /// el Menu, el <c>XRInteractionManager</c> de la raíz del rig). Lo agrega <c>XriRigBuilder</c> en la raíz del rig, junto al
    /// <c>InputActionManager</c>.
    ///
    /// Lo que no repara: XRI busca el <c>XROrigin</c> con un buscador global para colgar las anclas del agarre y el origen
    /// estabilizado del rayo. Dos rigs vivos a la vez no están soportados: el nuevo colgaría esas anclas del viejo.
    /// </summary>
    [AddComponentMenu("XRLabs/Rig Scene Guard")]
    [DisallowMultipleComponent]
    public class RigSceneGuard : MonoBehaviour
    {
        /// <summary>Cuántas veces se repuso algo desde que el componente se encendió (para el registro y los tests).</summary>
        public int Repairs { get; private set; }

        private void OnEnable() => SceneManager.sceneUnloaded += OnSceneUnloaded;

        private void OnDisable() => SceneManager.sceneUnloaded -= OnSceneUnloaded;

        private void Start() => Report(Refresh(), "al arrancar");

        private void OnSceneUnloaded(Scene scene) => Report(Refresh(), "tras descargar '" + scene.name + "'");

        /// <summary>
        /// Repone lo que el cambio de escena pudo dejar colgando: acciones, registro de UI y gestor de interacción. Devuelve
        /// cuántas piezas tuvo que reponer (0 si todo estaba bien).
        /// </summary>
        public int Refresh()
        {
            if (!isActiveAndEnabled) return 0;
            int repaired = EnableActions() + ReregisterUi() + RebindOrphanedInteractables();
            Repairs += repaired;
            return repaired;
        }

        // Una línea en el registro (logcat en el visor) solo si hubo que reponer algo: es la prueba del punto 8 en el casco.
        private void Report(int repaired, string when)
        {
            if (repaired > 0)
                Debug.Log("[MenuXRI] " + name + ": se repusieron " + repaired + " pieza(s) de entrada " + when +
                          " (acciones, UI o gestor de interacción).", this);
        }

        // Las acciones de los InputActionManager del rig (encender un mapa ya encendido no hace nada). Solo los que están
        // encendidos: uno apagado a propósito se respeta.
        private int EnableActions()
        {
            int repaired = 0;
            foreach (var manager in GetComponentsInChildren<InputActionManager>())
            {
                if (!manager.isActiveAndEnabled || manager.actionAssets == null) continue;
                foreach (var asset in manager.actionAssets)
                {
                    if (asset == null) continue;
                    foreach (var map in asset.actionMaps)
                        if (!map.enabled) { repaired++; break; }
                }
                manager.EnableInput();
            }
            return repaired;
        }

        // Un interactor con la UI encendida que ya no tiene modelo de UI perdió su XRUIInputModule (era del EventSystem que se
        // descargó). Apagar y encender enableUIInteraction lo registra de nuevo: XRI busca entonces EventSystem.current.
        private int ReregisterUi()
        {
            int repaired = 0;
            foreach (var interactor in GetComponentsInChildren<NearFarInteractor>())
            {
                if (!interactor.isActiveAndEnabled || !interactor.enableUIInteraction) continue;
                if (interactor.TryGetUIModel(out _)) continue;
                interactor.enableUIInteraction = false;
                interactor.enableUIInteraction = true;
                repaired++;
            }
            return repaired;
        }

        // Un interactuable activo cuyo gestor es una referencia destruida quedó registrado en el gestor de la escena que se
        // descargó. Se enlaza al gestor del rig (el setter lo registra). Los que tienen un gestor vivo no se tocan.
        private int RebindOrphanedInteractables()
        {
            var manager = GetComponentInChildren<XRInteractionManager>();
            if (manager == null) return 0;

            int repaired = 0;
            var interactables = FindObjectsByType<XRBaseInteractable>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
            foreach (var interactable in interactables)
            {
                if (!interactable.isActiveAndEnabled || interactable.interactionManager != null) continue;
                interactable.interactionManager = manager;
                repaired++;
            }
            return repaired;
        }
    }
}
