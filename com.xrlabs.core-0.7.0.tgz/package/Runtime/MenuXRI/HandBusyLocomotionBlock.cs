using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace XRLabs.MenuXRI
{
    /// <summary>
    /// Mano ocupada, stick inerte (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md §1): mientras un interactor de
    /// esta mano tiene algo seleccionado, se apagan los componentes de locomoción de la misma mano (el
    /// <c>TeleportModeActivator</c>, que al apagarse esconde el arco), y se vuelven a encender al soltar. Es el patrón de
    /// <c>ControllerInputActionManager</c> de la muestra Starter Assets de XRI, extendido al agarre cercano. El giro lo
    /// guarda <see cref="SnapTurnGrabGuard"/>, porque el proveedor de giro es uno solo para las dos manos. Lo agrega
    /// <c>XriRigBuilder</c> en cada mando.
    /// </summary>
    [AddComponentMenu("XRLabs/Hand Busy Locomotion Block")]
    [DefaultExecutionOrder(XRInteractionUpdateOrder.k_LocomotionProviders - 10)]
    public class HandBusyLocomotionBlock : MonoBehaviour
    {
        [SerializeField] private XRBaseInteractor[] interactors = new XRBaseInteractor[0];
        [SerializeField] private Behaviour[] blockWhileBusy = new Behaviour[0];

        private bool _busy;

        public XRBaseInteractor[] Interactors { get => interactors; set => interactors = value ?? new XRBaseInteractor[0]; }
        public Behaviour[] BlockWhileBusy { get => blockWhileBusy; set => blockWhileBusy = value ?? new Behaviour[0]; }

        /// <summary>Si la mano tiene algo seleccionado en este cuadro.</summary>
        public bool Busy => _busy;

        private void Update()
        {
            bool busy = false;
            foreach (var interactor in interactors)
                if (interactor != null && interactor.isActiveAndEnabled && interactor.hasSelection) { busy = true; break; }
            if (busy == _busy) return;
            _busy = busy;
            foreach (var behaviour in blockWhileBusy)
                if (behaviour != null) behaviour.enabled = !busy;
        }

        private void OnDisable()
        {
            if (!_busy) return;
            _busy = false;
            foreach (var behaviour in blockWhileBusy)
                if (behaviour != null) behaviour.enabled = true;
        }
    }
}
