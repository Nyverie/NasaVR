using UnityEngine;
using UnityEngine.InputSystem;

namespace XRLabs.MenuXRI
{
    /// <summary>
    /// Enciende el interactor de teleportación de una mano solo mientras se mantiene la acción «Teleport Mode» y lo apaga al
    /// soltarla o al pulsar «Teleport Mode Cancel» (lote X2, 2026-10-10; Documentation~/menu-xri.md §9). Es la lógica de
    /// <c>OnStartTeleport</c> / <c>OnCancelTeleport</c> de <c>ControllerInputActionManager</c>, el script de la muestra Starter
    /// Assets de XRI 3.3.1; está copiada aquí porque un paquete no puede referenciar scripts de <c>Samples~</c>.
    ///
    /// El apagado al soltar se aplaza al <c>Update</c> siguiente, como en la muestra: la <c>TeleportationArea</c> teleporta al
    /// terminar la selección, y esa selección la procesa el <c>XRInteractionManager</c> (que corre antes que este componente,
    /// con el orden de ejecución por defecto) en el mismo cuadro; apagar el objeto en el callback de la acción la cancelaría y
    /// no habría teleportación.
    ///
    /// Todo es opcional (D8): si falta el interactor o una acción, ese tramo no hace nada. No habilita las acciones: de eso se
    /// encarga el <c>InputActionManager</c> del rig.
    /// </summary>
    [AddComponentMenu("XRLabs/Teleport Mode Activator")]
    public class TeleportModeActivator : MonoBehaviour
    {
        [SerializeField, Tooltip("El objeto del interactor de teleportación de esta mano. Se deja desactivado hasta que se mantiene 'Teleport Mode'.")]
        private GameObject teleportInteractor;

        [SerializeField, Tooltip("La acción que, mientras se mantiene, enciende el interactor (XRI <Lado> Locomotion/Teleport Mode).")]
        private InputActionReference teleportMode;

        [SerializeField, Tooltip("La acción que cancela el modo de teleportación (XRI <Lado> Locomotion/Teleport Mode Cancel).")]
        private InputActionReference teleportModeCancel;

        private bool _postponedDeactivate;
        private InputAction _modeAction;
        private InputAction _cancelAction;

        public GameObject TeleportInteractor { get => teleportInteractor; set => teleportInteractor = value; }
        public InputActionReference TeleportMode { get => teleportMode; set => teleportMode = value; }
        public InputActionReference TeleportModeCancel { get => teleportModeCancel; set => teleportModeCancel = value; }

        private void OnEnable()
        {
            _postponedDeactivate = false;
            if (teleportInteractor != null) teleportInteractor.SetActive(false);

            _modeAction = teleportMode != null ? teleportMode.action : null;
            if (_modeAction != null)
            {
                _modeAction.performed += OnStartTeleport;
                _modeAction.canceled += OnCancelTeleport;
            }

            _cancelAction = teleportModeCancel != null ? teleportModeCancel.action : null;
            if (_cancelAction != null) _cancelAction.performed += OnCancelTeleport;
        }

        private void OnDisable()
        {
            if (_modeAction != null)
            {
                _modeAction.performed -= OnStartTeleport;
                _modeAction.canceled -= OnCancelTeleport;
                _modeAction = null;
            }
            if (_cancelAction != null)
            {
                _cancelAction.performed -= OnCancelTeleport;
                _cancelAction = null;
            }

            _postponedDeactivate = false;
            if (teleportInteractor != null) teleportInteractor.SetActive(false);
        }

        private void Update()
        {
            if (!_postponedDeactivate) return;
            _postponedDeactivate = false;
            if (teleportInteractor != null) teleportInteractor.SetActive(false);
        }

        private void OnStartTeleport(InputAction.CallbackContext context)
        {
            _postponedDeactivate = false;
            if (teleportInteractor != null) teleportInteractor.SetActive(true);
        }

        private void OnCancelTeleport(InputAction.CallbackContext context)
        {
            _postponedDeactivate = true;
        }
    }
}
