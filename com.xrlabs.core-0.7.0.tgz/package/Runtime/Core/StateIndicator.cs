using System;
using System.Collections.Generic;

namespace XRLabs.Core
{
    // 0.3 lote 4 (contrato-0.3.md §2.9): los indicadores del guion, ya resueltos por el importador, y su formato. C# puro:
    // lo usan IndicatorPanel (HUD), EvaluationFinalResultsPanel (enInforme) y los tests.

    /// <summary>Un valor de una variable de texto y la frase <c>soloTexto</c> que lo muestra.</summary>
    [Serializable]
    public class IndicatorText
    {
        public string value;
        public string lineId;
    }

    /// <summary>Un indicador: qué variable muestra, con qué etiqueta y cómo, y en qué pasos se ve.</summary>
    [Serializable]
    public class StateIndicator
    {
        public string id;
        public string variable;
        public string labelId;
        public List<IndicatorText> texts = new();
        public string unit;
        public int decimals;
        public string fromStepId;
        public string untilStepId;
        public bool inReport;

        /// <summary>La frase de un valor de texto, o null.</summary>
        public string LineFor(string value)
        {
            if (texts == null) return null;
            foreach (var t in texts)
                if (t != null && t.value == value) return t.lineId;
            return null;
        }
    }

    /// <summary>Formato y visibilidad de los indicadores. Puro: el texto de las frases llega por <c>resolve</c>.</summary>
    public static class IndicatorFormat
    {
        /// <summary>El valor que se muestra: por <c>textos</c> si es de texto, con <c>unidad</c> y <c>decimales</c> si es numérico.</summary>
        public static string Value(StateIndicator indicator, SimulationState state, Func<string, string> resolve)
        {
            if (indicator == null || state == null || !state.Has(indicator.variable)) return string.Empty;
            var def = state.GetDefinition(indicator.variable);
            if (def != null && def.isNumber)
            {
                double number = state.GetNumber(indicator.variable);
                int decimals = Math.Max(0, Math.Min(6, indicator.decimals));
                string text = number.ToString("F" + decimals, System.Globalization.CultureInfo.InvariantCulture);
                return string.IsNullOrEmpty(indicator.unit) ? text : $"{text} {indicator.unit}";
            }
            string value = state.GetText(indicator.variable);
            string line = indicator.LineFor(value);
            return string.IsNullOrEmpty(line) ? value ?? string.Empty : Resolve(line, state, resolve);
        }

        /// <summary>La etiqueta, con <c>{variable}</c> sustituido.</summary>
        public static string Label(StateIndicator indicator, SimulationState state, Func<string, string> resolve) =>
            indicator == null ? string.Empty : Resolve(indicator.labelId, state, resolve);

        /// <summary>«Etiqueta: valor».</summary>
        public static string Line(StateIndicator indicator, SimulationState state, Func<string, string> resolve)
        {
            string label = Label(indicator, state, resolve);
            string value = Value(indicator, state, resolve);
            return string.IsNullOrEmpty(label) ? value : $"{label}: {value}";
        }

        /// <summary>
        /// True si el indicador se ve en el paso <paramref name="stepIndex"/>: entre el índice de <c>desde</c> y el de
        /// <c>hasta</c> (los dos incluidos); sin ellos, siempre. Un id que no está en la secuencia no acota.
        /// </summary>
        public static bool IsVisibleAt(StateIndicator indicator, SimulationSequence sequence, int stepIndex)
        {
            if (indicator == null) return false;
            int from = IndexOf(sequence, indicator.fromStepId);
            int until = IndexOf(sequence, indicator.untilStepId);
            if (from >= 0 && stepIndex < from) return false;
            if (until >= 0 && stepIndex > until) return false;
            return true;
        }

        /// <summary>Las líneas del informe final: los indicadores con <c>enInforme</c>, con su valor final.</summary>
        public static List<string> ReportLines(SimulationSequence sequence, SimulationState state, Func<string, string> resolve)
        {
            var lines = new List<string>();
            if (sequence?.indicators == null || state == null) return lines;
            foreach (var indicator in sequence.indicators)
                if (indicator != null && indicator.inReport && state.Has(indicator.variable))
                    lines.Add(Line(indicator, state, resolve));
            return lines;
        }

        /// <summary>El texto de una frase con sus <c>{variable}</c> sustituidas; sin <c>resolve</c> o sin frase, el id.</summary>
        public static string Resolve(string lineId, SimulationState state, Func<string, string> resolve)
        {
            if (string.IsNullOrEmpty(lineId)) return string.Empty;
            string text = resolve?.Invoke(lineId);
            if (string.IsNullOrEmpty(text)) text = lineId;
            return StepSystem.ExpandVariables(text, state);
        }

        private static int IndexOf(SimulationSequence sequence, string stepId)
        {
            if (sequence?.steps == null || string.IsNullOrEmpty(stepId)) return -1;
            for (int i = 0; i < sequence.steps.Count; i++)
                if (sequence.steps[i] != null && sequence.steps[i].stepId == stepId) return i;
            return -1;
        }
    }
}
