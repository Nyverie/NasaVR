using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Repositorio central de todos los assets de audio e imagen de una simulación.
    /// Mantiene orden y evita referencias sueltas por los StepDefinition.
    /// Los StepDefinition referencian assets directamente (no por ID string).
    /// El ID sirve para lookup dinámico desde código cuando se necesita.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Asset Library")]
    public class SimulationAssetLibrary : ScriptableObject
    {
        [Serializable]
        public class NamedAudioClip
        {
            [Tooltip("Identificador único. Ej: VO-001, sfx-chime, sfx-whoosh")]
            public string id;
            public AudioClip clip;
        }

        [Serializable]
        public class NamedSprite
        {
            [Tooltip("Identificador único. Ej: IMG-001, IMG-101, IMG-202")]
            public string id;
            public Sprite sprite;
        }

        [Header("Voice Overs")]
        public List<NamedAudioClip> voClips = new();

        [Header("SFX")]
        public List<NamedAudioClip> sfxClips = new();

        [Header("Imágenes")]
        public List<NamedSprite> images = new();

        // Caches de runtime — se construyen la primera vez que se consultan
        private Dictionary<string, AudioClip> _voCache;
        private Dictionary<string, AudioClip> _sfxCache;
        private Dictionary<string, Sprite> _imgCache;

        // Invalidar caches cuando el asset se recarga en el editor
        private void OnEnable() => InvalidateCaches();
        private void OnValidate() => InvalidateCaches();

        private void InvalidateCaches()
        {
            _voCache = null;
            _sfxCache = null;
            _imgCache = null;
        }

        private void BuildCaches()
        {
            _voCache = new Dictionary<string, AudioClip>(voClips.Count);
            foreach (var e in voClips)
                if (e != null && !string.IsNullOrEmpty(e.id) && e.clip != null)
                    _voCache[e.id] = e.clip;

            _sfxCache = new Dictionary<string, AudioClip>(sfxClips.Count);
            foreach (var e in sfxClips)
                if (e != null && !string.IsNullOrEmpty(e.id) && e.clip != null)
                    _sfxCache[e.id] = e.clip;

            _imgCache = new Dictionary<string, Sprite>(images.Count);
            foreach (var e in images)
                if (e != null && !string.IsNullOrEmpty(e.id) && e.sprite != null)
                    _imgCache[e.id] = e.sprite;
        }

        /// <summary>Obtiene un clip de Voice Over por ID. Retorna null si no existe.</summary>
        public AudioClip GetVO(string id)
        {
            if (_voCache == null) BuildCaches();
            return _voCache.TryGetValue(id, out var c) ? c : null;
        }

        /// <summary>Obtiene un SFX por ID. Retorna null si no existe.</summary>
        public AudioClip GetSFX(string id)
        {
            if (_sfxCache == null) BuildCaches();
            return _sfxCache.TryGetValue(id, out var c) ? c : null;
        }

        /// <summary>Obtiene una imagen por ID. Retorna null si no existe.</summary>
        public Sprite GetImage(string id)
        {
            if (_imgCache == null) BuildCaches();
            return _imgCache.TryGetValue(id, out var s) ? s : null;
        }
    }
}
