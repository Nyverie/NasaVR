namespace XRLabs.Core
{
    // 0.3 lote 4 (contrato-0.3.md §2.5): un detalle que acompaña a cada error o aviso de una condición, en el mismo orden
    // en que los reporta. Lo usa ChoiceByTargetCondition para que step_error lleve metadata.opcion (el objeto tocado),
    // sin cambiar StepSignal ni StepCondition.

    /// <summary>Una condición que da, por cada error o aviso que reporta, la opción que lo causó.</summary>
    public interface IStepSignalDetails
    {
        /// <summary>La opción del error o aviso más antiguo sin consumir (y lo consume); null si no hay.</summary>
        string TakeSignalOption();
    }
}
