﻿using System;
using System.Collections;
using UnityEngine;

namespace XRLabs.Core
{
    public class HintSystem : MonoBehaviour
    {
        public static HintSystem Instance;

        private Coroutine _hintCoroutine;

        /// <summary>
        /// Mientras esté en true (menú o tarjeta abierta) el contador de inactividad no corre.
        /// </summary>
        public bool Paused { get; set; }

        /// <summary>Se mostró una pista para el paso dado.</summary>
        public event Action<StepDefinition> HintShown;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        public void ScheduleHint(StepDefinition step)
        {
            CancelScheduledHint();

            if (step == null)
            {
                return;
            }

            _hintCoroutine = StartCoroutine(HintRoutine(step));
        }

        public void CancelScheduledHint()
        {
            if (_hintCoroutine == null)
            {
                return;
            }

            StopCoroutine(_hintCoroutine);
            _hintCoroutine = null;
        }

        private IEnumerator HintRoutine(StepDefinition step)
        {
            float waited = 0f;
            while (waited < step.hintDelay)
            {
                if (!Paused) waited += Time.deltaTime;
                yield return null;
            }

            var vo = VOManager.Instance;
            LineRef dynamicHint = step.completionCondition != null ? step.completionCondition.CurrentHintLine : default;
            LineRef coachHint = !dynamicHint.IsEmpty ? dynamicHint
                : !step.hintLine.IsEmpty ? step.hintLine
                : step.instructionLine;

            if (!coachHint.IsEmpty && vo != null)
            {
                // No pisar una corrección o explicación que esté sonando.
                while (vo.IsSpeaking && vo.ActiveLine != null && vo.ActiveLine.IsError)
                    yield return null;
                vo.Say(coachHint);
            }
            else if (vo != null)
            {
                vo.PlayInstruction(step.hintVO);
            }

            if (FeedbackSystem.Instance != null)
                FeedbackSystem.Instance.ShowHintFeedback();

            _hintCoroutine = null;
            HintShown?.Invoke(step);

            Telemetry.TelemetryHub.Emit(new Telemetry.HintShownEvent
            {
                StepId = step.stepId,
                HintDelaySeconds = step.hintDelay
            });
        }
    }
}
