using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    // 0.3 lote 1: visibleSi (contrato 0.3 §2.10).

    /// <summary>
    /// Muestra u oculta su objeto según el estado: activo si se cumplen todas las <see cref="conditions"/> (forma de
    /// <c>si</c>). Oculto, un objeto no se ve ni se agarra y una zona no acepta ni se resalta. Se evalúa en Awake, antes
    /// que el resto de la escena (orden -300), para que lo que empieza oculto no llegue a despertar donde está escrito; y
    /// después a cada cambio del estado, aunque el objeto esté inactivo (la suscripción es un evento de C#).
    /// Sin <see cref="SimulationStateHost"/> en la escena, no hace nada.
    /// </summary>
    [DefaultExecutionOrder(-300)]
    [DisallowMultipleComponent]
    public class StateVisibility : MonoBehaviour
    {
        [Tooltip("Todas a la vez. Vacío: siempre visible.")]
        public List<StateCondition> conditions = new();

        private SimulationState _state;
        private SimulationStateHost _host;

        private void Awake()
        {
            _host = SimulationStateHost.Current;
            if (_host == null) return;
            _host.StateCreated += Bind;
            Bind(_host.State);
        }

        private void OnDestroy()
        {
            if (_state != null) _state.Changed -= OnChanged;
            if (_host != null) _host.StateCreated -= Bind;
        }

        private void Bind(SimulationState state)
        {
            if (_state != null) _state.Changed -= OnChanged;
            _state = state;
            if (_state != null) _state.Changed += OnChanged;
            Refresh();
        }

        private void OnChanged(StateChange change) => Refresh();

        /// <summary>¿Lo dejan visible las condiciones con el estado actual?</summary>
        public bool ShouldBeVisible => _state == null || _state.Evaluate(conditions);

        /// <summary>Aplica la visibilidad ahora.</summary>
        public void Refresh()
        {
            if (this == null) return;
            bool visible = ShouldBeVisible;
            if (gameObject.activeSelf != visible) gameObject.SetActive(visible);
        }
    }
}
