using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace XRLabs.Core
{
    /// <summary>
    /// Deja el mundo como queda al terminar cada paso, para saltar capítulos (menú de
    /// capítulos, pruebas). Al saltar hacia adelante aplica, en orden, los estados finales
    /// de todos los pasos que se saltaron.
    ///
    /// Regla: cada applyEndState debe ser idempotente (aplicarlo dos veces = una vez).
    /// Saltar hacia atrás no deshace el mundo: para eso hay que recargar la escena y saltar.
    /// </summary>
    public class StepEndStates : MonoBehaviour
    {
        [Serializable]
        public class EndState
        {
            public string stepId;
            public UnityEvent applyEndState = new();
        }

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private List<EndState> endStates = new();

        /// <summary>Se aplicaron estados finales al saltar (índice origen, índice destino).</summary>
        public event Action<int, int> Applied;

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();
            if (stepSystem != null) stepSystem.JumpedToStep += HandleJump;
        }

        private void OnDisable()
        {
            if (stepSystem != null) stepSystem.JumpedToStep -= HandleJump;
        }

        /// <summary>Aplica los estados finales de los pasos en [fromIndex, toIndex).</summary>
        public void ApplyRange(int fromIndex, int toIndex)
        {
            var sequence = stepSystem != null ? stepSystem.Sequence : null;
            if (sequence == null) return;

            for (int i = Mathf.Max(0, fromIndex); i < toIndex && i < sequence.TotalSteps; i++)
            {
                var step = sequence.GetStep(i);
                if (step == null) continue;
                foreach (var state in endStates)
                    if (state != null && state.stepId == step.stepId)
                        state.applyEndState.Invoke();
            }

            Applied?.Invoke(fromIndex, toIndex);
        }

        private void HandleJump(int fromIndex, int toIndex)
        {
            if (toIndex > fromIndex)
            {
                ApplyRange(fromIndex, toIndex);
                return;
            }

            if (toIndex < fromIndex)
                Debug.LogWarning("[StepEndStates] Salto hacia atrás: el mundo no se deshace. Recarga la escena y salta desde el inicio.");
        }
    }
}
