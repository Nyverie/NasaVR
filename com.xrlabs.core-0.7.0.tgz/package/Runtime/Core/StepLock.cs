using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// 0.3 lote 6: un bloqueo del guion (contrato-0.3.md §2.8). Mientras está activo, la zona rechaza todo soltado o el
    /// objeto no responde (no se agarra ni se activa). Activo desde que empieza el paso <c>fromStepId</c> (vacío = desde el
    /// inicio) hasta que se completa el paso <c>untilStepId</c>. Lo aplica LockEnforcer (XRLabs.Interactions).
    /// </summary>
    [Serializable]
    public class StepLock
    {
        [Tooltip("Zona bloqueada (ZoneId). Excluyente con objectId.")]
        public string zoneId;

        [Tooltip("Objeto bloqueado (InteractionId o SourceId de pila). Excluyente con zoneId.")]
        public string objectId;

        [Tooltip("Paso hasta cuyo cierre dura el bloqueo. Un grupo vale por su último paso desenrollado (<grupo>.*).")]
        public string untilStepId;

        [Tooltip("Paso desde cuyo inicio rige. Vacío = desde el inicio.")]
        public string fromStepId;

        [Tooltip("Clave de error que se reporta si el paso en curso la declara en errores. Vacía = no se dice ni cuenta.")]
        public string errorKey;

        public bool IsZone => !string.IsNullOrEmpty(zoneId);

        /// <summary>
        /// Índice del paso con ese id: el exacto o, si es un grupo, el último (<paramref name="last"/>) o el primero de los
        /// pasos desenrollados <c>&lt;id&gt;.…</c>. -1 si no existe.
        /// </summary>
        public static int ResolveIndex(IReadOnlyList<StepDefinition> steps, string id, bool last)
        {
            if (steps == null || string.IsNullOrEmpty(id)) return -1;
            for (int i = 0; i < steps.Count; i++)
                if (steps[i] != null && steps[i].stepId == id) return i;
            int found = -1;
            string prefix = id + ".";
            for (int i = 0; i < steps.Count; i++)
            {
                if (steps[i] == null || string.IsNullOrEmpty(steps[i].stepId) || !steps[i].stepId.StartsWith(prefix, StringComparison.Ordinal)) continue;
                found = i;
                if (!last) return i;
            }
            return found;
        }
    }
}
