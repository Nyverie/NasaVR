﻿using System;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Vibración del mando o de la mano. Core no conoce el SDK XR: Interactions
    /// registra una implementación (XRI) en <see cref="FeedbackSystem.Haptics"/>.
    /// </summary>
    public interface IHapticsProvider
    {
        void Pulse(float amplitude, float durationSeconds);
    }

    /// <summary>
    /// Feedback de acierto, error y pista: sonido + vibración + partículas, y eventos
    /// para que la UI reaccione (ej: el subtítulo se sacude en error).
    /// Todos los campos son opcionales; sin configurar solo emite los eventos.
    /// </summary>
    public class FeedbackSystem : MonoBehaviour
    {
        public static FeedbackSystem Instance;

        /// <summary>Proveedor de vibración registrado por la capa XR (puede ser null en modo plano).</summary>
        public static IHapticsProvider Haptics { get; set; }

        [Header("Sonido")]
        [SerializeField] private AudioClip successClip;
        [SerializeField] private AudioClip errorClip;
        [SerializeField] private AudioClip hintClip;

        [Header("Vibración")]
        [SerializeField, Range(0f, 1f)] private float successHapticAmplitude = 0.3f;
        [SerializeField, Min(0f)] private float successHapticSeconds = 0.03f;
        [SerializeField, Range(0f, 1f)] private float errorHapticAmplitude = 0.6f;
        [SerializeField, Min(0f)] private float errorHapticSeconds = 0.12f;

        [Header("Partículas (prefabs opcionales)")]
        [SerializeField] private ParticleSystem successParticles;
        [SerializeField] private ParticleSystem errorParticles;
        [SerializeField, Min(0.1f)] private float particleLifetimeSeconds = 3f;

        public event Action<Vector3?> SuccessShown;
        public event Action<Vector3?> ErrorShown;
        public event Action HintFeedbackShown;

        private void Awake()
        {
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void ShowSuccess() => ShowSuccess(null);

        public void ShowSuccess(Vector3? at)
        {
            PlayClip(successClip);
            Haptics?.Pulse(successHapticAmplitude, successHapticSeconds);
            SpawnParticles(successParticles, at);
            SuccessShown?.Invoke(at);
        }

        public void ShowError() => ShowError(null);

        public void ShowError(Vector3? at)
        {
            PlayClip(errorClip);
            Haptics?.Pulse(errorHapticAmplitude, errorHapticSeconds);
            SpawnParticles(errorParticles, at);
            ErrorShown?.Invoke(at);
        }

        public void ShowHintFeedback()
        {
            PlayClip(hintClip);
            HintFeedbackShown?.Invoke();
        }

        private static void PlayClip(AudioClip clip)
        {
            if (clip != null && VOManager.Instance != null)
                VOManager.Instance.PlaySFX(clip);
        }

        private void SpawnParticles(ParticleSystem prefab, Vector3? at)
        {
            if (prefab == null || !at.HasValue) return;
            var instance = Instantiate(prefab, at.Value, Quaternion.identity);
            instance.Play();
            Destroy(instance.gameObject, particleLifetimeSeconds);
        }
    }
}
