﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace XRLabs.Core
{
    public class TelemetryClient : MonoBehaviour
    {
        public enum SessionEndReason
        {
            Completed,
            Abandoned,
            Crashed,
            Timeout,
            UserExit
        }

        [Serializable]
        public class StepTelemetryEvent
        {
            public string type;
            public string timestampUtc;
            public string stepId;
            public int stepIndex;
            public float elapsedStepSeconds;
            public int scoreAfter;
        }

        [Serializable]
        public class DeviceInfo
        {
            public string type;
            public string platform;
            public string ipAddress;
        }

        [Serializable]
        public class ScoreTelemetryEvent
        {
            public string eventId;
            public string label;
            public int scoreDelta;
            public string timestampUtc;
            public string metadataJson;
        }

        [Serializable]
        public class SessionTelemetry
        {
            public string schemaVersion;
            public string sessionId;
            public int organizationId;
            public string userId;
            public int userNumericId;
            public string experienceId;
            public int experienceNumericId;
            public int groupId;
            public string mode;
            public string startedAtUtc;
            public string endedAtUtc;
            public string endReason;
            public int totalSteps;
            public int completedSteps;
            public float totalTimeSeconds;
            public int finalScore;
            public int attempt;
            public int attemptNumber;
            public int maxScore;
            public DeviceInfo device;
            public List<StepTelemetryEvent> events;
            public List<ScoreTelemetryEvent> scoreEvents;
        }

        [Serializable]
        private class ActiveSessionMarker
        {
            public string schemaVersion;
            public string sessionId;
            public int organizationId;
            public string userId;
            public int userNumericId;
            public string experienceId;
            public int experienceNumericId;
            public int groupId;
            public int attemptNumber;
            public string mode;
            public string startedAtUtc;
            public int totalSteps;
            public int completedSteps;
            public int lastKnownScore;
            public int maxScore;
        }

        private interface ITelemetryRepository
        {
            void SaveSession(SessionTelemetry sessionTelemetry);
            void AppendEvent(string sessionId, StepTelemetryEvent eventData);
        }

        private sealed class JsonFileTelemetryRepository : ITelemetryRepository
        {
            private readonly string _basePath;
            private readonly bool _prettyJson;

            public JsonFileTelemetryRepository(bool prettyJson)
            {
                _basePath = Path.Combine(Application.persistentDataPath, "Telemetry");
                _prettyJson = prettyJson;
            }

            public void SaveSession(SessionTelemetry sessionTelemetry)
            {
                if (sessionTelemetry == null)
                {
                    return;
                }

                string sessionFolder = Path.Combine(_basePath, sessionTelemetry.sessionId);
                Directory.CreateDirectory(sessionFolder);

                string filePath = Path.Combine(sessionFolder, "session.json");
                string json = JsonUtility.ToJson(sessionTelemetry, _prettyJson);
                File.WriteAllText(filePath, json);
            }

            public void AppendEvent(string sessionId, StepTelemetryEvent eventData)
            {
                if (string.IsNullOrEmpty(sessionId) || eventData == null)
                {
                    return;
                }

                string sessionFolder = Path.Combine(_basePath, sessionId);
                Directory.CreateDirectory(sessionFolder);

                string filePath = Path.Combine(sessionFolder, "events.jsonl");
                string line = JsonUtility.ToJson(eventData, false);
                File.AppendAllText(filePath, line + Environment.NewLine);
            }
        }

        public static TelemetryClient Instance;

        private const string ActiveSessionFileName = "active_session.json";

        [Header("Local Session Metadata")]
        [SerializeField] private int organizationId = -1;
        [SerializeField] private string userId = "local-user";
        [SerializeField] private int userNumericId = -1;
        [SerializeField] private string experienceId = "dev-experience";
        [SerializeField] private int experienceNumericId = -1;
        [SerializeField] private int groupId = -1;
        [SerializeField] private int attempt = 1;

        [Header("Device Metadata")]
        [SerializeField] private string deviceType = "vr_headset";
        [SerializeField] private string devicePlatform = "Meta Quest 3";
        [SerializeField] private string deviceIpAddress = string.Empty;

        [Header("Scoring Metadata")]
        [SerializeField] private int maxScore = 100;

        [Header("Storage")]
        [SerializeField] private bool prettyJson = true;
        [SerializeField] private bool keepDetailedEventLog = true;
        [SerializeField] private bool exportCsvArtifacts = true;

        [Header("Session End Detection")]
        [SerializeField] private float sessionTimeoutSeconds = 0f;

        private ITelemetryRepository _repository;
        private SessionTelemetry _currentSession;
        private bool _isAttachedToSimulation;
        private bool _sessionClosed;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            _repository = new JsonFileTelemetryRepository(prettyJson);
            RecoverCrashedSessionIfAny();
            AttachToSimulationEvents();
        }

        private void Update()
        {
            if (_currentSession == null || _sessionClosed || sessionTimeoutSeconds <= 0f)
            {
                return;
            }

            if (GetElapsedSessionSeconds() >= sessionTimeoutSeconds)
            {
                int score = ScoringSystem.Instance != null ? ScoringSystem.Instance.CurrentScore : _currentSession.finalScore;
                FinalizeSession(score, GetElapsedSessionSeconds(), SessionEndReason.Timeout);
            }
        }

        private void Start()
        {
            // Retry in case SimulationManager is instantiated after this component.
            AttachToSimulationEvents();
        }

        private void OnDestroy()
        {
            DetachFromSimulationEvents();

            if (Instance == this)
            {
                Instance = null;
            }
        }

        public void SendSessionResult(int finalScore)
        {
            EnsureSessionExists("Unknown");
            // Compatibility method called by SimulationManager at the end.
            float elapsed = _currentSession != null ? GetElapsedSessionSeconds() : 0f;
            FinalizeSession(finalScore, elapsed, SessionEndReason.Completed);
        }

        public void RecordScoreEvent(string eventId, string label, int scoreDelta, string metadataJson = "")
        {
            EnsureSessionExists("Unknown");

            if (_currentSession == null)
            {
                return;
            }

            if (_currentSession.scoreEvents == null)
            {
                _currentSession.scoreEvents = new List<ScoreTelemetryEvent>();
            }

            var scoreEvent = new ScoreTelemetryEvent
            {
                eventId = eventId,
                label = label,
                scoreDelta = scoreDelta,
                timestampUtc = DateTime.UtcNow.ToString("o"),
                metadataJson = metadataJson
            };

            _currentSession.scoreEvents.Add(scoreEvent);
            SaveActiveSessionMarker();
        }

        public void RequestSessionClose(SessionEndReason reason)
        {
            if (_currentSession == null || _sessionClosed)
            {
                return;
            }

            int score = ScoringSystem.Instance != null ? ScoringSystem.Instance.CurrentScore : _currentSession.finalScore;
            FinalizeSession(score, GetElapsedSessionSeconds(), reason);
        }

        private void OnApplicationQuit()
        {
            if (_currentSession == null || _sessionClosed)
            {
                return;
            }

            int score = ScoringSystem.Instance != null ? ScoringSystem.Instance.CurrentScore : _currentSession.finalScore;
            FinalizeSession(score, GetElapsedSessionSeconds(), SessionEndReason.UserExit);
        }

        private void AttachToSimulationEvents()
        {
            if (_isAttachedToSimulation || SimulationManager.Instance == null)
            {
                return;
            }

            SimulationManager.Instance.OnSimulationStarted += HandleSimulationStarted;
            SimulationManager.Instance.OnStepStarted += HandleStepStarted;
            SimulationManager.Instance.OnStepCompleted += HandleStepCompleted;
            SimulationManager.Instance.OnSimulationEnded += HandleSimulationEnded;
            _isAttachedToSimulation = true;
        }

        private void DetachFromSimulationEvents()
        {
            if (!_isAttachedToSimulation || SimulationManager.Instance == null)
            {
                return;
            }

            SimulationManager.Instance.OnSimulationStarted -= HandleSimulationStarted;
            SimulationManager.Instance.OnStepStarted -= HandleStepStarted;
            SimulationManager.Instance.OnStepCompleted -= HandleStepCompleted;
            SimulationManager.Instance.OnSimulationEnded -= HandleSimulationEnded;
            _isAttachedToSimulation = false;
        }

        private void HandleSimulationStarted(SimulationMode mode, int totalSteps)
        {
            _sessionClosed = false;
            _currentSession = new SessionTelemetry
            {
                schemaVersion = "1.0.0",
                sessionId = Guid.NewGuid().ToString("N"),
                organizationId = organizationId,
                userId = userId,
                userNumericId = userNumericId,
                experienceId = experienceId,
                experienceNumericId = experienceNumericId,
                groupId = groupId,
                mode = mode.ToString(),
                startedAtUtc = DateTime.UtcNow.ToString("o"),
                totalSteps = totalSteps,
                attempt = attempt,
                attemptNumber = attempt,
                maxScore = maxScore,
                device = BuildDeviceInfo(),
                events = new List<StepTelemetryEvent>(),
                scoreEvents = new List<ScoreTelemetryEvent>()
            };

            AppendEvent("session_started", string.Empty, -1, 0f, 0);
            SaveActiveSessionMarker();
        }

        private void HandleStepStarted(StepDefinition step, int stepIndex, int totalSteps)
        {
            EnsureSessionExists("Unknown");

            if (_currentSession == null)
            {
                return;
            }

            _currentSession.totalSteps = totalSteps;
            int score = ScoringSystem.Instance != null ? ScoringSystem.Instance.CurrentScore : 0;
            AppendEvent("step_started", step != null ? step.stepId : string.Empty, stepIndex, 0f, score);
        }

        private void HandleStepCompleted(StepDefinition step, int stepIndex, float elapsedTime, int scoreAfter)
        {
            EnsureSessionExists("Unknown");

            if (_currentSession == null)
            {
                return;
            }

            _currentSession.completedSteps = Mathf.Max(_currentSession.completedSteps, stepIndex + 1);
            AppendEvent("step_completed", step != null ? step.stepId : string.Empty, stepIndex, elapsedTime, scoreAfter);
        }

        private void HandleSimulationEnded(int finalScore, float totalTime)
        {
            FinalizeSession(finalScore, totalTime, SessionEndReason.Completed);
        }

        private void FinalizeSession(int finalScore, float totalTime, SessionEndReason endReason)
        {
            if (_currentSession == null || _sessionClosed)
            {
                return;
            }

            _sessionClosed = true;
            _currentSession.finalScore = finalScore;
            _currentSession.totalTimeSeconds = totalTime;
            _currentSession.endedAtUtc = DateTime.UtcNow.ToString("o");
            _currentSession.endReason = ToWireEndReason(endReason);

            AppendEvent("session_ended", string.Empty, -1, totalTime, finalScore);
            _repository.SaveSession(_currentSession);
            WriteCsvArtifacts(_currentSession);
            ClearActiveSessionMarker();

            Debug.Log($"Telemetry saved locally: session={_currentSession.sessionId}, score={finalScore}, endReason={_currentSession.endReason}");
        }

        private void WriteCsvArtifacts(SessionTelemetry sessionTelemetry)
        {
            if (!exportCsvArtifacts || sessionTelemetry == null)
            {
                return;
            }

            string telemetryBasePath = Path.Combine(Application.persistentDataPath, "Telemetry");
            string sessionFolder = Path.Combine(telemetryBasePath, sessionTelemetry.sessionId);
            Directory.CreateDirectory(sessionFolder);

            string summaryCsvPath = Path.Combine(sessionFolder, "session_summary.csv");
            string eventsCsvPath = Path.Combine(sessionFolder, "events.csv");

            var summaryBuilder = new StringBuilder();
            summaryBuilder.AppendLine("schemaVersion,sessionId,organizationId,userId,userNumericId,experienceId,experienceNumericId,groupId,mode,startedAtUtc,endedAtUtc,endReason,totalSteps,completedSteps,totalTimeSeconds,finalScore,attempt,attemptNumber,maxScore,deviceType,devicePlatform,deviceIpAddress,scoreEventsCount");
            summaryBuilder.AppendLine(string.Format(
                "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14:0.###},{15},{16},{17},{18},{19},{20},{21},{22}",
                Csv(sessionTelemetry.schemaVersion),
                Csv(sessionTelemetry.sessionId),
                sessionTelemetry.organizationId,
                Csv(sessionTelemetry.userId),
                sessionTelemetry.userNumericId,
                Csv(sessionTelemetry.experienceId),
                sessionTelemetry.experienceNumericId,
                sessionTelemetry.groupId,
                Csv(sessionTelemetry.mode),
                Csv(sessionTelemetry.startedAtUtc),
                Csv(sessionTelemetry.endedAtUtc),
                Csv(sessionTelemetry.endReason),
                sessionTelemetry.totalSteps,
                sessionTelemetry.completedSteps,
                sessionTelemetry.totalTimeSeconds,
                sessionTelemetry.finalScore,
                sessionTelemetry.attempt,
                sessionTelemetry.attemptNumber,
                sessionTelemetry.maxScore,
                Csv(sessionTelemetry.device != null ? sessionTelemetry.device.type : string.Empty),
                Csv(sessionTelemetry.device != null ? sessionTelemetry.device.platform : string.Empty),
                Csv(sessionTelemetry.device != null ? sessionTelemetry.device.ipAddress : string.Empty),
                sessionTelemetry.scoreEvents != null ? sessionTelemetry.scoreEvents.Count : 0
            ));
            File.WriteAllText(summaryCsvPath, summaryBuilder.ToString());

            var eventsBuilder = new StringBuilder();
            eventsBuilder.AppendLine("type,timestampUtc,stepId,stepIndex,elapsedStepSeconds,scoreAfter");

            if (sessionTelemetry.events != null)
            {
                foreach (var telemetryEvent in sessionTelemetry.events)
                {
                    eventsBuilder.AppendLine(string.Format(
                        "{0},{1},{2},{3},{4:0.###},{5}",
                        Csv(telemetryEvent.type),
                        Csv(telemetryEvent.timestampUtc),
                        Csv(telemetryEvent.stepId),
                        telemetryEvent.stepIndex,
                        telemetryEvent.elapsedStepSeconds,
                        telemetryEvent.scoreAfter
                    ));
                }
            }

            File.WriteAllText(eventsCsvPath, eventsBuilder.ToString());
        }

        private static string Csv(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            string escaped = value.Replace("\"", "\"\"");
            return "\"" + escaped + "\"";
        }

        private void EnsureSessionExists(string mode)
        {
            if (_currentSession != null)
            {
                return;
            }

            _currentSession = new SessionTelemetry
            {
                schemaVersion = "1.0.0",
                sessionId = Guid.NewGuid().ToString("N"),
                organizationId = organizationId,
                userId = userId,
                userNumericId = userNumericId,
                experienceId = experienceId,
                experienceNumericId = experienceNumericId,
                groupId = groupId,
                mode = mode,
                startedAtUtc = DateTime.UtcNow.ToString("o"),
                attempt = attempt,
                attemptNumber = attempt,
                maxScore = maxScore,
                device = BuildDeviceInfo(),
                events = new List<StepTelemetryEvent>(),
                scoreEvents = new List<ScoreTelemetryEvent>()
            };

            SaveActiveSessionMarker();
        }

        private void AppendEvent(string eventType, string stepId, int stepIndex, float elapsedStepSeconds, int scoreAfter)
        {
            if (_currentSession == null)
            {
                return;
            }

            var eventData = new StepTelemetryEvent
            {
                type = eventType,
                timestampUtc = DateTime.UtcNow.ToString("o"),
                stepId = stepId,
                stepIndex = stepIndex,
                elapsedStepSeconds = elapsedStepSeconds,
                scoreAfter = scoreAfter
            };

            _currentSession.events.Add(eventData);
            SaveActiveSessionMarker();

            if (keepDetailedEventLog)
            {
                _repository.AppendEvent(_currentSession.sessionId, eventData);
            }
        }

        private static string ToWireEndReason(SessionEndReason reason)
        {
            switch (reason)
            {
                case SessionEndReason.Completed:
                    return "completed";
                case SessionEndReason.Abandoned:
                    return "abandoned";
                case SessionEndReason.Crashed:
                    return "crashed";
                case SessionEndReason.Timeout:
                    return "timeout";
                case SessionEndReason.UserExit:
                    return "user_exit";
                default:
                    return "abandoned";
            }
        }

        private DeviceInfo BuildDeviceInfo()
        {
            return new DeviceInfo
            {
                type = deviceType,
                platform = devicePlatform,
                ipAddress = deviceIpAddress
            };
        }

        private float GetElapsedSessionSeconds()
        {
            if (_currentSession == null || string.IsNullOrEmpty(_currentSession.startedAtUtc))
            {
                return 0f;
            }

            DateTime startedAt;
            if (!DateTime.TryParse(_currentSession.startedAtUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out startedAt))
            {
                return 0f;
            }

            return Mathf.Max(0f, (float)(DateTime.UtcNow - startedAt.ToUniversalTime()).TotalSeconds);
        }

        private string GetActiveSessionMarkerPath()
        {
            string telemetryBasePath = Path.Combine(Application.persistentDataPath, "Telemetry");
            Directory.CreateDirectory(telemetryBasePath);
            return Path.Combine(telemetryBasePath, ActiveSessionFileName);
        }

        private void SaveActiveSessionMarker()
        {
            if (_currentSession == null || _sessionClosed)
            {
                return;
            }

            var marker = new ActiveSessionMarker
            {
                schemaVersion = _currentSession.schemaVersion,
                sessionId = _currentSession.sessionId,
                organizationId = _currentSession.organizationId,
                userId = _currentSession.userId,
                userNumericId = _currentSession.userNumericId,
                experienceId = _currentSession.experienceId,
                experienceNumericId = _currentSession.experienceNumericId,
                groupId = _currentSession.groupId,
                attemptNumber = _currentSession.attemptNumber,
                mode = _currentSession.mode,
                startedAtUtc = _currentSession.startedAtUtc,
                totalSteps = _currentSession.totalSteps,
                completedSteps = _currentSession.completedSteps,
                lastKnownScore = ScoringSystem.Instance != null ? ScoringSystem.Instance.CurrentScore : _currentSession.finalScore,
                maxScore = _currentSession.maxScore
            };

            File.WriteAllText(GetActiveSessionMarkerPath(), JsonUtility.ToJson(marker, prettyJson));
        }

        private void ClearActiveSessionMarker()
        {
            string markerPath = GetActiveSessionMarkerPath();
            if (File.Exists(markerPath))
            {
                File.Delete(markerPath);
            }
        }

        private void RecoverCrashedSessionIfAny()
        {
            string markerPath = GetActiveSessionMarkerPath();
            if (!File.Exists(markerPath))
            {
                return;
            }

            try
            {
                string json = File.ReadAllText(markerPath);
                var marker = JsonUtility.FromJson<ActiveSessionMarker>(json);
                if (marker == null || string.IsNullOrEmpty(marker.sessionId))
                {
                    File.Delete(markerPath);
                    return;
                }

                float totalSeconds = 0f;
                DateTime startedAt;
                if (DateTime.TryParse(marker.startedAtUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out startedAt))
                {
                    totalSeconds = Mathf.Max(0f, (float)(DateTime.UtcNow - startedAt.ToUniversalTime()).TotalSeconds);
                }

                var recovered = new SessionTelemetry
                {
                    schemaVersion = string.IsNullOrEmpty(marker.schemaVersion) ? "1.0.0" : marker.schemaVersion,
                    sessionId = marker.sessionId,
                    organizationId = marker.organizationId,
                    userId = marker.userId,
                    userNumericId = marker.userNumericId,
                    experienceId = marker.experienceId,
                    experienceNumericId = marker.experienceNumericId,
                    groupId = marker.groupId,
                    mode = marker.mode,
                    startedAtUtc = marker.startedAtUtc,
                    endedAtUtc = DateTime.UtcNow.ToString("o"),
                    endReason = ToWireEndReason(SessionEndReason.Crashed),
                    totalSteps = marker.totalSteps,
                    completedSteps = marker.completedSteps,
                    totalTimeSeconds = totalSeconds,
                    finalScore = marker.lastKnownScore,
                    attempt = marker.attemptNumber,
                    attemptNumber = marker.attemptNumber,
                    maxScore = marker.maxScore > 0 ? marker.maxScore : maxScore,
                    device = BuildDeviceInfo(),
                    events = new List<StepTelemetryEvent>(),
                    scoreEvents = new List<ScoreTelemetryEvent>()
                };

                recovered.events.Add(new StepTelemetryEvent
                {
                    type = "session_ended",
                    timestampUtc = DateTime.UtcNow.ToString("o"),
                    stepId = string.Empty,
                    stepIndex = -1,
                    elapsedStepSeconds = totalSeconds,
                    scoreAfter = recovered.finalScore
                });

                _repository.SaveSession(recovered);
                WriteCsvArtifacts(recovered);
                Debug.Log($"Recovered crashed session telemetry: session={recovered.sessionId}");
            }
            catch (Exception ex)
            {
                Debug.LogWarning("Failed to recover crashed session marker: " + ex.Message);
            }
            finally
            {
                if (File.Exists(markerPath))
                {
                    File.Delete(markerPath);
                }
            }
        }
    }
}