using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>Cómo se calcula el puntaje.</summary>
    public enum ScoringRule
    {
        /// <summary>v0.5: parte de initialScore, suma scoreOnSuccess y penaliza por tiempo en Evaluación.</summary>
        TimeBased,

        /// <summary>v0.6: precisión = tareas/(tareas+errores)×100, menos hintPenalty por ayuda (0–100).</summary>
        TasksErrorsHints
    }

    public class ScoringSystem : MonoBehaviour
    {
        public struct StepScoreResult
        {
            public int pointsAwarded;
            public int penaltyApplied;
            public bool penaltyIgnoredByEarlyTolerance;
        }

        public static ScoringSystem Instance;

        [Header("Regla")]
        [SerializeField] private ScoringRule rule = ScoringRule.TimeBased;
        [Tooltip("Solo TasksErrorsHints: puntos que resta cada ayuda.")]
        [SerializeField, Min(0f)] private float hintPenalty = 2f;

        [Header("Base Score")]
        [SerializeField] private int initialScore = 100;
        [SerializeField] private int maxScore = 100;

        [Header("Phase Rules")]
        [SerializeField] private int earlyPhaseStepCount = 2;
        [SerializeField] private int freeMistakesInEarlyPhase = 1;
        [SerializeField] private int minimumLatePenalty = 5;

        public int CurrentScore { get; private set; }

        public ScoringRule Rule => rule;

        /// <summary>Nota por letra: A ≥ 90 · B ≥ 75 · C ≥ 60 · D.</summary>
        public string Grade => GradeFor(CurrentScore);

        public static string GradeFor(int score) =>
            score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : "D";

        private int _earlyPhaseMistakesUsed;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        public void Initialize(SimulationMode mode)
        {
            int normalizedMaxScore = Mathf.Max(1, maxScore);
            CurrentScore = Mathf.Clamp(initialScore, 0, normalizedMaxScore);
            _earlyPhaseMistakesUsed = 0;

            if (rule == ScoringRule.TasksErrorsHints)
                CurrentScore = Mathf.Min(100, normalizedMaxScore);
        }

        /// <summary>Recalcula el puntaje desde las estadísticas (solo regla TasksErrorsHints).</summary>
        public void RecomputeFromStats(SessionStats stats)
        {
            if (rule != ScoringRule.TasksErrorsHints || stats == null) return;
            float score = stats.Accuracy - hintPenalty * stats.Hints;
            CurrentScore = Mathf.Clamp(Mathf.RoundToInt(score), 0, 100);
        }

        /// <summary>
        /// 0.3 lote 2 (contrato-0.3.md §2.1): un paso saltado por su guarda no suma ni resta. Con la regla por tareas el total
        /// ya lo descontó <see cref="SessionStats.SkipTask"/>; aquí solo se recalcula.
        /// </summary>
        public void RegisterSkippedStep(StepDefinition step, SessionStats stats)
        {
            RecomputeFromStats(stats);
        }

        // Backward-compatible signature.
        public void RegisterStepResult(
            StepDefinition step,
            float timeSpent,
            SimulationMode mode
        )
        {
            RegisterStepResult(step, timeSpent, mode, 0);
        }

        public StepScoreResult RegisterStepResult(
            StepDefinition step,
            float timeSpent,
            SimulationMode mode,
            int stepIndex
        )
        {
            var result = new StepScoreResult();

            if (step == null || rule == ScoringRule.TasksErrorsHints)
            {
                return result;
            }

            result.pointsAwarded = step.scoreOnSuccess;
            CurrentScore = Mathf.Clamp(CurrentScore + result.pointsAwarded, 0, Mathf.Max(1, maxScore));

            bool isEvaluation = mode == SimulationMode.Evaluation;
            bool exceededAllowedTime = timeSpent > step.maxAllowedTime;

            if (!isEvaluation || !exceededAllowedTime)
            {
                return result;
            }

            bool isEarlyPhase = stepIndex < earlyPhaseStepCount;

            if (isEarlyPhase && _earlyPhaseMistakesUsed < freeMistakesInEarlyPhase)
            {
                _earlyPhaseMistakesUsed++;
                result.penaltyIgnoredByEarlyTolerance = true;
                return result;
            }

            int penalty = step.penaltyOnError;
            if (!isEarlyPhase)
            {
                penalty = Mathf.Max(penalty, minimumLatePenalty);
            }

            result.penaltyApplied = penalty;
            CurrentScore = Mathf.Max(0, CurrentScore - penalty);

            return result;
        }
    }
}