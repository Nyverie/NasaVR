using System;
using System.Collections.Generic;
using System.Globalization;

namespace XRLabs.Core
{
    // 0.3 lote 1: estado de la escena (contrato 0.3 §2.1). C# puro, sin UnityEngine, para que
    // se pruebe en EditMode sin escena y lo compartan StepSystem (guardas, lote 2), las
    // condiciones (alElegir), StateVisibility y StateLayout (§2.10).

    /// <summary>Declaración de una variable de <c>estado</c>: de texto (lista cerrada) o numérica.</summary>
    [Serializable]
    public class StateVariableDef
    {
        public string name;
        public bool isNumber;
        /// <summary>Valores posibles de una variable de texto (2 o más, sin repetidos).</summary>
        public List<string> values = new();
        public string initialText;
        public double initialNumber;
        public bool hasMin;
        public double min;
        public bool hasMax;
        public double max;
        /// <summary>Manda <c>state_changed</c> por telemetría cuando cambia.</summary>
        public bool register;

        public static StateVariableDef Text(string name, string initial, params string[] values)
        {
            return new StateVariableDef
            {
                name = name,
                isNumber = false,
                values = new List<string>(values ?? Array.Empty<string>()),
                initialText = initial
            };
        }

        public static StateVariableDef Number(string name, double initial)
        {
            return new StateVariableDef { name = name, isNumber = true, initialNumber = initial };
        }

        /// <summary>Valor inicial efectivo de una de texto: el declarado o, si falta, el primero de <c>values</c>.</summary>
        public string EffectiveInitialText =>
            !string.IsNullOrEmpty(initialText) ? initialText
            : (values != null && values.Count > 0 ? values[0] : string.Empty);
    }

    /// <summary>Un efecto sobre una variable: fijar un texto, fijar un número o sumar.</summary>
    [Serializable]
    public class StateEffect
    {
        public enum Operation { Set, Add }

        public string variable;
        public Operation operation;
        public bool isNumber;
        public string text;
        public double number;

        public static StateEffect SetText(string variable, string value) =>
            new StateEffect { variable = variable, operation = Operation.Set, isNumber = false, text = value };

        public static StateEffect SetNumber(string variable, double value) =>
            new StateEffect { variable = variable, operation = Operation.Set, isNumber = true, number = value };

        public static StateEffect Add(string variable, double amount) =>
            new StateEffect { variable = variable, operation = Operation.Add, isNumber = true, number = amount };
    }

    /// <summary>
    /// Condición sobre una variable (forma de <c>si</c> y de <c>visibleSi</c>): lista de valores
    /// (cualquiera), <c>mayor</c>, <c>menor</c> o los dos (entre, exclusivo).
    /// </summary>
    [Serializable]
    public class StateCondition
    {
        public string variable;
        public List<string> anyText = new();
        public List<double> anyNumber = new();
        public bool hasGreater;
        public double greater;
        public bool hasLess;
        public double less;

        public static StateCondition TextIn(string variable, params string[] values) =>
            new StateCondition { variable = variable, anyText = new List<string>(values ?? Array.Empty<string>()) };

        public static StateCondition NumberIn(string variable, params double[] values) =>
            new StateCondition { variable = variable, anyNumber = new List<double>(values ?? Array.Empty<double>()) };

        public static StateCondition Between(string variable, double? greaterThan, double? lessThan) =>
            new StateCondition
            {
                variable = variable,
                hasGreater = greaterThan.HasValue, greater = greaterThan ?? 0,
                hasLess = lessThan.HasValue, less = lessThan ?? 0
            };
    }

    /// <summary>Un cambio de valor, tal como sale por el evento <see cref="SimulationState.Changed"/>.</summary>
    public readonly struct StateChange
    {
        public readonly string Variable;
        public readonly string Before;
        public readonly string After;
        public readonly bool Register;

        public StateChange(string variable, string before, string after, bool register)
        {
            Variable = variable;
            Before = before;
            After = after;
            Register = register;
        }
    }

    /// <summary>
    /// Tabla de estado de la escena (contrato 0.3 §2.1): valores actuales, <see cref="Apply(StateEffect)"/>,
    /// <see cref="Evaluate(StateCondition)"/>, <see cref="Replay"/> para los saltos y el evento
    /// <see cref="Changed"/>. Una operación inválida (variable sin declarar, valor fuera de
    /// <c>valores</c>, <c>sumar</c> en una de texto) no cambia nada y devuelve <c>false</c>: el
    /// validador ya la rechazó al importar.
    /// </summary>
    public class SimulationState
    {
        private readonly Dictionary<string, StateVariableDef> _defs = new(StringComparer.Ordinal);
        private readonly Dictionary<string, string> _text = new(StringComparer.Ordinal);
        private readonly Dictionary<string, double> _number = new(StringComparer.Ordinal);
        private readonly List<string> _order = new();

        /// <summary>Se dispara una vez por variable que cambia de valor (no si queda igual).</summary>
        public event Action<StateChange> Changed;

        public SimulationState(IEnumerable<StateVariableDef> definitions)
        {
            if (definitions == null) return;
            foreach (var d in definitions)
            {
                if (d == null || string.IsNullOrEmpty(d.name) || _defs.ContainsKey(d.name)) continue;
                _defs[d.name] = d;
                _order.Add(d.name);
            }
            SetInitialValues();
        }

        public IReadOnlyList<string> Variables => _order;
        public bool IsEmpty => _order.Count == 0;
        public bool Has(string variable) => variable != null && _defs.ContainsKey(variable);
        public StateVariableDef GetDefinition(string variable) =>
            variable != null && _defs.TryGetValue(variable, out var d) ? d : null;

        public string GetText(string variable) =>
            variable != null && _text.TryGetValue(variable, out var v) ? v : null;

        public double GetNumber(string variable) =>
            variable != null && _number.TryGetValue(variable, out var v) ? v : 0;

        /// <summary>Valor como texto: el de la lista, o el número entero sin decimales o con uno y coma (§2.2).</summary>
        public string Format(string variable)
        {
            var d = GetDefinition(variable);
            if (d == null) return null;
            return d.isNumber ? FormatNumber(_number[variable]) : _text[variable];
        }

        public static string FormatNumber(double value)
        {
            if (Math.Abs(value - Math.Round(value)) < 1e-9)
                return Math.Round(value).ToString("0", CultureInfo.InvariantCulture);
            return value.ToString("0.0", CultureInfo.InvariantCulture).Replace('.', ',');
        }

        /// <summary>Valores actuales de todas las variables, en orden de declaración (para <c>metadata.estado</c>).</summary>
        public Dictionary<string, string> Snapshot()
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var name in _order) result[name] = Format(name);
            return result;
        }

        /// <summary>Aplica un efecto. Devuelve <c>true</c> si el valor cambió.</summary>
        public bool Apply(StateEffect effect)
        {
            if (effect == null) return false;
            var d = GetDefinition(effect.variable);
            if (d == null) return false;

            if (!d.isNumber)
            {
                if (effect.operation != StateEffect.Operation.Set || effect.isNumber) return false;
                if (d.values == null || !d.values.Contains(effect.text)) return false;
                var before = _text[d.name];
                if (before == effect.text) return false;
                _text[d.name] = effect.text;
                Changed?.Invoke(new StateChange(d.name, before, effect.text, d.register));
                return true;
            }

            if (!effect.isNumber) return false;
            var old = _number[d.name];
            var next = effect.operation == StateEffect.Operation.Add ? old + effect.number : effect.number;
            next = Clamp(d, next);
            if (Math.Abs(next - old) < 1e-9) return false;
            _number[d.name] = next;
            Changed?.Invoke(new StateChange(d.name, FormatNumber(old), FormatNumber(next), d.register));
            return true;
        }

        /// <summary>Aplica varios efectos en orden. Devuelve <c>true</c> si alguno cambió algo.</summary>
        public bool Apply(IEnumerable<StateEffect> effects)
        {
            if (effects == null) return false;
            bool any = false;
            foreach (var e in effects) any |= Apply(e);
            return any;
        }

        /// <summary>¿Se cumple la condición? Variable sin declarar: no se cumple.</summary>
        public bool Evaluate(StateCondition condition)
        {
            if (condition == null) return true;
            var d = GetDefinition(condition.variable);
            if (d == null) return false;

            if (!d.isNumber)
            {
                if (condition.anyText == null || condition.anyText.Count == 0) return true;
                return condition.anyText.Contains(_text[d.name]);
            }

            var v = _number[d.name];
            if (condition.anyNumber != null && condition.anyNumber.Count > 0)
            {
                bool match = false;
                foreach (var n in condition.anyNumber)
                    if (Math.Abs(n - v) < 1e-9) { match = true; break; }
                if (!match) return false;
            }
            if (condition.hasGreater && !(v > condition.greater)) return false;
            if (condition.hasLess && !(v < condition.less)) return false;
            return true;
        }

        /// <summary>Todas las condiciones a la vez (lista vacía o nula: se cumple).</summary>
        public bool Evaluate(IEnumerable<StateCondition> conditions)
        {
            if (conditions == null) return true;
            foreach (var c in conditions)
                if (!Evaluate(c)) return false;
            return true;
        }

        /// <summary>Vuelve al estado inicial; avisa por <see cref="Changed"/> de lo que cambie.</summary>
        public void Reset()
        {
            foreach (var name in _order)
            {
                var d = _defs[name];
                if (d.isNumber) Apply(StateEffect.SetNumber(name, Clamp(d, d.initialNumber)));
                else Apply(StateEffect.SetText(name, d.EffectiveInitialText));
            }
        }

        /// <summary>
        /// Saltos (§4): vuelve al inicial y aplica, en orden, los efectos de los pasos recorridos
        /// hasta el destino.
        /// </summary>
        public void Replay(IEnumerable<IEnumerable<StateEffect>> effectsInOrder)
        {
            Reset();
            if (effectsInOrder == null) return;
            foreach (var group in effectsInOrder) Apply(group);
        }

        private void SetInitialValues()
        {
            foreach (var name in _order)
            {
                var d = _defs[name];
                if (d.isNumber) _number[name] = Clamp(d, d.initialNumber);
                else _text[name] = d.EffectiveInitialText;
            }
        }

        private static double Clamp(StateVariableDef d, double v)
        {
            if (d.hasMin && v < d.min) v = d.min;
            if (d.hasMax && v > d.max) v = d.max;
            return v;
        }
    }
}
