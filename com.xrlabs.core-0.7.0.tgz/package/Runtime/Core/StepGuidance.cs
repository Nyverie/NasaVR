using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Un sitio del suelo recomendado para hacer ciertos pasos (UX visor 2026-10-31): lo implementa el ancla de
    /// teletransporte orientada (<c>XRLabs.Interactions.TeleportGuideAnchor</c>) y lo consulta <see cref="StepGuidance"/>
    /// para llevar la línea de guía hasta él cuando la persona está lejos.
    /// </summary>
    public interface IStepGuideAnchor
    {
        /// <summary>Si este sitio es el mejor para el paso dado.</summary>
        bool IsRecommendedFor(string stepId);

        /// <summary>El punto del suelo donde se llega.</summary>
        Vector3 GuidePosition { get; }
    }

    /// <summary>Registro de los sitios recomendados de la escena (los anclas se apuntan al activarse).</summary>
    public static class StepGuideAnchors
    {
        private static readonly List<IStepGuideAnchor> Anchors = new();

        public static IReadOnlyList<IStepGuideAnchor> All => Anchors;

        public static void Register(IStepGuideAnchor anchor)
        {
            if (anchor != null && !Anchors.Contains(anchor)) Anchors.Add(anchor);
        }

        public static void Unregister(IStepGuideAnchor anchor) => Anchors.Remove(anchor);

        /// <summary>El sitio recomendado para el paso más cercano a <paramref name="from"/>, o false si no hay ninguno.</summary>
        public static bool TryGetRecommended(string stepId, Vector3 from, out IStepGuideAnchor best)
        {
            best = null;
            float bestDistance = float.PositiveInfinity;
            if (string.IsNullOrEmpty(stepId)) return false;
            foreach (var anchor in Anchors)
            {
                if (anchor == null || !anchor.IsRecommendedFor(stepId)) continue;
                float d = (anchor.GuidePosition - from).sqrMagnitude;
                if (d < bestDistance) { bestDistance = d; best = anchor; }
            }
            return best != null;
        }
    }

    /// <summary>Qué control del mando pide un paso, para la ayuda de mandos del HUD (UX visor 2026-10-31).</summary>
    public enum ControlHint
    {
        None,
        /// <summary>Gatillo lateral (grip): agarrar, llevar, sostener, frotar con una herramienta.</summary>
        Grip,
        /// <summary>Gatillo (índice): pulsar, elegir, tocar un punto.</summary>
        Trigger,
        /// <summary>El botón «Comenzar» del HUD o la tecla B del mando.</summary>
        Button,
    }

    public static class ControlHints
    {
        /// <summary>
        /// El control que pide un paso, por el tipo de su condición (el Core no ve los tipos de Interactions, así que mira el
        /// nombre de la clase): sostener, soltar en zona, frotar y llevar piden agarrar; apuntar, tocar y elegir piden el
        /// gatillo; los pasos manuales, el botón. Un paso sin interacción no pide nada.
        /// </summary>
        public static ControlHint For(StepDefinition step)
        {
            if (step == null || step.stepType != StepType.Interaction) return ControlHint.None;
            if (step.completionCondition == null) return step.waitForManualCompletion ? ControlHint.Button : ControlHint.None;
            string type = step.completionCondition.GetType().Name;
            if (Contains(type, "Hold") || Contains(type, "Drop") || Contains(type, "Scrub") || Contains(type, "Grab")
                || Contains(type, "Carry") || Contains(type, "Snap"))
                return ControlHint.Grip;
            if (Contains(type, "Aim") || Contains(type, "Touch") || Contains(type, "Hotspot") || Contains(type, "Choice"))
                return ControlHint.Trigger;
            if (Contains(type, "Manual") || Contains(type, "Key")) return ControlHint.Button;
            return ControlHint.None;
        }

        /// <summary>La frase corta para el HUD.</summary>
        public static string Label(ControlHint hint)
        {
            switch (hint)
            {
                case ControlHint.Grip: return "Ahora: mantén el GATILLO LATERAL para agarrar";
                case ControlHint.Trigger: return "Ahora: apunta y pulsa el GATILLO";
                case ControlHint.Button: return "Ahora: pulsa «Comenzar» (o B)";
                default: return string.Empty;
            }
        }

        private static bool Contains(string text, string part) => text.IndexOf(part, StringComparison.Ordinal) >= 0;
    }

    /// <summary>
    /// Guía cuando pasa el tiempo (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md §4). El dueño en el Quest 3:
    /// «ayuda a que el usuario sepa qué hacer si pasó algún tiempo». A los <see cref="GuideDelayFor"/> segundos sin avance
    /// en un paso interactivo (8 s por defecto, antes que la pista de voz del <c>hintDelay</c>, como propone la escalera
    /// del informe de UX del 2026-10-31):
    /// los objetivos del paso pulsan con emisión (material instanciado, nunca el compartido) y aparece una línea en el suelo
    /// con punta de flecha desde los pies de la persona hasta el sitio recomendado (si lo hay y está a más de
    /// <see cref="nearAnchorDistance"/>) o hasta el objetivo. Si pasan otros tantos segundos (<see cref="RepeatAtFor"/>), el
    /// coach repite la instrucción. <see cref="RequestHelp"/> (botón «¿Qué hago?» del HUD, botón Menú del mando izquierdo o
    /// tecla H en pantalla) hace las dos cosas al instante.
    ///
    /// «Avance» es empezar o completar un paso, o completar una tarea del paso. El contador no corre mientras
    /// <see cref="HintSystem.Paused"/> (menú o tarjeta abierta). El tiempo entra por <see cref="Tick"/>; <c>Update</c> le
    /// pasa <c>Time.deltaTime</c> y los tests lo llaman con tiempo simulado.
    /// </summary>
    [AddComponentMenu("XRLabs/Step Guidance")]
    public class StepGuidance : MonoBehaviour
    {
        public static StepGuidance Instance { get; private set; }

        [SerializeField] private StepSystem stepSystem;

        [Tooltip("Segundos sin avance hasta encender la guía (8 s, informe de UX del 2026-10-31). 0 = el hintDelay del paso.")]
        [SerializeField, Min(0f)] private float guideDelaySeconds = DefaultGuideDelaySeconds;

        [Tooltip("Segundos más, con la guía encendida, hasta que el coach repite la instrucción. 0 = los mismos que la guía.")]
        [SerializeField, Min(0f)] private float repeatDelaySeconds;

        [Tooltip("Si la persona está más cerca que esto del sitio recomendado, la línea va directa al objetivo.")]
        [SerializeField, Min(0f)] private float nearAnchorDistance = 1.2f;

        [Header("Aspecto")]
        [SerializeField] private Color guideColor = new Color(1f, 0.85f, 0.2f, 1f);
        [SerializeField, Min(0.005f)] private float lineWidth = 0.06f;
        [SerializeField, Min(0.1f)] private float pulsePeriod = 1.1f;
        [SerializeField, Min(0f)] private float pulseIntensity = 2.2f;

        [Tooltip("Cabeza de la persona. Vacío = Camera.main.")]
        [SerializeField] private Transform head;

        public const float DefaultGuideDelaySeconds = 8f;
        public const float FallbackDelaySeconds = 12f;

        /// <summary>El botón Menú del mando izquierdo abre la ayuda (Meta: el botón Menú es para menús).</summary>
        public const string HelpButtonBinding = "<XRController>{LeftHand}/{MenuButton}";
        private UnityEngine.InputSystem.InputAction _helpAction;
        private static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

        private sealed class Pulsed
        {
            public Renderer Renderer;
            public Material[] Shared;
            public Material[] Instances;
        }

        private readonly List<Pulsed> _pulsed = new();
        private StepDefinition _step;
        private float _idle;
        private float _pulseClock;
        private bool _repeated;
        private bool _repeatPending;
        private LineRenderer _line;
        private LineRenderer _arrow;
        private Material _lineMaterial;

        /// <summary>Se encendió la guía del paso (por tiempo o a pedido).</summary>
        public event Action<StepDefinition> GuideShown;

        /// <summary>Se pidió repetir la instrucción del paso (por tiempo o a pedido).</summary>
        public event Action<StepDefinition> InstructionRepeated;

        public bool GuideVisible { get; private set; }
        public int PulsedRendererCount => _pulsed.Count;
        public int RepeatCount { get; private set; }
        public float IdleSeconds => _idle;
        public Vector3 GuideDestination { get; private set; }
        public bool GuideGoesToAnchor { get; private set; }
        public LineRenderer GuideLine => _line;
        public StepSystem Steps { get => stepSystem; set { Unsubscribe(); stepSystem = value; Subscribe(); } }
        public float GuideDelaySeconds { get => guideDelaySeconds; set => guideDelaySeconds = Mathf.Max(0f, value); }
        public float RepeatDelaySeconds { get => repeatDelaySeconds; set => repeatDelaySeconds = Mathf.Max(0f, value); }
        public Transform Head { get => head; set => head = value; }

        /// <summary>Segundos sin avance hasta la guía para un paso.</summary>
        public float GuideDelayFor(StepDefinition step)
        {
            if (guideDelaySeconds > 0f) return guideDelaySeconds;
            return step != null && step.hintDelay > 0f ? step.hintDelay : FallbackDelaySeconds;
        }

        private float RepeatDelayFor(StepDefinition step) => repeatDelaySeconds > 0f ? repeatDelaySeconds : GuideDelayFor(step);

        /// <summary>
        /// Segundos sin avance hasta que el coach repite: la guía más otro tanto, y nunca antes de que la pista del
        /// <see cref="HintSystem"/> (a los <c>hintDelay</c>) haya tenido ese mismo margen, para no hablar dos veces seguidas.
        /// </summary>
        public float RepeatAtFor(StepDefinition step)
        {
            float repeat = RepeatDelayFor(step);
            float hint = step != null && step.hintDelay > 0f ? step.hintDelay : 0f;
            return Mathf.Max(GuideDelayFor(step) + repeat, hint + repeat);
        }

        private void Awake()
        {
            if (Instance == null) Instance = this;
        }

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            Subscribe();
            if (_helpAction == null)
            {
                _helpAction = new UnityEngine.InputSystem.InputAction("QueHago", UnityEngine.InputSystem.InputActionType.Button, HelpButtonBinding);
                _helpAction.performed += OnHelpButton;
            }
            _helpAction.Enable();
        }

        private void OnHelpButton(UnityEngine.InputSystem.InputAction.CallbackContext context) => RequestHelp();

        private void OnDisable()
        {
            if (_helpAction != null) _helpAction.Disable();
            Unsubscribe();
            HideGuide();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            if (_lineMaterial != null) Destroy(_lineMaterial);
            if (_helpAction != null) { _helpAction.performed -= OnHelpButton; _helpAction.Dispose(); _helpAction = null; }
        }

        private void Subscribe()
        {
            if (stepSystem == null || !isActiveAndEnabled) return;
            stepSystem.StepStarted -= OnStepStarted;
            stepSystem.StepStarted += OnStepStarted;
            stepSystem.StepCompleted -= OnStepCompleted;
            stepSystem.StepCompleted += OnStepCompleted;
            stepSystem.TaskCompleted -= OnTaskCompleted;
            stepSystem.TaskCompleted += OnTaskCompleted;
            stepSystem.JumpedToStep -= OnJumped;
            stepSystem.JumpedToStep += OnJumped;
            stepSystem.StepsFinished -= OnFinished;
            stepSystem.StepsFinished += OnFinished;
            if (stepSystem.IsRunning) Restart(stepSystem.CurrentStep);
        }

        private void Unsubscribe()
        {
            if (stepSystem == null) return;
            stepSystem.StepStarted -= OnStepStarted;
            stepSystem.StepCompleted -= OnStepCompleted;
            stepSystem.TaskCompleted -= OnTaskCompleted;
            stepSystem.JumpedToStep -= OnJumped;
            stepSystem.StepsFinished -= OnFinished;
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => Restart(step);
        private void OnStepCompleted(StepDefinition step, int index, float seconds) => Restart(null);
        private void OnTaskCompleted(StepDefinition step, int done, int total) => Restart(step);
        private void OnJumped(int from, int to) => Restart(stepSystem != null ? stepSystem.CurrentStep : null);
        private void OnFinished() => Restart(null);

        /// <summary>Empieza a contar de cero para el paso dado (null = nada que guiar) y apaga la guía.</summary>
        public void Restart(StepDefinition step)
        {
            HideGuide();
            _step = step;
            _idle = 0f;
            _repeated = false;
            _repeatPending = false;
        }

        private void Update()
        {
            Tick(Time.deltaTime);
            if (GuideVisible) Animate(Time.deltaTime);
            if (InputKeyCompat.IsKeyDown(KeyCode.H)) RequestHelp();   // modo pantalla: la tecla del «¿Qué hago?»
        }

        /// <summary>Avanza el contador de inactividad (el reloj de los tests).</summary>
        public void Tick(float deltaSeconds)
        {
            if (_step == null || _step.stepType != StepType.Interaction) return;
            if (_repeatPending) TryRepeat();
            if (HintSystem.Instance != null && HintSystem.Instance.Paused) return;

            _idle += Mathf.Max(0f, deltaSeconds);
            float delay = GuideDelayFor(_step);
            if (!GuideVisible && _idle >= delay) ShowGuide();
            if (!_repeated && _idle >= RepeatAtFor(_step))
            {
                _repeated = true;
                TryRepeat();
            }
        }

        /// <summary>«¿Qué hago?»: repite la instrucción y enciende la guía al instante.</summary>
        public void RequestHelp()
        {
            var step = _step != null ? _step : stepSystem != null ? stepSystem.CurrentStep : null;
            if (step == null) return;
            _step = step;
            TryRepeat();
            ShowGuide();
        }

        private void TryRepeat()
        {
            var vo = VOManager.Instance;
            // No pisar una corrección que esté sonando: se repite al terminar.
            if (vo != null && vo.IsSpeaking && vo.ActiveLine != null && vo.ActiveLine.IsError) { _repeatPending = true; return; }
            _repeatPending = false;
            RepeatCount++;
            if (vo != null && !_step.instructionLine.IsEmpty) vo.Say(_step.instructionLine);
            InstructionRepeated?.Invoke(_step);
        }

        /// <summary>Enciende el pulso de los objetivos y la línea de guía del paso en curso.</summary>
        public void ShowGuide()
        {
            if (_step == null) return;
            if (!GuideVisible)
            {
                GuideVisible = true;
                _pulseClock = 0f;
                StartPulse(_step);
                EnsureLine();
                _line.gameObject.SetActive(true);
                _arrow.gameObject.SetActive(true);
            }
            UpdateLine();
            GuideShown?.Invoke(_step);
        }

        /// <summary>Apaga la guía y devuelve los materiales originales.</summary>
        public void HideGuide()
        {
            GuideVisible = false;
            StopPulse();
            if (_line != null) _line.gameObject.SetActive(false);
            if (_arrow != null) _arrow.gameObject.SetActive(false);
        }

        private void Animate(float deltaSeconds)
        {
            _pulseClock += deltaSeconds;
            float wave = 0.5f + 0.5f * Mathf.Sin(_pulseClock * Mathf.PI * 2f / pulsePeriod);
            var emission = guideColor * (pulseIntensity * wave);
            foreach (var p in _pulsed)
                foreach (var m in p.Instances)
                    if (m != null && m.HasProperty(EmissionColorId)) m.SetColor(EmissionColorId, emission);
            UpdateLine();
        }

        // ── Pulso ───────────────────────────────────────────────────────────

        private void StartPulse(StepDefinition step)
        {
            StopPulse();
            if (step.activeTargetIds == null) return;
            foreach (var id in step.activeTargetIds)
            {
                if (string.IsNullOrEmpty(id) || !SceneTargetRegistry.TryGet(id, out var target) || target == null) continue;
                foreach (var renderer in target.GetComponentsInChildren<Renderer>())
                {
                    if (renderer is LineRenderer || renderer is ParticleSystemRenderer) continue;
                    var shared = renderer.sharedMaterials;
                    var instances = new Material[shared.Length];
                    for (int i = 0; i < shared.Length; i++)
                    {
                        if (shared[i] == null) continue;
                        instances[i] = new Material(shared[i]) { name = shared[i].name + " (guía)" };
                        instances[i].EnableKeyword("_EMISSION");
                        instances[i].globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
                        if (instances[i].HasProperty(EmissionColorId)) instances[i].SetColor(EmissionColorId, guideColor * pulseIntensity);
                    }
                    renderer.sharedMaterials = instances;
                    _pulsed.Add(new Pulsed { Renderer = renderer, Shared = shared, Instances = instances });
                }
            }
        }

        private void StopPulse()
        {
            foreach (var p in _pulsed)
            {
                if (p.Renderer != null) p.Renderer.sharedMaterials = p.Shared;
                foreach (var m in p.Instances)
                    if (m != null) Destroy(m);
            }
            _pulsed.Clear();
        }

        // ── Línea en el suelo ───────────────────────────────────────────────

        private void EnsureLine()
        {
            if (_line != null) return;
            if (_lineMaterial == null)
            {
                var shader = Shader.Find("Sprites/Default");
                _lineMaterial = shader != null ? new Material(shader) : null;
            }
            _line = NewLine("GuiaSuelo", 2);
            _arrow = NewLine("GuiaFlecha", 3);
        }

        private LineRenderer NewLine(string name, int points)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            var line = go.AddComponent<LineRenderer>();
            line.useWorldSpace = true;
            line.positionCount = points;
            line.widthMultiplier = lineWidth;
            line.numCapVertices = 4;
            line.alignment = LineAlignment.TransformZ;   // plana sobre el suelo
            go.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            line.startColor = line.endColor = guideColor;
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            line.receiveShadows = false;
            if (_lineMaterial != null) line.sharedMaterial = _lineMaterial;
            return line;
        }

        private void UpdateLine()
        {
            if (_line == null || _step == null) return;
            var headTransform = head != null ? head : Camera.main != null ? Camera.main.transform : null;
            Vector3 person = headTransform != null ? headTransform.position : transform.position;

            Vector3? targetPoint = null;
            float floorY = 0f;
            if (_step.activeTargetIds != null)
                foreach (var id in _step.activeTargetIds)
                    if (!string.IsNullOrEmpty(id) && SceneTargetRegistry.TryGet(id, out var target) && target != null)
                    {
                        targetPoint = target.position;
                        break;
                    }

            GuideGoesToAnchor = false;
            Vector3 destination = targetPoint ?? person;
            if (StepGuideAnchors.TryGetRecommended(_step.stepId, person, out var anchor))
            {
                var flat = anchor.GuidePosition - person;
                flat.y = 0f;
                if (flat.magnitude > nearAnchorDistance || targetPoint == null)
                {
                    destination = anchor.GuidePosition;
                    GuideGoesToAnchor = true;
                }
                floorY = anchor.GuidePosition.y;
            }
            else if (targetPoint.HasValue)
            {
                floorY = targetPoint.Value.y;
                var rig = headTransform != null && headTransform.parent != null ? headTransform.root : null;
                if (rig != null && rig != headTransform) floorY = rig.position.y;
            }
            GuideDestination = destination;

            const float lift = 0.02f;
            var start = new Vector3(person.x, floorY + lift, person.z);
            var end = new Vector3(destination.x, floorY + lift, destination.z);
            var dir = end - start;
            if (dir.sqrMagnitude < 1e-4f) dir = Vector3.forward * 0.01f;
            var forward = dir.normalized;
            // La línea empieza un poco delante de los pies, para que se vea al mirar abajo.
            start += forward * Mathf.Min(0.35f, dir.magnitude * 0.5f);
            _line.SetPosition(0, start);
            _line.SetPosition(1, end);
            var side = Vector3.Cross(Vector3.up, forward) * 0.22f;
            var back = -forward * 0.3f;
            _arrow.SetPosition(0, end + back + side);
            _arrow.SetPosition(1, end);
            _arrow.SetPosition(2, end + back - side);
        }
    }
}
