﻿using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>Tipo de señal que una condición puede reportar además de "cumplido".</summary>
    public enum StepSignalKind
    {
        /// <summary>Acción incorrecta: cuenta como error, el coach dice la corrección y el paso se repite.</summary>
        Error,

        /// <summary>Algo va mal pero es reversible: frase no bloqueante, una vez por paso, no cuenta.</summary>
        Warning,

        /// <summary>Progreso o comentario ("Capa uno de cuatro"): frase no bloqueante, no cuenta, puede repetirse.</summary>
        Info
    }

    /// <summary>Señal reportada por una condición (o por la escena vía StepSystem).</summary>
    public readonly struct StepSignal
    {
        public readonly StepSignalKind Kind;
        public readonly string Key;

        public StepSignal(StepSignalKind kind, string key)
        {
            Kind = kind;
            Key = key;
        }
    }

    /// <summary>
    /// Base abstracta para todas las condiciones de finalización de un paso.
    /// Cada tipo de interacción (grab, snap, inspect, etc.)
    /// debe heredar de esta clase.
    ///
    /// v0.6: una condición también puede reportar errores y avisos con
    /// <see cref="ReportError"/> / <see cref="ReportWarning"/>. La condición solo informa
    /// qué pasó; qué frase se dice lo decide el StepDefinition (errorLines).
    /// </summary>
    public abstract class StepCondition : ScriptableObject
    {
        private readonly Queue<StepSignal> _signals = new();

        /// <summary>
        /// Se llama cuando el paso inicia.
        /// Aquí se suscriben eventos o se inicializa estado.
        /// </summary>
        public abstract void Initialize();

        /// <summary>
        /// Devuelve TRUE cuando el usuario cumplió el paso.
        /// StepSystem consulta esto.
        /// </summary>
        public abstract bool IsCompleted();

        /// <summary>
        /// Limpieza al terminar el paso.
        /// Se desuscriben eventos y se resetea estado.
        /// </summary>
        public abstract void Cleanup();

        /// <summary>
        /// Se llama tras decir la corrección de un error, para volver a pedir el mismo paso.
        /// Por defecto reinicia la condición completa. Sobrescribir si se debe conservar
        /// progreso parcial (ej: capas ya colocadas).
        /// </summary>
        public virtual void Rearm()
        {
            Cleanup();
            Initialize();
        }

        /// <summary>
        /// Pista que depende del estado (ej: "ahora toca vegetal" vs "ahora toca estiércol").
        /// Vacío (por defecto) = usa StepDefinition.hintLine / instructionLine.
        /// </summary>
        public virtual LineRef CurrentHintLine => default;

        // 0.3 lote 5: «Continuar» que dice qué falta (contrato-0.3.md §2.7).

        /// <summary>
        /// 0.3 lote 5: lo pide el botón «Continuar» del HUD (o Intro en pantalla) a través de
        /// <see cref="StepSystem.TryConfirm"/>. Devuelve true si el paso puede cerrarse ya; si no, <paramref name="clave"/> es
        /// la clave de error que explica qué falta (null = la <c>claveIncompleto</c> del paso). Por defecto no confirma: el
        /// paso se cierra solo al cumplirse la condición, como siempre.
        /// </summary>
        public virtual bool TryConfirm(out string clave)
        {
            clave = null;
            return false;
        }

        /// <summary>
        /// 0.3 lote 5: todas las claves de lo que falta, en orden (la primera es la de <see cref="TryConfirm"/>). El coach
        /// las dice seguidas, así la persona oye la lista entera. Vacía por defecto.
        /// </summary>
        public virtual IReadOnlyList<string> MissingKeys() => System.Array.Empty<string>();

        /// <summary>Reporta una acción incorrecta. El paso no avanza.</summary>
        protected void ReportError(string errorKey) =>
            _signals.Enqueue(new StepSignal(StepSignalKind.Error, errorKey));

        /// <summary>Reporta un aviso (frase no bloqueante, una sola vez por paso).</summary>
        protected void ReportWarning(string warningKey) =>
            _signals.Enqueue(new StepSignal(StepSignalKind.Warning, warningKey));

        /// <summary>Reporta progreso (frase no bloqueante que no cuenta; ej: "Capa uno de cuatro").</summary>
        protected void ReportInfo(string infoKey) =>
            _signals.Enqueue(new StepSignal(StepSignalKind.Info, infoKey));

        /// <summary>Lo consume StepSystem cada frame.</summary>
        public bool TryConsumeSignal(out StepSignal signal)
        {
            if (_signals.Count > 0)
            {
                signal = _signals.Dequeue();
                return true;
            }
            signal = default;
            return false;
        }

        /// <summary>Descarta señales pendientes (al iniciar o terminar el paso).</summary>
        public void ClearSignals() => _signals.Clear();
    }
}
