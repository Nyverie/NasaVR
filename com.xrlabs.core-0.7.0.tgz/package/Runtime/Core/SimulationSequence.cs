using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Contenedor portable de todos los pasos de una simulación.
    /// El StepSystem lee de este asset en lugar de una lista local en la escena,
    /// lo que permite transportar, versionar y reutilizar la secuencia entre escenas.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Simulation Sequence")]
    public class SimulationSequence : ScriptableObject
    {
        [Header("Metadata")]
        public string sequenceName;
        [TextArea(1, 3)] public string description;
        public SimulationMode mode;

        [Header("Pasos")]
        public List<StepDefinition> steps = new();

        [Header("Secciones (navegación en debugger)")]
        [Tooltip("Agrupa pasos por sección para saltar fácilmente en el SimDebugHUD")]
        public List<StepSection> sections = new();

        // 0.3 lote 1: estado inicial de la escena (contrato 0.3 §2.1). Vacío = como antes.
        [Header("Estado (0.3)")]
        [Tooltip("Variables de 'estado' del guion con su valor inicial. Vacío: la experiencia no usa estado.")]
        public List<StateVariableDef> initialState = new();

        [Tooltip("Efectos de estado por paso: alCompletar y el alElegir de la opción correcta (para repetirlos en los saltos).")]
        public List<StepStateEffects> stepStateEffects = new();

        /// <summary>Los efectos de estado del paso con ese id, o null.</summary>
        public StepStateEffects GetStateEffects(string stepId)
        {
            if (string.IsNullOrEmpty(stepId) || stepStateEffects == null) return null;
            foreach (var e in stepStateEffects)
                if (e != null && e.stepId == stepId) return e;
            return null;
        }

        // 0.3 lote 6
        [Header("Bloqueos (0.3)")]
        [Tooltip("bloqueos del guion (contrato-0.3.md §2.8): los aplica LockEnforcer. Vacío = como antes.")]
        public List<StepLock> locks = new();

        // 0.3 lote 4
        [Header("Indicadores (0.3)")]
        [Tooltip("indicadores del guion (contrato-0.3.md §2.9): los muestra IndicatorPanel en el HUD; los de enInforme, el panel final. Vacío = sin panel.")]
        public List<StateIndicator> indicators = new();

        /// <summary>Número total de pasos en la secuencia.</summary>
        public int TotalSteps => steps != null ? steps.Count : 0;

        /// <summary>Retorna el StepDefinition en el índice dado, o null si está fuera de rango.</summary>
        public StepDefinition GetStep(int index)
        {
            if (steps == null || index < 0 || index >= steps.Count) return null;
            return steps[index];
        }

        /// <summary>Retorna el índice del primer paso de una sección por nombre. -1 si no existe.</summary>
        public int GetSectionStartIndex(string sectionName)
        {
            if (sections == null) return -1;
            foreach (var s in sections)
                if (s.sectionName == sectionName)
                    return s.startStepIndex;
            return -1;
        }
    }

    /// <summary>
    /// Agrupa un rango de pasos bajo un nombre de sección para navegación en el debugger.
    /// </summary>
    [Serializable]
    public class StepSection
    {
        [Tooltip("Nombre descriptivo de la sección (ej: 'Falla 1 - Presentación')")]
        public string sectionName;
        [Tooltip("Índice del primer paso de esta sección (0-based)")]
        public int startStepIndex;
    }

    // 0.3 lote 1: efectos de estado de un paso, ya resueltos por el importador (contrato 0.3 §2.1 y §2.5).
    [Serializable]
    public class StepStateEffects
    {
        public string stepId;
        [Tooltip("alCompletar: se aplica al cumplirse la condición.")]
        public List<StateEffect> onComplete = new();
        [Tooltip("alElegir de la opción correcta: la condición lo aplica al tocarla; aquí está para repetirlo en un salto.")]
        public List<StateEffect> onChooseCorrect = new();

        // 0.3 lote 4 (contrato-0.3.md §2.5): con 'segun', la opción correcta depende del estado al llegar al paso; en un
        // salto se repite el alElegir de la opción cuyo 'valor' es el de la variable en ese momento.
        [Tooltip("segun: la variable de texto que decide la opción correcta. Vacío: la correcta es fija (onChooseCorrect).")]
        public string chooseBy;
        [Tooltip("alElegir de cada opción por su 'valor' (solo con segun).")]
        public List<StateValueEffects> onChooseByValue = new();

        /// <summary>Los efectos de elegir la opción correcta con este estado: los fijos y, con segun, los de su valor.</summary>
        public List<StateEffect> ChooseEffectsFor(SimulationState state)
        {
            if (string.IsNullOrEmpty(chooseBy) || state == null || onChooseByValue == null) return onChooseCorrect;
            var result = new List<StateEffect>(onChooseCorrect ?? new List<StateEffect>());
            string value = state.GetText(chooseBy);
            foreach (var entry in onChooseByValue)
                if (entry != null && entry.value == value && entry.effects != null) result.AddRange(entry.effects);
            return result;
        }
    }

    // 0.3 lote 4: efectos asociados a un valor de una variable de texto.
    [Serializable]
    public class StateValueEffects
    {
        public string value;
        public List<StateEffect> effects = new();
    }
}
