using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core.Telemetry;

namespace XRLabs.Core
{
    /// <summary>
    /// Ejecuta la SimulationSequence paso a paso.
    ///
    /// Pasos v0.5 (sin frases del coach): flujo original sin cambios.
    /// Pasos v0.6 (con introLines / instructionLine / successLine):
    ///   1. introLines bloqueantes
    ///   2. Interaction: arma la condición, dice instructionLine sin bloquear, programa la pista
    ///      NonInteractive: avanza tras las frases
    ///   3. Error reportado → corrección bloqueante (errorLines) y se repite el paso
    ///      Aviso reportado → frase no bloqueante, una vez por paso
    ///   4. Acierto → tarea al checklist + feedback → successLine bloqueante → siguiente
    /// </summary>
    public class StepSystem : MonoBehaviour
    {
        /// <summary>Fase interna del paso actual.</summary>
        public enum StepPhase
        {
            Idle,
            /// <summary>Diciendo introLines.</summary>
            Intro,
            /// <summary>Esperando al usuario (o el auto-avance).</summary>
            Active,
            /// <summary>Diciendo la corrección de un error.</summary>
            Correcting,
            /// <summary>Diciendo la confirmación tras acertar.</summary>
            Confirming
        }

        [SerializeField] private SimulationSequence sequence;
        [SerializeField, Min(0f)] private float autoAdvanceGraceSeconds = 3f;

        [Tooltip("v0.6: pausa tras la última frase de un paso NonInteractive que usa frases del coach.")]
        [SerializeField, Min(0f)] private float lineAdvanceGraceSeconds = 0.4f;

        public event Action<StepDefinition, int, int> StepStarted;
        public event Action<StepDefinition, int, float> StepCompleted;
        public event Action StepsFinished;

        /// <summary>v0.6: error reportado en el paso (step, índice, clave).</summary>
        public event Action<StepDefinition, int, string> StepFailed;

        /// <summary>v0.6: aviso reportado en el paso (step, índice, clave). Una vez por clave y paso.</summary>
        public event Action<StepDefinition, int, string> StepWarned;

        /// <summary>v0.6: se completó un paso que cuenta como tarea (step, tareas hechas, total).</summary>
        public event Action<StepDefinition, int, int> TaskCompleted;

        /// <summary>v0.6: salto de capítulo (índice origen, índice destino), antes de iniciar el destino.</summary>
        public event Action<int, int> JumpedToStep;

        /// <summary>v0.6: cambió la fase del paso actual.</summary>
        public event Action<StepPhase> PhaseChanged;

        public SimulationSequence Sequence => sequence;
        public int TotalSteps => sequence != null ? sequence.TotalSteps : 0;
        public int CurrentStepIndex => _currentStepIndex;
        public StepDefinition CurrentStep => _currentStep;
        public bool IsRunning => _currentStep != null;
        public StepPhase Phase => _phase;

        /// <summary>Tareas, errores, ayudas y tiempo por sección de la sesión actual.</summary>
        public SessionStats Stats { get; } = new();

        private int _currentStepIndex;
        private StepDefinition _currentStep;
        private float _stepStartTime;
        private SimulationMode _simulationMode;
        private StepPhase _phase = StepPhase.Idle;
        private Coroutine _coachRoutine;
        private HintSystem _hintSource;

        // Auto-advance for NonInteractive steps
        private bool _autoAdvancePending;
        private float _autoAdvanceAt;

        // Condition logging: evita loggear IsCompleted() cada frame
        private bool _conditionMetLogged;

        // Señales que reporta la escena (no la condición) vía ReportError/ReportWarning
        private readonly Queue<StepSignal> _externalSignals = new();
        private readonly HashSet<string> _warnedKeys = new();

        public void StartSteps(SimulationMode mode)
        {
            _simulationMode = mode;
            _currentStepIndex = 0;
            Stats.Reset(CountTasks());
            SubscribeToHints();
            ResetStateForRun(); // 0.3 lote 2
            StartCurrentStep();
        }

        private void OnDestroy()
        {
            if (_hintSource != null)
                _hintSource.HintShown -= HandleHintShown;
            UnsubscribeState(); // 0.3 lote 2
        }

        private void Update()
        {
            if (_currentStep == null) return;

            Stats.AddTime(Time.deltaTime);

            if (_phase != StepPhase.Active) return;

            // NonInteractive: advance when VO sequence finishes
            if (_autoAdvancePending && Time.time >= _autoAdvanceAt)
            {
                _autoAdvancePending = false;
                CompleteStep(skipLines: false);
                return;
            }

            if (_currentStep.stepType != StepType.Interaction) return;

            var condition = _currentStep.completionCondition;

            // Errores y avisos antes que el acierto: si el usuario hizo algo mal en el mismo frame, se corrige.
            if (TryConsumeAnySignal(condition, out var signal))
            {
                HandleSignal(signal);
                return;
            }

            // 0.3 lote 5: Intro es «Continuar» en pantalla, solo con el coach callado (con una frase sonando, Intro la salta).
            if (ContinueKeyPressed())
            {
                TryConfirm();
                return;
            }

            // Interaction: poll condition
            if (condition != null && condition.IsCompleted())
            {
                if (!_conditionMetLogged)
                {
                    _conditionMetLogged = true;
                    Debug.Log($"[Step] ✓ Condición cumplida: <b>{condition.GetType().Name}</b> | paso: <b>{_currentStep.stepId}</b>");
                }
                CompleteStep(skipLines: false);
            }
        }

        // ── API pública v0.6 ──────────────────────────────────────────────────

        /// <summary>
        /// Reporta un error desde la escena (para pasos cuya validación vive en un componente
        /// de la sim y no en la condición). Mismo efecto que StepCondition.ReportError.
        /// </summary>
        public void ReportError(string errorKey) =>
            _externalSignals.Enqueue(new StepSignal(StepSignalKind.Error, errorKey));

        /// <summary>Reporta un aviso desde la escena. Mismo efecto que StepCondition.ReportWarning.</summary>
        public void ReportWarning(string warningKey) =>
            _externalSignals.Enqueue(new StepSignal(StepSignalKind.Warning, warningKey));

        /// <summary>Reporta progreso desde la escena. Mismo efecto que StepCondition.ReportInfo.</summary>
        public void ReportInfo(string infoKey) =>
            _externalSignals.Enqueue(new StepSignal(StepSignalKind.Info, infoKey));

        /// <summary>v0.6: progreso reportado en el paso (step, índice, clave).</summary>
        public event Action<StepDefinition, int, string> StepInfo;

        /// <summary>
        /// Salta a un paso (menú de capítulos, pruebas). Emite JumpedToStep para que la escena
        /// aplique los estados finales de los pasos saltados (ver StepEndStates).
        /// </summary>
        public void JumpToStep(int targetIndex)
        {
            if (targetIndex < 0 || targetIndex >= TotalSteps) return;

            StopCoachRoutine();
            _autoAdvancePending = false;

            if (_currentStep?.completionCondition != null)
            {
                _currentStep.completionCondition.Cleanup();
                _currentStep.completionCondition.ClearSignals();
            }

            if (HintSystem.Instance != null)
                HintSystem.Instance.CancelScheduledHint();

            VOManager.Instance?.StopVoice();

            int from = _currentStepIndex;
            _currentStepIndex = targetIndex;
            ReplayStateUpTo(targetIndex); // 0.3 lote 2
            JumpedToStep?.Invoke(from, targetIndex);
            StartCurrentStep();
        }

        /// <summary>Salta al primer paso de una sección por nombre. False si no existe.</summary>
        public bool JumpToSection(string sectionName)
        {
            if (sequence == null) return false;
            int index = sequence.GetSectionStartIndex(sectionName);
            if (index < 0) return false;
            JumpToStep(index);
            return true;
        }

        /// <summary>Nombre de la sección a la que pertenece un índice de paso (o null).</summary>
        public string GetSectionNameFor(int stepIndex)
        {
            if (sequence == null || sequence.sections == null) return null;
            StepSection best = null;
            foreach (var section in sequence.sections)
            {
                if (section == null || section.startStepIndex > stepIndex) continue;
                if (best == null || section.startStepIndex >= best.startStepIndex) best = section;
            }
            return best?.sectionName;
        }

        // ── Flujo del paso ────────────────────────────────────────────────────

        private void StartCurrentStep()
        {
            if (_currentStepIndex >= TotalSteps)
            {
                _currentStep = null;
                _autoAdvancePending = false;
                SetPhase(StepPhase.Idle);
                StepsFinished?.Invoke();
                return;
            }

            _currentStep = sequence.GetStep(_currentStepIndex);

            // 0.3 lote 2: la guarda 'si' se mira al llegar; si no se cumple, el paso se salta sin sonar ni contar.
            if (ShouldSkip(_currentStep))
            {
                SkipCurrentStep();
                return;
            }

            _stepStartTime = Time.time;
            _autoAdvancePending = false;
            _conditionMetLogged = false;
            _externalSignals.Clear();
            _warnedKeys.Clear();
            _reactionPlayback = null;
            _continueExtraKeys.Clear();   // 0.3 lote 5
            CompletedByContinue = false;
            _currentStep.completionCondition?.ClearSignals();
            Stats.EnterSection(GetSectionNameFor(_currentStepIndex));

            // SFX on enter
            if (VOManager.Instance != null && _currentStep.sfxOnEnter != null)
                VOManager.Instance.PlaySFX(_currentStep.sfxOnEnter);

            TelemetryContext.CurrentStepId = _currentStep.stepId;

            // 0.3 lote 2: 'avanzar' (cortinilla, días y alIniciar con la pantalla en negro) y alIniciar de los demás pasos.
            if (_currentStep.IsTimeAdvance)
            {
                StepStarted?.Invoke(_currentStep, _currentStepIndex, TotalSteps);
                _coachRoutine = StartCoroutine(RunTimeAdvanceStep(_currentStep));
                return;
            }
            ApplyEffects(_currentStep.onStartEffects);

            if (!_currentStep.UsesCoachLines)
            {
                StartLegacyStep();
                StepStarted?.Invoke(_currentStep, _currentStepIndex, TotalSteps);
                return;
            }

            // v0.6: el VO legado solo suena si el paso lo define (no cortar frases por un array vacío).
            if (VOManager.Instance != null && _currentStep.voSequence != null && _currentStep.voSequence.Length > 0)
                VOManager.Instance.PlaySequence(_currentStep.voSequence);

            StepStarted?.Invoke(_currentStep, _currentStepIndex, TotalSteps);
            _coachRoutine = StartCoroutine(RunCoachStep(_currentStep));
        }

        /// <summary>Flujo v0.5 tal cual.</summary>
        private void StartLegacyStep()
        {
            // Play VO sequence
            if (VOManager.Instance != null)
                VOManager.Instance.PlaySequence(_currentStep.voSequence);

            // Setup auto-advance for NonInteractive steps
            if (_currentStep.stepType == StepType.NonInteractive)
            {
                if (_currentStep.waitForManualCompletion)
                {
                    _autoAdvancePending = false;
                }
                else
                {
                    float voDuration = VOManager.Instance != null
                        ? VOManager.Instance.CurrentSequenceDuration
                        : 0f;
                    _autoAdvancePending = true;
                    _autoAdvanceAt = Time.time + voDuration + autoAdvanceGraceSeconds;
                }
            }
            else
            {
                // Interaction: initialize condition and schedule hint
                InitializeCondition();

                if (HintSystem.Instance != null)
                    HintSystem.Instance.ScheduleHint(_currentStep);
            }

            SetPhase(StepPhase.Active);
        }

        private IEnumerator RunCoachStep(StepDefinition step)
        {
            var vo = VOManager.Instance;

            SetPhase(StepPhase.Intro);
            if (vo != null && step.introLines != null)
            {
                foreach (var line in step.introLines)
                {
                    if (line.IsEmpty) continue;
                    yield return vo.WaitFor(vo.Say(ResolveLine(line)));
                }
            }

            if (step.stepType == StepType.NonInteractive)
            {
                SetPhase(StepPhase.Active);
                if (step.waitForManualCompletion)
                {
                    _coachRoutine = null;
                    yield break;
                }

                // Si además hay VO legado, esperar a que termine.
                while (vo != null && vo.IsSequencePlaying)
                    yield return null;

                if (lineAdvanceGraceSeconds > 0f)
                    yield return new WaitForSeconds(lineAdvanceGraceSeconds);

                _coachRoutine = null;
                CompleteStep(skipLines: false);
                yield break;
            }

            InitializeCondition();

            if (vo != null && !step.instructionLine.IsEmpty)
                vo.Say(ResolveLine(step.instructionLine));

            if (HintSystem.Instance != null)
                HintSystem.Instance.ScheduleHint(step);

            _coachRoutine = null;
            SetPhase(StepPhase.Active);
        }

        private void InitializeCondition()
        {
            if (_currentStep.completionCondition == null) return;

            _currentStep.completionCondition.Initialize();
            Debug.Log($"[Step] ◎ Condición escuchando: <b>{_currentStep.completionCondition.GetType().Name}</b> | paso: <b>{_currentStep.stepId}</b>");
        }

        // ── Errores y avisos ──────────────────────────────────────────────────

        // 0.3 lote 4: la opción de la señal en curso (de IStepSignalDetails), para metadata.opcion de step_error.
        private string _signalOption;

        private bool TryConsumeAnySignal(StepCondition condition, out StepSignal signal)
        {
            _signalOption = null;   // 0.3 lote 4
            if (_externalSignals.Count > 0)
            {
                signal = _externalSignals.Dequeue();
                return true;
            }

            if (condition != null && condition.TryConsumeSignal(out signal))
            {
                // 0.3 lote 4: la opción tocada (metadata.opcion), si la condición la da y la señal no es informativa.
                if (signal.Kind != StepSignalKind.Info && condition is IStepSignalDetails details)
                    _signalOption = details.TakeSignalOption();
                return true;
            }

            signal = default;
            return false;
        }

        private void HandleSignal(StepSignal signal)
        {
            var step = _currentStep;

            if (signal.Kind == StepSignalKind.Info)
            {
                StepInfo?.Invoke(step, _currentStepIndex, signal.Key);
                var infoLine = step.GetErrorLine(signal.Key, out bool hasInfoLine);
                if (hasInfoLine && !infoLine.IsEmpty && VOManager.Instance != null)
                    _reactionPlayback = VOManager.Instance.Say(ResolveLine(infoLine)); // 0.3 lote 2: el éxito la espera
                return;
            }

            TelemetryHub.Emit(new StepSignalEvent
            {
                StepId = step.stepId,
                StepIndex = _currentStepIndex,
                Kind = signal.Kind == StepSignalKind.Error ? "error" : "warning",
                Key = signal.Key,
                Option = _signalOption   // 0.3 lote 4
            });

            if (signal.Kind == StepSignalKind.Warning)
            {
                if (!_warnedKeys.Add(signal.Key ?? string.Empty)) return;

                Stats.Warning();
                StepWarned?.Invoke(step, _currentStepIndex, signal.Key);

                var warningLine = step.GetErrorLine(signal.Key, out bool hasWarningLine);
                if (hasWarningLine && !warningLine.IsEmpty)
                    VOManager.Instance?.Say(ResolveLine(warningLine));
                return;
            }

            _coachRoutine = StartCoroutine(RunCorrection(step, signal.Key));
        }

        private IEnumerator RunCorrection(StepDefinition step, string errorKey)
        {
            SetPhase(StepPhase.Correcting);

            if (HintSystem.Instance != null)
                HintSystem.Instance.CancelScheduledHint();

            Stats.Error();
            ScoringSystem.Instance?.RecomputeFromStats(Stats);

            if (FeedbackSystem.Instance != null)
                FeedbackSystem.Instance.ShowError(GetFeedbackPosition(step));

            StepFailed?.Invoke(step, _currentStepIndex, errorKey);
            Debug.Log($"[Step] ✗ Error <b>{errorKey}</b> | paso: <b>{step.stepId}</b>");

            var line = step.GetErrorLine(errorKey, out bool found);
            if (!found && line.IsEmpty)
                Debug.LogWarning($"[Step] El paso '{step.stepId}' no tiene frase para el error '{errorKey}' ni defaultErrorLine.");

            var vo = VOManager.Instance;
            if (vo != null && !line.IsEmpty)
                yield return vo.WaitFor(vo.Say(ResolveLine(line), isError: true));

            // 0.3 lote 5: un «Continuar» incompleto dice, tras la primera, la frase de cada otra cosa que falta (la lista).
            if (_continueExtraKeys.Count > 0)
            {
                var extra = new List<string>(_continueExtraKeys);
                _continueExtraKeys.Clear();
                foreach (var key in extra)
                {
                    var extraLine = step.GetErrorLine(key, out bool hasExtra);
                    if (vo != null && hasExtra && !extraLine.IsEmpty)
                        yield return vo.WaitFor(vo.Say(ResolveLine(extraLine), isError: true));
                }
            }

            // 0.3 lote 2: 'alError', después de la corrección y antes de repetir.
            ApplyEffects(step.GetErrorEffects(errorKey));

            // Lo que el usuario hizo mientras sonaba la corrección no cuenta.
            _externalSignals.Clear();
            if (step.completionCondition != null)
            {
                step.completionCondition.ClearSignals();
                step.completionCondition.Rearm();
            }

            if (step.repeatInstructionAfterError && vo != null && !step.instructionLine.IsEmpty)
                vo.Say(ResolveLine(step.instructionLine));

            if (HintSystem.Instance != null)
                HintSystem.Instance.ScheduleHint(step);

            _coachRoutine = null;
            SetPhase(StepPhase.Active);
        }

        // ── Cierre del paso ───────────────────────────────────────────────────

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        /// <summary>Solo debug. Fuerza completar el paso actual sin importar su condición.</summary>
        public void DebugForceAdvanceCurrentStep()
        {
            if (_currentStep != null)
                CompleteStep(skipLines: true);
        }

        /// <summary>Solo debug. Salta directamente a un paso por índice (0-based).</summary>
        public void DebugJumpToStep(int targetIndex)
        {
            JumpToStep(targetIndex);
        }
#endif

        public void CompleteCurrentStep()
        {
            if (_currentStep != null)
                CompleteStep(skipLines: false);
        }

        private void CompleteStep(bool skipLines)
        {
            if (_phase == StepPhase.Confirming)
            {
                // El paso ya se cerró y solo falta la confirmación: no volver a contarlo.
                if (!skipLines) return;
                StopCoachRoutine();
                VOManager.Instance?.StopVoice();
                AdvanceToNextStep();
                return;
            }

            StopCoachRoutine();

            var completedStep = _currentStep;
            float elapsedTime = Time.time - _stepStartTime;

            _autoAdvancePending = false;

            if (HintSystem.Instance != null)
                HintSystem.Instance.CancelScheduledHint();

            if (completedStep.completionCondition != null)
            {
                completedStep.completionCondition.Cleanup();
                completedStep.completionCondition.ClearSignals();
            }

            // SFX on complete
            if (VOManager.Instance != null && completedStep.sfxOnComplete != null)
                VOManager.Instance.PlaySFX(completedStep.sfxOnComplete);

            if (completedStep.countsAsTask)
            {
                Stats.TaskDone();
                if (FeedbackSystem.Instance != null)
                    FeedbackSystem.Instance.ShowSuccess(GetFeedbackPosition(completedStep));
                TaskCompleted?.Invoke(completedStep, Stats.TasksDone, Stats.TotalTasks);
            }

            if (ScoringSystem.Instance != null)
            {
                ScoringSystem.Instance.RegisterStepResult(
                    completedStep,
                    elapsedTime,
                    _simulationMode,
                    _currentStepIndex
                );
                ScoringSystem.Instance.RecomputeFromStats(Stats);
            }

            // 0.3: alCompletar (lote 1), antes de StepCompleted y de la frase de éxito. El StepSystem es la única ruta que
            // aplica efectos de estado (alIniciar, alError, avanzar, alCompletar y su repetición en los saltos), así que cada
            // efecto se aplica una vez; el SimulationStateHost guarda la tabla y manda state_changed.
            ApplyEffects(sequence != null ? sequence.GetStateEffects(completedStep.stepId)?.onComplete : null);

            StepCompleted?.Invoke(completedStep, _currentStepIndex, elapsedTime);

            if (!skipLines && !completedStep.successLine.IsEmpty && VOManager.Instance != null)
            {
                _coachRoutine = StartCoroutine(RunConfirmation(completedStep));
                return;
            }

            AdvanceToNextStep();
        }

        private IEnumerator RunConfirmation(StepDefinition step)
        {
            SetPhase(StepPhase.Confirming);
            var vo = VOManager.Instance;
            // 0.3 lote 2 (contrato-0.3.md §2.6): si una reacción sigue sonando, el éxito espera a que termine.
            if (_reactionPlayback != null && !_reactionPlayback.IsDone)
                yield return vo.WaitFor(_reactionPlayback);
            _reactionPlayback = null;
            yield return vo.WaitFor(vo.Say(ResolveLine(step.successLine)));
            _coachRoutine = null;
            AdvanceToNextStep();
        }

        private void AdvanceToNextStep()
        {
            _currentStepIndex++;
            StartCurrentStep();
        }

        // ── 0.3 lote 5: «Continuar» que dice qué falta (contrato-0.3.md §2.7) ──────────────────

        /// <summary>La tecla de «Continuar» en pantalla (en el visor, el botón del HUD con el rayo).</summary>
        public const KeyCode ContinueKey = KeyCode.Return;

        /// <summary>
        /// True si el último paso cerrado lo cerró «Continuar» (para <c>metadata.porContinuar</c>); vuelve a false al empezar
        /// el siguiente paso.
        /// </summary>
        public bool CompletedByContinue { get; private set; }

        /// <summary>True mientras el paso en curso escucha «Continuar» (el HUD enseña el botón).</summary>
        public bool CanContinue => _currentStep != null && _phase == StepPhase.Active && _currentStep.AcceptsContinue;

        /// <summary>«Continuar» incompleto: paso, índice y claves de lo que falta, en orden.</summary>
        public event Action<StepDefinition, int, IReadOnlyList<string>> ContinueRejected;

        private readonly List<string> _continueExtraKeys = new();
        private bool _voWasSpeaking;

        /// <summary>
        /// 0.3 lote 5: lo que hace el botón «Continuar» (o Intro). Con la condición cumplida (o si ella confirma con
        /// <see cref="StepCondition.TryConfirm"/>) cierra el paso; si no, reporta un error con la clave de lo que falta
        /// (o la <c>claveIncompleto</c> del paso) y sigue el camino de siempre: corrección, cuenta, se repite, 'alError'.
        /// La corrección dice, seguidas, las frases de todo lo que falta. Devuelve true si cerró el paso.
        /// </summary>
        public bool TryConfirm()
        {
            var step = _currentStep;
            if (!CanContinue) return false;

            var condition = step.completionCondition;
            string key = null;
            if (condition == null || condition.IsCompleted() || condition.TryConfirm(out key))
            {
                CompletedByContinue = true;
                Debug.Log($"[Step] ✓ Continuar con la condición cumplida | paso: <b>{step.stepId}</b>");
                CompleteStep(skipLines: false);
                return true;
            }

            var keys = new List<string>();
            if (!string.IsNullOrEmpty(key)) keys.Add(key);
            var missing = condition.MissingKeys();
            if (missing != null)
                foreach (var k in missing)
                    if (!string.IsNullOrEmpty(k) && !keys.Contains(k)) keys.Add(k);
            if (keys.Count == 0 && !string.IsNullOrEmpty(step.continueIncompleteKey)) keys.Add(step.continueIncompleteKey);

            ContinueRejected?.Invoke(step, _currentStepIndex, keys);
            _continueExtraKeys.Clear();
            for (int i = 1; i < keys.Count; i++) _continueExtraKeys.Add(keys[i]);
            // Integración de los lotes 4 y 5: el rechazo de «Continuar» no viene de tocar una opción; sin esto, un clic del
            // botón en el mismo frame que una señal de 'elegir' heredaría su metadata.opcion.
            _signalOption = null;
            HandleSignal(new StepSignal(StepSignalKind.Error, keys.Count > 0 ? keys[0] : null));
            return false;
        }

        private bool ContinueKeyPressed()
        {
            var vo = VOManager.Instance;
            bool speaking = vo != null && vo.IsSpeaking;
            bool wasSpeaking = _voWasSpeaking;
            _voWasSpeaking = speaking;
            if (!_currentStep.AcceptsContinue || speaking || wasSpeaking) return false;
            return InputKeyCompat.IsKeyDown(ContinueKey) || InputKeyCompat.IsKeyDown(KeyCode.KeypadEnter);
        }

        // ── 0.3 lote 2: estado, guardas, efectos, {variable} y avanzar ──────────
        // contrato-0.3.md §2.1–§2.3. Todo lo guarda un campo vacío del paso: sin 'si', sin efectos y sin 'avanzar' el
        // flujo es el de antes (D8).

        /// <summary>Nombre de la variable que suma 'avanzar' (la declara el importador).</summary>
        public const string DayVariable = "dia";

        /// <summary>0.3: un paso se saltó por su guarda 'si' (step, índice).</summary>
        public event Action<StepDefinition, int> StepSkipped;

        /// <summary>0.3: empieza la cortinilla de un 'avanzar' (step, segundos totales del fundido).</summary>
        public event Action<StepDefinition, float> TimeAdvanceStarted;

        /// <summary>0.3: con la pantalla en negro ya se sumaron los días (step, días, día actual, texto de la etiqueta).</summary>
        public event Action<StepDefinition, int, int, string> TimeAdvanced;

        /// <summary>0.3: termina la cortinilla (se vuelve a ver la escena).</summary>
        public event Action<StepDefinition> TimeAdvanceFinished;

        private StepDefinition _advancePendingStep;
        private StepDefinition _curtainStep;
        private SimulationState _ownState;
        private SimulationState _stateOverride;
        private SimulationState _subscribedState;
        private LinePlayback _reactionPlayback;

        /// <summary>
        /// 0.3: la tabla de estado de la escena: la del <see cref="SimulationStateHost"/> si hay uno; si no, una propia con el
        /// estado inicial de la secuencia (o null si la secuencia no declara estado).
        /// </summary>
        public SimulationState State
        {
            get
            {
                if (_stateOverride != null) return _stateOverride;
                var host = SimulationStateHost.Current;
                if (host != null) return host.State;
                if (_ownState == null && sequence != null && sequence.initialState != null && sequence.initialState.Count > 0)
                    _ownState = new SimulationState(sequence.initialState);
                return _ownState;
            }
        }

        /// <summary>0.3, para pruebas y herramientas: usa esta tabla en vez de la de la escena (null = volver a la de la escena).</summary>
        public void UseState(SimulationState state)
        {
            _stateOverride = state;
            SubscribeState();
        }

        /// <summary>
        /// 0.3 (§2.2): sustituye cada <c>{variable}</c> del texto por su valor actual. Variables desconocidas quedan como
        /// están (el validador ya las rechazó al importar).
        /// </summary>
        public static string ExpandVariables(string template, SimulationState state)
        {
            if (string.IsNullOrEmpty(template) || state == null || template.IndexOf('{') < 0) return template;
            var sb = new System.Text.StringBuilder(template.Length);
            int i = 0;
            while (i < template.Length)
            {
                char c = template[i];
                if (c == '{')
                {
                    int close = template.IndexOf('}', i + 1);
                    if (close > i)
                    {
                        var name = template.Substring(i + 1, close - i - 1);
                        var value = state.Has(name) ? state.Format(name) : null;
                        if (value != null)
                        {
                            sb.Append(value);
                            i = close + 1;
                            continue;
                        }
                    }
                }
                sb.Append(c);
                i++;
            }
            return sb.ToString();
        }

        /// <summary>0.3: la frase con su id ya sustituido (la voz está horneada: el valor va en el id).</summary>
        public LineRef ResolveLine(LineRef line)
        {
            if (line.IsEmpty || line.id.IndexOf('{') < 0) return line;
            return new LineRef(ExpandVariables(line.id, State));
        }

        private void ResetStateForRun()
        {
            _ownState = null;
            var state = State;
            state?.Reset();
            SubscribeState();
        }

        // state_changed sale una vez por cambio: la tabla del SimulationStateHost la reporta el host; aquí solo se escucha la
        // propia del StepSystem o la de UseState.
        private void SubscribeState()
        {
            var state = State;
            var host = SimulationStateHost.Current;
            if (state != null && host != null && ReferenceEquals(state, host.State)) state = null;
            if (ReferenceEquals(state, _subscribedState)) return;
            UnsubscribeState();
            _subscribedState = state;
            if (_subscribedState != null) _subscribedState.Changed += HandleStateChanged;
        }

        private void UnsubscribeState()
        {
            if (_subscribedState != null) _subscribedState.Changed -= HandleStateChanged;
            _subscribedState = null;
        }

        private void HandleStateChanged(StateChange change)
        {
            if (!change.Register) return;
            TelemetryHub.Emit(new StateChangedEvent
            {
                StepId = _currentStep != null ? _currentStep.stepId : TelemetryContext.CurrentStepId,
                Variable = change.Variable,
                Before = change.Before,
                Value = change.After
            });
        }

        private bool ShouldSkip(StepDefinition step)
        {
            if (step == null || !step.HasGuard) return false;
            var state = State;
            // Sin tabla no hay con qué comparar: la guarda no se cumple (el validador exige declarar las variables).
            return state == null || !state.Evaluate(step.guard);
        }

        private void SkipCurrentStep()
        {
            var step = _currentStep;
            Debug.Log($"[Step] ↷ Paso saltado por 'si': <b>{step.stepId}</b>");
            if (step.countsAsTask)
            {
                Stats.SkipTask();
                ScoringSystem.Instance?.RegisterSkippedStep(step, Stats);
            }
            TelemetryHub.Emit(new StepSkippedEvent { StepId = step.stepId, StepIndex = _currentStepIndex, Reason = "si" });
            StepSkipped?.Invoke(step, _currentStepIndex);
            _currentStepIndex++;
            StartCurrentStep();
        }

        private void ApplyEffects(List<StateEffect> effects)
        {
            if (effects == null || effects.Count == 0) return;
            var state = State;
            if (state == null)
            {
                Debug.LogWarning($"[Step] El paso '{_currentStep?.stepId}' tiene efectos de estado y la escena no tiene estado.");
                return;
            }
            SubscribeState();
            state.Apply(effects);
        }

        private int ApplyTimeAdvance(StepDefinition step)
        {
            var state = State;
            int day = 0;
            if (state != null && state.Has(DayVariable))
            {
                SubscribeState();
                state.Apply(StateEffect.Add(DayVariable, step.advanceDays));
                day = (int)Math.Round(state.GetNumber(DayVariable));
            }
            else
                Debug.LogWarning($"[Step] El paso 'avanzar' '{step.stepId}' no encuentra la variable '{DayVariable}' en el estado.");

            ApplyEffects(step.onStartEffects);
            TelemetryHub.Emit(new TimeAdvancedEvent { StepId = step.stepId, Days = step.advanceDays, Day = day });
            return day;
        }

        private string ResolveAdvanceLabel(StepDefinition step)
        {
            if (string.IsNullOrEmpty(step.advanceLabel)) return string.Empty;
            string text = step.advanceLabel;
            var vo = VOManager.Instance;
            if (vo != null && vo.TryResolve(step.advanceLabel, out var resolved) && !string.IsNullOrEmpty(resolved.Text))
                text = resolved.Text;
            return ExpandVariables(text, State);
        }

        /// <summary>
        /// 'avanzar': funde a negro, suma los días y aplica alIniciar con la pantalla en negro, enseña la etiqueta, vuelve
        /// a la escena y sigue con la introducción. El fundido se reparte en tres tercios (entrar, etiqueta, salir).
        /// </summary>
        private IEnumerator RunTimeAdvanceStep(StepDefinition step)
        {
            SetPhase(StepPhase.Intro);
            float fade = Mathf.Clamp(step.advanceFadeSeconds, 0f, 5f);
            float third = fade / 3f;

            _advancePendingStep = step;
            if (fade > 0f)
            {
                _curtainStep = step;
                TimeAdvanceStarted?.Invoke(step, fade);
                yield return new WaitForSeconds(third);
            }

            _advancePendingStep = null;
            int day = ApplyTimeAdvance(step);
            TimeAdvanced?.Invoke(step, step.advanceDays, day, ResolveAdvanceLabel(step));

            if (fade > 0f)
            {
                yield return new WaitForSeconds(third);
                _curtainStep = null;
                TimeAdvanceFinished?.Invoke(step);
                yield return new WaitForSeconds(third);
            }

            // Sigue como un paso de narración: introducción (si la hay) y cierre solo. No suma tarea ni puntaje.
            yield return RunCoachStep(step);
        }

        // Completar o saltar a mitad de la cortinilla (panel de desarrollo, capítulos): los días se suman igual y la
        // cortinilla se va; si no, se quedaría en negro.
        private void FinishInterruptedTimeAdvance()
        {
            if (_advancePendingStep != null)
            {
                var pending = _advancePendingStep;
                _advancePendingStep = null;
                // 0.3 lote 7: los días y el alIniciar se aplican aunque nadie escuche TimeAdvanced. Antes iban como argumento
                // de «TimeAdvanced?.Invoke(...)», que no evalúa sus argumentos si el evento no tiene suscriptores: sin la
                // cortinilla, completar un 'avanzar' en pleno fundido no sumaba los días ni ponía las lecturas de la semana.
                int day = ApplyTimeAdvance(pending);
                TimeAdvanced?.Invoke(pending, pending.advanceDays, day, ResolveAdvanceLabel(pending));
                // fin 0.3 lote 7
            }
            if (_curtainStep != null)
            {
                var shown = _curtainStep;
                _curtainStep = null;
                TimeAdvanceFinished?.Invoke(shown);
            }
        }

        /// <summary>
        /// Saltos (§4): el estado vuelve al inicial y se aplican, en orden, los efectos de los pasos anteriores al destino
        /// cuya guarda se cumplía, como en un recorrido: los días de 'avanzar', alIniciar, el alElegir de la opción correcta
        /// de un elegir y alCompletar (los dos últimos, de <see cref="SimulationSequence.stepStateEffects"/>). alError no se
        /// repite: un salto supone el recorrido sin errores. Adelante y atrás dan lo mismo: son datos.
        /// </summary>
        private void ReplayStateUpTo(int targetIndex)
        {
            var state = State;
            if (state == null || sequence == null) return;
            SubscribeState();
            state.Reset();
            for (int i = 0; i < targetIndex && i < TotalSteps; i++)
            {
                var step = sequence.GetStep(i);
                if (step == null) continue;
                if (step.HasGuard && !state.Evaluate(step.guard)) continue;
                if (step.IsTimeAdvance && state.Has(DayVariable))
                    state.Apply(StateEffect.Add(DayVariable, step.advanceDays));
                state.Apply(step.onStartEffects);
                var recorded = sequence.GetStateEffects(step.stepId);
                if (recorded == null) continue;
                state.Apply(recorded.ChooseEffectsFor(state));   // 0.3 lote 4: con 'segun', la opción del valor de ese momento
                state.Apply(recorded.onComplete);
            }
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        private void SetPhase(StepPhase phase)
        {
            if (_phase == phase) return;
            _phase = phase;
            PhaseChanged?.Invoke(phase);
        }

        private void StopCoachRoutine()
        {
            if (_coachRoutine == null) return;
            StopCoroutine(_coachRoutine);
            _coachRoutine = null;
            FinishInterruptedTimeAdvance(); // 0.3 lote 2
        }

        private int CountTasks()
        {
            if (sequence == null || sequence.steps == null) return 0;
            int count = 0;
            foreach (var step in sequence.steps)
                if (step != null && step.countsAsTask) count++;
            return count;
        }

        private void SubscribeToHints()
        {
            if (_hintSource != null) _hintSource.HintShown -= HandleHintShown;
            _hintSource = HintSystem.Instance;
            if (_hintSource != null) _hintSource.HintShown += HandleHintShown;
        }

        private void HandleHintShown(StepDefinition step)
        {
            Stats.Hint();
            ScoringSystem.Instance?.RecomputeFromStats(Stats);
        }

        private static Vector3? GetFeedbackPosition(StepDefinition step)
        {
            if (SceneTargetRegistry.TryGet(step.pointAtTargetId, out var target))
                return target.position;

            if (step.activeTargetIds != null)
                foreach (var id in step.activeTargetIds)
                    if (SceneTargetRegistry.TryGet(id, out target))
                        return target.position;

            return null;
        }
    }
}
