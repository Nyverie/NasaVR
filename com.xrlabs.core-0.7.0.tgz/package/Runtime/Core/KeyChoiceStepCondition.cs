using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Condición de demo y pruebas del flujo del coach sin headset: una tecla acierta,
    /// otra reporta un error y otra un aviso. Sirve para probar errorLines, reintento y
    /// avisos antes de tener las interacciones reales.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Key Choice (demo)")]
    public class KeyChoiceStepCondition : StepCondition
    {
        [SerializeField] private KeyCode correctKey = KeyCode.Alpha1;
        [SerializeField] private KeyCode errorKey = KeyCode.Alpha2;
        [SerializeField] private string errorKeyId = "wrong_choice";
        [SerializeField] private KeyCode warningKey = KeyCode.Alpha3;
        [SerializeField] private string warningKeyId = "careful";

        private bool _completed;

        public override void Initialize() => _completed = false;

        public override bool IsCompleted()
        {
            if (_completed) return true;

            if (InputKeyCompat.IsKeyDown(errorKey)) ReportError(errorKeyId);
            else if (InputKeyCompat.IsKeyDown(warningKey)) ReportWarning(warningKeyId);
            else if (InputKeyCompat.IsKeyDown(correctKey)) _completed = true;

            return _completed;
        }

        public override void Cleanup() => _completed = false;

        /// <summary>Para pruebas automáticas: simula cada tecla.</summary>
        public void SimulateCorrect() => _completed = true;
        public void SimulateError() => ReportError(errorKeyId);
        public void SimulateWarning() => ReportWarning(warningKeyId);
    }
}
