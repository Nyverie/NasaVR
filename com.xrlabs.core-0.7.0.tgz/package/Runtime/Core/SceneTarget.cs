using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Registra este objeto en SceneTargetRegistry con un ID estable, para que el coach
    /// pueda señalarlo aunque no sea interactuable (ej: la pila, una zona del terreno).
    /// Los InteractableBase ya se registran solos con su InteractionId.
    /// </summary>
    public class SceneTarget : MonoBehaviour
    {
        [Tooltip("ID estable. Vacío = nombre del GameObject.")]
        [SerializeField] private string targetId;

        public string TargetId => string.IsNullOrEmpty(targetId) ? gameObject.name : targetId;

        private void OnEnable() => SceneTargetRegistry.Register(TargetId, transform);

        private void OnDisable() => SceneTargetRegistry.Unregister(TargetId, transform);
    }
}
