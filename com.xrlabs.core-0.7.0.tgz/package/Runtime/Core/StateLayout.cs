using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    // 0.3 lote 1: posicionSegun (contrato 0.3 §2.10).

    /// <summary>Un lugar de <see cref="StateLayout"/>: el valor de la variable y la pose local (ejes de Unity) del lugar.</summary>
    [Serializable]
    public class StateLayoutPlace
    {
        public string value;
        public Vector3 position;
        public float yaw;
    }

    /// <summary>
    /// Lleva su objeto (el <c>Conjunto_&lt;id&gt;</c> de la colocación) al lugar que corresponde al valor de una variable de
    /// texto: su posición local pasa a ser la del lugar más <see cref="offset"/>, y con <see cref="applyYaw"/> también el giro.
    /// Un valor sin lugar lo deja en su pose escrita (<see cref="defaultPosition"/>, <see cref="defaultYaw"/>). Se mueve en
    /// el mismo fotograma del cambio, sin animación: el guion lo escribe para que ocurra oculto. Como
    /// <see cref="StateVisibility"/>, se evalúa en Awake (orden -300) y a cada cambio aunque esté inactivo.
    /// </summary>
    [DefaultExecutionOrder(-300)]
    [DisallowMultipleComponent]
    public class StateLayout : MonoBehaviour
    {
        [Tooltip("Variable de texto del estado que decide el lugar.")]
        public string variable;
        public List<StateLayoutPlace> places = new();
        [Tooltip("true: también toma el giro del lugar (posicionSegun.girar).")]
        public bool applyYaw;
        [Tooltip("Desplazamiento desde el lugar, en ejes de Unity (posicionSegun.desplazar).")]
        public Vector3 offset;
        [Tooltip("Pose local escrita (el 'origen' del conjunto): la del valor sin lugar.")]
        public Vector3 defaultPosition;
        public float defaultYaw;

        private SimulationState _state;
        private SimulationStateHost _host;

        private void Awake()
        {
            _host = SimulationStateHost.Current;
            if (_host == null) return;
            _host.StateCreated += Bind;
            Bind(_host.State);
        }

        private void OnDestroy()
        {
            if (_state != null) _state.Changed -= OnChanged;
            if (_host != null) _host.StateCreated -= Bind;
        }

        private void Bind(SimulationState state)
        {
            if (_state != null) _state.Changed -= OnChanged;
            _state = state;
            if (_state != null) _state.Changed += OnChanged;
            Refresh();
        }

        private void OnChanged(StateChange change)
        {
            if (change.Variable == variable) Refresh();
        }

        /// <summary>El lugar del valor actual, o null (queda en su pose escrita).</summary>
        public StateLayoutPlace CurrentPlace
        {
            get
            {
                var value = _state?.GetText(variable);
                if (value == null || places == null) return null;
                foreach (var p in places)
                    if (p != null && p.value == value) return p;
                return null;
            }
        }

        /// <summary>Coloca el objeto según el estado actual.</summary>
        public void Refresh()
        {
            if (this == null) return;
            var place = CurrentPlace;
            var t = transform;
            if (place == null)
            {
                t.localPosition = defaultPosition;
                t.localRotation = Quaternion.Euler(0f, defaultYaw, 0f);
                return;
            }
            t.localPosition = place.position + offset;
            t.localRotation = Quaternion.Euler(0f, applyYaw ? place.yaw : defaultYaw, 0f);
        }
    }
}
