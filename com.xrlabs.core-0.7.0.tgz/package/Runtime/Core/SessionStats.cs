using System;
using System.Collections.Generic;

namespace XRLabs.Core
{
    /// <summary>
    /// Contadores de la sesión que alimentan el puntaje por tareas/errores/ayudas y el
    /// informe final. Lo mantiene el StepSystem; la UI lo lee.
    /// </summary>
    [Serializable]
    public class SessionStats
    {
        [Serializable]
        public class SectionStats
        {
            public string sectionName;
            public float seconds;
            public int tasks;
            public int errors;
            public int hints;
        }

        public int TotalTasks { get; internal set; }
        public int TasksDone { get; private set; }
        public int Errors { get; private set; }
        public int Warnings { get; private set; }
        public int Hints { get; private set; }

        public IReadOnlyList<SectionStats> Sections => _sections;

        public event Action Changed;

        private readonly List<SectionStats> _sections = new();
        private SectionStats _currentSection;

        /// <summary>precisión = tareas / (tareas + errores) × 100. Sin intentos = 100.</summary>
        public float Accuracy =>
            TasksDone + Errors == 0 ? 100f : TasksDone * 100f / (TasksDone + Errors);

        public void Reset(int totalTasks)
        {
            TotalTasks = totalTasks;
            TasksDone = 0;
            Errors = 0;
            Warnings = 0;
            Hints = 0;
            SkippedTasks = 0;
            _sections.Clear();
            _currentSection = null;
            Changed?.Invoke();
        }

        public void EnterSection(string sectionName)
        {
            if (string.IsNullOrEmpty(sectionName)) return;
            if (_currentSection != null && _currentSection.sectionName == sectionName) return;

            _currentSection = _sections.Find(s => s.sectionName == sectionName);
            if (_currentSection == null)
            {
                _currentSection = new SectionStats { sectionName = sectionName };
                _sections.Add(_currentSection);
            }
        }

        public void AddTime(float seconds)
        {
            if (_currentSection != null && seconds > 0f)
                _currentSection.seconds += seconds;
        }

        public void TaskDone()
        {
            TasksDone++;
            if (_currentSection != null) _currentSection.tasks++;
            Changed?.Invoke();
        }

        public void Error()
        {
            Errors++;
            if (_currentSection != null) _currentSection.errors++;
            Changed?.Invoke();
        }

        public void Warning()
        {
            Warnings++;
            Changed?.Invoke();
        }

        /// <summary>
        /// 0.3 lote 2 (contrato-0.3.md §2.1): un paso que cuenta como tarea se saltó por su guarda 'si'. Descuenta la tarea
        /// del total para que el checklist y el informe no esperen algo que no se pidió.
        /// </summary>
        public int SkippedTasks { get; private set; }

        public void SkipTask()
        {
            if (TotalTasks > 0) TotalTasks--;
            SkippedTasks++;
            Changed?.Invoke();
        }

        public void Hint()
        {
            Hints++;
            if (_currentSection != null) _currentSection.hints++;
            Changed?.Invoke();
        }
    }
}
