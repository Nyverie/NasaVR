﻿using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Lightweight IMGUI overlay for editor demos without needing a Canvas setup.
    /// </summary>
    public class CoreSimulationDemoHUD : MonoBehaviour
    {
        [SerializeField] private bool showHud = true;
        [SerializeField] private int width = 440;
        [SerializeField] private int height = 220;

        private Rect _windowRect = new Rect(20f, 20f, 440f, 220f);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        private void Update()
        {
            if (InputKeyCompat.IsKeyDown(KeyCode.F1))
            {
                showHud = !showHud;
            }
        }

        private void OnGUI()
        {
            if (!showHud)
            {
                return;
            }

            _windowRect.width = Mathf.Max(300, width);
            _windowRect.height = Mathf.Max(180, height);
            _windowRect = GUILayout.Window(12035, _windowRect, DrawWindow, "Core Simulation Demo HUD");
        }

        private void DrawWindow(int id)
        {
            var simulationManager = SimulationManager.Instance;
            var stepSystem = simulationManager != null ? simulationManager.GetComponent<StepSystem>() : null;
            var scoringSystem = ScoringSystem.Instance;

            if (simulationManager == null)
            {
                GUILayout.Label("SimulationManager: no encontrado en escena.");
                GUILayout.Label("Agrega SimulationManager y componentes Core al objeto SimulationRoot.");
                GUI.DragWindow();
                return;
            }

            string mode = simulationManager.CurrentMode.ToString();
            int score = scoringSystem != null ? scoringSystem.CurrentScore : 0;
            float elapsed = simulationManager.ElapsedSimulationTime;
            int totalSteps = stepSystem != null ? stepSystem.TotalSteps : 0;
            int currentStep = stepSystem != null ? stepSystem.CurrentStepIndex + 1 : 0;
            string currentStepId = stepSystem != null && stepSystem.CurrentStep != null
                ? stepSystem.CurrentStep.stepId
                : "N/A";

            GUILayout.Label("F1: mostrar/ocultar HUD");
            GUILayout.Space(4);
            GUILayout.Label("Modo: " + mode);
            GUILayout.Label("Score: " + score);
            GUILayout.Label("Tiempo sesion (s): " + elapsed.ToString("0.0"));
            GUILayout.Label("Paso: " + currentStep + " / " + totalSteps);
            GUILayout.Label("StepId: " + currentStepId);
            GUILayout.Space(8);
            GUILayout.Label("Demo teclado:");
            GUILayout.Label("- Step 1: Space");
            GUILayout.Label("- Step 2: espera tiempo configurado");
            GUILayout.Label("- Step 3: Enter");

            GUI.DragWindow();
        }
#endif
    }
}


