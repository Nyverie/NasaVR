using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Resalta los objetos usables del paso: al iniciar muestra un anillo que pulsa bajo cada
    /// <c>activeTargetIds</c> (los busca en SceneTargetRegistry) y lo oculta al completar el paso.
    /// Cuando sale una pista (HintSystem.HintShown) los anillos crecen 15 % para llamar la atención.
    /// Anillo procedural (LineRenderer): no requiere prefabs ni TextMeshPro.
    /// Los objetivos que aún no existen al iniciar el paso se esperan y se resaltan al aparecer.
    /// </summary>
    public class StepTargetHighlighter : MonoBehaviour
    {
        [SerializeField] private StepSystem stepSystem;

        [Header("Anillo")]
        [Tooltip("Material del anillo. Vacío = Sprites/Default (usa el color del vértice).")]
        [SerializeField] private Material ringMaterial;
        [SerializeField] private Color ringColor = new Color(1f, 0.85f, 0.2f, 1f);
        [SerializeField, Min(0.001f)] private float lineWidth = 0.025f;
        [SerializeField, Min(0.05f)] private float minRadius = 0.18f;
        [Tooltip("Margen sobre la mitad del objeto, en proporción.")]
        [SerializeField, Min(1f)] private float radiusPadding = 1.3f;
        [Tooltip("Elevación sobre el punto más bajo del objeto (evita z-fighting con el suelo).")]
        [SerializeField] private float groundOffset = 0.01f;

        [Header("Pulso")]
        [SerializeField, Range(0f, 0.5f)] private float pulseAmplitude = 0.08f;
        [SerializeField, Min(0.1f)] private float pulsePeriod = 1.2f;

        [Tooltip("Factor de crecimiento al mostrarse una pista.")]
        [SerializeField, Min(1f)] private float hintScale = 1.15f;
        [SerializeField, Min(0.01f)] private float hintGrowSeconds = 0.35f;

        private sealed class Ring
        {
            public string Id;
            public Transform Target;
            public Transform Root;
            public LineRenderer Line;
        }

        private const int Segments = 48;

        private readonly List<Ring> _rings = new();
        private readonly List<string> _pendingIds = new();
        private HintSystem _hintSource;
        private Material _runtimeMaterial;
        private float _hintFactor = 1f;
        private float _hintTarget = 1f;

        /// <summary>Anillos visibles ahora.</summary>
        public int ActiveRingCount => _rings.Count;

        /// <summary>Ids de objetivos del paso que aún no existen en la escena.</summary>
        public int PendingCount => _pendingIds.Count;

        /// <summary>Factor de escala actual por pista (1 = normal, hintScale = pista mostrada).</summary>
        public float HintFactor => _hintFactor;

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem == null) return;

            stepSystem.StepStarted += OnStepStarted;
            stepSystem.StepCompleted += OnStepCompleted;
            stepSystem.StepsFinished += HideAll;
            stepSystem.JumpedToStep += OnJumped;

            // Si el paso ya había iniciado cuando se activó este componente.
            if (stepSystem.IsRunning) Show(stepSystem.CurrentStep);
        }

        private void OnDisable()
        {
            if (stepSystem != null)
            {
                stepSystem.StepStarted -= OnStepStarted;
                stepSystem.StepCompleted -= OnStepCompleted;
                stepSystem.StepsFinished -= HideAll;
                stepSystem.JumpedToStep -= OnJumped;
            }
            UnsubscribeHints();
            HideAll();
        }

        private void OnDestroy()
        {
            if (_runtimeMaterial != null) Destroy(_runtimeMaterial);
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => Show(step);

        private void OnStepCompleted(StepDefinition step, int index, float elapsed) => HideAll();

        private void OnJumped(int from, int to) => HideAll();

        // ── Mostrar / ocultar ─────────────────────────────────────────────────

        private void Show(StepDefinition step)
        {
            HideAll();
            if (step == null || step.activeTargetIds == null) return;

            foreach (var id in step.activeTargetIds)
            {
                if (string.IsNullOrEmpty(id)) continue;
                if (!TryAddRing(id)) _pendingIds.Add(id);
            }
        }

        private void HideAll()
        {
            foreach (var ring in _rings)
                if (ring.Root != null) Destroy(ring.Root.gameObject);
            _rings.Clear();
            _pendingIds.Clear();
            _hintFactor = _hintTarget = 1f;
        }

        private bool TryAddRing(string id)
        {
            if (!SceneTargetRegistry.TryGet(id, out var target)) return false;

            var root = new GameObject($"Ring_{id}");
            root.transform.SetParent(transform, false);

            var line = root.AddComponent<LineRenderer>();
            line.useWorldSpace = false;
            line.loop = true;
            line.positionCount = Segments;
            line.widthMultiplier = lineWidth;
            line.numCapVertices = 0;
            line.alignment = LineAlignment.View;
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            line.receiveShadows = false;
            line.sharedMaterial = GetMaterial();
            line.startColor = line.endColor = ringColor;

            for (int i = 0; i < Segments; i++)
            {
                float a = i / (float)Segments * Mathf.PI * 2f;
                line.SetPosition(i, new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a)));
            }

            var ring = new Ring { Id = id, Target = target, Root = root.transform, Line = line };
            _rings.Add(ring);
            PlaceRing(ring, 1f);

            SubscribeHints();
            return true;
        }

        private Material GetMaterial()
        {
            if (ringMaterial != null) return ringMaterial;
            if (_runtimeMaterial == null)
            {
                var shader = Shader.Find("Sprites/Default") ?? Shader.Find("Universal Render Pipeline/Unlit")
                             ?? Shader.Find("Unlit/Color");
                _runtimeMaterial = new Material(shader) { name = "StepTargetRing (runtime)" };
            }
            return _runtimeMaterial;
        }

        // ── Pulso y seguimiento ───────────────────────────────────────────────

        private void Update()
        {
            if (_pendingIds.Count > 0) ResolvePending();

            if (_hintSource == null && HintSystem.Instance != null && (_rings.Count > 0 || _pendingIds.Count > 0))
                SubscribeHints();

            if (_rings.Count == 0) return;

            _hintFactor = Mathf.MoveTowards(_hintFactor, _hintTarget,
                (hintScale - 1f) / hintGrowSeconds * Time.deltaTime);

            float pulse = 1f + pulseAmplitude * Mathf.Sin(Time.time * Mathf.PI * 2f / pulsePeriod);
            float alpha = 0.65f + 0.35f * (0.5f + 0.5f * Mathf.Sin(Time.time * Mathf.PI * 2f / pulsePeriod));

            for (int i = _rings.Count - 1; i >= 0; i--)
            {
                var ring = _rings[i];
                if (ring.Target == null)
                {
                    // El objetivo desapareció: espera a que vuelva a existir.
                    if (ring.Root != null) Destroy(ring.Root.gameObject);
                    _rings.RemoveAt(i);
                    _pendingIds.Add(ring.Id);
                    continue;
                }

                PlaceRing(ring, pulse * _hintFactor);
                var color = ringColor;
                color.a *= alpha;
                ring.Line.startColor = ring.Line.endColor = color;
            }
        }

        private void ResolvePending()
        {
            for (int i = _pendingIds.Count - 1; i >= 0; i--)
            {
                if (TryAddRing(_pendingIds[i])) _pendingIds.RemoveAt(i);
            }
        }

        private void PlaceRing(Ring ring, float scale)
        {
            var bounds = GetBounds(ring.Target, out bool hasBounds);
            float baseY = hasBounds ? bounds.min.y : ring.Target.position.y;
            Vector3 center = hasBounds ? bounds.center : ring.Target.position;
            float half = hasBounds ? Mathf.Max(bounds.extents.x, bounds.extents.z) : 0f;
            float radius = Mathf.Max(minRadius, half * radiusPadding) * scale;

            ring.Root.position = new Vector3(center.x, baseY + groundOffset, center.z);
            ring.Root.rotation = Quaternion.identity;
            ring.Root.localScale = new Vector3(radius, 1f, radius);
        }

        private static Bounds GetBounds(Transform target, out bool found)
        {
            var renderers = target.GetComponentsInChildren<Renderer>();
            found = false;
            Bounds bounds = default;
            foreach (var r in renderers)
            {
                if (r is LineRenderer) continue; // no medir los propios anillos
                if (!found) { bounds = r.bounds; found = true; }
                else bounds.Encapsulate(r.bounds);
            }
            return bounds;
        }

        // ── Pistas ────────────────────────────────────────────────────────────

        private void SubscribeHints()
        {
            var source = HintSystem.Instance;
            if (source == null || source == _hintSource) return;

            UnsubscribeHints();
            _hintSource = source;
            _hintSource.HintShown += OnHintShown;
        }

        private void UnsubscribeHints()
        {
            if (_hintSource != null) _hintSource.HintShown -= OnHintShown;
            _hintSource = null;
        }

        private void OnHintShown(StepDefinition step) => _hintTarget = hintScale;
    }
}
