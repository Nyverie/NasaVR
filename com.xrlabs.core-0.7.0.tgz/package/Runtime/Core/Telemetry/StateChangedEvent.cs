namespace XRLabs.Core.Telemetry
{
    // 0.3 lote 1: fichero propio para no chocar con los eventos nuevos del lote 2 en TelemetryEvents.cs.

    /// <summary>
    /// Cambio de una variable de <c>estado</c> con <c>registrar: true</c> (contrato 0.3 §2.1). Al API sale como
    /// <c>state_changed</c> (el <c>action</c> del activity log es texto libre: <c>CreateActivityLogDto.action</c> es
    /// <c>@IsString()</c>), con <c>entity: "Step"</c>, <c>entityId</c> = el paso en curso y metadata
    /// <c>variable</c>, <c>antes</c>, <c>valor</c>.
    /// </summary>
    public class StateChangedEvent : TelemetryEvent
    {
        public string Variable;
        public string Before;
        public string Value;
    }
}
