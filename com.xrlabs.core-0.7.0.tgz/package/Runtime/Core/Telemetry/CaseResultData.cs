namespace XRLabs.Core.Telemetry
{
    /// <summary>
    /// Resultado de un caso evaluativo, independiente de la capa de red.
    /// Las simulaciones emiten este POCO; el adaptador de sesión (capa UI/Networking)
    /// lo mapea al DTO del API. Semilla del pipeline de telemetría de F4.
    /// </summary>
    public class CaseResultData
    {
        public int CaseNumber;
        public string FailureName;
        public bool TypeCorrect;
        public bool CauseCorrect;
        public bool RecommendationCorrect;
        public int CaseTimeSeconds;
    }
}
