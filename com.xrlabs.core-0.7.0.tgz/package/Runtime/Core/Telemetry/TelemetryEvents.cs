using System;

namespace XRLabs.Core.Telemetry
{
    /// <summary>
    /// Contexto compartido para enriquecer eventos: el StepSystem publica aquí
    /// el paso actual para que emisores sin referencia al paso (conditions, hints)
    /// puedan etiquetar sus eventos.
    /// </summary>
    public static class TelemetryContext
    {
        public static string CurrentStepId;
    }

    /// <summary>
    /// Base de todos los eventos de telemetría del framework.
    /// schemaVersion permite evolucionar el formato sin romper clientes instalados.
    /// </summary>
    public abstract class TelemetryEvent
    {
        public const string SchemaVersion = "1.0";

        public string TimestampUtc = DateTime.UtcNow.ToString("o");
        public string StepId;
    }

    /// <summary>
    /// Respuesta a una pregunta del quiz evaluativo, con todo el contexto de aprendizaje:
    /// qué distractor eligió, cuánto tardó y cuántos intentos usó.
    /// </summary>
    public class QuizAnswerEvent : TelemetryEvent
    {
        public int CaseNumber;
        public int QuestionIndex;          // 0=tipo_falla, 1=causa, 2=recomendación
        public string QuestionType;        // "failure_type" | "cause" | "recommendation"
        public string QuestionText;
        public string[] Options;
        public int CorrectAnswerIndex;
        public int UserAnswerIndex;
        public bool IsCorrect;
        public int AttemptsUsed;
        public float ResponseTimeSeconds;
        public int ScoreDelta;

        public static string TypeForIndex(int questionIndex) => questionIndex switch
        {
            0 => "failure_type",
            1 => "cause",
            2 => "recommendation",
            _ => $"question_{questionIndex}"
        };
    }

    /// <summary>Se mostró un hint por inactividad — señal directa de dificultad en el paso.</summary>
    public class HintShownEvent : TelemetryEvent
    {
        public float HintDelaySeconds;
    }

    /// <summary>
    /// Resumen de exploración del modelo 3D al cerrar un paso de inspección:
    /// cuánto rotó y cuánto tiempo exploró antes de responder.
    /// </summary>
    public class ExplorationEvent : TelemetryEvent
    {
        public float RotationDegrees;
        public float ExplorationSeconds;
    }

    /// <summary>Cierre de un paso con su tiempo — identifica dónde se atasca el usuario.</summary>
    public class StepCompletedEvent : TelemetryEvent
    {
        public int StepIndex;
        public float ElapsedSeconds;
        public int ScoreAfter;
    }

    /// <summary>
    /// Error o aviso dentro de un paso (v0.6): qué hizo mal el usuario y en qué paso.
    /// Es la señal más directa de qué concepto no se entendió.
    /// </summary>
    public class StepSignalEvent : TelemetryEvent
    {
        public int StepIndex;
        public string Kind;   // "error" | "warning"
        public string Key;    // clave reportada por la condición
        public string Option; // 0.3 lote 4: el objeto tocado en un 'elegir' (metadata.opcion); null si no aplica
    }

    /// <summary>
    /// Interacción física con un objeto (grab, release, touch, activate).
    /// Emitida automáticamente por InteractableBase — cuenta la interacción real
    /// con el modelo 3D, no solo las respuestas de quiz.
    /// </summary>
    public class InteractionEvent : TelemetryEvent
    {
        public string InteractionId;
        public string Kind; // "hover" | "select" | "release" | "activate" | "deactivate" | "drop" | "snap"
    }

    // ── 0.3 lote 2: estado y tiempo simulado (contrato-0.3.md §2.1 y §2.3) ─────────────────────────

    /// <summary>Un paso se saltó porque su guarda 'si' no se cumplía al llegar a él.</summary>
    public class StepSkippedEvent : TelemetryEvent
    {
        public int StepIndex;
        public string Reason = "si";
    }

    // StateChangedEvent (cambió una variable con 'registrar') vive en su propio fichero, StateChangedEvent.cs, del lote 1:
    // el mismo evento para los dos lotes.

    /// <summary>Un paso 'avanzar' sumó días al calendario simulado.</summary>
    public class TimeAdvancedEvent : TelemetryEvent
    {
        public int Days;
        public int Day;
    }
}
