using System.Collections.Generic;
using XRLabs.Core.Diagnostics;

namespace XRLabs.Core.Telemetry
{
    /// <summary>
    /// Punto central de emisión de telemetría. Las simulaciones emiten eventos tipados
    /// sin conocer los destinos; los canales (archivo local, API) se registran al arrancar.
    /// </summary>
    public static class TelemetryHub
    {
        private static readonly List<ITelemetryChannel> Channels = new();

        public static void Register(ITelemetryChannel channel)
        {
            if (channel != null && !Channels.Contains(channel))
                Channels.Add(channel);
        }

        public static void Unregister(ITelemetryChannel channel)
        {
            Channels.Remove(channel);
        }

        /// <summary>Emite el evento a todos los canales registrados. Nunca lanza.</summary>
        public static void Emit(TelemetryEvent telemetryEvent)
        {
            if (telemetryEvent == null) return;

            for (int i = 0; i < Channels.Count; i++)
            {
                try
                {
                    Channels[i].Emit(telemetryEvent);
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[TelemetryHub] Canal {Channels[i].GetType().Name} falló: {ex.Message}");
                }
            }
        }
    }
}
