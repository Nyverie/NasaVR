using UnityEngine;

namespace XRLabs.Core.Telemetry
{
    /// <summary>
    /// Canal que persiste eventos en el TelemetryClient local (JSON/CSV en disco).
    /// Se auto-registra al cargar la app — no requiere wiring en escena.
    /// Mantiene la compatibilidad del archivo local existente (mismo RecordScoreEvent).
    /// </summary>
    public class LocalFileTelemetryChannel : ITelemetryChannel
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoRegister()
        {
            TelemetryHub.Register(new LocalFileTelemetryChannel());
        }

        public void Emit(TelemetryEvent telemetryEvent)
        {
            var client = TelemetryClient.Instance;
            if (client == null) return;

            switch (telemetryEvent)
            {
                case QuizAnswerEvent quiz:
                {
                    string suffix = quiz.IsCorrect ? "" : "_fail";
                    string metadata = JsonUtility.ToJson(new QuizMetadata(quiz));
                    client.RecordScoreEvent(
                        $"case{quiz.CaseNumber}_q{quiz.QuestionIndex + 1}{suffix}",
                        $"Caso {quiz.CaseNumber} - Q{quiz.QuestionIndex + 1}{(quiz.IsCorrect ? "" : " fallido")}",
                        quiz.ScoreDelta,
                        metadata);
                    break;
                }

                case HintShownEvent hint:
                    client.RecordScoreEvent($"hint_{hint.StepId}", $"Hint mostrado en {hint.StepId}", 0);
                    break;

                case ExplorationEvent expl:
                    client.RecordScoreEvent(
                        $"exploration_{expl.StepId}",
                        $"Exploración: {expl.RotationDegrees:0}° / {expl.ExplorationSeconds:0.0}s",
                        0);
                    break;

                case StepSignalEvent signal:
                    client.RecordScoreEvent(
                        $"{signal.Kind}_{signal.StepId}_{signal.Key}",
                        $"{(signal.Kind == "error" ? "Error" : "Aviso")} en {signal.StepId}: {signal.Key}",
                        0);
                    break;

                // StepCompletedEvent ya lo captura TelemetryClient por sus propios
                // eventos de SimulationManager — no duplicar.
            }
        }

        [System.Serializable]
        private struct QuizMetadata
        {
            public string questionType;
            public string questionText;
            public int userAnswer;
            public int correctAnswer;
            public bool isCorrect;
            public int attemptsUsed;
            public float responseTimeSeconds;

            public QuizMetadata(QuizAnswerEvent e)
            {
                questionType = e.QuestionType;
                questionText = e.QuestionText;
                userAnswer = e.UserAnswerIndex;
                correctAnswer = e.CorrectAnswerIndex;
                isCorrect = e.IsCorrect;
                attemptsUsed = e.AttemptsUsed;
                responseTimeSeconds = e.ResponseTimeSeconds;
            }
        }
    }
}
