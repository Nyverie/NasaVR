namespace XRLabs.Core.Telemetry
{
    /// <summary>
    /// Destino de eventos de telemetría (archivo local, API, consola...).
    /// Los canales se registran en el TelemetryHub y reciben cada evento emitido.
    /// </summary>
    public interface ITelemetryChannel
    {
        /// <summary>Recibe un evento. Debe ser barato: encolar, no bloquear.</summary>
        void Emit(TelemetryEvent telemetryEvent);
    }
}
