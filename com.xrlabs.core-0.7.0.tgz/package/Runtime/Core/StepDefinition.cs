using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;
#if ODIN_INSPECTOR
using Sirenix.OdinInspector;
#endif

namespace XRLabs.Core
{
    /// <summary>
    /// Tipo de paso. Controla cómo avanza la simulación.
    /// </summary>
    public enum StepType
    {
        /// <summary>
        /// 🟣 NON INTERACTIVE — El paso avanza automáticamente al terminar el VO.
        /// No requiere acción del usuario. Ideal para narración, transiciones y presentaciones.
        /// </summary>
        NonInteractive,

        /// <summary>
        /// 🔵 INTERACTION — El paso espera a que se cumpla la condición asignada.
        /// Tiene Happy Path (instructionVO) e Idle Path (hintVO tras hintDelay).
        /// </summary>
        Interaction
    }

    /// <summary>
    /// Modo de presentación del modelo 3D principal del paso (genérico: broca, barra, motor, etc.).
    /// </summary>
    public enum ModelDisplay
    {
        /// <summary>Sin modelo. Permanece oculto o en su estado anterior.</summary>
        None,

        /// <summary>El modelo aparece estático en el punto de presentación.</summary>
        Show,

        /// <summary>El modelo aparece y gira en loop (presentación cinematográfica).</summary>
        ShowAndSpin
    }

    /// <summary>
    /// Tipo de panel visual que se muestra durante el paso.
    /// </summary>
    public enum PanelType
    {
        /// <summary>Sin panel visual.</summary>
        None,

        /// <summary>Muestra un Sprite en el HolographicImagePanel flotante.</summary>
        Image,

        /// <summary>
        /// Muestra la imagen Y anima íconos superpuestos uno a uno sincronizados con el VO.
        /// Usar iconCount para indicar cuántos íconos tiene la imagen.
        /// </summary>
        IconSequence,

        /// <summary>Muestra el nombre de una parte en PartLabelCard (aparece al tocar el hotspot).</summary>
        PartLabel,

        /// <summary>Muestra un checklist lateral de hotspots pendientes (ChecklistPanel).</summary>
        Checklist
    }

    /// <summary>
    /// Define un paso de la simulación: qué se dice, qué se muestra, qué debe hacer el usuario
    /// y cómo se puntúa. Vive como asset independiente dentro de un SimulationSequence.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Step Definition")]
    public class StepDefinition : ScriptableObject
    {
        // ── Tipo ──────────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Tipo"), HideLabel]
#else
        [Header("Tipo de paso")]
#endif
        public StepType stepType = StepType.NonInteractive;

        // ── Identificación ────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Identificación"), Required]
#else
        [Header("Identificación")]
#endif
        public string stepId;

#if ODIN_INSPECTOR
        [BoxGroup("Identificación"), TextArea(1, 3), HideLabel]
#else
        [TextArea(1, 3)]
#endif
        public string description;

#if ODIN_INSPECTOR
        [BoxGroup("Identificación")]
#endif
        [Tooltip("Texto del título flotante en escena. Vacío = sin título. Ej: 'RAJADURA EN EL BORDE'")]
        public string titleText;

        // ── Voice Overs ───────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Voice Overs")]
#else
        [Header("Voice Overs")]
#endif
        [Tooltip("Clips de VO reproducidos en secuencia al iniciar el paso (VO-001, VO-002, …)")]
        public AudioClip[] voSequence;

#if ODIN_INSPECTOR
        [BoxGroup("Voice Overs"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("VO del Idle Path — se reproduce tras hintDelay si el usuario no actúa")]
        public AudioClip hintVO;

#if ODIN_INSPECTOR
        [BoxGroup("Voice Overs"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Segundos de inactividad antes de reproducir el hint VO")]
        public float hintDelay = 10f;

        // ── Panel visual ──────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Panel Visual")]
#else
        [Header("Panel Visual")]
#endif
        public PanelType panelType = PanelType.None;

#if ODIN_INSPECTOR
        [BoxGroup("Panel Visual"),
         ShowIf("@panelType == PanelType.Image || panelType == PanelType.IconSequence")]
#endif
        [Tooltip("Imagen mostrada en el HolographicImagePanel durante el paso")]
        public Sprite displayImage;

#if ODIN_INSPECTOR
        [BoxGroup("Panel Visual"), ShowIf("@panelType == PanelType.IconSequence")]
#endif
        [Tooltip("Número de íconos en la imagen para sincronizar su iluminación con el VO")]
        public int iconCount;

        // ── Audio FX ──────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Audio FX")]
#else
        [Header("Audio FX")]
#endif
        [Tooltip("SFX reproducido al iniciar el paso (ej: whoosh de transición, shimmer holográfico)")]
        public AudioClip sfxOnEnter;

#if ODIN_INSPECTOR
        [BoxGroup("Audio FX")]
#endif
        [Tooltip("SFX reproducido al completar el paso (ej: chime de confirmación, pulse positivo)")]
        public AudioClip sfxOnComplete;

        // ── Timing ────────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Timing & Scoring")]
#else
        [Header("Timing")]
#endif
        [Tooltip("Tiempo máximo. En modo Evaluación, superarlo aplica penalización")]
        public float maxAllowedTime = 60f;

        [Tooltip("Si esta activo, el paso no avanza automaticamente. Debe cerrarse desde codigo o UI.")]
        public bool waitForManualCompletion;

        // ── Scoring ───────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Timing & Scoring")]
#else
        [Header("Scoring")]
#endif
        [Tooltip("Puntos sumados al completar. Usar 0 en pasos de aprendizaje (Parte 1)")]
        public int scoreOnSuccess = 0;

#if ODIN_INSPECTOR
        [BoxGroup("Timing & Scoring")]
#endif
        public int penaltyOnError = 0;

        // ── Modelo 3D ─────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Modelo 3D")]
#else
        [Header("Modelo 3D")]
#endif
        [Tooltip("None = sin modelo | Show = estático | ShowAndSpin = gira en loop")]
        [FormerlySerializedAs("drillBitDisplay")]
        public ModelDisplay modelDisplay = ModelDisplay.None;

#if ODIN_INSPECTOR
        [BoxGroup("Modelo 3D"), ShowIf("@modelDisplay == ModelDisplay.ShowAndSpin")]
#endif
        [Tooltip("Velocidad de rotación en grados/segundo (solo ShowAndSpin)")]
        public float spinSpeed = 30f;

#if ODIN_INSPECTOR
        [BoxGroup("Modelo 3D"), ShowIf("@modelDisplay != ModelDisplay.None")]
#endif
        [Tooltip("Prefab del modelo a mostrar en este paso. Nulo = usa la instancia en escena.")]
        [FormerlySerializedAs("drillBitPrefab")]
        public GameObject modelPrefab;

        // ── Condición ─────────────────────────────────────────────────────────────
#if ODIN_INSPECTOR
        [BoxGroup("Condición"),
         ShowIf("@stepType == StepType.Interaction"),
         InlineEditor(InlineEditorObjectFieldModes.Foldout)]
#else
        [Header("Condición de completado")]
#endif
        [Tooltip("Solo para Interaction. Null en NonInteractive: el paso avanza al terminar el VO")]
        public StepCondition completionCondition;

        // ── Coach (v0.6) ──────────────────────────────────────────────────────────
        // Todos opcionales: vacíos = comportamiento idéntico a v0.5.

#if ODIN_INSPECTOR
        [BoxGroup("Coach")]
#else
        [Header("Coach — frases (v0.6)")]
#endif
        [Tooltip("Frases que se dicen al iniciar el paso, en orden y BLOQUEANTES (explicaciones). " +
                 "En Interaction, la condición se arma al terminarlas.")]
        public List<LineRef> introLines = new();

#if ODIN_INSPECTOR
        [BoxGroup("Coach"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Instrucción del paso. NO bloquea: el usuario puede actuar mientras suena. " +
                 "Si no hay hintLine, también se repite como pista.")]
        public LineRef instructionLine;

#if ODIN_INSPECTOR
        [BoxGroup("Coach"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Pista por inactividad (tras hintDelay). Vacío = repite instructionLine.")]
        public LineRef hintLine;

#if ODIN_INSPECTOR
        [BoxGroup("Coach")]
#endif
        [Tooltip("Confirmación tras acertar (BLOQUEANTE). Conviene que explique el porqué.")]
        public LineRef successLine;

#if ODIN_INSPECTOR
        [BoxGroup("Coach"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Frase por cada clave que reporta la condición: errores, avisos y progreso (ReportInfo). " +
                 "La frase de error siempre dice qué estuvo mal y por qué.")]
        public List<StepErrorLine> errorLines = new();

#if ODIN_INSPECTOR
        [BoxGroup("Coach"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Tras decir la corrección de un error, repetir la instructionLine (útil en preguntas cortas).")]
        public bool repeatInstructionAfterError;

#if ODIN_INSPECTOR
        [BoxGroup("Coach"), ShowIf("@stepType == StepType.Interaction")]
#endif
        [Tooltip("Frase de error cuando la clave reportada no tiene entrada en errorLines.")]
        public LineRef defaultErrorLine;

#if ODIN_INSPECTOR
        [BoxGroup("Coach — checklist y escena")]
#else
        [Header("Coach — checklist y escena (v0.6)")]
#endif
        [Tooltip("Si suma una tarea al checklist y al puntaje por tareas.")]
        public bool countsAsTask;

#if ODIN_INSPECTOR
        [BoxGroup("Coach — checklist y escena"), ShowIf("countsAsTask")]
#endif
        [Tooltip("Texto de la tarea en el checklist. Puede ser un ID de LineLibrary (se resuelve por idioma) o texto plano.")]
        public string taskLabel;

#if ODIN_INSPECTOR
        [BoxGroup("Coach — checklist y escena")]
#endif
        [Tooltip("ID del CoachAnchor donde se coloca el coach durante el paso. Vacío = modo seguir.")]
        public string coachAnchorId;

#if ODIN_INSPECTOR
        [BoxGroup("Coach — checklist y escena")]
#endif
        [Tooltip("ID del objeto (SceneTargetRegistry) al que señala el coach durante el paso.")]
        public string pointAtTargetId;

#if ODIN_INSPECTOR
        [BoxGroup("Coach — checklist y escena")]
#endif
        [Tooltip("IDs de los objetos usables del paso (anillo y etiqueta de resaltado).")]
        public List<string> activeTargetIds = new();

        /// <summary>Frase configurada para una clave de error/aviso, o la frase por defecto.</summary>
        public LineRef GetErrorLine(string key, out bool found)
        {
            if (errorLines != null)
            {
                foreach (var entry in errorLines)
                {
                    if (entry != null && entry.key == key)
                    {
                        found = true;
                        return entry.line;
                    }
                }
            }
            found = false;
            return defaultErrorLine;
        }

        /// <summary>True si el paso usa el flujo de frases del coach (v0.6).</summary>
        public bool UsesCoachLines =>
            (introLines != null && introLines.Count > 0) || !instructionLine.IsEmpty || !successLine.IsEmpty;

        // ── 0.3 lote 2: guarda, efectos y tiempo simulado (contrato-0.3.md §2.1 y §2.3) ──────────
        // Todos vacíos por defecto: un paso sin ellos se comporta como antes (D8). El importador los deja resueltos; en
        // ejecución no se interpreta texto.

        [Header("Estado — guarda y efectos (0.3)")]
        [Tooltip("'si': condiciones sobre el estado, todas a la vez. Si no se cumplen al llegar al paso, se salta: no suena, " +
                 "no cuenta y descuenta su tarea del total. Vacío = siempre.")]
        public List<StateCondition> guard = new();

        [Tooltip("'alIniciar': efectos al empezar el paso, antes de la introducción (en 'avanzar', con la pantalla en negro).")]
        public List<StateEffect> onStartEffects = new();

        [Tooltip("'alError': efectos por clave de error, tras la frase de corrección y antes de repetir.")]
        public List<StepErrorEffects> onErrorEffects = new();

        [Header("Tiempo simulado — avanzar (0.3)")]
        [Tooltip("Días que suma el paso 'avanzar' a la variable 'dia'. 0 = el paso no es 'avanzar'.")]
        [Min(0)] public int advanceDays;

        [Tooltip("Id de la frase soloTexto que la cortinilla muestra al centro (admite {variable}). Vacío = sin texto.")]
        public string advanceLabel;

        [Tooltip("Segundos de la cortinilla negra (0–5). 0 = sin fundido.")]
        [Range(0f, 5f)] public float advanceFadeSeconds = 1.5f;

        /// <summary>0.3: el paso es un 'avanzar' (suma días a 'dia' con la cortinilla).</summary>
        public bool IsTimeAdvance => advanceDays > 0;

        /// <summary>0.3: el paso tiene guarda 'si'.</summary>
        public bool HasGuard => guard != null && guard.Count > 0;

        /// <summary>0.3: los efectos 'alError' de una clave, o null.</summary>
        public List<StateEffect> GetErrorEffects(string key)
        {
            if (onErrorEffects == null) return null;
            foreach (var entry in onErrorEffects)
                if (entry != null && entry.key == key) return entry.effects;
            return null;
        }

        #region 0.3 lote 5: «Continuar» que dice qué falta (contrato-0.3.md §2.7)

        [Header("Continuar (0.3)")]
        [Tooltip("El HUD enseña el botón «Continuar» mientras el paso escucha (y en pantalla vale Intro).")]
        public bool hasContinue;

        [Tooltip("Frase del botón (por defecto ui.continuar).")]
        public LineRef continueLabel;

        [Tooltip("Clave de 'errores' que se reporta si la condición no se cumple y no dice qué falta.")]
        public string continueIncompleteKey;

        /// <summary>0.3 lote 5: el paso escucha «Continuar» (solo pasos Interaction con 'continuar' en el guion).</summary>
        public bool AcceptsContinue => hasContinue && stepType == StepType.Interaction;

        #endregion
    }

    /// <summary>0.3 lote 2: efectos 'alError' de una clave de error.</summary>
    [System.Serializable]
    public class StepErrorEffects
    {
        public string key;
        public List<StateEffect> effects = new();
    }

    /// <summary>Frase asociada a una clave que reporta la condición.</summary>
    [System.Serializable]
    public class StepErrorLine
    {
        [Tooltip("Clave que reporta la condición (ReportError/ReportWarning). Ej: 'empieza_con_estiercol'")]
        public string key;
        public LineRef line;
    }
}
