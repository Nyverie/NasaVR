﻿using UnityEngine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace XRLabs.Core
{
    public static class InputKeyCompat
    {
        /// <summary>Devuelve true mientras la tecla esté presionada (held).</summary>
        public static bool IsKeyHeld(KeyCode keyCode)
        {
#if ENABLE_INPUT_SYSTEM
            var keyboard = Keyboard.current;
            if (keyboard != null && TryMapKey(keyCode, out var key))
            {
                return keyboard[key].isPressed;
            }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKey(keyCode);
#else
            return false;
#endif
        }

        public static bool IsKeyDown(KeyCode keyCode)
        {
#if ENABLE_INPUT_SYSTEM
            var keyboard = Keyboard.current;
            if (keyboard != null && TryMapKey(keyCode, out var key))
            {
                return keyboard[key].wasPressedThisFrame;
            }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKeyDown(keyCode);
#else
            return false;
#endif
        }

#if ENABLE_INPUT_SYSTEM
        private static bool TryMapKey(KeyCode keyCode, out Key key)
        {
            switch (keyCode)
            {
                case KeyCode.Space:
                    key = Key.Space;
                    return true;
                case KeyCode.Return:
                    key = Key.Enter;
                    return true;
                case KeyCode.KeypadEnter:
                    key = Key.NumpadEnter;
                    return true;
                case KeyCode.F1:
                    key = Key.F1;
                    return true;
                case KeyCode.F2:
                    key = Key.F2;
                    return true;
                case KeyCode.F3:
                    key = Key.F3;
                    return true;
                case KeyCode.F4:
                    key = Key.F4;
                    return true;
                case KeyCode.F5:
                    key = Key.F5;
                    return true;
                case KeyCode.F6:
                    key = Key.F6;
                    return true;
                case KeyCode.F7:
                    key = Key.F7;
                    return true;
                case KeyCode.LeftShift:
                    key = Key.LeftShift;
                    return true;
                case KeyCode.RightShift:
                    key = Key.RightShift;
                    return true;
            }

            if (TryMapAlphaNumeric(keyCode, out key))
            {
                return true;
            }

            key = Key.None;
            return false;
        }

        private static bool TryMapAlphaNumeric(KeyCode keyCode, out Key key)
        {
            // Covers A-Z and Alpha0-Alpha9 for editor shortcuts in demo conditions.
            if (keyCode >= KeyCode.A && keyCode <= KeyCode.Z)
            {
                int offset = keyCode - KeyCode.A;
                key = Key.A + offset;
                return true;
            }

            if (keyCode >= KeyCode.Alpha0 && keyCode <= KeyCode.Alpha9)
            {
                int offset = keyCode - KeyCode.Alpha0;
                key = Key.Digit0 + offset;
                return true;
            }

            key = Key.None;
            return false;
        }
#endif
    }
}

