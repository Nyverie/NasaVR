using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace XRLabs.Core
{
    /// <summary>
    /// Conecta pasos (por stepId) con efectos sobre el mundo de la escena: crecer la pila,
    /// encender una máquina, mostrar un objeto. Un ScriptableObject no puede referenciar
    /// objetos de escena, así que estos efectos viven aquí y no en el StepDefinition.
    /// </summary>
    public class StepEventBindings : MonoBehaviour
    {
        [Serializable]
        public class StringEvent : UnityEvent<string> { }

        [Serializable]
        public class Binding
        {
            public string stepId;
            public UnityEvent onStarted = new();
            public UnityEvent onCompleted = new();
            [Tooltip("Recibe la clave del error reportado.")]
            public StringEvent onFailed = new();
        }

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private List<Binding> bindings = new();

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();
            if (stepSystem == null) return;

            stepSystem.StepStarted += HandleStarted;
            stepSystem.StepCompleted += HandleCompleted;
            stepSystem.StepFailed += HandleFailed;
        }

        private void OnDisable()
        {
            if (stepSystem == null) return;

            stepSystem.StepStarted -= HandleStarted;
            stepSystem.StepCompleted -= HandleCompleted;
            stepSystem.StepFailed -= HandleFailed;
        }

        private void HandleStarted(StepDefinition step, int index, int total)
        {
            foreach (var b in Matching(step)) b.onStarted.Invoke();
        }

        private void HandleCompleted(StepDefinition step, int index, float elapsed)
        {
            foreach (var b in Matching(step)) b.onCompleted.Invoke();
        }

        private void HandleFailed(StepDefinition step, int index, string key)
        {
            foreach (var b in Matching(step)) b.onFailed.Invoke(key);
        }

        private IEnumerable<Binding> Matching(StepDefinition step)
        {
            if (step == null) yield break;
            foreach (var b in bindings)
                if (b != null && b.stepId == step.stepId)
                    yield return b;
        }
    }
}
