﻿using UnityEngine;

namespace XRLabs.Core
{
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Elapsed Time")]
    public class ElapsedTimeStepCondition : StepCondition
    {
        [SerializeField] private float secondsToComplete = 3f;

        private float _startedAt;

        public override void Initialize()
        {
            _startedAt = Time.time;
        }

        public override bool IsCompleted()
        {
            return Time.time - _startedAt >= secondsToComplete;
        }

        public override void Cleanup()
        {
        }
    }
}

