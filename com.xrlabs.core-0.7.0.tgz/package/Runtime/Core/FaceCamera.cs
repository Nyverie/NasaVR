using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Gira el objeto para que mire a la cámara principal (solo en el eje vertical): las etiquetas de los marcadores y de
    /// las zonas de la escena preparada se leen desde donde esté la persona, en modo plano o en el visor (2026-10-17, tras
    /// el recorrido de la muestra: «no sé qué hacer en este paso»). Sin cámara no hace nada.
    /// </summary>
    public class FaceCamera : MonoBehaviour
    {
        [Tooltip("TMP se lee mirando hacia +Z: la etiqueta da la espalda a la cámara para que el texto se lea de frente.")]
        [SerializeField] private bool backToCamera = true;

        private void LateUpdate()
        {
            var cam = Camera.main;
            if (cam == null) return;
            var to = transform.position - cam.transform.position;
            to.y = 0f;
            if (to.sqrMagnitude < 1e-6f) return;
            transform.rotation = Quaternion.LookRotation(backToCamera ? to : -to, Vector3.up);
        }
    }
}
