﻿using System;
using UnityEngine;

namespace XRLabs.Core
{
    public enum SimulationMode
    {
        Guided,
        Evaluation
    }

    public class SimulationManager : MonoBehaviour
    {
        public static SimulationManager Instance;

        [Header("Simulation Mode")]
        [SerializeField] private SimulationMode simulationMode = SimulationMode.Guided;

        [Header("Core Systems")]
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private ScoringSystem scoringSystem;
        [SerializeField] private TelemetryClient telemetryClient;

        public event Action<SimulationMode, int> OnSimulationStarted;
        public event Action<StepDefinition, int, int> OnStepStarted;
        public event Action<StepDefinition, int, float, int> OnStepCompleted;
        public event Action<int, float> OnSimulationEnded;

        public SimulationMode CurrentMode => simulationMode;

        /// <summary>El StepSystem de la simulación; sus <see cref="StepSystem.Stats"/> cuentan tareas, errores y ayudas.</summary>
        public StepSystem Steps => stepSystem;

        public float ElapsedSimulationTime => Mathf.Max(0f, Time.time - _simulationStartTime);
        public bool IsSimulationRunning => !_simulationEnded;

        private float _simulationStartTime;
        private bool _simulationEnded;
        private int? _finalScoreOverride;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
        }

        private void OnDestroy()
        {
            UnsubscribeFromStepEvents();

            if (Instance == this)
            {
                Instance = null;
            }
        }

        private void Start()
        {
            StartSimulation();
        }

        private void StartSimulation()
        {
            _simulationEnded = false;
            _simulationStartTime = Time.time;

            if (stepSystem == null || scoringSystem == null)
            {
                Debug.LogError("SimulationManager requires StepSystem and ScoringSystem references.");
                return;
            }

            SubscribeToStepEvents();

            scoringSystem.Initialize(simulationMode);
            OnSimulationStarted?.Invoke(simulationMode, stepSystem.TotalSteps);
            stepSystem.StartSteps(simulationMode);
        }

        public void EndSimulation()
        {
            EndSimulation(null);
        }

        public void EndSimulation(int finalScoreOverride)
        {
            EndSimulation((int?)finalScoreOverride);
        }

        /// <summary>
        /// Completa el paso actual y avanza al siguiente sin terminar la simulación.
        /// Usar desde paneles intermedios (ej: resumen de caso) para no esperar el timer automático.
        /// </summary>
        public void CompleteCurrentStep()
        {
            if (stepSystem != null && stepSystem.IsRunning && !_simulationEnded)
                stepSystem.CompleteCurrentStep();
        }

        public void CompleteCurrentStepAndEndSimulation(int finalScoreOverride)
        {
            _finalScoreOverride = finalScoreOverride;

            if (stepSystem != null && stepSystem.IsRunning)
            {
                stepSystem.CompleteCurrentStep();
            }

            EndSimulation(finalScoreOverride);
        }

        private void EndSimulation(int? finalScoreOverride)
        {
            if (_simulationEnded)
            {
                return;
            }

            _simulationEnded = true;

            int finalScore = finalScoreOverride ??
                             _finalScoreOverride ??
                             (scoringSystem != null ? scoringSystem.CurrentScore : 0);
            float totalTime = Time.time - _simulationStartTime;
            _finalScoreOverride = null;

            Debug.Log("Simulation finished");
            OnSimulationEnded?.Invoke(finalScore, totalTime);

            // Keep compatibility with existing integration point.
            if (telemetryClient != null)
            {
                telemetryClient.SendSessionResult(finalScore);
            }
        }

        private void SubscribeToStepEvents()
        {
            UnsubscribeFromStepEvents();

            stepSystem.StepStarted += HandleStepStarted;
            stepSystem.StepCompleted += HandleStepCompleted;
            stepSystem.StepsFinished += EndSimulation;
        }

        private void UnsubscribeFromStepEvents()
        {
            if (stepSystem == null)
            {
                return;
            }

            stepSystem.StepStarted -= HandleStepStarted;
            stepSystem.StepCompleted -= HandleStepCompleted;
            stepSystem.StepsFinished -= EndSimulation;
        }

        private void HandleStepStarted(StepDefinition step, int stepIndex, int totalSteps)
        {
            OnStepStarted?.Invoke(step, stepIndex, totalSteps);
        }

        private void HandleStepCompleted(StepDefinition step, int stepIndex, float elapsedTime)
        {
            int score = scoringSystem != null ? scoringSystem.CurrentScore : 0;
            OnStepCompleted?.Invoke(step, stepIndex, elapsedTime, score);
        }
    }
}
