using UnityEngine;
using XRLabs.Core.Telemetry;

namespace XRLabs.Core
{
    // 0.3 lote 1: el componente de escena que guarda la SimulationState (C# pura). Lo añade
    // «Preparar escena» solo si el guion declara 'estado'. Lo leen StateVisibility, StateLayout,
    // las condiciones (alElegir) y el StepSystem (guardas y todos los efectos de los pasos).

    /// <summary>
    /// Dueño en escena de la <see cref="SimulationState"/>: la crea con el estado inicial de la
    /// <see cref="SimulationSequence"/> y la expone por <see cref="State"/>.
    /// </summary>
    [DefaultExecutionOrder(-400)]
    [DisallowMultipleComponent]
    public class SimulationStateHost : MonoBehaviour
    {
        [Tooltip("Secuencia de la que sale el estado inicial. Vacía: la del StepSystem de la escena.")]
        [SerializeField] private SimulationSequence sequence;

        private SimulationState _state;
        private static SimulationStateHost _current;

        /// <summary>Se dispara cuando la tabla se crea (o se recrea): para suscribirse a <c>Changed</c>.</summary>
        public event System.Action<SimulationState> StateCreated;

        public SimulationSequence Sequence
        {
            get => sequence;
            set { sequence = value; _state = null; }
        }

        /// <summary>La tabla de estado; se crea al primer uso.</summary>
        public SimulationState State
        {
            get
            {
                if (_state == null) Build();
                return _state;
            }
        }

        /// <summary>El host de la escena activa, o null si la experiencia no usa estado.</summary>
        public static SimulationStateHost Current
        {
            get
            {
                if (_current == null) _current = FindFirstObjectByType<SimulationStateHost>();
                return _current;
            }
        }

        /// <summary>Atajo: la tabla de la escena, o null.</summary>
        public static SimulationState CurrentState => Current != null ? Current.State : null;

        private StepSystem _steps;

        private void Awake()
        {
            if (_current == null) _current = this;
            if (_state == null) Build();
        }

        private void OnDestroy()
        {
            if (_current == this) _current = null;
        }

        // Los efectos (alIniciar, alError, avanzar, alCompletar y su repetición en los saltos) los aplica el StepSystem, una
        // sola ruta para que cada uno ocurra una vez; el alElegir, ChoiceByTargetCondition al tocar. El host es dueño de la
        // tabla y de su state_changed (integración del contrato 0.3, 2026-10-31).
        private SimulationSequence EffectiveSequence()
        {
            if (sequence != null) return sequence;
            if (_steps == null) _steps = FindFirstObjectByType<StepSystem>();
            return _steps != null ? _steps.Sequence : null;
        }

        // Telemetría (§2.1): state_changed solo para las variables con 'registrar'.
        private static void OnStateChanged(StateChange change)
        {
            if (!change.Register) return;
            TelemetryHub.Emit(new StateChangedEvent
            {
                StepId = TelemetryContext.CurrentStepId,
                Variable = change.Variable,
                Before = change.Before,
                Value = change.After
            });
        }

        /// <summary>Recrea la tabla desde la secuencia (vuelve al estado inicial).</summary>
        public void Build()
        {
            if (_state != null) _state.Changed -= OnStateChanged;
            var seq = EffectiveSequence();
            _state = new SimulationState(seq != null ? seq.initialState : null);
            _state.Changed += OnStateChanged;
            StateCreated?.Invoke(_state);
        }
    }
}
