using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace XRLabs.Core.Diagnostics
{
    /// <summary>
    /// Wrapper de logging del framework. Info/Warn se compilan fuera de los builds
    /// de producción ([Conditional]); Error se mantiene siempre.
    /// Uso: Log.Info("[Modulo] mensaje"), Log.Warn(...), Log.Error(...).
    /// </summary>
    public static class Log
    {
        /// <summary>Log informativo. Solo Editor y Development Build.</summary>
        [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void Info(string message, Object context = null)
        {
            Debug.Log(message, context);
        }

        /// <summary>Advertencia. Solo Editor y Development Build.</summary>
        [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void Warn(string message, Object context = null)
        {
            Debug.LogWarning(message, context);
        }

        /// <summary>Error. Siempre presente, también en producción.</summary>
        public static void Error(string message, Object context = null)
        {
            Debug.LogError(message, context);
        }
    }
}
