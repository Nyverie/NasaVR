﻿using UnityEngine;

namespace XRLabs.Core
{
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Manual Key")]
    public class ManualKeyStepCondition : StepCondition
    {
        [SerializeField] private KeyCode completeKey = KeyCode.Space;

        private bool _completed;

        public override void Initialize()
        {
            _completed = false;
        }

        public override bool IsCompleted()
        {
            if (_completed)
            {
                return true;
            }

            if (InputKeyCompat.IsKeyDown(completeKey))
            {
                _completed = true;
            }

            return _completed;
        }

        public override void Cleanup()
        {
            _completed = false;
        }

        /// <summary>
        /// Lo completa algo que no es la tecla: el botón «Comenzar» del HUD en modo plano (2026-10-17: la frase del
        /// storyboard dice «pulsa Comenzar» y en pantalla no había nada que pulsar). StepSystem lo recoge en IsCompleted.
        /// </summary>
        public void Complete() => _completed = true;

        /// <summary>
        /// 0.3 lote 5 (contrato-0.3.md §2.7): «Continuar» en un paso manual lo completa, como el clic en «Comenzar». En
        /// pantalla la tecla es Intro (la recoge <see cref="StepSystem"/>, que solo la toma por «Continuar» con el coach
        /// callado: con una frase sonando, Intro la salta).
        /// </summary>
        public override bool TryConfirm(out string clave)
        {
            clave = null;
            _completed = true;
            return true;
        }
    }
}


