using System;
using System.Collections;
using System.Threading;
using UnityEngine;
using UnityEngine.Audio;

namespace XRLabs.Core
{
    /// <summary>
    /// Una frase en reproducción. La devuelve <see cref="VOManager.Say"/>; el llamador
    /// puede esperar <see cref="IsDone"/> (bloqueante) o ignorarla (no bloqueante).
    /// </summary>
    public sealed class LinePlayback
    {
        public string LineId { get; internal set; }
        public string Text { get; internal set; }
        public AudioClip Clip { get; internal set; }
        public float Duration { get; internal set; }
        public bool IsError { get; internal set; }

        public bool IsDone { get; internal set; }

        /// <summary>El usuario la saltó.</summary>
        public bool WasSkipped { get; internal set; }

        /// <summary>Otra frase (o StopAll) la cortó antes de terminar.</summary>
        public bool WasInterrupted { get; internal set; }

        internal float StartTime;

        internal static LinePlayback Completed(string id) => new() { LineId = id, Text = string.Empty, IsDone = true };
    }

    [RequireComponent(typeof(AudioSource))]
    public class VOManager : MonoBehaviour
    {
        public static VOManager Instance;

        [SerializeField, Min(0f)] private float clipGapSeconds = 0.08f;

        [Header("Frases del coach (v0.6)")]
        [Tooltip("Tablas de frases que resuelve Say(). Se busca en orden.")]
        [SerializeField] private LineLibrary[] lineLibraries;

        [Tooltip("Duración mínima de una frase antes de considerarla terminada.")]
        [SerializeField, Min(0f)] private float minLineSeconds = 0.7f;

        [Tooltip("Segundos por palabra para estimar la duración cuando falta el clip.")]
        [SerializeField, Min(0.05f)] private float secondsPerWord = 0.36f;

        [Tooltip("Duración mínima estimada cuando falta el clip.")]
        [SerializeField, Min(0f)] private float minEstimatedSeconds = 1.4f;

        [Header("Mezcla (opcional)")]
        [SerializeField] private AudioMixerGroup voiceMixerGroup;
        [SerializeField] private AudioMixerGroup sfxMixerGroup;

        private AudioSource _voSource;
        private AudioSource _sfxSource;
        private Coroutine _sequenceCoroutine;

        private LinePlayback _activeLine;
        private readonly float[] _outputBuffer = new float[256];
        private float _amplitude;

        /// <summary>True mientras hay una secuencia de VO reproduciéndose.</summary>
        public bool IsSequencePlaying => _sequenceCoroutine != null;

        /// <summary>Duración total del VO en curso (suma de todos los clips). 0 si no hay secuencia.</summary>
        public float CurrentSequenceDuration { get; private set; }

        /// <summary>Frase de Say() en curso, o null.</summary>
        public LinePlayback ActiveLine => _activeLine;

        /// <summary>True mientras suena una frase de Say().</summary>
        public bool IsSpeaking => _activeLine != null && !_activeLine.IsDone;

        /// <summary>Amplitud suavizada (0–1) de la voz. La usan el avatar y la UI del coach.</summary>
        public float Amplitude => _amplitude;

        /// <summary>Nombre y retrato del personaje (de la primera LineLibrary asignada).</summary>
        public string SpeakerName => FirstLibrary != null ? FirstLibrary.speakerName : string.Empty;
        public Sprite SpeakerPortrait => FirstLibrary != null ? FirstLibrary.speakerPortrait : null;

        public event Action<LinePlayback> LineStarted;
        public event Action<LinePlayback> LineEnded;

        private LineLibrary FirstLibrary
        {
            get
            {
                if (lineLibraries == null) return null;
                foreach (var lib in lineLibraries)
                    if (lib != null) return lib;
                return null;
            }
        }

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            _voSource = GetComponent<AudioSource>();
            if (voiceMixerGroup != null) _voSource.outputAudioMixerGroup = voiceMixerGroup;

            _sfxSource = gameObject.AddComponent<AudioSource>();
            _sfxSource.playOnAwake = false;
            _sfxSource.spatialBlend = 0f;
            if (sfxMixerGroup != null) _sfxSource.outputAudioMixerGroup = sfxMixerGroup;
        }

        private void OnDestroy()
        {
            if (Instance == this)
                Instance = null;
        }

        private void Update()
        {
            UpdateAmplitude();

            if (_activeLine == null || _activeLine.IsDone) return;

            float elapsed = Time.unscaledTime - _activeLine.StartTime;
            if (elapsed >= Mathf.Max(_activeLine.Duration, minLineSeconds))
                EndActiveLine(skipped: false, interrupted: false);
        }

        // ── Frases (v0.6) ──────────────────────────────────────────────────────

        /// <summary>Agrega una tabla de frases en runtime (ej: la sim la carga al iniciar).</summary>
        public void AddLibrary(LineLibrary library)
        {
            if (library == null) return;
            if (lineLibraries != null)
                foreach (var lib in lineLibraries)
                    if (lib == library) return;

            int n = lineLibraries != null ? lineLibraries.Length : 0;
            var next = new LineLibrary[n + 1];
            if (n > 0) Array.Copy(lineLibraries, next, n);
            next[n] = library;
            lineLibraries = next;
        }

        public bool HasLine(string lineId)
        {
            if (string.IsNullOrEmpty(lineId) || lineLibraries == null) return false;
            foreach (var lib in lineLibraries)
                if (lib != null && lib.Contains(lineId)) return true;
            return false;
        }

        public bool TryResolve(string lineId, out ResolvedLine resolved)
        {
            resolved = default;
            if (string.IsNullOrEmpty(lineId) || lineLibraries == null) return false;
            foreach (var lib in lineLibraries)
                if (lib != null && lib.TryResolve(lineId, LanguageService.Current, out resolved))
                    return true;
            return false;
        }

        /// <summary>
        /// Dice una frase por ID en el idioma activo. Corta cualquier frase o secuencia
        /// anterior (una sola voz a la vez). Si falta el clip, la frase igual se muestra
        /// como subtítulo y dura una estimación por palabras.
        /// </summary>
        public LinePlayback Say(string lineId, bool isError = false)
        {
            if (string.IsNullOrEmpty(lineId))
                return LinePlayback.Completed(lineId);

            InterruptVoice();

            string text;
            AudioClip clip = null;
            if (TryResolve(lineId, out var resolved))
            {
                text = resolved.Text;
                clip = resolved.Clip;
            }
            else
            {
                Debug.LogWarning($"[VO] Frase no encontrada en las LineLibrary: '{lineId}'");
                text = Debug.isDebugBuild ? $"[{lineId}]" : string.Empty;
            }

            if (clip == null && !string.IsNullOrEmpty(text))
                Debug.LogWarning($"[VO] Sin clip para '{lineId}' ({LanguageService.Code}); se usa duración estimada.");

            var playback = new LinePlayback
            {
                LineId = lineId,
                Text = text,
                Clip = clip,
                IsError = isError,
                Duration = clip != null ? clip.length : EstimateDuration(text),
                StartTime = Time.unscaledTime
            };

            _activeLine = playback;

            if (clip != null)
            {
                _voSource.clip = clip;
                _voSource.Play();
            }

            LineStarted?.Invoke(playback);
            return playback;
        }

        public LinePlayback Say(LineRef line, bool isError = false) => Say(line.id, isError);

        /// <summary>Versión await-able de Say: termina cuando acaba la frase (o la cortan).</summary>
        public async Awaitable SayAsync(string lineId, bool isError = false, CancellationToken cancellationToken = default)
        {
            var playback = Say(lineId, isError);
            while (!playback.IsDone)
                await Awaitable.NextFrameAsync(cancellationToken);
        }

        /// <summary>Para corrutinas: <c>yield return VOManager.Instance.WaitFor(playback);</c></summary>
        public IEnumerator WaitFor(LinePlayback playback)
        {
            while (playback != null && !playback.IsDone)
                yield return null;
        }

        /// <summary>Salta la frase en curso (clic en el subtítulo, botón del mando).</summary>
        public void Skip()
        {
            if (!IsSpeaking) return;
            _voSource.Stop();
            EndActiveLine(skipped: true, interrupted: false);
        }

        /// <summary>Detiene solo la voz (frase o secuencia), sin tocar los SFX.</summary>
        public void StopVoice()
        {
            InterruptVoice();
            CurrentSequenceDuration = 0f;
        }

        /// <summary>Estimación usada cuando falta el clip.</summary>
        public float EstimateDuration(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return 0f;
            int words = text.Split((char[])null, StringSplitOptions.RemoveEmptyEntries).Length;
            return Mathf.Max(minEstimatedSeconds, words * secondsPerWord);
        }

        /// <summary>Espectro de la voz para visualizaciones (tamaño potencia de 2, 64–8192).</summary>
        public void GetSpectrum(float[] destination)
        {
            if (destination == null || _voSource == null) return;
            _voSource.GetSpectrumData(destination, 0, FFTWindow.BlackmanHarris);
        }

        // ── API legada (v0.5) ─────────────────────────────────────────────────

        /// <summary>
        /// Reproduce una secuencia de clips de VO uno tras otro.
        /// Si ya hay una secuencia en curso, la detiene antes de iniciar la nueva.
        /// </summary>
        public void PlaySequence(AudioClip[] clips)
        {
            InterruptVoice();

            if (clips == null || clips.Length == 0)
            {
                CurrentSequenceDuration = 0f;
                _sequenceCoroutine = null;
                return;
            }

            float total = 0f;
            int playableClipCount = 0;
            foreach (var c in clips)
            {
                if (c == null) continue;
                total += c.length;
                playableClipCount++;
            }
            total += Mathf.Max(0, playableClipCount - 1) * clipGapSeconds;
            CurrentSequenceDuration = total;

            _sequenceCoroutine = StartCoroutine(PlaySequenceRoutine(clips));
        }

        /// <summary>Reproduce un único clip de VO (compatibilidad con código anterior).</summary>
        public void PlayInstruction(AudioClip clip)
        {
            PlaySequence(clip != null ? new[] { clip } : null);
        }

        /// <summary>Reproduce un SFX por encima del VO sin interrumpirlo.</summary>
        public void PlaySFX(AudioClip clip)
        {
            if (clip == null) return;
            _sfxSource.PlayOneShot(clip);
        }

        /// <summary>Detiene el VO en curso y el SFX.</summary>
        public void StopAll()
        {
            InterruptVoice();
            _sfxSource.Stop();
            CurrentSequenceDuration = 0f;
        }

        // ── Internos ──────────────────────────────────────────────────────────

        private void InterruptVoice()
        {
            if (_sequenceCoroutine != null)
            {
                StopCoroutine(_sequenceCoroutine);
                _sequenceCoroutine = null;
            }

            _voSource.Stop();

            if (IsSpeaking)
                EndActiveLine(skipped: false, interrupted: true);
        }

        private void EndActiveLine(bool skipped, bool interrupted)
        {
            var line = _activeLine;
            if (line == null || line.IsDone) return;

            line.IsDone = true;
            line.WasSkipped = skipped;
            line.WasInterrupted = interrupted;
            LineEnded?.Invoke(line);
        }

        private void UpdateAmplitude()
        {
            float target = 0f;
            if (_voSource != null && _voSource.isPlaying)
            {
                _voSource.GetOutputData(_outputBuffer, 0);
                float sum = 0f;
                for (int i = 0; i < _outputBuffer.Length; i++)
                    sum += _outputBuffer[i] * _outputBuffer[i];
                target = Mathf.Clamp01(Mathf.Sqrt(sum / _outputBuffer.Length) * 6f);
            }
            _amplitude = Mathf.Lerp(_amplitude, target, 0.4f);
        }

        private IEnumerator PlaySequenceRoutine(AudioClip[] clips)
        {
            int playableClipCount = 0;
            foreach (var clip in clips)
                if (clip != null) playableClipCount++;

            int playedClipCount = 0;
            foreach (var clip in clips)
            {
                if (clip == null) continue;
                _voSource.clip = clip;
                _voSource.Play();
                yield return new WaitForSeconds(clip.length);

                playedClipCount++;
                if (clipGapSeconds > 0f && playedClipCount < playableClipCount)
                    yield return new WaitForSeconds(clipGapSeconds);
            }
            _sequenceCoroutine = null;
        }
    }
}
