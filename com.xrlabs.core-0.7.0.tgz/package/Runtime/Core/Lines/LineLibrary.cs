using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Referencia serializable a una frase por ID estable (ej: "s4.cubrir.instr").
    /// Los StepDefinition guardan LineRef en lugar de clips sueltos: el texto y el
    /// audio se resuelven por idioma en runtime.
    /// </summary>
    [Serializable]
    public struct LineRef
    {
        public string id;

        public LineRef(string id) => this.id = id;

        public bool IsEmpty => string.IsNullOrEmpty(id);

        public override string ToString() => id;
    }

    /// <summary>Texto y audio de una frase en un idioma.</summary>
    [Serializable]
    public class VoiceLineVariant
    {
        public CoachLanguage language;

        [Tooltip("Texto en pantalla (subtítulo).")]
        [TextArea(2, 5)] public string text;

        [Tooltip("Opcional. Texto que se envía al TTS cuando difiere del subtítulo (siglas, números con letras).")]
        [TextArea(1, 4)] public string spokenText;

        [Tooltip("Clip horneado para este idioma. Vacío = la frase dura una estimación y solo muestra subtítulo.")]
        public AudioClip clip;

        [Tooltip("Hash de lo que generó el clip (lo escribe el horneador de voz). No editar a mano.")]
        public string bakeHash;
    }

    /// <summary>Una frase del coach: ID estable + una variante por idioma.</summary>
    [Serializable]
    public class VoiceLine
    {
        public string id;

        [Tooltip("Nota para quien escribe el guion (contexto, intención). No se muestra.")]
        public string note;

        [Tooltip("Solo texto: etiquetas, títulos, opciones o tarjetas que se muestran pero no se dicen. " +
                 "El horneador de voz las salta y no cuentan para la validación del build.")]
        public bool textOnly;

        public List<VoiceLineVariant> variants = new();

        public VoiceLineVariant GetVariant(CoachLanguage language)
        {
            if (variants == null) return null;
            foreach (var v in variants)
                if (v != null && v.language == language)
                    return v;
            return null;
        }
    }

    /// <summary>Regla del diccionario de pronunciación: lo escrito en pantalla → lo que se dice.</summary>
    [Serializable]
    public class PronunciationRule
    {
        public CoachLanguage language;
        public string written;
        public string spoken;
    }

    /// <summary>Frase resuelta para el idioma activo, lista para mostrar y reproducir.</summary>
    public readonly struct ResolvedLine
    {
        public readonly string Id;
        public readonly string Text;
        public readonly AudioClip Clip;

        public ResolvedLine(string id, string text, AudioClip clip)
        {
            Id = id;
            Text = text;
            Clip = clip;
        }
    }

    /// <summary>
    /// Tabla de frases de una simulación (subtítulos + voz por idioma). Es la fuente
    /// única de lo que dice el coach; el horneador de voz del editor la recorre para
    /// generar los clips que faltan.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Line Library")]
    public class LineLibrary : ScriptableObject
    {
        [Header("Personaje")]
        public string speakerName = "Coach";
        public Sprite speakerPortrait;

        [Header("Frases")]
        public List<VoiceLine> lines = new();

        [Header("Pronunciación (solo para el TTS)")]
        public List<PronunciationRule> pronunciation = new();

        private Dictionary<string, VoiceLine> _cache;

        private void OnEnable() => _cache = null;
        private void OnValidate() => _cache = null;

        /// <summary>Descarta la caché de búsqueda. Llamar tras reemplazar <see cref="lines"/> por código (importadores).</summary>
        public void InvalidateCache() => _cache = null;

        public bool Contains(string id) => Find(id) != null;

        public VoiceLine Find(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;

            if (_cache == null)
            {
                _cache = new Dictionary<string, VoiceLine>(lines.Count);
                foreach (var line in lines)
                    if (line != null && !string.IsNullOrEmpty(line.id))
                        _cache[line.id] = line;
            }

            return _cache.TryGetValue(id, out var found) ? found : null;
        }

        /// <summary>
        /// Resuelve texto y clip en el idioma pedido. Si falta el texto en ese idioma,
        /// usa el de cualquier otro idioma (mejor un subtítulo en otro idioma que nada).
        /// </summary>
        public bool TryResolve(string id, CoachLanguage language, out ResolvedLine resolved)
        {
            resolved = default;
            var line = Find(id);
            if (line == null) return false;

            var variant = line.GetVariant(language);
            string text = variant != null ? variant.text : null;
            AudioClip clip = variant != null ? variant.clip : null;

            if (string.IsNullOrEmpty(text) && line.variants != null)
            {
                foreach (var v in line.variants)
                {
                    if (v != null && !string.IsNullOrEmpty(v.text))
                    {
                        text = v.text;
                        break;
                    }
                }
            }

            resolved = new ResolvedLine(id, text ?? string.Empty, clip);
            return true;
        }

        /// <summary>Texto que debe recibir el TTS: spokenText si existe, si no el texto con el diccionario aplicado.</summary>
        public string GetSpokenText(VoiceLineVariant variant)
        {
            if (variant == null) return string.Empty;
            if (!string.IsNullOrEmpty(variant.spokenText)) return variant.spokenText;

            string result = variant.text ?? string.Empty;
            if (pronunciation == null) return result;

            foreach (var rule in pronunciation)
            {
                if (rule == null || rule.language != variant.language || string.IsNullOrEmpty(rule.written)) continue;
                result = result.Replace(rule.written, rule.spoken ?? string.Empty);
            }
            return result;
        }
    }
}
