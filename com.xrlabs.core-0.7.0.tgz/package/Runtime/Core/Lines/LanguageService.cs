using System;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>Idiomas soportados por las frases del coach.</summary>
    public enum CoachLanguage
    {
        Spanish,
        English
    }

    /// <summary>
    /// Idioma activo de la experiencia. El cambio se aplica en caliente: subtítulos y
    /// voz lo leen en cada frase nueva, y la UI puede escuchar <see cref="Changed"/>.
    /// Se persiste en PlayerPrefs para que el idioma elegido sobreviva entre sesiones.
    /// </summary>
    public static class LanguageService
    {
        private const string PrefsKey = "xrlabs.language";

        private static bool _loaded;
        private static CoachLanguage _current = CoachLanguage.Spanish;

        public static event Action<CoachLanguage> Changed;

        public static CoachLanguage Current
        {
            get
            {
                EnsureLoaded();
                return _current;
            }
        }

        /// <summary>Código ISO corto del idioma activo ("es" | "en").</summary>
        public static string Code => ToCode(Current);

        public static void Set(CoachLanguage language)
        {
            EnsureLoaded();
            if (_current == language) return;

            _current = language;
            PlayerPrefs.SetInt(PrefsKey, (int)language);
            Changed?.Invoke(language);
        }

        public static string ToCode(CoachLanguage language) => language switch
        {
            CoachLanguage.English => "en",
            _ => "es"
        };

        private static void EnsureLoaded()
        {
            if (_loaded) return;
            _loaded = true;
            _current = (CoachLanguage)PlayerPrefs.GetInt(PrefsKey, (int)CoachLanguage.Spanish);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics()
        {
            _loaded = false;
            Changed = null;
        }
    }
}
