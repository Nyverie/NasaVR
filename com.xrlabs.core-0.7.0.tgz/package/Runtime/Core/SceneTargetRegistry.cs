using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Core
{
    /// <summary>
    /// Registro de objetos de escena por ID estable. Lo usan el coach (a dónde señalar),
    /// el feedback (dónde lanzar partículas) y los resaltados del paso, sin que Core
    /// dependa de Interactions. InteractableBase y CoachAnchor se registran solos.
    /// </summary>
    public static class SceneTargetRegistry
    {
        private static readonly Dictionary<string, Transform> Targets = new();

        public static void Register(string id, Transform target)
        {
            if (string.IsNullOrEmpty(id) || target == null) return;
            Targets[id] = target;
        }

        public static void Unregister(string id, Transform target)
        {
            if (string.IsNullOrEmpty(id)) return;
            if (Targets.TryGetValue(id, out var current) && current == target)
                Targets.Remove(id);
        }

        public static bool TryGet(string id, out Transform target)
        {
            target = null;
            if (string.IsNullOrEmpty(id)) return false;
            if (!Targets.TryGetValue(id, out target)) return false;
            if (target != null) return true;

            Targets.Remove(id);
            return false;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() => Targets.Clear();
    }
}
