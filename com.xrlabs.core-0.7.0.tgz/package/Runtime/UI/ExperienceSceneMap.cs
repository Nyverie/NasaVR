using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace XRLabs.UI
{
    /// <summary>
    /// Mapeo id de experiencia (del API) → nombre de escena Unity de la experiencia.
    /// El proyecto consumidor crea una instancia llamada "ExperienceSceneMap" dentro
    /// de una carpeta Resources (menú: XR Platform → Experience Scene Map) — el paquete
    /// es read-only, por eso el registro vive del lado del proyecto.
    /// Desde 0.7.0 los ids son de texto: cada entrada se busca por <see cref="Entry.experienceKey"/> y, si ninguna
    /// coincide, por el <see cref="Entry.experienceId"/> heredado convertido a texto, así que un asset de v0.5.1 sigue
    /// resolviendo igual sin tocarlo (D8).
    /// </summary>
    [CreateAssetMenu(fileName = "ExperienceSceneMap", menuName = "XR Platform/Experience Scene Map")]
    public class ExperienceSceneMap : ScriptableObject
    {
        [Serializable]
        public struct Entry
        {
            [Tooltip("Id de texto de la experiencia según el backend (p. ej. el cuid). Opcional: si está vacío, cuenta Experience Id")]
            public string experienceKey;
            [Tooltip("Id numérico heredado (v0.5): se compara como texto cuando ninguna clave coincide")]
            public int experienceId;
            [Tooltip("Nombre de la escena (debe estar en Build Settings)")]
            public string sceneName;
            [Tooltip("Título que ve la persona en el menú (opcional: lo rellena «Importar guion» con experiencia.titulo). Vacío = el nombre de la escena, como en v0.7.0")]
            public string title;
        }

        [SerializeField] private List<Entry> entries = new();

        /// <summary>Las entradas tal como están en el asset (solo lectura).</summary>
        public IReadOnlyList<Entry> Entries => entries;

        /// <summary>
        /// La escena de una experiencia: primero la entrada cuya clave de texto es <paramref name="experienceId"/>
        /// (comparación exacta), después la que tiene ese id heredado; null si ninguna.
        /// </summary>
        public string GetSceneName(string experienceId)
        {
            if (string.IsNullOrEmpty(experienceId)) return null;

            foreach (var e in entries)
                if (!string.IsNullOrEmpty(e.experienceKey) && string.Equals(e.experienceKey, experienceId, StringComparison.Ordinal))
                    return e.sceneName;

            foreach (var e in entries)
                if (string.Equals(e.experienceId.ToString(CultureInfo.InvariantCulture), experienceId, StringComparison.Ordinal))
                    return e.sceneName;

            return null;
        }
    }
}
