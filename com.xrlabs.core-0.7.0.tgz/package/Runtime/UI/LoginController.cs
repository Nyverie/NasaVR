using Cysharp.Threading.Tasks;
using XRLabs.Networking;
using XRLabs.Networking.Mock;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.UI
{
    /// <summary>
    /// Controla la pantalla de login con PIN de 6 digitos.
    /// Puede conectarse desde Inspector o autocablearse con los nombres de Menu.unity.
    /// </summary>
    public class LoginController : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private TextMeshProUGUI pinDisplay;
        [SerializeField] private TextMeshProUGUI errorText;
        [SerializeField] private GameObject loadingIndicator;
        [SerializeField] private GameObject pinKeyboard;
        [SerializeField] private TextMeshProUGUI[] pinSlots;

        [Header("Navigation")]
        [SerializeField] private UnityEngine.Events.UnityEvent onLoginSuccess;

        private string _currentPin = "";
        private bool _isLoggingIn;

        private void Awake()
        {
            AutoWireSceneReferences();
            AutoWireNumpadButtons();
        }

        private void Start()
        {
            if (errorText) errorText.gameObject.SetActive(false);
            if (loadingIndicator) loadingIndicator.SetActive(false);
            UpdatePinDisplay();
        }

        /// <summary>Llamar desde los botones del teclado VR (0-9).</summary>
        public void OnKeyPressed(string digit)
        {
            if (_isLoggingIn || _currentPin.Length >= 6) return;
            _currentPin += digit;
            UpdatePinDisplay();

            if (_currentPin.Length == 6)
                SubmitPin().Forget();
        }

        public void OnDeletePressed()
        {
            if (_isLoggingIn || _currentPin.Length == 0) return;
            _currentPin = _currentPin[..^1];
            UpdatePinDisplay();
            HideError();
        }

        public void OnClearPressed()
        {
            if (_isLoggingIn) return;
            _currentPin = "";
            UpdatePinDisplay();
            HideError();
        }

        private async UniTaskVoid SubmitPin()
        {
            _isLoggingIn = true;
            HideError();
            SetLoading(true);

            bool useMock = ApiClient.Instance != null && ApiClient.Instance.Settings.useMockData;

            if (useMock)
            {
                var mockResult = await MockApiClient.Login(_currentPin, destroyCancellationToken);
                if (mockResult.Success && mockResult.Data?.User != null)
                {
                    var u = mockResult.Data.User;
                    AuthManager.Instance?.SetUser(new XRLabs.Networking.Models.AuthenticatedUser
                    {
                        Id = u.Id,
                        DisplayName = !string.IsNullOrEmpty(u.FirstName) ? u.FirstName : u.Username ?? "Usuario",
                        OrgId = u.Organization?.Id,
                        RoleId = u.Role?.Id
                    });
                }
                HandleLoginResult(mockResult.Success, mockResult.Success ? null : mockResult.ErrorMessage, null);
            }
            else
            {
                var result = await AuthManager.Instance.LoginWithPin(_currentPin);
                HandleLoginResult(result.Success, result.Success ? null : result.ErrorMessage, null);
            }
        }

        private void HandleLoginResult(bool success, string errorMessage, object userData)
        {
            SetLoading(false);
            _isLoggingIn = false;

            if (success)
            {
                if (onLoginSuccess != null && onLoginSuccess.GetPersistentEventCount() > 0)
                    onLoginSuccess.Invoke();
                else
                    FindFirstObjectByType<UIFlowController>()?.ShowMainMenu();

                return;
            }

            // Mostrar mensaje amigable según el tipo de error
            string displayMessage = errorMessage switch
            {
                var m when m != null && (m.Contains("401") || m.Contains("inválido") || m.Contains("expirado") || m.Contains("Unauthorized"))
                    => "PIN incorrecto o expirado.\nSolicita un nuevo PIN e intenta de nuevo.",
                var m when m != null && (m.Contains("400") || m.Contains("Validation"))
                    => "PIN inválido. Verifica e intenta de nuevo.",
                var m when m != null && (m.Contains("timeout") || m.Contains("cancelado") || m.Contains("network") || m.Contains("red"))
                    => "Sin conexión al servidor.\nVerifica tu red e intenta de nuevo.",
                _ => "No se pudo conectar. Intenta de nuevo."
            };

            ShowError(displayMessage);
            _currentPin = "";
            UpdatePinDisplay();
        }

        private void UpdatePinDisplay()
        {
            string display = new string('\u25CF', _currentPin.Length).PadRight(6, '\u25CB');

            if (pinDisplay)
                pinDisplay.text = display;

            if (pinSlots == null || pinSlots.Length == 0)
                return;

            for (int i = 0; i < pinSlots.Length; i++)
            {
                if (!pinSlots[i]) continue;
                pinSlots[i].text = i < _currentPin.Length ? "\u25CF" : "\u25CB";
            }
        }

        private void ShowError(string message)
        {
            if (!errorText) return;
            errorText.text = message;
            errorText.gameObject.SetActive(true);
        }

        private void HideError()
        {
            if (errorText) errorText.gameObject.SetActive(false);
        }

        private void SetLoading(bool active)
        {
            if (loadingIndicator) loadingIndicator.SetActive(active);
            if (pinKeyboard) pinKeyboard.SetActive(!active);
        }

        private void AutoWireSceneReferences()
        {
            var loginRoot = GameObject.Find("Login");
            if (!loginRoot)
                return;

            if (!pinKeyboard)
                pinKeyboard = FindChildByName(loginRoot.transform, "Numpad")?.gameObject;

            if (!errorText)
                errorText = FindTextByObjectName(loginRoot.transform, "Error");

            if (!loadingIndicator)
                loadingIndicator = FindChildByName(loginRoot.transform, "LoadingIndicator")?.gameObject;

            if (!pinDisplay)
                pinDisplay = FindChildByName(loginRoot.transform, "PinDisplay")?.GetComponent<TextMeshProUGUI>();

            if ((pinSlots == null || pinSlots.Length == 0) && pinKeyboard)
                pinSlots = FindPinSlots(loginRoot.transform, pinKeyboard.transform);
        }

        private void AutoWireNumpadButtons()
        {
            if (!pinKeyboard)
                return;

            foreach (var button in pinKeyboard.GetComponentsInChildren<Button>(true))
            {
                if (!TryGetDigit(button.gameObject.name, out string digit))
                    continue;

                string capturedDigit = digit;
                button.onClick.AddListener(() => OnKeyPressed(capturedDigit));
            }
        }

        private static bool TryGetDigit(string objectName, out string digit)
        {
            digit = null;
            if (string.IsNullOrEmpty(objectName) || !objectName.StartsWith("Digito"))
                return false;

            for (int i = objectName.Length - 1; i >= 0; i--)
            {
                if (!char.IsDigit(objectName[i]))
                    continue;

                digit = objectName[i].ToString();
                return true;
            }

            return false;
        }

        private static Transform FindChildByName(Transform root, string childName)
        {
            foreach (var child in root.GetComponentsInChildren<Transform>(true))
            {
                if (child.name == childName)
                    return child;
            }

            return null;
        }

        private static TextMeshProUGUI FindTextByObjectName(Transform root, string objectName)
        {
            foreach (var text in root.GetComponentsInChildren<TextMeshProUGUI>(true))
            {
                if (text.gameObject.name == objectName)
                    return text;
            }

            return null;
        }

        private static TextMeshProUGUI[] FindPinSlots(Transform loginRoot, Transform keyboardRoot)
        {
            var slotList = new System.Collections.Generic.List<TextMeshProUGUI>();

            foreach (var text in loginRoot.GetComponentsInChildren<TextMeshProUGUI>(true))
            {
                if (!text.gameObject.name.StartsWith("Pin"))
                    continue;

                if (text.transform.IsChildOf(keyboardRoot))
                    continue;

                slotList.Add(text);
            }

            slotList.Sort((a, b) =>
            {
                var aPos = ((RectTransform)a.transform).anchoredPosition;
                var bPos = ((RectTransform)b.transform).anchoredPosition;
                return aPos.x.CompareTo(bPos.x);
            });

            return slotList.ToArray();
        }
    }
}
