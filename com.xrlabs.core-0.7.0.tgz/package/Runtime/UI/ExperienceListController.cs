using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using XRLabs.Networking;
using XRLabs.Networking.Mock;
using XRLabs.Networking.Models;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace XRLabs.UI
{
    /// <summary>
    /// Muestra las experiencias del grupo seleccionado con el progreso del usuario.
    /// Conectar en el Inspector: cardContainer, experienceCardPrefab, loadingIndicator.
    /// </summary>
    public class ExperienceListController : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private Transform cardContainer;
        [SerializeField] private GameObject experienceCardPrefab;

        // CAMBIO:
        // Layout XR personalizado para posicionar cards.
        [SerializeField] private XRVerticalLayout layout;

        [SerializeField] private GameObject loadingIndicator;
        [SerializeField] private GameObject errorPanel;
        [SerializeField] private TMPro.TextMeshProUGUI errorText;
        [SerializeField] private TMPro.TextMeshProUGUI groupNameText;

        private void Start()
        {
            if (groupNameText && AppState.SelectedGroup != null)
                groupNameText.text = AppState.SelectedGroup.Group?.Name ?? "";

            LoadExperiences().Forget();
        }

        private async UniTaskVoid LoadExperiences()
        {
            SetLoading(true);

            var group = AppState.SelectedGroup;

            if (group == null)
            {
                ShowError("No hay grupo seleccionado.");
                return;
            }

            string groupId = group.Group?.Id;
            string userId = AuthManager.Instance?.CurrentUser?.Id ?? "";

            bool useMock =
                ApiClient.Instance != null &&
                ApiClient.Instance.Settings.useMockData;

            List<ExperienceListItem> experiences;

            if (useMock)
            {
                var result = await MockApiClient.GetGroupExperiences(
                    groupId,
                    userId,
                    destroyCancellationToken
                );

                if (!result.Success)
                {
                    ShowError(result.ErrorMessage);
                    return;
                }

                experiences = result.Data;
            }
            else
            {
                var result = await DataService.Instance.FetchGroupExperiences(
                    groupId,
                    userId
                );

                if (!result.Success)
                {
                    ShowError(result.ErrorMessage);
                    return;
                }

                experiences = result.Data;
            }

            SetLoading(false);

            SpawnCards(experiences);
        }

        private void SpawnCards(List<ExperienceListItem> experiences)
        {
            if (!cardContainer || !experienceCardPrefab)
                return;

            // CAMBIO:
            // En XR evitamos destruir UI dinámica.
            // Solo desactivamos cards anteriores.
            foreach (Transform child in cardContainer)
            {
                child.gameObject.SetActive(false);
            }

            foreach (var item in experiences)
            {
                if (!item.Experience.IsVR)
                    continue;

                var card = Instantiate(
                    experienceCardPrefab,
                    cardContainer
                );

                var cardView =
                    card.GetComponent<ExperienceCardView>();

                if (cardView != null)
                    cardView.Bind(item, OnStartExperience);
            }

            // CAMBIO:
            // Reconstruir layout XR manualmente.
            if (layout != null)
            {
                layout.Rebuild();
            }
        }

        private async void OnStartExperience(
            ExperienceListItem item
        )
        {
            AppState.SelectedExperience = item;

            // Cargar la escena de la experiencia (ExperienceSceneMap de Resources, por id de texto)
            string sceneName =
                GetSceneName(item.Experience.Id);

            if (!string.IsNullOrEmpty(sceneName))
            {
                SceneTransitionManager.LoadScene(sceneName);
            }
            else
            {
                Debug.LogWarning(
                    $"[ExperienceList] No hay escena configurada para experienceId={item.Experience.Id}"
                );
            }

            await UniTask.CompletedTask;
        }

        private static ExperienceSceneMap _sceneMap;
        private static bool _sceneMapSearched;

        private static string GetSceneName(string experienceId)
        {
            if (!_sceneMapSearched)
            {
                _sceneMap = Resources.Load<ExperienceSceneMap>("ExperienceSceneMap");
                _sceneMapSearched = true;

                if (_sceneMap == null)
                    Debug.LogWarning("[ExperienceList] No se encontró un ExperienceSceneMap en Resources. " +
                                     "Crear uno con el menú 'XR Platform → Experience Scene Map' y registrar las escenas.");
            }

            return _sceneMap != null ? _sceneMap.GetSceneName(experienceId) : null;
        }

        private void SetLoading(bool active)
        {
            if (loadingIndicator)
                loadingIndicator.SetActive(active);

            if (cardContainer)
                cardContainer.gameObject.SetActive(!active);
        }

        private void ShowError(string message)
        {
            SetLoading(false);

            if (errorPanel)
                errorPanel.SetActive(true);

            if (errorText)
                errorText.text = message;
        }
    }
}