namespace XRLabs.UI
{
    /// <summary>
    /// Estado de navegación entre escenas. Permite que una escena destino sepa
    /// desde dónde fue cargada para mostrar el panel correcto al inicio.
    /// </summary>
    public static class NavigationState
    {
        /// <summary>
        /// Si true, la escena Menu debe mostrar MainMenuPanel_Futuristic directamente
        /// en lugar del LoginPanel_Futuristic (el usuario ya está autenticado).
        /// </summary>
        public static bool SkipToMainMenu { get; set; }
    }
}
