using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;

namespace XRLabs.UI
{
    /// <summary>
    /// Gestiona el flujo Login → Menú → Experiencias usando únicamente los paneles _Futuristic.
    /// Los 3 campos están conectados en el Inspector a los prefabs Futuristic de la escena Menu.
    /// </summary>
    public class UIFlowController : MonoBehaviour
    {
        [Header("Paneles Futuristic")]
        [FormerlySerializedAs("loginPanel")]
        [SerializeField] private CanvasGroup loginPanelFuturistic;

        [FormerlySerializedAs("mainMenuPanel")]
        [SerializeField] private CanvasGroup mainMenuPanelFuturistic;

        [FormerlySerializedAs("experienceListPanel")]
        [SerializeField] private CanvasGroup experienceListPanelFuturistic;

        [Header("Transición")]
        [SerializeField] private float fadeDuration = 0.25f;

        private CanvasGroup _current;
        private Coroutine _transition;

        private void Awake()
        {
            AutoWirePanels();
            EnsureInputModule(FindFirstObjectByType<EventSystem>());
        }

        /// <summary>
        /// El EventSystem de la escena Menu del paquete trae como único módulo de entrada el del SDK de Meta
        /// (PointableCanvasModule). En un proyecto sin ese SDK queda como script perdido y el EventSystem no tiene ningún
        /// módulo: nadie puede teclear el PIN, ni con el ratón en el Editor. Entonces se agrega uno (el del Input System, o
        /// el estándar si el proyecto solo usa el Input Manager viejo) para el ratón y el teclado en el Editor y en
        /// pantalla plana; el visor necesita además un rig XR (Documentation~/plan.md, «Lote siguiente»). Con un módulo
        /// activo, como el del SDK de Meta, no se toca nada (D8).
        /// </summary>
        internal static bool EnsureInputModule(EventSystem eventSystem)
        {
            if (eventSystem == null) return false;
            foreach (var module in eventSystem.GetComponents<BaseInputModule>())
                if (module.enabled) return false;

#if ENABLE_INPUT_SYSTEM
            eventSystem.gameObject.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            eventSystem.gameObject.AddComponent<StandaloneInputModule>();
#endif
            Debug.LogWarning("[UIFlow] El EventSystem no tenía ningún módulo de entrada activo (¿falta el SDK de Meta?): " +
                             "se agregó uno para el ratón y el teclado. El visor necesita además un rig XR.");
            return true;
        }

        private void Start()
        {
            if (NavigationState.SkipToMainMenu)
            {
                NavigationState.SkipToMainMenu = false;
                BootstrapToMainMenuFuturistic();
                return;
            }

            // Estado inicial normal: solo LoginPanel_Futuristic visible
            SetImmediate(loginPanelFuturistic, true);
            SetImmediate(mainMenuPanelFuturistic, false);
            SetImmediate(experienceListPanelFuturistic, false);
            _current = loginPanelFuturistic;
        }

        /// <summary>Llamar desde el evento onLoginSuccess del LoginController.</summary>
        public void ShowMainMenu() => TransitionTo(mainMenuPanelFuturistic);

        /// <summary>Llamar desde el evento onGroupSelected del MainMenuController.</summary>
        public void ShowExperienceList() => TransitionTo(experienceListPanelFuturistic);

        /// <summary>Vuelve al menú principal desde la lista de experiencias (botón Atrás).</summary>
        public void ShowMainMenuBack() => TransitionTo(mainMenuPanelFuturistic);

        /// <summary>
        /// Carga la escena de la simulación.
        /// Llamar desde ExperienceListController cuando el usuario toca "Iniciar".
        /// </summary>
        public void LoadSimulationScene(string sceneName)
        {
            SceneTransitionManager.LoadScene(sceneName);
        }

        // Activa directamente MainMenuPanel_Futuristic cuando se llega desde evaluación
        private void BootstrapToMainMenuFuturistic()
        {
            SetImmediate(loginPanelFuturistic, false);
            SetImmediate(mainMenuPanelFuturistic, true);
            SetImmediate(experienceListPanelFuturistic, false);
            _current = mainMenuPanelFuturistic;
        }

        private void TransitionTo(CanvasGroup next)
        {
            if (!next) return;
            if (next == _current) return;

            var leaving = _current;
            _current = next;

            if (!leaving)
            {
                SetImmediate(next, true);
                return;
            }

            if (_transition != null) StopCoroutine(_transition);
            _transition = StartCoroutine(TransitionRoutine(leaving, next));
        }

        private IEnumerator TransitionRoutine(CanvasGroup leaving, CanvasGroup next)
        {
            yield return CanvasGroupFade.FadeTo(leaving, 0f, fadeDuration);

            leaving.interactable = false;
            leaving.blocksRaycasts = false;
            leaving.gameObject.SetActive(false);

            next.gameObject.SetActive(true);
            next.alpha = 0f;

            yield return CanvasGroupFade.FadeTo(next, 1f, fadeDuration);

            next.interactable = true;
            next.blocksRaycasts = true;
            _transition = null;
        }

        private static void SetImmediate(CanvasGroup panel, bool visible)
        {
            if (!panel) return;
            panel.alpha = visible ? 1f : 0f;
            panel.interactable = visible;
            panel.blocksRaycasts = visible;
            panel.gameObject.SetActive(visible);
        }

        // Fallback: auto-conecta los paneles por nombre si los campos están vacíos en el Inspector.
        // Busca también en GameObjects inactivos usando Resources.FindObjectsOfTypeAll.
        private void AutoWirePanels()
        {
            if (!loginPanelFuturistic)
                loginPanelFuturistic = FindPanelInScene("LoginPanel_Futuristic");

            if (!mainMenuPanelFuturistic)
                mainMenuPanelFuturistic = FindPanelInScene("MainMenuPanel_Futuristic");

            if (!experienceListPanelFuturistic)
                experienceListPanelFuturistic = FindPanelInScene("ExperienceListPanel_Futuristic");
        }

        private CanvasGroup FindPanelInScene(string panelName)
        {
            foreach (var t in Resources.FindObjectsOfTypeAll<Transform>())
            {
                if (t.name != panelName) continue;
                if (t.gameObject.scene != gameObject.scene) continue;

                return t.GetComponent<CanvasGroup>() ?? t.gameObject.AddComponent<CanvasGroup>();
            }

            return null;
        }
    }
}
