using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using XRLabs.Networking;
using XRLabs.Networking.Mock;
using XRLabs.Networking.Models;
using UnityEngine;

namespace XRLabs.UI
{
    /// <summary>
    /// Muestra los grupos/cursos del usuario autenticado.
    /// Conectar en el Inspector: cardContainer, courseCardPrefab, loadingIndicator, errorPanel.
    /// </summary>
    public class MainMenuController : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private Transform cardContainer;
        [SerializeField] private GameObject courseCardPrefab;
        [SerializeField] private GameObject loadingIndicator;
        [SerializeField] private GameObject errorPanel;
        [SerializeField] private TMPro.TextMeshProUGUI errorText;
        [SerializeField] private TMPro.TextMeshProUGUI userNameText;

        [Header("Navigation")]
        [SerializeField] private UnityEngine.Events.UnityEvent onGroupSelected;

        private List<UserGroupResponse> _groups;

        private void OnEnable()
        {
            // Carga datos solo cuando este panel se activa y el usuario ya está autenticado.
            // Cubre el caso en que el panel se habilita DESPUÉS del login (flujo normal).
            if (AuthManager.Instance?.CurrentUser != null)
            {
                ShowUser();
                LoadGroups().Forget();
            }
            else
            {
                // Si aún no hay usuario, esperar al evento de auth.
                Debug.Log("[MainMenu] Esperando autenticación...");
                if (AuthManager.Instance != null)
                    AuthManager.Instance.OnAuthStateChanged += OnAuthenticated;
            }
        }

        private void OnDisable()
        {
            if (AuthManager.Instance != null)
                AuthManager.Instance.OnAuthStateChanged -= OnAuthenticated;
        }

        private void OnAuthenticated(AuthenticatedUser user)
        {
            if (AuthManager.Instance != null)
                AuthManager.Instance.OnAuthStateChanged -= OnAuthenticated;

            if (user == null) return;

            ShowUser();
            LoadGroups().Forget();
        }

        private void ShowUser()
        {
            if (!userNameText) return;
            var user = AuthManager.Instance?.CurrentUser;
            userNameText.text = user != null ? $"Bienvenido, {user.DisplayName}" : "Bienvenido";
        }

        private async UniTaskVoid LoadGroups()
        {
            SetLoading(true);
            HideError();

            string userId = AuthManager.Instance?.CurrentUser?.Id ?? "";

            if (string.IsNullOrEmpty(userId))
            {
                Debug.LogError("[MainMenu] userId vacío — usuario no autenticado.");
                ShowError("Sesión no válida. Ingresa tu PIN nuevamente.");
                return;
            }

            Debug.Log($"[MainMenu] Cargando grupos para userId={userId}");

            bool useMock = ApiClient.Instance != null && ApiClient.Instance.Settings.useMockData;
            List<UserGroupResponse> groups;

            if (useMock)
            {
                var result = await MockApiClient.GetUserGroups(userId, destroyCancellationToken);
                if (!result.Success) { ShowError(result.ErrorMessage); return; }
                groups = result.Data;
            }
            else
            {
                var result = await DataService.Instance.FetchUserGroups(userId);
                if (!result.Success) { ShowError(result.ErrorMessage); return; }
                groups = result.Data;
            }

            Debug.Log($"[MainMenu] {groups.Count} grupos cargados.");
            SetLoading(false);
            _groups = groups;
            SpawnGroupCards(groups);
        }

        private void SpawnGroupCards(List<UserGroupResponse> groups)
        {
            if (!cardContainer || !courseCardPrefab) return;

            foreach (Transform child in cardContainer)
                child.gameObject.SetActive(false);

            foreach (var group in groups)
            {
                var card = Instantiate(courseCardPrefab, cardContainer);
                var cardView = card.GetComponent<CourseCardView>();
                if (cardView != null)
                    cardView.Bind(group, OnCardSelected);
            }
        }

        private void OnCardSelected(UserGroupResponse group)
        {
            AppState.SelectedGroup = group;
            onGroupSelected?.Invoke();
        }

        private void SetLoading(bool active)
        {
            if (loadingIndicator) loadingIndicator.SetActive(active);
            if (cardContainer) cardContainer.gameObject.SetActive(!active);
        }

        private void ShowError(string message)
        {
            SetLoading(false);
            if (errorPanel) errorPanel.SetActive(true);
            if (errorText) errorText.text = message ?? "Error al cargar los grupos.";
        }

        private void HideError()
        {
            if (errorPanel) errorPanel.SetActive(false);
        }
    }
}
