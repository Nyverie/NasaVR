using System.Runtime.CompilerServices;

// Los tests EditMode del paquete leen las conversiones internas de la UI (p. ej. el texto del estado de una experiencia).
[assembly: InternalsVisibleTo("XRLabs.Coach.Editor.Tests")]
