using System;
using XRLabs.Networking.Models;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.UI
{
    /// <summary>
    /// Vista de una tarjeta de experiencia en la lista de experiencias.
    /// Conectar en el Inspector los textos, botón y el badge de estado.
    /// </summary>
    public class ExperienceCardView : MonoBehaviour
    {
        [Header("Info")]
        [SerializeField] private TMPro.TextMeshProUGUI nameText;
        [SerializeField] private TMPro.TextMeshProUGUI descriptionText;
        [SerializeField] private TMPro.TextMeshProUGUI durationText;
        [SerializeField] private TMPro.TextMeshProUGUI statusText;
        [SerializeField] private TMPro.TextMeshProUGUI scoreText;
        [SerializeField] private TMPro.TextMeshProUGUI mandatoryBadge;

        [Header("Actions")]
        [SerializeField] private Button startButton;

        [Header("Status Colors")]
        [SerializeField] private Color colorCompleted = Color.green;
        [SerializeField] private Color colorPending = Color.yellow;
        [SerializeField] private Color colorFailed = Color.red;

        private ExperienceListItem _data;
        private Action<ExperienceListItem> _onStart;

        public void Bind(ExperienceListItem data, Action<ExperienceListItem> onStart)
        {
            _data = data;
            _onStart = onStart;

            var exp = data.Experience;
            var progress = data.GroupExperience;

            if (nameText) nameText.text = exp.Name;
            if (descriptionText) descriptionText.text = exp.Description;
            if (durationText) durationText.text = $"{exp.DurationMinutes} min";
            if (mandatoryBadge) mandatoryBadge.gameObject.SetActive(progress?.Mandatory ?? false);

            UpdateStatus(progress);

            if (startButton)
            {
                // Siempre se permiten reintentos: el backend no bloquea por attempts (lo decide el cliente).
                startButton.interactable = true;
                startButton.onClick.AddListener(() => _onStart?.Invoke(_data));
            }
        }

        private void UpdateStatus(GroupExperienceData progress)
        {
            if (progress == null) return;

            if (statusText)
            {
                statusText.text = StatusLabel(progress.Status);
                statusText.color = ApiStatus.Is(progress.Status, ApiStatus.Completed) ? colorCompleted
                    : ApiStatus.Is(progress.Status, ApiStatus.Failed) ? colorFailed
                    : colorPending;
            }

            if (scoreText)
            {
                scoreText.text = progress.FinalScore.HasValue
                    ? $"{progress.FinalScore:0} pts"
                    : "—";
            }
        }

        /// <summary>
        /// El texto del estado. El backend lo envía en MAYÚSCULAS y los datos viejos en minúsculas: no se distingue
        /// (hasta 0.6.0 se comparaba en minúsculas y un "COMPLETED" del backend se mostraba «Pendiente»).
        /// </summary>
        internal static string StatusLabel(string status)
        {
            if (ApiStatus.Is(status, ApiStatus.Completed)) return "Completado";
            if (ApiStatus.Is(status, ApiStatus.InProgress)) return "En progreso";
            if (ApiStatus.Is(status, ApiStatus.Failed)) return "Fallido";
            return "Pendiente";
        }
    }
}
