using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEngine;
using XRLabs.Networking.Mock;
using XRLabs.Networking.Models;

namespace XRLabs.UI
{
    /// <summary>
    /// En modo mock, el menú del curso ofrece también las experiencias que el anfitrión tiene registradas en su
    /// <see cref="ExperienceSceneMap"/> (las que escribe «Importar guion»): así PIN del mock → curso → experiencia carga
    /// cualquier escena importada, no solo la de demostración. Sin mapa, el menú de siempre (D8).
    /// </summary>
    public static class MockExperienceCatalog
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Install() =>
            MockApiClient.ExtraExperiencesProvider = () => FromMap(Resources.Load<ExperienceSceneMap>("ExperienceSceneMap"));

        /// <summary>
        /// La escena de la experiencia cero, la de la muestra más vieja: su paso p3 elige con las teclas 1 y 2
        /// (<c>KeyChoiceStepCondition</c>) y en un visor, sin teclado, la persona se queda atascada ahí.
        /// </summary>
        public const string KeyboardOnlySceneName = "ExperienciaCero";

        /// <summary>
        /// La escena de la muestra del producto, la de compostaje del INIA (id 11): va primera en el menú del mock aunque exista
        /// otra de id mayor (la réplica de la planta, 12).
        /// </summary>
        public const string ProductSceneName = "ExperienciaCompostaje";

        /// <summary>Se añade a la descripción de <see cref="KeyboardOnlySceneName"/> para avisar antes de elegirla.</summary>
        public const string KeyboardOnlyNote = " (solo pantalla: elige con teclado)";

        /// <summary>
        /// Una experiencia por entrada del mapa, con el id con que el mapa la resuelve (la clave de texto o, si está vacía,
        /// el id heredado) y el título de la entrada (<c>title</c>, o el nombre de la escena legible si está vacío). Entradas sin escena o sin id se saltan.
        /// <para>
        /// Orden: el catálogo no conoce los pasos de cada guion, así que no puede saber cuáles se contestan solo con
        /// teclado. Usa un criterio simple y explícito: primero la muestra del producto (<see cref="ProductSceneName"/>, la
        /// de compostaje del INIA, id 11); después, el <c>experienceId</c> heredado mayor primero (la más nueva arriba, orden
        /// estable; las que solo tienen clave de texto, id 0, quedan al final en el orden del asset). La cero (id 10) es la
        /// de teclado y la más vieja, así que va detrás; lo primero de la lista es lo que se prueba con las manos en el visor
        /// (el INIA, 11; después la réplica de la planta, 12). Hasta el 2026-10-25 mandaba solo el id y la réplica (12) iba
        /// delante del producto. <see cref="ExperienceData.Order"/> sigue el orden de salida, y
        /// <c>MockApiClient.BuildGroupExperiences</c> respeta este orden poniendo estas entradas antes que la de demostración.
        /// </para>
        /// </summary>
        public static List<ExperienceData> FromMap(ExperienceSceneMap map)
        {
            var list = new List<ExperienceData>();
            if (map == null) return list;

            int order = 2;
            foreach (var entry in map.Entries.OrderByDescending(e => e.sceneName == ProductSceneName).ThenByDescending(e => e.experienceId))
            {
                if (string.IsNullOrWhiteSpace(entry.sceneName)) continue;
                string id = !string.IsNullOrEmpty(entry.experienceKey)
                    ? entry.experienceKey
                    : entry.experienceId > 0 ? entry.experienceId.ToString(CultureInfo.InvariantCulture) : null;
                if (id == null) continue;

                list.Add(new ExperienceData
                {
                    Id = id,
                    Name = TitleOf(entry),
                    Description = $"Escena «{entry.sceneName}» del anfitrión (ExperienceSceneMap)."
                        + (entry.sceneName == KeyboardOnlySceneName ? KeyboardOnlyNote : ""),
                    Type = "VR", Duration = 600, Score = 70f,
                    Status = ApiStatus.Available, Attempts = 3, Order = order++
                });
            }
            return list;
        }

        /// <summary>
        /// El título de la entrada: el campo <c>title</c> que escribe «Importar guion» (experiencia.titulo) y, si está vacío
        /// (entradas de antes, D8), el nombre de la escena legible.
        /// </summary>
        public static string TitleOf(ExperienceSceneMap.Entry entry) =>
            !string.IsNullOrWhiteSpace(entry.title) ? entry.title.Trim() : Humanize(entry.sceneName);

        /// <summary>«ExperienciaCompostaje» → «Experiencia compostaje»; «experiencia-cero» → «Experiencia cero».</summary>
        public static string Humanize(string sceneName)
        {
            var sb = new StringBuilder(sceneName.Length + 4);
            for (int i = 0; i < sceneName.Length; i++)
            {
                char c = sceneName[i];
                if (c == '-' || c == '_') { sb.Append(' '); continue; }
                if (i > 0 && char.IsUpper(c) && char.IsLower(sceneName[i - 1])) sb.Append(' ');
                sb.Append(sb.Length == 0 ? char.ToUpperInvariant(c) : char.ToLowerInvariant(c));
            }
            return sb.ToString().Trim();
        }
    }
}
