﻿using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.UI
{
    /// <summary>
    /// Layout vertical XR con scroll mediante botones.
    /// </summary>
    public class XRVerticalLayout : MonoBehaviour
    {
        [Header("Layout")]
        [SerializeField] private float spacing = 180f;

        [SerializeField] private float startY = 0f;

        [SerializeField] private bool centerX = true;

        [Header("Scroll")]
        [SerializeField] private float scrollAmount = 200f;

        [SerializeField] private float minScrollY = -1000f;

        [SerializeField] private float maxScrollY = 0f;

        [Header("Buttons")]
        [SerializeField] private Button scrollUpButton;

        [SerializeField] private Button scrollDownButton;

        private RectTransform _container;

        private void Awake()
        {
            _container = GetComponent<RectTransform>();

            ConfigureButtons();
        }

        /// <summary>
        /// Configurar botones automáticamente.
        /// </summary>
        private void ConfigureButtons()
        {
            if (scrollUpButton != null)
            {
                scrollUpButton.onClick.RemoveAllListeners();

                scrollUpButton.onClick.AddListener(ScrollUp);
            }

            if (scrollDownButton != null)
            {
                scrollDownButton.onClick.RemoveAllListeners();

                scrollDownButton.onClick.AddListener(ScrollDown);
            }
        }

        /// <summary>
        /// Organiza automáticamente las cards.
        /// </summary>
        public void Rebuild()
        {
            int visibleIndex = 0;

            for (int i = 0; i < transform.childCount; i++)
            {
                RectTransform rect =
                    transform.GetChild(i).GetComponent<RectTransform>();

                if (rect == null)
                    continue;

                if (!rect.gameObject.activeSelf)
                    continue;

                float posX =
                    centerX
                    ? 0f
                    : rect.anchoredPosition.x;

                float posY =
                    startY - (visibleIndex * spacing);

                rect.anchoredPosition =
                    new Vector2(posX, posY);

                rect.localScale = Vector3.one;

                visibleIndex++;
            }

            if (_container != null)
            {
                float height =
                    Mathf.Max(
                        visibleIndex * spacing,
                        0f);

                _container.sizeDelta =
                    new Vector2(
                        _container.sizeDelta.x,
                        height);
            }
        }

        /// <summary>
        /// Baja el contenido.
        /// </summary>
        public void ScrollDown()
        {
            if (_container == null)
                return;

            Vector2 pos =
                _container.anchoredPosition;

            pos.y += scrollAmount;

            pos.y =
                Mathf.Clamp(
                    pos.y,
                    minScrollY,
                    maxScrollY);

            _container.anchoredPosition = pos;

            Debug.Log("Scroll Down");
        }

        /// <summary>
        /// Sube el contenido.
        /// </summary>
        public void ScrollUp()
        {
            if (_container == null)
                return;

            Vector2 pos =
                _container.anchoredPosition;

            pos.y -= scrollAmount;

            pos.y =
                Mathf.Clamp(
                    pos.y,
                    minScrollY,
                    maxScrollY);

            _container.anchoredPosition = pos;

            Debug.Log("Scroll Up");
        }
    }
}