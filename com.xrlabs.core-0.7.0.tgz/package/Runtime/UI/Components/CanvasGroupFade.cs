using System.Collections;
using UnityEngine;

namespace XRLabs.UI
{
    /// <summary>
    /// Fade de CanvasGroup por corrutina, sin depender de DOTween
    /// (DOTween queda fuera del framework; sus módulos UI no son visibles desde asmdefs).
    /// Usa tiempo no escalado para funcionar durante pausas y transiciones de escena.
    /// </summary>
    public static class CanvasGroupFade
    {
        /// <summary>Interpola el alpha del grupo hasta target en duration segundos.</summary>
        public static IEnumerator FadeTo(CanvasGroup group, float target, float duration)
        {
            if (group == null) yield break;

            if (duration <= 0f)
            {
                group.alpha = target;
                yield break;
            }

            float start = group.alpha;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                group.alpha = Mathf.Lerp(start, target, Mathf.Clamp01(elapsed / duration));
                yield return null;
            }

            group.alpha = target;
        }
    }
}
