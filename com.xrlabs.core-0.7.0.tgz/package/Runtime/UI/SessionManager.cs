using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using XRLabs.Networking;
using XRLabs.Networking.Mock;
using XRLabs.Networking.Models;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace XRLabs.UI
{
    /// <summary>
    /// Orquestador de una sesión de experiencia VR.
    /// Inicializa el bridge de telemetría, escucha el fin de simulación y navega de vuelta al menú.
    /// Agregar a la escena de experiencia junto a SimulationManager (y un ApiTelemetryBridge en un objeto raíz: «Preparar
    /// escena» pone los dos). La sesión se abre y se cierra siempre por el bridge, que decide si va al API real o al mock.
    /// </summary>
    public class SessionManager : MonoBehaviour
    {
        [Header("Navigation")]
        [SerializeField] private string mainMenuScene = "Menu";
        [Tooltip("Si está configurado, al terminar la simulación navega aquí en vez de mainMenuScene. Útil para encadenar Guided → Evaluation.")]
        [SerializeField] private string nextScene = "";
        [Tooltip("Encendido (como siempre), al terminar carga nextScene o mainMenuScene. Apagado, cierra la sesión en el backend y no carga ninguna escena: la experiencia muestra su propio cierre (por ejemplo un informe final) y decide cuándo volver al menú; OnSessionEnded avisa cuando la sesión quedó cerrada.")]
        [SerializeField] private bool navigateOnEnd = true;

        [Header("Debug")]
        [SerializeField] private bool logEvents = true;

        private ExperienceListItem _experience;
        private float _sessionStartTime;
        private int _totalCorrect;
        private int _totalIncorrect;
        private int _interactionsCount;
        private readonly List<CaseResult> _caseResults = new();
        private int _pendingRating;
        private int _expectedTotalQuestions;
        private int _pauseCount;
        private bool _sessionEnding;

        public int TotalCorrect => _totalCorrect;
        public int TotalIncorrect => Mathf.Max(_totalIncorrect, TotalQuestions - _totalCorrect);
        public int TotalQuestions => Mathf.Max(_totalCorrect + _totalIncorrect, _expectedTotalQuestions);
        public int InteractionsCount => _interactionsCount;
        public int TotalTimeSeconds => Mathf.RoundToInt(Mathf.Max(0f, Time.time - _sessionStartTime));
        public IReadOnlyList<CaseResult> CaseResults => _caseResults;

        /// <summary>Verdadero cuando EndSession ya cerró la sesión (en el backend, en el mock o localmente).</summary>
        public bool SessionEnded { get; private set; }

        /// <summary>Se dispara al cerrar la sesión, con el puntaje final enviado, antes de navegar si se navega.</summary>
        public event System.Action<float> OnSessionEnded;

        private void Start()
        {
            _experience = AppState.SelectedExperience;
            _sessionStartTime = Time.time;

            if (_experience == null)
            {
                Debug.LogWarning("[SessionManager] No hay experiencia seleccionada. Usando valores de debug.");
            }

            InitSession().Forget();
            SubscribeToSimulation();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSimulation();
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused) _pauseCount++;
        }

        private async UniTaskVoid InitSession()
        {
            var bridge = ApiTelemetryBridge.Instance;
            if (bridge == null) return;

            // Sin experiencia elegida en el menú (escena abierta directamente), los ids de la demo del mock.
            string experienceId = _experience?.Experience?.Id ?? MockApiClient.DemoExperienceId;
            string groupId = _experience?.GroupExperience?.GroupId ?? MockApiClient.DemoGroupId;

            // 2026-10-25: también en modo mock la sesión se abre en el bridge (que la manda al MockApiClient). Antes el
            // mock la abría aquí, por fuera, y el bridge quedaba sin sesión: los errores de los pasos y el cierre no
            // llegaban a ningún cliente. Sin ApiClient (escena abierta sin el Menu) el bridge también usa el mock.
            bool started = await bridge.StartSession(experienceId, groupId);
            if (started && logEvents && bridge.SessionIsMock) Debug.Log($"[SessionManager] Mock session: {bridge.SessionId}");

            ApiTelemetryBridge.Instance?.LogActivity(new ActivityEvent
            {
                Action = "start_experience",
                Entity = "Experience",
                EntityId = experienceId,
                Metadata = new { group_id = groupId }
            });
        }

        /// <summary>
        /// Llamar desde CaseEvaluationController al registrar cada respuesta.
        /// </summary>
        public void RegisterAnswer(bool isCorrect)
        {
            if (isCorrect) _totalCorrect++;
            else _totalIncorrect++;
            _interactionsCount++;
        }

        public void SetExpectedTotalQuestions(int totalQuestions)
        {
            _expectedTotalQuestions = Mathf.Max(_expectedTotalQuestions, totalQuestions);
        }

        /// <summary>
        /// Llamar desde CaseEvaluationController al terminar un caso.
        /// Recibe el POCO de Core y lo mapea al DTO del API (la simulación no conoce Networking).
        /// </summary>
        public void RegisterCaseResult(XRLabs.Core.Telemetry.CaseResultData caseResult)
        {
            if (caseResult == null) return;

            _caseResults.Add(new CaseResult
            {
                CaseNumber = caseResult.CaseNumber,
                FailureName = caseResult.FailureName,
                TypeCorrect = caseResult.TypeCorrect,
                CauseCorrect = caseResult.CauseCorrect,
                RecommendationCorrect = caseResult.RecommendationCorrect,
                CaseTimeSeconds = caseResult.CaseTimeSeconds
            });
            ApiTelemetryBridge.Instance?.FlushEvents().Forget();
        }

        /// <summary>Llamar desde StarRatingPanel con el valor 1-5.</summary>
        public void SetRating(int rating)
        {
            _pendingRating = rating;
        }

        public float CalculateEvaluationScore(float maxScore = 20f)
        {
            int totalQuestions = TotalQuestions;
            if (totalQuestions <= 0)
                return 0;

            float normalizedMaxScore = Mathf.Max(1f, maxScore);
            float ratio = Mathf.Clamp01(_totalCorrect / (float)totalQuestions);
            return Mathf.Clamp(ratio * normalizedMaxScore, 0f, normalizedMaxScore);
        }

        /// <summary>
        /// Llamar para finalizar la sesión y navegar al menú. endReason es opcional ("completed", "abandoned"...):
        /// sin él, el cierre viaja sin ese campo, como siempre.
        /// </summary>
        public async UniTaskVoid EndSession(float finalScore, string endReason = null)
        {
            if (_sessionEnding)
                return;

            _sessionEnding = true;

            int totalTime = Mathf.RoundToInt(Time.time - _sessionStartTime);
            int totalQuestions = TotalQuestions;
            int totalIncorrect = TotalIncorrect;

            var completeRequest = new SessionCompleteRequest
            {
                FinalScore = finalScore,
                TotalTimeSeconds = totalTime,
                TotalCorrect = _totalCorrect,
                TotalIncorrect = totalIncorrect,
                TotalQuestions = totalQuestions,
                Cases = new List<CaseResult>(_caseResults),
                InteractionsCount = _interactionsCount,
                PauseCount = _pauseCount,
                ErrorCount = StepErrorCount(),
                Rating = _pendingRating,
                EndReason = endReason
            };

            try
            {
                var bridge = ApiTelemetryBridge.Instance;
                if (bridge != null)
                {
                    // El bridge cierra en el API real o en el mock, según cómo abrió la sesión.
                    await bridge.CompleteSession(completeRequest);
                    if (logEvents && bridge.SessionIsMock) Debug.Log($"[SessionManager] Mock complete: score={finalScore}");
                }
                else if (ApiTelemetryBridge.UsesMock)
                {
                    if (logEvents) Debug.Log($"[SessionManager] Mock complete (sin ApiTelemetryBridge, local): score={finalScore}");
                }
                else
                {
                    Debug.LogWarning("[SessionManager] No hay ApiTelemetryBridge; se cierra la experiencia localmente.");
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[SessionManager] Error al completar la sesion: {ex.Message}");
            }

            ApiTelemetryBridge.Instance?.LogActivity(new ActivityEvent
            {
                Action = "complete_experience",
                Entity = "Experience",
                EntityId = _experience?.Experience?.Id,
                Metadata = CompleteMetadata(finalScore, totalTime, _pendingRating)   // 0.3 lote 4: + metadata.estado
            });

            SessionEnded = true;
            OnSessionEnded?.Invoke(finalScore);

            string destination = DestinationAfterEnd();
            if (destination != null)
                SceneTransitionManager.LoadScene(destination);
        }

        #region 0.3 lote 4: metadata.estado en complete_experience (contrato-0.3.md §2.1 y §2.9)

        // Los valores finales del estado (variable -> valor como texto), base del informe final; sin estado, el cierre de
        // siempre, sin la clave.
        internal static object CompleteMetadata(float score, int time, int rating)
        {
            var estado = FinalStateSnapshot();
            if (estado == null || estado.Count == 0) return new { score, time, rating };
            return new { score, time, rating, estado };
        }

        internal static Dictionary<string, string> FinalStateSnapshot()
        {
            var sim = XRLabs.Core.SimulationManager.Instance;
            var state = sim != null && sim.Steps != null ? sim.Steps.State : XRLabs.Core.SimulationStateHost.CurrentState;
            return state != null && !state.IsEmpty ? state.Snapshot() : null;
        }

        #endregion

        // 2026-10-25: los errores de los pasos (las correcciones del coach, los step_error del activity log). Antes viajaba
        // siempre 0 y el backend guarda y suma errorCount en los agregados del grupo.
        private static int StepErrorCount()
        {
            var sim = XRLabs.Core.SimulationManager.Instance;
            var steps = sim != null ? sim.Steps : null;
            return steps != null ? steps.Stats.Errors : 0;
        }

        /// <summary>
        /// La escena que se carga al terminar: nextScene si está puesta, si no mainMenuScene; null con navigateOnEnd
        /// apagado (la experiencia se queda en su escena). Pura, para los tests.
        /// </summary>
        internal string DestinationAfterEnd()
        {
            if (!navigateOnEnd) return null;
            return string.IsNullOrEmpty(nextScene) ? mainMenuScene : nextScene;
        }

        private void SubscribeToSimulation()
        {
            var sim = XRLabs.Core.SimulationManager.Instance;
            if (sim == null) return;
            sim.OnSimulationEnded += HandleSimulationEnded;
        }

        private void UnsubscribeFromSimulation()
        {
            var sim = XRLabs.Core.SimulationManager.Instance;
            if (sim == null) return;
            sim.OnSimulationEnded -= HandleSimulationEnded;
        }

        private void HandleSimulationEnded(int finalScore, float totalTime)
        {
            float scoreToSend = TotalQuestions > 0 ? CalculateEvaluationScore() : finalScore;
            EndSession(scoreToSend).Forget();
        }
    }
}
