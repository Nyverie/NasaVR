using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace XRLabs.UI
{
    /// <summary>
    /// Fade negro entre escenas (Menu → Parte 1 → Evaluación → Menu).
    /// Se auto-instancia la primera vez que se llama a LoadScene().
    /// Persiste entre escenas via DontDestroyOnLoad.
    /// </summary>
    public class SceneTransitionManager : MonoBehaviour
    {
        public static SceneTransitionManager Instance { get; private set; }

        private const float FadeDuration = 0.5f;

        private CanvasGroup _overlay;
        private bool _transitioning;
        private Coroutine _fade;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            BuildOverlay();
            SceneManager.sceneLoaded += OnSceneLoaded;
        }

        private void OnDestroy()
        {
            if (Instance == this)
                SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        /// <summary>
        /// Reemplaza SceneManager.LoadScene() con fade negro de 0.5s de entrada y salida.
        /// Se puede llamar desde cualquier clase sin obtener la instancia primero.
        /// </summary>
        public static void LoadScene(string sceneName)
        {
            if (string.IsNullOrEmpty(sceneName))
            {
                Debug.LogError("[SceneTransitionManager] Nombre de escena vacío — carga cancelada.");
                return;
            }

            if (Instance == null)
            {
                var go = new GameObject("SceneTransitionManager");
                go.AddComponent<SceneTransitionManager>();
            }

            Instance.LoadSceneInternal(sceneName);
        }

        private void LoadSceneInternal(string sceneName)
        {
            if (_transitioning) return;

            _transitioning = true;
            _overlay.blocksRaycasts = true;

            if (_fade != null) StopCoroutine(_fade);
            _fade = StartCoroutine(FadeOutAndLoad(sceneName));
        }

        private IEnumerator FadeOutAndLoad(string sceneName)
        {
            yield return CanvasGroupFade.FadeTo(_overlay, 1f, FadeDuration);
            SceneManager.LoadScene(sceneName);
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (_fade != null) StopCoroutine(_fade);
            _overlay.alpha = 1f;
            _fade = StartCoroutine(FadeInAfterLoad());
        }

        private IEnumerator FadeInAfterLoad()
        {
            yield return CanvasGroupFade.FadeTo(_overlay, 0f, FadeDuration);
            _overlay.blocksRaycasts = false;
            _transitioning = false;
        }

        private void BuildOverlay()
        {
            var canvasGO = new GameObject("FadeOverlay");
            canvasGO.transform.SetParent(transform, false);

            var canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 9999;

            var imgGO = new GameObject("BlackScreen");
            imgGO.transform.SetParent(canvasGO.transform, false);

            var img = imgGO.AddComponent<Image>();
            img.color = Color.black;
            img.raycastTarget = false;

            var rect = img.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            _overlay = canvasGO.AddComponent<CanvasGroup>();
            _overlay.alpha = 0f;
            _overlay.interactable = false;
            _overlay.blocksRaycasts = false;
        }
    }
}
