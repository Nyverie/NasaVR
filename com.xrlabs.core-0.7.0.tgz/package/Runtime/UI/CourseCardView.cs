using System;
using XRLabs.Networking.Models;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.UI
{
    /// <summary>
    /// Vista de una tarjeta de curso en el menú principal.
    /// Conectar en el Inspector los textos y el botón.
    /// </summary>
    public class CourseCardView : MonoBehaviour
    {
        [SerializeField] private TMPro.TextMeshProUGUI courseNameText;
        [SerializeField] private TMPro.TextMeshProUGUI specialtyText;
        [SerializeField] private TMPro.TextMeshProUGUI groupNameText;
        [SerializeField] private TMPro.TextMeshProUGUI progressText;
        [SerializeField] private Button selectButton;

        private UserGroupResponse _data;
        private Action<UserGroupResponse> _onSelected;

        public void Bind(UserGroupResponse data, Action<UserGroupResponse> onSelected)
        {
            _data = data;
            _onSelected = onSelected;

            if (courseNameText) courseNameText.text = data.Course?.Name ?? "";
            if (specialtyText) specialtyText.text = data.Specialty?.Name ?? "";
            if (groupNameText) groupNameText.text = data.Group?.Name ?? "";
            if (progressText) progressText.text = $"{data.CompletedCount}/{data.ExperienceCount}";

            if (selectButton)
                selectButton.onClick.AddListener(() => _onSelected?.Invoke(_data));
        }
    }
}
