using XRLabs.Networking.Models;

namespace XRLabs.UI
{
    /// <summary>
    /// Estado global compartido entre escenas (datos de navegación en memoria).
    /// </summary>
    public static class AppState
    {
        public static UserGroupResponse SelectedGroup { get; set; }
        public static ExperienceListItem SelectedExperience { get; set; }

        public static void Clear()
        {
            SelectedGroup = null;
            SelectedExperience = null;
        }
    }
}
