using System.Collections;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach
{
    /// <summary>
    /// Mueve, orienta y hace señalar al coach según el paso actual.
    ///
    /// - Paso con coachAnchorId: el coach va a esa ancla (estaciones de la web).
    /// - Paso sin ancla (modo seguir): si el usuario se aleja o deja de verlo, el coach
    ///   reaparece a un lado de su mirada (CoachPlacement).
    /// - Paso con pointAtTargetId: el coach señala ese objeto.
    /// - Nunca se mueve mientras dice una corrección.
    ///
    /// No conoce el SDK XR: la cabeza es un Transform (la cámara del rig o la cámara plana).
    /// </summary>
    public class CoachDirector : MonoBehaviour
    {
        [Header("Referencias")]
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private CoachPresence presence;
        [Tooltip("Cabeza del usuario. Vacío = Camera.main.")]
        [SerializeField] private Transform head;

        [Header("Seguir al usuario")]
        [SerializeField] private bool followEnabled = true;
        [Tooltip("Si el usuario se aleja más que esto (m, en horizontal), el coach lo sigue.")]
        [SerializeField, Min(0.5f)] private float followDistance = 3f;
        [Tooltip("Si el coach queda fuera de la vista más de estos segundos, se reubica.")]
        [SerializeField, Min(0f)] private float outOfViewSeconds = 2f;
        [Tooltip("Medio ángulo horizontal considerado 'a la vista' (grados).")]
        [SerializeField, Range(10f, 90f)] private float viewHalfAngle = 50f;
        [Tooltip("Más cerca que esto el coach se aparta (m).")]
        [SerializeField, Min(0.2f)] private float minDistance = 0.9f;
        [Tooltip("Cada cuánto se evalúa si moverse (s).")]
        [SerializeField, Min(0.05f)] private float evaluateInterval = 0.25f;
        [SerializeField] private CoachPlacement placement = new();

        [Header("Movimiento")]
        [Tooltip("Hasta esta distancia se desliza; más lejos desaparece y reaparece (m).")]
        [SerializeField, Min(0f)] private float glideMaxDistance = 4f;
        [SerializeField, Min(0.05f)] private float glideSeconds = 0.8f;
        [SerializeField, Min(0f)] private float turnSpeedDegrees = 240f;

        /// <summary>True mientras el coach se está reubicando.</summary>
        public bool IsMoving => _moveRoutine != null;

        /// <summary>Ancla del paso actual, o null en modo seguir.</summary>
        public CoachAnchor CurrentAnchor { get; private set; }

        public bool FollowEnabled
        {
            get => followEnabled;
            set => followEnabled = value;
        }

        private Coroutine _moveRoutine;
        private float _nextEvaluateAt;
        private float _outOfViewSince = -1f;
        private Transform _pointTarget;

        private Transform Head
        {
            get
            {
                if (head != null) return head;
                var cam = Camera.main;
                return cam != null ? cam.transform : null;
            }
        }

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();
            if (stepSystem != null)
            {
                stepSystem.StepStarted += HandleStepStarted;
                stepSystem.StepCompleted += HandleStepCompleted;
            }
        }

        private void OnDisable()
        {
            if (stepSystem != null)
            {
                stepSystem.StepStarted -= HandleStepStarted;
                stepSystem.StepCompleted -= HandleStepCompleted;
            }
        }

        private void Update()
        {
            if (presence == null) return;

            var vo = VOManager.Instance;
            bool isError = vo != null && vo.IsSpeaking && vo.ActiveLine != null && vo.ActiveLine.IsError;
            presence.SetVoice(vo != null ? vo.Amplitude : 0f, isError);

            var headTransform = Head;
            if (headTransform == null) return;

            FaceUser(headTransform);
            presence.LookAt(headTransform.position);

            if (Time.time >= _nextEvaluateAt)
            {
                _nextEvaluateAt = Time.time + evaluateInterval;
                EvaluateFollow(headTransform, isError);
            }
        }

        // ── API pública ───────────────────────────────────────────────────────

        /// <summary>Lleva el coach a un ancla por ID (también usable desde UnityEvents).</summary>
        public void GoToAnchor(string anchorId)
        {
            if (!CoachAnchor.TryGet(anchorId, out var anchor))
            {
                Debug.LogWarning($"[Coach] Ancla '{anchorId}' no encontrada en la escena.");
                return;
            }
            CurrentAnchor = anchor;
            MoveTo(anchor.transform.position, anchor.FaceUser ? (Quaternion?)null : anchor.transform.rotation);
        }

        /// <summary>Vuelve al modo seguir (sin ancla).</summary>
        public void ReleaseAnchor() => CurrentAnchor = null;

        /// <summary>Señala un objeto por ID (SceneTargetRegistry). Vacío = dejar de señalar.</summary>
        public void PointAt(string targetId)
        {
            _pointTarget = SceneTargetRegistry.TryGet(targetId, out var target) ? target : null;
            if (presence != null) presence.PointAt(_pointTarget);
        }

        /// <summary>Reubica al coach junto al usuario ahora mismo.</summary>
        public void ComeToUser()
        {
            var headTransform = Head;
            if (headTransform == null || presence == null) return;
            if (placement.TryFindSpot(headTransform.position, headTransform.forward, SideOfUser(headTransform),
                    presence.Height, presence.transform, out var spot))
                MoveTo(spot, null);
        }

        // ── Pasos ─────────────────────────────────────────────────────────────

        private void HandleStepStarted(StepDefinition step, int index, int total)
        {
            if (!string.IsNullOrEmpty(step.coachAnchorId)) GoToAnchor(step.coachAnchorId);
            else ReleaseAnchor();

            PointAt(step.pointAtTargetId);
        }

        private void HandleStepCompleted(StepDefinition step, int index, float elapsed)
        {
            PointAt(null);
        }

        // ── Seguir ────────────────────────────────────────────────────────────

        private void EvaluateFollow(Transform headTransform, bool isError)
        {
            if (!followEnabled || CurrentAnchor != null || IsMoving || isError) return;

            Vector3 toCoach = presence.transform.position - headTransform.position;
            toCoach.y = 0f;
            float distance = toCoach.magnitude;

            Vector3 forward = Vector3.ProjectOnPlane(headTransform.forward, Vector3.up);
            bool inView = distance > 0.01f && Vector3.Angle(forward, toCoach) <= viewHalfAngle;

            if (inView) _outOfViewSince = -1f;
            else if (_outOfViewSince < 0f) _outOfViewSince = Time.time;

            bool tooFar = distance > followDistance;
            bool tooClose = distance < minDistance;
            bool lostSight = _outOfViewSince >= 0f && Time.time - _outOfViewSince >= outOfViewSeconds;

            if (!tooFar && !tooClose && !lostSight) return;

            if (placement.TryFindSpot(headTransform.position, headTransform.forward, SideOfUser(headTransform),
                    presence.Height, presence.transform, out var spot))
            {
                _outOfViewSince = -1f;
                MoveTo(spot, null);
            }
        }

        private float SideOfUser(Transform headTransform)
        {
            Vector3 toCoach = presence.transform.position - headTransform.position;
            return Vector3.Dot(headTransform.right, toCoach) >= 0f ? 1f : -1f;
        }

        // ── Movimiento ────────────────────────────────────────────────────────

        private void MoveTo(Vector3 position, Quaternion? fixedRotation)
        {
            if (presence == null) return;
            if (_moveRoutine != null) StopCoroutine(_moveRoutine);
            _moveRoutine = StartCoroutine(MoveRoutine(position, fixedRotation));
        }

        private IEnumerator MoveRoutine(Vector3 target, Quaternion? fixedRotation)
        {
            var root = presence.transform;
            float distance = Vector3.Distance(root.position, target);

            if (distance > glideMaxDistance)
            {
                yield return presence.Disappear();
                root.position = target;
                if (fixedRotation.HasValue) root.rotation = fixedRotation.Value;
                else SnapFaceUser();
                yield return presence.Appear();
            }
            else if (distance > 0.01f)
            {
                Vector3 start = root.position;
                float t = 0f;
                while (t < 1f)
                {
                    t += Time.deltaTime / glideSeconds;
                    root.position = Vector3.Lerp(start, target, Mathf.SmoothStep(0f, 1f, t));
                    yield return null;
                }
                if (fixedRotation.HasValue) root.rotation = fixedRotation.Value;
            }

            _moveRoutine = null;
        }

        private void FaceUser(Transform headTransform)
        {
            if (CurrentAnchor != null && !CurrentAnchor.FaceUser) return;

            Vector3 toUser = headTransform.position - presence.transform.position;
            toUser.y = 0f;
            if (toUser.sqrMagnitude < 1e-4f) return;

            var targetRotation = Quaternion.LookRotation(toUser, Vector3.up);
            presence.transform.rotation = Quaternion.RotateTowards(
                presence.transform.rotation, targetRotation, turnSpeedDegrees * Time.deltaTime);
        }

        private void SnapFaceUser()
        {
            var headTransform = Head;
            if (headTransform == null) return;
            Vector3 toUser = headTransform.position - presence.transform.position;
            toUser.y = 0f;
            if (toUser.sqrMagnitude > 1e-4f)
                presence.transform.rotation = Quaternion.LookRotation(toUser, Vector3.up);
        }
    }
}
