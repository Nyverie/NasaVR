using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Coach
{
    /// <summary>
    /// Punto donde se coloca el coach durante uno o más pasos (StepDefinition.coachAnchorId).
    /// Equivale a las "estaciones" de la web (intro, site, pile, …), pero en VR se mueve el
    /// coach y no la cámara. La flecha azul del gizmo indica hacia dónde mira por defecto.
    /// </summary>
    public class CoachAnchor : MonoBehaviour
    {
        private static readonly Dictionary<string, CoachAnchor> Anchors = new();

        [Tooltip("ID que usan los pasos. Vacío = nombre del GameObject.")]
        [SerializeField] private string anchorId;

        [Tooltip("Si el coach debe mirar al usuario (true) o a la dirección del ancla (false).")]
        [SerializeField] private bool faceUser = true;

        public string AnchorId => string.IsNullOrEmpty(anchorId) ? gameObject.name : anchorId;
        public bool FaceUser => faceUser;

        public static bool TryGet(string id, out CoachAnchor anchor)
        {
            anchor = null;
            if (string.IsNullOrEmpty(id)) return false;
            return Anchors.TryGetValue(id, out anchor) && anchor != null;
        }

        private void OnEnable() => Anchors[AnchorId] = this;

        private void OnDisable()
        {
            if (Anchors.TryGetValue(AnchorId, out var current) && current == this)
                Anchors.Remove(AnchorId);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() => Anchors.Clear();

        private void OnDrawGizmos()
        {
            Gizmos.color = new Color(0.16f, 0.76f, 0.78f, 0.8f);
            Gizmos.DrawWireSphere(transform.position + Vector3.up * 0.05f, 0.3f);
            Gizmos.DrawLine(transform.position, transform.position + Vector3.up * 1.8f);
            Gizmos.color = Color.blue;
            Gizmos.DrawLine(transform.position + Vector3.up * 1f, transform.position + Vector3.up * 1f + transform.forward * 0.5f);
        }
    }
}
