using System.Collections;
using TMPro;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach
{
    /// <summary>
    /// Coach v1: proyector holográfico (sin rig, sin animación). Base metálica con lente, cono de luz
    /// con líneas que suben, y un disco con el retrato de la instructora que gira en Y hacia el usuario,
    /// flota, brilla con la voz y se rodea de una onda circular que sale del espectro de la voz.
    /// Replica la instructora de la versión web (ver Documentation~/coach.md).
    ///
    /// Presupuesto Quest: sin luces ni sombras, ~8 renderers, MaterialPropertyBlock para los parámetros
    /// por frame y ningún GC por frame (los arreglos se crean una sola vez).
    ///
    /// El prefab se genera con Tools → XRLabs → Create Hologram Coach Prefab. El transform raíz es el punto
    /// de apoyo en el suelo; el CoachDirector lo mueve y lo gira. El disco se orienta solo en LookAt().
    /// </summary>
    [DisallowMultipleComponent]
    public class HologramCoach : CoachPresence
    {
        private const int WavePoints = 128;
        private const int SpectrumSize = 256;
        private const float VoiceStaleSeconds = 0.5f;

        private static readonly int AccentId = Shader.PropertyToID("_Accent");
        private static readonly int AmpId = Shader.PropertyToID("_Amp");
        private static readonly int FadeId = Shader.PropertyToID("_Fade");
        private static readonly int MapId = Shader.PropertyToID("_Map");
        private static readonly int MapStId = Shader.PropertyToID("_Map_ST");
        private static readonly int LengthId = Shader.PropertyToID("_Length");

        [Header("Retrato")]
        [Tooltip("Retrato como textura. Tiene prioridad sobre el sprite.")]
        [SerializeField] private Texture2D portraitTexture;
        [Tooltip("Retrato como sprite. Si ambos están vacíos se usa LineLibrary.speakerPortrait (VOManager.SpeakerPortrait).")]
        [SerializeField] private Sprite portraitSprite;

        [Header("Placa con nombre")]
        [Tooltip("Vacío = VOManager.SpeakerName.")]
        [SerializeField] private string speakerName;
        [SerializeField] private string roleLabel = "Instructora";
        [SerializeField] private TMP_Text namePlate;

        [Header("Geometría")]
        [Tooltip("Raíz de lo visible; se escala al aparecer/desaparecer.")]
        [SerializeField] private Transform visualRoot;
        [Tooltip("Disco + anillo + onda + placa. Gira en Y hacia el usuario y flota.")]
        [SerializeField] private Transform discPivot;
        [Tooltip("Centro del disco: de aquí sale el rayo punteado.")]
        [SerializeField] private Transform pointerOrigin;
        [SerializeField] private Transform ring;
        [Tooltip("Altura del centro del disco sobre el suelo (m). La web usa 1,98; en VR conviene a la altura de los ojos.")]
        [SerializeField, Min(0.5f)] private float discHeight = 1.7f;
        [Tooltip("Radio del disco (m): 0,24 = 0,48 m de diámetro. Si se escala el prefab, ajustar también esto.")]
        [SerializeField, Min(0.05f)] private float discRadius = 0.24f;
        [SerializeField, Min(0f)] private float floatAmplitude = 0.04f;
        [Tooltip("Velocidad angular de la flotación (rad/s).")]
        [SerializeField, Min(0f)] private float floatSpeed = 1.5f;

        [Header("Partes")]
        [Tooltip("Renderers holográficos que comparten parámetros (cono, lente, anillo, fondo de la placa).")]
        [SerializeField] private Renderer[] glowRenderers;
        [SerializeField] private Renderer discRenderer;
        [SerializeField] private LineRenderer waveLine;
        [SerializeField] private LineRenderer pointerLine;

        [Header("Color")]
        [SerializeField, ColorUsage(false, true)] private Color accentColor = new(0.161f, 0.761f, 0.78f, 1f);
        [Tooltip("Acento durante una corrección.")]
        [SerializeField, ColorUsage(false, true)] private Color errorColor = new(1f, 0.55f, 0.16f, 1f);

        [Header("Voz y onda")]
        [Tooltip("Ganancia del espectro (se aplica a la raíz cuadrada de la magnitud FFT).")]
        [SerializeField, Min(0f)] private float spectrumGain = 2.5f;
        [SerializeField, Range(0f, 1f)] private float waveOpacitySpeaking = 0.9f;
        [SerializeField, Range(0f, 1f)] private float waveOpacitySilent = 0.35f;

        [Header("Rayo punteado")]
        [Tooltip("El rayo nace a esta distancia del centro del disco, hacia el objetivo (m). 0 = discRadius × 1,1.")]
        [SerializeField, Min(0f)] private float pointerStartOffset;

        [Header("Transición")]
        [SerializeField, Min(0.01f)] private float fadeSeconds = 0.3f;

        // Estado
        private readonly float[] _spectrum = new float[SpectrumSize];
        private readonly float[] _waveLevels = new float[WavePoints];
        private readonly Vector3[] _wavePositions = new Vector3[WavePoints];
        private readonly Vector3[] _pointerPositions = new Vector3[2];
        private float[] _cos, _sin;

        private MaterialPropertyBlock _sharedBlock, _discBlock, _waveBlock, _pointerBlock;
        private Renderer[] _allRenderers;
        private Texture2D _placeholder;

        private float _targetAmp, _amp, _errorBlend, _speakFactor, _waveOpacity, _fade = 1f;
        private float _lastVoiceTime = -10f;
        private bool _isError, _visible = true;
        private Texture _portraitTexture;
        private Vector4 _portraitST = new(1f, 1f, 0f, 0f);
        private Sprite _lastSprite;
        private Texture2D _lastTexture;
        private string _lastName;
        private Transform _pointTarget;
        private Renderer _pointTargetRenderer;
        private bool _initialized;

        // ── API de presencia ──────────────────────────────────────────────────

        public override Transform PointerOrigin => pointerOrigin != null ? pointerOrigin : (discPivot != null ? discPivot : transform);

        public override float Height => discHeight + discRadius + floatAmplitude;

        /// <summary>El rayo punteado está encendido.</summary>
        public bool IsPointing => _pointTarget != null;

        /// <summary>Los renderers están visibles (false tras Disappear).</summary>
        public bool IsVisible => _visible;

        /// <summary>Línea del rayo punteado (para pruebas y personalización).</summary>
        public LineRenderer PointerLine => pointerLine;

        /// <summary>Línea de la onda circular de voz.</summary>
        public LineRenderer WaveLine => waveLine;

        /// <summary>Color de acento actual (turquesa → naranja según el modo error).</summary>
        public Color CurrentAccent => Color.Lerp(accentColor, errorColor, _errorBlend);

        /// <summary>Retrato propio. Null en ambos = el de la LineLibrary.</summary>
        public void SetPortrait(Sprite sprite, Texture2D texture = null)
        {
            portraitSprite = sprite;
            portraitTexture = texture;
        }

        public override void SetVoice(float amplitude, bool isError)
        {
            _targetAmp = Mathf.Clamp01(amplitude);
            _isError = isError;
            _lastVoiceTime = Time.unscaledTime;
        }

        public override void PointAt(Transform target)
        {
            EnsureInitialized();
            _pointTarget = target;
            _pointTargetRenderer = target != null ? target.GetComponentInChildren<Renderer>() : null;
            if (pointerLine != null) pointerLine.enabled = target != null && _visible;
            if (target != null) UpdatePointer();
        }

        public override void LookAt(Vector3 worldPoint)
        {
            if (discPivot == null) return;
            Vector3 direction = worldPoint - discPivot.position;
            direction.y = 0f;
            if (direction.sqrMagnitude < 1e-4f) return;
            discPivot.rotation = Quaternion.LookRotation(direction, Vector3.up);
        }

        public override IEnumerator Disappear() => Transition(false);

        public override IEnumerator Appear() => Transition(true);

        /// <summary>
        /// Construye un coach en memoria (mallas y materiales sin guardar), útil en pruebas o sin el prefab.
        /// En producción usar el prefab HologramCoach (así los shaders entran al build).
        /// </summary>
        public static HologramCoach CreateDefault(float discRadius = 0.24f, float discHeight = 1.7f)
        {
            var resources = HologramCoachBuilder.CreateMeshes(discRadius, discHeight);
            HologramCoachBuilder.FillRuntimeMaterials(resources);
            return HologramCoachBuilder.Build(resources, "HologramCoach", discRadius, discHeight);
        }

        // ── Ciclo de vida ─────────────────────────────────────────────────────

        private void Awake() => EnsureInitialized();

        private void OnEnable()
        {
            EnsureInitialized();
            SetFade(_visible ? 1f : 0f);
        }

        private void OnDestroy()
        {
            if (_placeholder != null) Destroy(_placeholder);
        }

        private void EnsureInitialized()
        {
            if (_initialized) return;
            _initialized = true;

            _sharedBlock = new MaterialPropertyBlock();
            _discBlock = new MaterialPropertyBlock();
            _waveBlock = new MaterialPropertyBlock();
            _pointerBlock = new MaterialPropertyBlock();
            _allRenderers = GetComponentsInChildren<Renderer>(true);

            _cos = new float[WavePoints];
            _sin = new float[WavePoints];
            for (int i = 0; i < WavePoints; i++)
            {
                float angle = (float)i / WavePoints * Mathf.PI * 2f;
                _cos[i] = Mathf.Cos(angle);
                _sin[i] = Mathf.Sin(angle);
            }

            if (waveLine != null)
            {
                waveLine.useWorldSpace = false;
                waveLine.loop = true;
                waveLine.positionCount = WavePoints;
            }
            if (pointerLine != null)
            {
                pointerLine.useWorldSpace = true;
                pointerLine.positionCount = 2;
                pointerLine.enabled = false;
            }

            _waveOpacity = waveOpacitySilent;
        }

        private void Update()
        {
            float dt = Time.unscaledDeltaTime;
            float now = Time.unscaledTime;

            bool voiceFresh = now - _lastVoiceTime <= VoiceStaleSeconds;
            float amplitudeTarget = voiceFresh ? _targetAmp : 0f;
            _amp = Mathf.Lerp(_amp, amplitudeTarget, 1f - Mathf.Exp(-dt * 20f));
            _errorBlend = Mathf.MoveTowards(_errorBlend, voiceFresh && _isError ? 1f : 0f, dt * 5f);

            var vo = VOManager.Instance;
            bool speaking = _amp > 0.03f || (vo != null && vo.IsSpeaking);
            _speakFactor = Mathf.MoveTowards(_speakFactor, speaking ? 1f : 0f, dt * 6f);
            _waveOpacity = Mathf.MoveTowards(_waveOpacity, speaking ? waveOpacitySpeaking : waveOpacitySilent, dt * 3f);

            UpdateFloat(now);
            UpdateName(vo);
            UpdatePortrait(vo);

            if (!_visible) return;

            UpdateWave(now, dt, vo, speaking);
            UpdatePointer();
            ApplyProperties();
        }

        // ── Animación ─────────────────────────────────────────────────────────

        private void UpdateFloat(float time)
        {
            if (discPivot != null)
            {
                var local = discPivot.localPosition;
                local.y = discHeight + Mathf.Sin(time * floatSpeed) * floatAmplitude;
                discPivot.localPosition = local;
            }
            if (ring != null) ring.localScale = Vector3.one * (1f + _amp * 0.06f);
        }

        private void UpdateWave(float time, float dt, VOManager vo, bool speaking)
        {
            if (waveLine == null) return;

            bool haveSpectrum = speaking && vo != null && vo.IsSpeaking;
            if (haveSpectrum) vo.GetSpectrum(_spectrum);

            float follow = 1f - Mathf.Exp(-dt * 25f);
            float baseRadius = discRadius * 1.2f;
            float ripple = discRadius * 0.025f;
            float reach = discRadius * 0.3f;

            for (int i = 0; i < WavePoints; i++)
            {
                float target = 0f;
                if (haveSpectrum)
                {
                    // Simétrica respecto del eje vertical: graves abajo, agudos arriba (el punto 96 es el de abajo).
                    int fromBottom = Mathf.Abs((i + WavePoints / 2 - WavePoints * 3 / 4 + WavePoints) % WavePoints - WavePoints / 2);
                    int bin = 1 + (fromBottom * 3) / 4;
                    target = Mathf.Clamp01(Mathf.Sqrt(Mathf.Max(0f, _spectrum[bin])) * spectrumGain);
                }
                _waveLevels[i] = Mathf.Lerp(_waveLevels[i], target, follow);

                float angle = (float)i / WavePoints * Mathf.PI * 2f;
                float radius = baseRadius + ripple * Mathf.Sin(angle * 6f + time * 3f) + _waveLevels[i] * reach * _speakFactor;
                _wavePositions[i] = new Vector3(_cos[i] * radius, _sin[i] * radius, 0.002f);
            }
            waveLine.SetPositions(_wavePositions);
        }

        private void UpdatePointer()
        {
            if (_pointTarget == null)
            {
                // El objetivo pudo destruirse: apagar.
                if (pointerLine != null && pointerLine.enabled) pointerLine.enabled = false;
                _pointTargetRenderer = null;
                return;
            }
            if (pointerLine == null) return;

            Vector3 origin = PointerOrigin.position;
            Vector3 end = _pointTargetRenderer != null ? _pointTargetRenderer.bounds.center : _pointTarget.position;

            Vector3 toTarget = end - origin;
            float distance = toTarget.magnitude;
            float startOffset = pointerStartOffset > 0f ? pointerStartOffset : discRadius * 1.1f;
            Vector3 start = distance > startOffset ? origin + toTarget / distance * startOffset : origin;

            _pointerPositions[0] = start;
            _pointerPositions[1] = end;
            pointerLine.SetPositions(_pointerPositions);
            pointerLine.enabled = _visible;
            _pointerBlock.SetFloat(LengthId, Vector3.Distance(start, end));
        }

        // ── Datos visibles ────────────────────────────────────────────────────

        private void UpdateName(VOManager vo)
        {
            if (namePlate == null) return;
            string name = !string.IsNullOrEmpty(speakerName) ? speakerName : (vo != null ? vo.SpeakerName : string.Empty);
            if (name == _lastName) return;
            _lastName = name;
            namePlate.text = string.IsNullOrEmpty(roleLabel) ? name : $"{name}\n<size=55%><color=#9DB0AA>{roleLabel}</color></size>";
        }

        private void UpdatePortrait(VOManager vo)
        {
            Sprite sprite = null;
            if (portraitTexture == null)
            {
                sprite = portraitSprite != null ? portraitSprite : (vo != null ? vo.SpeakerPortrait : null);
            }

            if (portraitTexture == _lastTexture && sprite == _lastSprite && _portraitTexture != null) return;
            _lastTexture = portraitTexture;
            _lastSprite = sprite;

            if (portraitTexture != null)
            {
                _portraitTexture = portraitTexture;
                _portraitST = new Vector4(1f, 1f, 0f, 0f);
            }
            else if (sprite != null && sprite.texture != null)
            {
                var texture = sprite.texture;
                var rect = sprite.textureRect;
                _portraitTexture = texture;
                _portraitST = new Vector4(rect.width / texture.width, rect.height / texture.height,
                    rect.x / texture.width, rect.y / texture.height);
            }
            else
            {
                if (_placeholder == null) _placeholder = CreatePlaceholderPortrait();
                _portraitTexture = _placeholder;
                _portraitST = new Vector4(1f, 1f, 0f, 0f);
            }
        }

        private void ApplyProperties()
        {
            Color accent = CurrentAccent;

            _sharedBlock.SetColor(AccentId, accent);
            _sharedBlock.SetFloat(AmpId, _amp);
            _sharedBlock.SetFloat(FadeId, _fade);
            if (glowRenderers != null)
                for (int i = 0; i < glowRenderers.Length; i++)
                    if (glowRenderers[i] != null) glowRenderers[i].SetPropertyBlock(_sharedBlock);

            if (discRenderer != null)
            {
                _discBlock.SetColor(AccentId, accent);
                _discBlock.SetFloat(AmpId, _amp);
                _discBlock.SetFloat(FadeId, _fade);
                if (_portraitTexture != null)
                {
                    _discBlock.SetTexture(MapId, _portraitTexture);
                    _discBlock.SetVector(MapStId, _portraitST);
                }
                discRenderer.SetPropertyBlock(_discBlock);
            }

            if (waveLine != null)
            {
                _waveBlock.SetColor(AccentId, accent);
                _waveBlock.SetFloat(AmpId, _amp);
                _waveBlock.SetFloat(FadeId, _fade * _waveOpacity);
                waveLine.SetPropertyBlock(_waveBlock);
            }

            if (pointerLine != null && pointerLine.enabled)
            {
                _pointerBlock.SetColor(AccentId, accent);
                _pointerBlock.SetFloat(FadeId, _fade);
                pointerLine.SetPropertyBlock(_pointerBlock);
            }
        }

        // ── Aparecer / desaparecer ────────────────────────────────────────────

        private IEnumerator Transition(bool show)
        {
            EnsureInitialized();
            if (show) SetVisible(true);

            float from = _fade;
            float to = show ? 1f : 0f;
            float duration = fadeSeconds * Mathf.Abs(to - from);
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                SetFade(Mathf.Lerp(from, to, Mathf.SmoothStep(0f, 1f, elapsed / duration)));
                yield return null;
            }

            SetFade(to);
            if (!show) SetVisible(false);
        }

        private void SetFade(float value)
        {
            _fade = Mathf.Clamp01(value);
            if (visualRoot == null) return;
            // Se pliega en vertical hacia el suelo, como un holograma que se apaga.
            float horizontal = Mathf.Lerp(0.75f, 1f, _fade);
            visualRoot.localScale = new Vector3(horizontal, Mathf.Max(0.001f, _fade), horizontal);
        }

        private void SetVisible(bool visible)
        {
            _visible = visible;
            if (_allRenderers == null) return;
            foreach (var r in _allRenderers)
                if (r != null) r.enabled = visible;
            if (pointerLine != null) pointerLine.enabled = visible && _pointTarget != null;
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        // Silueta simple para cuando no hay retrato asignado (nunca se ve un disco vacío).
        private static Texture2D CreatePlaceholderPortrait()
        {
            const int size = 128;
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                name = "HologramCoach_Placeholder",
                hideFlags = HideFlags.HideAndDontSave,
                wrapMode = TextureWrapMode.Clamp
            };

            var pixels = new Color32[size * size];
            for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float u = (x + 0.5f) / size, v = (y + 0.5f) / size;
                float shade = Mathf.Lerp(0.10f, 0.28f, v);
                var color = new Color(shade * 0.6f, shade * 0.95f, shade, 1f);

                float head = Vector2.Distance(new Vector2(u, v), new Vector2(0.5f, 0.6f));
                float shoulders = Vector2.Distance(new Vector2((u - 0.5f) / 0.75f, (v - 0.05f) / 0.45f), Vector2.zero);
                if (head < 0.17f || shoulders < 0.5f) color = new Color(0.55f, 0.85f, 0.88f, 1f);
                pixels[y * size + x] = color;
            }
            texture.SetPixels32(pixels);
            texture.Apply(false, true);
            return texture;
        }

        /// <summary>Usado por el constructor del prefab (HologramCoachBuilder) para enlazar las partes.</summary>
        internal void Bind(Transform visualRoot, Transform discPivot, Transform pointerOrigin, Transform ring,
            Renderer[] glowRenderers, Renderer discRenderer, LineRenderer waveLine, LineRenderer pointerLine, TMP_Text namePlate,
            float discRadius, float discHeight)
        {
            this.visualRoot = visualRoot;
            this.discPivot = discPivot;
            this.pointerOrigin = pointerOrigin;
            this.ring = ring;
            this.glowRenderers = glowRenderers;
            this.discRenderer = discRenderer;
            this.waveLine = waveLine;
            this.pointerLine = pointerLine;
            this.namePlate = namePlate;
            this.discRadius = discRadius;
            this.discHeight = discHeight;
        }
    }
}
