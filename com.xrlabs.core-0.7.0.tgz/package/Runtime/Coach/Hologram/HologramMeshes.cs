using UnityEngine;

namespace XRLabs.Coach
{
    /// <summary>
    /// Mallas procedurales del proyector holográfico. Pocas caras: el presupuesto es Quest 3.
    /// Convención del disco: el frente mira a +Z del objeto (el usuario lo ve desde +Z mirando hacia −Z),
    /// por eso la U de la textura va invertida respecto de X.
    /// </summary>
    public static class HologramMeshes
    {
        /// <summary>Cono abierto. uv.x = vuelta (0–1), uv.y = 0 abajo → 1 arriba.</summary>
        public static Mesh CreateCone(float bottomRadius, float topRadius, float height, int segments = 40)
        {
            segments = Mathf.Max(3, segments);
            var vertices = new Vector3[(segments + 1) * 2];
            var normals = new Vector3[vertices.Length];
            var uvs = new Vector2[vertices.Length];
            var triangles = new int[segments * 6];

            float slope = (bottomRadius - topRadius) / Mathf.Max(height, 1e-4f);
            for (int i = 0; i <= segments; i++)
            {
                float u = (float)i / segments;
                float angle = u * Mathf.PI * 2f;
                var dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
                var normal = new Vector3(dir.x, slope, dir.z).normalized;

                vertices[i * 2] = dir * bottomRadius;
                vertices[i * 2 + 1] = dir * topRadius + Vector3.up * height;
                normals[i * 2] = normals[i * 2 + 1] = normal;
                uvs[i * 2] = new Vector2(u, 0f);
                uvs[i * 2 + 1] = new Vector2(u, 1f);
            }

            for (int i = 0; i < segments; i++)
            {
                int a = i * 2, b = a + 1, c = a + 2, d = a + 3;
                int t = i * 6;
                triangles[t] = a; triangles[t + 1] = b; triangles[t + 2] = c;
                triangles[t + 3] = c; triangles[t + 4] = b; triangles[t + 5] = d;
            }

            return Build("HoloCone", vertices, normals, uvs, triangles);
        }

        /// <summary>Disco plano en XY mirando a +Z, con uv 0–1 (U invertida, ver resumen de la clase).</summary>
        public static Mesh CreateDisc(float radius, int segments = 48)
        {
            segments = Mathf.Max(3, segments);
            var vertices = new Vector3[segments + 2];
            var normals = new Vector3[vertices.Length];
            var uvs = new Vector2[vertices.Length];
            var triangles = new int[segments * 3];

            vertices[0] = Vector3.zero;
            uvs[0] = new Vector2(0.5f, 0.5f);
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * Mathf.PI * 2f;
                float x = Mathf.Cos(angle), y = Mathf.Sin(angle);
                vertices[i + 1] = new Vector3(x * radius, y * radius, 0f);
                uvs[i + 1] = new Vector2(0.5f - x * 0.5f, 0.5f + y * 0.5f);
            }
            for (int i = 0; i < normals.Length; i++) normals[i] = Vector3.forward;

            for (int i = 0; i < segments; i++)
            {
                int t = i * 3;
                triangles[t] = 0; triangles[t + 1] = i + 2; triangles[t + 2] = i + 1;
            }

            return Build("HoloDisc", vertices, normals, uvs, triangles);
        }

        /// <summary>Cuadrilátero centrado en XY mirando a +Z (U invertida, igual que el disco).</summary>
        public static Mesh CreateQuad(float width, float height)
        {
            float w = width * 0.5f, h = height * 0.5f;
            var vertices = new[] { new Vector3(-w, -h, 0f), new Vector3(w, -h, 0f), new Vector3(-w, h, 0f), new Vector3(w, h, 0f) };
            var normals = new[] { Vector3.forward, Vector3.forward, Vector3.forward, Vector3.forward };
            var uvs = new[] { new Vector2(1f, 0f), new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(0f, 1f) };
            var triangles = new[] { 0, 2, 1, 2, 3, 1 };
            return Build("HoloQuad", vertices, normals, uvs, triangles);
        }

        /// <summary>Cilindro/tronco cerrado con tapas (base metálica del proyector).</summary>
        public static Mesh CreateCylinder(float bottomRadius, float topRadius, float height, int segments = 32)
        {
            segments = Mathf.Max(3, segments);
            int ring = segments + 1;
            // lado (2 anillos) + tapa superior (centro + anillo) + tapa inferior (centro + anillo)
            var vertices = new Vector3[ring * 2 + (ring + 1) * 2];
            var normals = new Vector3[vertices.Length];
            var uvs = new Vector2[vertices.Length];
            var triangles = new int[segments * 6 + segments * 3 * 2];

            float slope = (bottomRadius - topRadius) / Mathf.Max(height, 1e-4f);
            for (int i = 0; i <= segments; i++)
            {
                float u = (float)i / segments;
                float angle = u * Mathf.PI * 2f;
                var dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
                var normal = new Vector3(dir.x, slope, dir.z).normalized;
                vertices[i] = dir * bottomRadius;
                vertices[ring + i] = dir * topRadius + Vector3.up * height;
                normals[i] = normals[ring + i] = normal;
                uvs[i] = new Vector2(u, 0f);
                uvs[ring + i] = new Vector2(u, 1f);
            }

            int t = 0;
            for (int i = 0; i < segments; i++)
            {
                int a = i, b = ring + i, c = i + 1, d = ring + i + 1;
                triangles[t++] = a; triangles[t++] = b; triangles[t++] = c;
                triangles[t++] = c; triangles[t++] = b; triangles[t++] = d;
            }

            int topCenter = ring * 2;
            vertices[topCenter] = Vector3.up * height;
            normals[topCenter] = Vector3.up;
            uvs[topCenter] = new Vector2(0.5f, 0.5f);
            int bottomCenter = topCenter + ring + 1;
            vertices[bottomCenter] = Vector3.zero;
            normals[bottomCenter] = Vector3.down;
            uvs[bottomCenter] = new Vector2(0.5f, 0.5f);
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * Mathf.PI * 2f;
                var dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
                vertices[topCenter + 1 + i] = dir * topRadius + Vector3.up * height;
                normals[topCenter + 1 + i] = Vector3.up;
                uvs[topCenter + 1 + i] = new Vector2(dir.x * 0.5f + 0.5f, dir.z * 0.5f + 0.5f);
                vertices[bottomCenter + 1 + i] = dir * bottomRadius;
                normals[bottomCenter + 1 + i] = Vector3.down;
                uvs[bottomCenter + 1 + i] = new Vector2(dir.x * 0.5f + 0.5f, dir.z * 0.5f + 0.5f);
            }
            for (int i = 0; i < segments; i++)
            {
                triangles[t++] = topCenter; triangles[t++] = topCenter + 2 + i; triangles[t++] = topCenter + 1 + i;
                triangles[t++] = bottomCenter; triangles[t++] = bottomCenter + 1 + i; triangles[t++] = bottomCenter + 2 + i;
            }

            return Build("HoloBase", vertices, normals, uvs, triangles);
        }

        /// <summary>Toro en el plano XY (anillo del disco).</summary>
        public static Mesh CreateTorus(float radius, float tubeRadius, int radialSegments = 64, int tubeSegments = 6)
        {
            radialSegments = Mathf.Max(3, radialSegments);
            tubeSegments = Mathf.Max(3, tubeSegments);
            int ringVerts = tubeSegments + 1;
            var vertices = new Vector3[(radialSegments + 1) * ringVerts];
            var normals = new Vector3[vertices.Length];
            var uvs = new Vector2[vertices.Length];
            var triangles = new int[radialSegments * tubeSegments * 6];

            for (int i = 0; i <= radialSegments; i++)
            {
                float a = (float)i / radialSegments * Mathf.PI * 2f;
                var center = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0f) * radius;
                for (int j = 0; j <= tubeSegments; j++)
                {
                    float b = (float)j / tubeSegments * Mathf.PI * 2f;
                    var outward = new Vector3(Mathf.Cos(a) * Mathf.Cos(b), Mathf.Sin(a) * Mathf.Cos(b), Mathf.Sin(b));
                    int index = i * ringVerts + j;
                    vertices[index] = center + outward * tubeRadius;
                    normals[index] = outward;
                    uvs[index] = new Vector2((float)i / radialSegments, (float)j / tubeSegments);
                }
            }

            int t = 0;
            for (int i = 0; i < radialSegments; i++)
            for (int j = 0; j < tubeSegments; j++)
            {
                int a = i * ringVerts + j, b = (i + 1) * ringVerts + j, c = a + 1, d = b + 1;
                triangles[t++] = a; triangles[t++] = b; triangles[t++] = c;
                triangles[t++] = c; triangles[t++] = b; triangles[t++] = d;
            }

            return Build("HoloRing", vertices, normals, uvs, triangles);
        }

        private static Mesh Build(string name, Vector3[] vertices, Vector3[] normals, Vector2[] uvs, int[] triangles)
        {
            var mesh = new Mesh { name = name, vertices = vertices, normals = normals, uv = uvs, triangles = triangles };
            mesh.RecalculateBounds();
            return mesh;
        }
    }
}
