using TMPro;
using UnityEngine;
using UnityEngine.Rendering;

namespace XRLabs.Coach
{
    /// <summary>
    /// Arma la jerarquía del proyector holográfico a partir de mallas y materiales. La usa el generador del
    /// prefab (Tools → XRLabs → Create Hologram Coach Prefab) y, como alternativa sin prefab, <see cref="HologramCoach.CreateDefault"/>.
    /// </summary>
    public static class HologramCoachBuilder
    {
        public const string ShaderCone = "XRLabs/HoloCone";
        public const string ShaderDisc = "XRLabs/HoloDisc";
        public const string ShaderDots = "XRLabs/HoloDots";
        public const string ShaderGlow = "XRLabs/HoloGlow";

        /// <summary>Mallas y materiales que consume <see cref="Build"/>.</summary>
        public class Resources
        {
            public Mesh baseMesh, lensMesh, coneMesh, discMesh, ringMesh, plateMesh, barMesh;
            public Material baseMat, lensMat, coneMat, discMat, ringMat, waveMat, dotsMat, plateMat, barMat;
        }

        // Cotas del diseño original (web: disco de radio 0,48). Todo se escala con el radio del disco.
        private const float ReferenceRadius = 0.48f;
        // Placa con nombre, en múltiplos del radio del disco.
        private const float PlateWidth = 2.6f, PlateHeight = 0.5f, PlateOffset = 1.6f;

        // Intensidades pensadas para LDR (Quest sin HDR): el acento × intensidad no debe pasar de ~1,3.
        public const float LensIntensity = 1.5f, RingIntensity = 1.2f, WaveIntensity = 1.2f, BarIntensity = 1.2f;

        /// <summary>Crea mallas con las medidas por defecto para un disco de <paramref name="discRadius"/> metros.</summary>
        public static Resources CreateMeshes(float discRadius, float discHeight)
        {
            float k = discRadius / ReferenceRadius;
            float coneBottom = 0.09f;
            float coneTop = discHeight - discRadius - 0.04f;
            return new Resources
            {
                baseMesh = HologramMeshes.CreateCylinder(0.26f * k, 0.2f * k, 0.1f * k),
                lensMesh = HologramMeshes.CreateDisc(0.15f * k, 32),
                coneMesh = HologramMeshes.CreateCone(0.13f * k, discRadius * 1.04f, coneTop - coneBottom, 40),
                discMesh = HologramMeshes.CreateDisc(discRadius, 64),
                ringMesh = HologramMeshes.CreateTorus(discRadius * 1.052f, discRadius * 0.029f, 96, 6),
                plateMesh = HologramMeshes.CreateQuad(discRadius * PlateWidth, discRadius * PlateHeight),
                barMesh = HologramMeshes.CreateQuad(discRadius * 0.025f, discRadius * PlateHeight)
            };
        }

        /// <summary>Materiales en memoria (sin guardar). Requiere que los shaders estén en el proyecto.</summary>
        public static void FillRuntimeMaterials(Resources res)
        {
            var lit = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            res.baseMat = new Material(lit) { name = "Holo_Base" };
            ConfigureBase(res.baseMat);
            res.lensMat = Glow("Holo_Lens", LensIntensity, additive: true);
            res.coneMat = new Material(Shader.Find(ShaderCone)) { name = "Holo_Cone" };
            res.discMat = new Material(Shader.Find(ShaderDisc)) { name = "Holo_Disc" };
            res.ringMat = Glow("Holo_Ring", RingIntensity, additive: true);
            res.waveMat = Glow("Holo_Wave", WaveIntensity, additive: true);
            res.dotsMat = new Material(Shader.Find(ShaderDots)) { name = "Holo_Dots" };
            res.plateMat = Glow("Holo_Plate", 1f, additive: false, fixedColor: new Color(0.03f, 0.08f, 0.09f, 0.85f));
            res.barMat = Glow("Holo_PlateBar", BarIntensity, additive: true);
        }

        public static void ConfigureBase(Material material)
        {
            var color = new Color(0.17f, 0.2f, 0.21f, 1f);
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", 0.8f);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 0.65f);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.65f);
        }

        /// <summary>Configura un material XRLabs/HoloGlow: aditivo o con alfa, acento del script o color fijo.</summary>
        public static Material Glow(string name, float intensity, bool additive, Color? fixedColor = null)
        {
            var material = new Material(Shader.Find(ShaderGlow)) { name = name };
            ConfigureGlow(material, intensity, additive, fixedColor);
            return material;
        }

        public static void ConfigureGlow(Material material, float intensity, bool additive, Color? fixedColor = null)
        {
            material.SetFloat("_Intensity", intensity);
            material.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha);
            material.SetFloat("_DstBlend", (float)(additive ? BlendMode.One : BlendMode.OneMinusSrcAlpha));
            material.SetFloat("_UseAccent", fixedColor.HasValue ? 0f : 1f);
            if (fixedColor.HasValue) material.SetColor("_Color", fixedColor.Value);
            // El fondo de la placa va antes del texto TMP (Transparent = 3000) y después del cono.
            if (!additive) material.renderQueue = 3001;
        }

        /// <summary>Arma el GameObject raíz con HologramCoach y todas sus partes.</summary>
        public static HologramCoach Build(Resources res, string name = "HologramCoach", float discRadius = 0.24f, float discHeight = 1.7f)
        {
            float k = discRadius / ReferenceRadius;

            var root = new GameObject(name);
            var coach = root.AddComponent<HologramCoach>();

            var visual = Child("Visual", root.transform);

            // Base y lente en el suelo
            Mesh(Child("Base", visual), res.baseMesh, res.baseMat);
            var lens = Child("Lens", visual);
            lens.localPosition = new Vector3(0f, 0.102f * k, 0f);
            lens.localRotation = Quaternion.Euler(-90f, 0f, 0f);
            var lensRenderer = Mesh(lens, res.lensMesh, res.lensMat);

            // Cono de luz
            var cone = Child("LightCone", visual);
            cone.localPosition = new Vector3(0f, 0.09f, 0f);
            var coneRenderer = Mesh(cone, res.coneMesh, res.coneMat);

            // Disco y accesorios
            var pivot = Child("DiscPivot", visual);
            pivot.localPosition = new Vector3(0f, discHeight, 0f);

            var discRenderer = Mesh(Child("Portrait", pivot), res.discMesh, res.discMat);
            var ring = Child("Ring", pivot);
            var ringRenderer = Mesh(ring, res.ringMesh, res.ringMat);

            var origin = Child("PointerOrigin", pivot);

            var wave = Child("VoiceWave", pivot).gameObject.AddComponent<LineRenderer>();
            ConfigureLine(wave, res.waveMat, discRadius * 0.025f);
            wave.loop = true;
            wave.useWorldSpace = false;
            wave.positionCount = 128;

            // Placa con nombre
            float plateY = -discRadius * PlateOffset;
            var plate = Child("NamePlate", pivot);
            plate.localPosition = new Vector3(0f, plateY, 0f);
            var plateBg = Mesh(Child("Background", plate), res.plateMesh, res.plateMat);
            var bar = Child("AccentBar", plate);
            bar.localPosition = new Vector3(discRadius * PlateWidth * 0.5f, 0f, 0.001f);
            var barRenderer = Mesh(bar, res.barMesh, res.barMat);

            var textTransform = Child("Text", plate);
            textTransform.localPosition = new Vector3(-discRadius * 0.06f, 0f, 0.002f);
            textTransform.localRotation = Quaternion.Euler(0f, 180f, 0f); // TMP se lee mirando hacia +Z
            var text = textTransform.gameObject.AddComponent<TextMeshPro>();
            text.rectTransform.sizeDelta = new Vector2(discRadius * (PlateWidth - 0.2f), discRadius * PlateHeight);
            text.fontSize = discRadius * 2f;
            text.alignment = TextAlignmentOptions.MidlineLeft;
            text.textWrappingMode = TextWrappingModes.NoWrap;
            text.overflowMode = TextOverflowModes.Ellipsis;
            text.color = Color.white;
            text.fontStyle = FontStyles.Bold;
            text.text = "INSTRUCTORA";
            text.GetComponent<MeshRenderer>().sortingOrder = 1;

            // Rayo punteado (en coordenadas de mundo, cuelga de la raíz)
            var pointer = Child("PointerBeam", root.transform).gameObject.AddComponent<LineRenderer>();
            ConfigureLine(pointer, res.dotsMat, 0.014f);
            pointer.useWorldSpace = true;
            pointer.positionCount = 2;
            pointer.textureMode = LineTextureMode.Stretch;
            pointer.enabled = false;

            // Sin sombras ni sondas: solo se dibuja
            foreach (var r in root.GetComponentsInChildren<Renderer>(true))
            {
                r.shadowCastingMode = ShadowCastingMode.Off;
                r.receiveShadows = false;
                r.lightProbeUsage = LightProbeUsage.Off;
                r.reflectionProbeUsage = ReflectionProbeUsage.Off;
                r.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
            }

            coach.Bind(visual, pivot, origin, ring,
                new Renderer[] { lensRenderer, coneRenderer, ringRenderer, plateBg, barRenderer },
                discRenderer, wave, pointer, text, discRadius, discHeight);
            return coach;
        }

        private static Transform Child(string name, Transform parent)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            return go.transform;
        }

        private static MeshRenderer Mesh(Transform target, Mesh mesh, Material material)
        {
            target.gameObject.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = target.gameObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            return renderer;
        }

        private static void ConfigureLine(LineRenderer line, Material material, float width)
        {
            line.sharedMaterial = material;
            line.widthMultiplier = width;
            line.numCapVertices = 0;
            line.numCornerVertices = 0;
            line.alignment = LineAlignment.View;
            line.textureMode = LineTextureMode.Stretch;
            line.generateLightingData = false;
        }
    }
}
