// Color emisivo plano (lente, anillo, onda circular, placa). Tipo de mezcla por material:
// aditivo (SrcAlpha, One) o alfa (SrcAlpha, OneMinusSrcAlpha).
Shader "XRLabs/HoloGlow"
{
    Properties
    {
        [HDR] _Accent ("Color de acento", Color) = (0.16, 0.76, 0.78, 1)
        _Intensity ("Intensidad", Range(0, 6)) = 1.5
        _Opacity ("Opacidad", Range(0, 1)) = 1
        [Toggle] _UseAccent ("Usar color de acento del script", Float) = 1
        [HDR] _Color ("Color fijo (si no usa acento)", Color) = (0.03, 0.08, 0.09, 0.85)
        _Amp ("Amplitud de voz (MPB)", Range(0, 1)) = 0
        _AmpGain ("Brillo extra por voz", Range(0, 2)) = 0.4
        _Fade ("Aparición (MPB)", Range(0, 1)) = 1
        [Enum(UnityEngine.Rendering.BlendMode)] _SrcBlend ("Src", Float) = 5
        [Enum(UnityEngine.Rendering.BlendMode)] _DstBlend ("Dst", Float) = 1
    }

    SubShader
    {
        Tags { "RenderType" = "Transparent" "Queue" = "Transparent+2" "RenderPipeline" = "UniversalPipeline" "IgnoreProjector" = "True" }

        Pass
        {
            Name "HoloGlow"
            Tags { "LightMode" = "UniversalForward" }
            Blend [_SrcBlend] [_DstBlend]
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma target 2.0

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _Accent;
                half4 _Color;
                half _Intensity;
                half _Opacity;
                half _UseAccent;
                half _Amp;
                half _AmpGain;
                half _Fade;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);

                half3 rgb = _UseAccent > 0.5h ? _Accent.rgb * _Intensity * (1.0h + _Amp * _AmpGain) : _Color.rgb;
                half a = (_UseAccent > 0.5h ? 1.0h : _Color.a) * _Opacity * _Fade;
                return half4(rgb, a);
            }
            ENDHLSL
        }
    }
}
