// Rayo punteado hacia el objetivo (LineRenderer, textura estirada: uv.x va de 0 a 1 a lo largo del rayo).
// El script envía _Length (m) por MaterialPropertyBlock para que los guiones tengan largo constante.
Shader "XRLabs/HoloDots"
{
    Properties
    {
        [HDR] _Accent ("Color de acento", Color) = (0.16, 0.76, 0.78, 1)
        _Intensity ("Intensidad", Range(0, 4)) = 1
        _DashLength ("Largo del guion (m)", Float) = 0.14
        _GapLength ("Largo del hueco (m)", Float) = 0.09
        _Speed ("Velocidad (m/s)", Float) = 0.5
        _EndFade ("Desvanecido en los extremos (m)", Float) = 0.12
        _Length ("Largo del rayo (MPB)", Float) = 1
        _Fade ("Aparición (MPB)", Range(0, 1)) = 1
    }

    SubShader
    {
        Tags { "RenderType" = "Transparent" "Queue" = "Transparent+2" "RenderPipeline" = "UniversalPipeline" "IgnoreProjector" = "True" }

        Pass
        {
            Name "HoloDots"
            Tags { "LightMode" = "UniversalForward" }
            Blend SrcAlpha One
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma target 2.0

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _Accent;
                half _Intensity;
                float _DashLength;
                float _GapLength;
                float _Speed;
                float _EndFade;
                float _Length;
                half _Fade;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.uv = input.uv;
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);

                float along = input.uv.x * _Length;                       // metros desde el disco
                float period = max(_DashLength + _GapLength, 1e-3);
                float phase = frac((along - _Time.y * _Speed) / period) * period;
                half dash = smoothstep(0.0, 0.02, phase) * (1.0h - smoothstep(_DashLength - 0.02, _DashLength, phase));

                half across = 1.0h - abs(input.uv.y - 0.5h) * 2.0h;     // borde suave en el ancho
                half ends = saturate(along / max(_EndFade, 1e-3)) * saturate((_Length - along) / max(_EndFade, 1e-3));

                half a = dash * saturate(across * 1.5h) * ends * _Fade;
                return half4(_Accent.rgb * _Intensity, a);
            }
            ENDHLSL
        }
    }
}
