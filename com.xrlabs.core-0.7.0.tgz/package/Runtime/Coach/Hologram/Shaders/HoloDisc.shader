// Disco del holograma: retrato + líneas de escaneo + parpadeo leve + borde que brilla con la voz.
// Uv 0–1 sobre el disco; el recorte circular y el borde se calculan aquí (no hace falta textura de máscara).
Shader "XRLabs/HoloDisc"
{
    Properties
    {
        _Map ("Retrato", 2D) = "white" {}
        [HDR] _Accent ("Color de acento", Color) = (0.16, 0.76, 0.78, 1)
        _HoloTint ("Tinte holográfico", Range(0, 1)) = 0.2
        _RimIntensity ("Brillo del borde", Range(0, 4)) = 0.7
        _RimStart ("Inicio del borde", Range(0.5, 0.99)) = 0.8
        _ScanDensity ("Densidad de escaneo", Float) = 380
        _ScanSpeed ("Velocidad de escaneo", Float) = 5
        _ScanDepth ("Contraste de escaneo", Range(0, 0.5)) = 0.07
        _FlickerDepth ("Parpadeo", Range(0, 0.2)) = 0.03
        _Amp ("Amplitud de voz (MPB)", Range(0, 1)) = 0
        _Fade ("Aparición (MPB)", Range(0, 1)) = 1
    }

    SubShader
    {
        Tags { "RenderType" = "Transparent" "Queue" = "Transparent+1" "RenderPipeline" = "UniversalPipeline" "IgnoreProjector" = "True" }

        Pass
        {
            Name "HoloDisc"
            Tags { "LightMode" = "UniversalForward" }
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma target 2.0

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            TEXTURE2D(_Map);
            SAMPLER(sampler_Map);

            CBUFFER_START(UnityPerMaterial)
                float4 _Map_ST;
                half4 _Accent;
                half _HoloTint;
                half _RimIntensity;
                half _RimStart;
                half _ScanDensity;
                half _ScanSpeed;
                half _ScanDepth;
                half _FlickerDepth;
                half _Amp;
                half _Fade;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.uv = input.uv;
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);

                float2 c = input.uv - 0.5;
                half r = (half)(length(c) * 2.0);
                half edge = 1.0h - smoothstep(0.985h, 1.0h, r);
                clip(edge - 0.003h);

                half3 col = SAMPLE_TEXTURE2D(_Map, sampler_Map, input.uv * _Map_ST.xy + _Map_ST.zw).rgb;

                half lum = dot(col, half3(0.299h, 0.587h, 0.114h));
                col = lerp(col, lum * _Accent.rgb * 1.6h, _HoloTint);

                half t = (half)_Time.y;
                half scan = (1.0h - _ScanDepth) + _ScanDepth * sin(input.uv.y * _ScanDensity + t * _ScanSpeed);
                half rim = smoothstep(_RimStart, 1.0h, r);
                col = col * scan * 1.05h + _Accent.rgb * rim * (1.4h + _Amp * 3.0h) * _RimIntensity;

                half flicker = 1.0h - _FlickerDepth + _FlickerDepth * sin(t * 31.0h) * sin(t * 11.0h);
                return half4(col * flicker, edge * _Fade);
            }
            ENDHLSL
        }
    }
}
