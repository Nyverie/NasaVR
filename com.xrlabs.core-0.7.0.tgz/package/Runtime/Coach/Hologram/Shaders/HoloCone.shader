// Cono de luz del proyector: aditivo, con líneas que suben. El brillo se multiplica por (1 + _Amp).
// Uv: x = vuelta alrededor del cono, y = 0 en la base (angosta) → 1 arriba (ancha).
Shader "XRLabs/HoloCone"
{
    Properties
    {
        [HDR] _Accent ("Color de acento", Color) = (0.16, 0.76, 0.78, 1)
        _Intensity ("Intensidad", Range(0, 4)) = 1
        _BaseAlpha ("Brillo mínimo", Range(0, 1)) = 0.03
        _BaseGlow ("Brillo en la base del cono", Range(0, 1)) = 0.22
        _LineFreq ("Líneas por unidad de uv", Float) = 60
        _LineSpeed ("Velocidad de ascenso", Float) = 6
        _LineDepth ("Contraste de líneas", Range(0, 1)) = 0.25
        _Amp ("Amplitud de voz (MPB)", Range(0, 1)) = 0
        _Fade ("Aparición (MPB)", Range(0, 1)) = 1
    }

    SubShader
    {
        Tags { "RenderType" = "Transparent" "Queue" = "Transparent" "RenderPipeline" = "UniversalPipeline" "IgnoreProjector" = "True" }

        Pass
        {
            Name "HoloCone"
            Tags { "LightMode" = "UniversalForward" }
            Blend One One
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma target 2.0

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _Accent;
                half _Intensity;
                half _BaseAlpha;
                half _BaseGlow;
                half _LineFreq;
                half _LineSpeed;
                half _LineDepth;
                half _Amp;
                half _Fade;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.uv = input.uv;
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);

                half a = (1.0h - input.uv.y) * _BaseGlow + _BaseAlpha;
                // Líneas que suben (el tiempo resta, así el patrón se desplaza hacia +uv.y).
                half lines = (1.0h - _LineDepth) + _LineDepth * sin(input.uv.y * _LineFreq - _Time.y * _LineSpeed);
                a *= lines;
                a *= (1.0h + _Amp) * _Intensity * _Fade;
                return half4(_Accent.rgb * a, a);
            }
            ENDHLSL
        }
    }
}
