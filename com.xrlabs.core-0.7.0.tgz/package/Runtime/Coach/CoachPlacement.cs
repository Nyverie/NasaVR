using System;
using UnityEngine;
using UnityEngine.AI;

namespace XRLabs.Coach
{
    /// <summary>
    /// Elige dónde pararse cuando el coach sigue al usuario: a un lado de su mirada, sobre
    /// el suelo, sin chocar con nada y a la vista. Separado del director para poder probarlo.
    /// </summary>
    [Serializable]
    public class CoachPlacement
    {
        [Tooltip("Distancias al usuario que se prueban, en orden de preferencia (m).")]
        public float[] distances = { 1.8f, 1.4f, 2.2f };

        [Tooltip("Ángulos respecto de la mirada que se prueban (grados, se prueban a ambos lados).")]
        public float[] angles = { 35f, 55f, 20f, 75f };

        [Tooltip("Capas que cuentan como suelo.")]
        public LayerMask floorMask = ~0;

        [Tooltip("Capas que bloquean (paredes, muebles). Excluir la capa del propio coach y del rig.")]
        public LayerMask obstacleMask = ~0;

        [Tooltip("Radio del espacio libre que necesita el coach (m).")]
        public float clearanceRadius = 0.3f;

        [Tooltip("El suelo válido debe estar al menos esto por debajo de la cabeza (m). Evita pararse sobre muebles o muros bajos.")]
        public float minHeadAboveFloor = 0.9f;

        [Tooltip("Validar contra el NavMesh si existe uno horneado.")]
        public bool useNavMesh;

        [Tooltip("Distancia máxima para ajustar al NavMesh (m).")]
        public float navMeshSnapDistance = 0.5f;

        /// <summary>
        /// Busca un punto libre. preferredSide (+1 derecha / −1 izquierda) evita que el coach
        /// cruce delante del usuario si ya estaba de un lado.
        /// </summary>
        public bool TryFindSpot(Vector3 headPosition, Vector3 headForward, float preferredSide, float coachHeight,
            Transform ignoreRoot, out Vector3 spot)
        {
            Vector3 forward = Vector3.ProjectOnPlane(headForward, Vector3.up);
            if (forward.sqrMagnitude < 1e-4f) forward = Vector3.forward;
            forward.Normalize();

            float side = preferredSide >= 0f ? 1f : -1f;

            foreach (float distance in distances)
            foreach (float angle in angles)
            for (int s = 0; s < 2; s++)
            {
                float signedAngle = angle * (s == 0 ? side : -side);
                Vector3 direction = Quaternion.AngleAxis(signedAngle, Vector3.up) * forward;
                Vector3 candidate = headPosition + direction * distance;

                if (TryValidate(headPosition, candidate, coachHeight, ignoreRoot, out spot))
                    return true;
            }

            spot = default;
            return false;
        }

        private bool TryValidate(Vector3 head, Vector3 candidate, float coachHeight, Transform ignoreRoot, out Vector3 spot)
        {
            spot = default;

            // 1. Suelo bajo el candidato (desde la altura de la cabeza hacia abajo).
            var rayOrigin = new Vector3(candidate.x, head.y + 0.5f, candidate.z);
            if (!Physics.Raycast(rayOrigin, Vector3.down, out var floorHit, 4f, floorMask, QueryTriggerInteraction.Ignore))
                return false;
            Vector3 ground = floorHit.point;
            if (head.y - ground.y < minHeadAboveFloor)
                return false;

            // 2. NavMesh opcional.
            if (useNavMesh)
            {
                if (!NavMesh.SamplePosition(ground, out var navHit, navMeshSnapDistance, NavMesh.AllAreas))
                    return false;
                ground = navHit.position;
            }

            // 3. Espacio libre (cápsula un poco sobre el suelo para no tocarlo).
            Vector3 bottom = ground + Vector3.up * (clearanceRadius + 0.05f);
            Vector3 top = ground + Vector3.up * Mathf.Max(clearanceRadius + 0.1f, coachHeight - clearanceRadius);
            foreach (var hit in Physics.OverlapCapsule(bottom, top, clearanceRadius, obstacleMask, QueryTriggerInteraction.Ignore))
            {
                if (ignoreRoot != null && hit.transform.IsChildOf(ignoreRoot)) continue;
                if (hit == floorHit.collider) continue;
                return false;
            }

            // 4. A la vista: nada entre la cabeza y el pecho del coach.
            Vector3 chest = ground + Vector3.up * Mathf.Min(1.4f, coachHeight * 0.7f);
            if (Physics.Linecast(head, chest, out var blockHit, obstacleMask, QueryTriggerInteraction.Ignore) &&
                (ignoreRoot == null || !blockHit.transform.IsChildOf(ignoreRoot)))
                return false;

            spot = ground;
            return true;
        }
    }
}
