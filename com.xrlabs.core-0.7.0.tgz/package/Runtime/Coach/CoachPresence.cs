using System.Collections;
using UnityEngine;

namespace XRLabs.Coach
{
    /// <summary>
    /// Cuerpo visible del coach. El CoachDirector decide dónde está, a quién mira y a qué
    /// señala; la presencia solo se dibuja. v1 = HologramCoach (disco con foto); un avatar
    /// 3D futuro hereda de esta misma clase sin tocar el director.
    ///
    /// El transform raíz es el punto de apoyo en el suelo; el director lo mueve y lo gira
    /// en Y hacia el usuario.
    /// </summary>
    public abstract class CoachPresence : MonoBehaviour
    {
        /// <summary>Punto desde donde sale el rayo hacia el objetivo (ej: centro del disco).</summary>
        public abstract Transform PointerOrigin { get; }

        /// <summary>Altura aproximada del coach (para encuadre y chequeo de espacio libre).</summary>
        public virtual float Height => 2f;

        /// <summary>Se llama cada frame con la amplitud de la voz (0–1) y si la frase es una corrección.</summary>
        public abstract void SetVoice(float amplitude, bool isError);

        /// <summary>Hace que el coach señale un objetivo (rayo, gesto). null = dejar de señalar.</summary>
        public abstract void PointAt(Transform target);

        /// <summary>Mira hacia un punto (el usuario). Por defecto no hace nada: el director ya gira la raíz.</summary>
        public virtual void LookAt(Vector3 worldPoint) { }

        /// <summary>Efecto de desaparición antes de reubicarse lejos. Por defecto, instantáneo.</summary>
        public virtual IEnumerator Disappear()
        {
            SetRenderersVisible(false);
            yield break;
        }

        /// <summary>Efecto de aparición tras reubicarse. Por defecto, instantáneo.</summary>
        public virtual IEnumerator Appear()
        {
            SetRenderersVisible(true);
            yield break;
        }

        protected void SetRenderersVisible(bool visible)
        {
            foreach (var r in GetComponentsInChildren<Renderer>(true))
                r.enabled = visible;
        }
    }
}
