using System;
using System.Text;
using System.Threading;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using XRLabs.Networking.Models;
using UnityEngine;
using UnityEngine.Networking;

namespace XRLabs.Networking
{
    public class ApiClient : MonoBehaviour
    {
        public static ApiClient Instance { get; private set; }

        [SerializeField] private ApiSettings settings;

        private string _accessToken;
        private string _refreshToken;

        public bool IsAuthenticated => !string.IsNullOrEmpty(_accessToken);
        public ApiSettings Settings => settings;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            if (settings == null)
                Debug.LogError("[API] ApiSettings NO está asignado en el Inspector del ApiClient.");
            else
                Debug.Log($"[API] Inicializado — baseUrl={settings.baseUrl} | mock={settings.useMockData}");
        }

        public void SetTokens(string access, string refresh)
        {
            _accessToken = access;
            _refreshToken = refresh;
        }

        public void ClearTokens()
        {
            _accessToken = null;
            _refreshToken = null;
        }

        /// <summary>GET genérico con reintento automático ante 401.</summary>
        public async UniTask<ApiResponse<T>> GetAsync<T>(string endpoint, CancellationToken ct = default)
        {
            return await ExecuteWithRetry(() => SendGet<T>(endpoint, ct), endpoint, ct);
        }

        /// <summary>POST genérico con body JSON.</summary>
        public async UniTask<ApiResponse<T>> PostAsync<T>(string endpoint, object body, CancellationToken ct = default)
        {
            return await ExecuteWithRetry(() => SendPost<T>(endpoint, body, ct), endpoint, ct);
        }

        /// <summary>PATCH genérico con body JSON.</summary>
        public async UniTask<ApiResponse<T>> PatchAsync<T>(string endpoint, object body, CancellationToken ct = default)
        {
            return await ExecuteWithRetry(() => SendPatch<T>(endpoint, body, ct), endpoint, ct);
        }

        private async UniTask<ApiResponse<T>> ExecuteWithRetry<T>(
            Func<UniTask<ApiResponse<T>>> operation,
            string endpoint,
            CancellationToken ct)
        {
            ApiResponse<T> result = default;
            for (int attempt = 0; attempt < settings.maxRetries; attempt++)
            {
                if (ct.IsCancellationRequested)
                    return ApiResponse<T>.Fail(0, "Request cancelado");

                result = await operation();

                if (result.Success)
                    return result;

                // Auto-refresh en 401
                if (result.StatusCode == 401 && !string.IsNullOrEmpty(_refreshToken))
                {
                    bool refreshed = await TryRefreshToken(ct);
                    if (!refreshed)
                        return result;
                    // Reintentar con el token nuevo
                    result = await operation();
                    if (result.Success) return result;
                }

                // No reintentar en errores de cliente (4xx excepto 401/429)
                if (result.StatusCode >= 400 && result.StatusCode < 500 && result.StatusCode != 429)
                    return result;

                if (attempt < settings.maxRetries - 1)
                {
                    float delay = settings.retryBaseDelaySeconds * Mathf.Pow(2, attempt);
                    await UniTask.Delay(TimeSpan.FromSeconds(delay), cancellationToken: ct);
                }
            }
            return result;
        }

        private async UniTask<ApiResponse<T>> SendGet<T>(string endpoint, CancellationToken ct)
        {
            var url = $"{settings.baseUrl}{endpoint}";
            using var request = UnityWebRequest.Get(url);
            SetHeaders(request);
            request.timeout = (int)settings.requestTimeoutSeconds;

            Debug.Log($"[API] → GET {url}");

            try
            {
                await request.SendWebRequest().WithCancellation(ct);
                return HandleResponse<T>(request, "GET", url);
            }
            catch (UnityWebRequestException uwEx)
            {
                // UniTask lanza esta excepción en errores HTTP (4xx/5xx)
                return HandleHttpException<T>(uwEx, "GET", url);
            }
            catch (OperationCanceledException)
            {
                Debug.LogWarning($"[API] GET {url} — cancelado");
                return ApiResponse<T>.Fail(0, "Request cancelado");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[API] GET {url} — error de red: {ex.Message}");
                return ApiResponse<T>.Fail(0, ex.Message);
            }
        }

        private async UniTask<ApiResponse<T>> SendPost<T>(string endpoint, object body, CancellationToken ct)
        {
            var url = $"{settings.baseUrl}{endpoint}";
            var json = JsonConvert.SerializeObject(body);
            var bodyBytes = Encoding.UTF8.GetBytes(json);

            using var request = new UnityWebRequest(url, "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            SetHeaders(request);
            request.timeout = (int)settings.requestTimeoutSeconds;

            Debug.Log($"[API] → POST {url}\n  body: {json}");

            try
            {
                await request.SendWebRequest().WithCancellation(ct);
                return HandleResponse<T>(request, "POST", url);
            }
            catch (UnityWebRequestException uwEx)
            {
                return HandleHttpException<T>(uwEx, "POST", url);
            }
            catch (OperationCanceledException)
            {
                Debug.LogWarning($"[API] POST {url} — cancelado");
                return ApiResponse<T>.Fail(0, "Request cancelado");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[API] POST {url} — error de red: {ex.Message}");
                return ApiResponse<T>.Fail(0, ex.Message);
            }
        }

        private async UniTask<ApiResponse<T>> SendPatch<T>(string endpoint, object body, CancellationToken ct)
        {
            var url = $"{settings.baseUrl}{endpoint}";
            var json = JsonConvert.SerializeObject(body);
            var bodyBytes = Encoding.UTF8.GetBytes(json);

            using var request = new UnityWebRequest(url, "PATCH");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            SetHeaders(request);
            request.timeout = (int)settings.requestTimeoutSeconds;

            Debug.Log($"[API] → PATCH {url}\n  body: {json}");

            try
            {
                await request.SendWebRequest().WithCancellation(ct);
                return HandleResponse<T>(request, "PATCH", url);
            }
            catch (UnityWebRequestException uwEx)
            {
                return HandleHttpException<T>(uwEx, "PATCH", url);
            }
            catch (OperationCanceledException)
            {
                Debug.LogWarning($"[API] PATCH {url} — cancelado");
                return ApiResponse<T>.Fail(0, "Request cancelado");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[API] PATCH {url} — error de red: {ex.Message}");
                return ApiResponse<T>.Fail(0, ex.Message);
            }
        }

        private ApiResponse<T> HandleHttpException<T>(UnityWebRequestException uwEx, string method, string url)
        {
            var status = (int)uwEx.ResponseCode;
            var body = uwEx.Text;

            if (status >= 500)
                Debug.LogError($"[API] ← {status} {method} {url}\n  {body}");
            else
                Debug.LogWarning($"[API] ← {status} {method} {url}\n  {body}");

            try
            {
                var error = JsonConvert.DeserializeObject<ApiError>(body);
                return ApiResponse<T>.Fail(status, error?.Message ?? uwEx.Error);
            }
            catch
            {
                return ApiResponse<T>.Fail(status, string.IsNullOrEmpty(body) ? uwEx.Error : body);
            }
        }

        private async UniTask<bool> TryRefreshToken(CancellationToken ct)
        {
            var body = new { refresh_token = _refreshToken };
            var result = await SendPost<RefreshResponse>("/auth/refresh", body, ct);
            if (!result.Success) return false;

            _accessToken = result.Data.AccessToken;
            _refreshToken = result.Data.RefreshToken;
            return true;
        }

        private void SetHeaders(UnityWebRequest request)
        {
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("X-Device-Type", "vr_headset");
            request.SetRequestHeader("X-Platform", "quest3");
            request.SetRequestHeader("X-App-Version", Application.version);

            if (!string.IsNullOrEmpty(_accessToken))
            {
                request.SetRequestHeader("Authorization", $"Bearer {_accessToken}");
                Debug.Log($"[API] Auth header → Bearer {_accessToken[..Mathf.Min(12, _accessToken.Length)]}...");
            }
            else
            {
                Debug.LogWarning("[API] ⚠ Sin token — request enviado sin Authorization.");
            }
        }

        private ApiResponse<T> HandleResponse<T>(UnityWebRequest request, string method, string url)
        {
            var status = (int)request.responseCode;
            var body = request.downloadHandler?.text;

            if (request.result == UnityWebRequest.Result.Success)
            {
                if (settings.logRequests)
                    Debug.Log($"[API] ← {status} {method} {url}\n  {Truncate(body, 300)}");

                try
                {
                    var data = JsonConvert.DeserializeObject<T>(body);
                    return ApiResponse<T>.Ok(data, status);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[API] Error deserializando respuesta de {url}\n  body: {body}\n  error: {ex.Message}");
                    return ApiResponse<T>.Fail(status, $"Error deserializando respuesta: {ex.Message}");
                }
            }

            // Error HTTP — siempre loguearlo aunque logRequests=false
            var fullBody = string.IsNullOrEmpty(body) ? request.error : body;
            if (status >= 500)
                Debug.LogError($"[API] ← {status} {method} {url}\n  {fullBody}");
            else
                Debug.LogWarning($"[API] ← {status} {method} {url}\n  {fullBody}");

            try
            {
                var error = JsonConvert.DeserializeObject<ApiError>(body);
                return ApiResponse<T>.Fail(status, error?.Message ?? fullBody);
            }
            catch
            {
                return ApiResponse<T>.Fail(status, fullBody);
            }
        }

        private static string Truncate(string s, int max) =>
            s == null ? "(vacío)" : s.Length <= max ? s : s[..max] + "…";
    }
}
