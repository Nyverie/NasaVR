using System.Runtime.CompilerServices;

// Los tests EditMode del paquete leen las formas internas del API (DataService) y sus conversiones.
[assembly: InternalsVisibleTo("XRLabs.Coach.Editor.Tests")]
