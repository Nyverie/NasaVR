using System;
using Cysharp.Threading.Tasks;
using XRLabs.Networking.Models;
using UnityEngine;

namespace XRLabs.Networking
{
    public class AuthManager : MonoBehaviour
    {
        public static AuthManager Instance { get; private set; }

        public event Action<AuthenticatedUser> OnAuthStateChanged;

        public AuthenticatedUser CurrentUser { get; private set; }
        public bool IsAuthenticated => ApiClient.Instance != null && ApiClient.Instance.IsAuthenticated;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        /// <summary>Autentica al usuario con un PIN de 6 dígitos vía XR Auth.</summary>
        public async UniTask<ApiResponse<XrTokenResponse>> LoginWithPin(string pin)
        {
            Debug.Log($"[Auth] Iniciando login con PIN de {pin.Length} dígitos...");

            var request = new ValidatePinRequest { Pin = pin };
            var response = await ApiClient.Instance.PostAsync<XrTokenResponse>("/xr-auth/validate-pin", request);

            if (response.Success && response.Data != null)
            {
                ApiClient.Instance.SetTokens(response.Data.Token, null);

                CurrentUser = new AuthenticatedUser
                {
                    Id = response.Data.User?.Id,
                    DisplayName = response.Data.User?.Name ?? response.Data.User?.Email ?? "Usuario",
                    OrgId = response.Data.User?.OrgId,
                    RoleId = response.Data.User?.RoleId
                };

                var tokenPreview = response.Data.Token?[..Mathf.Min(12, response.Data.Token?.Length ?? 0)] ?? "(null)";
                Debug.Log($"[Auth] Login exitoso — userId={CurrentUser.Id} | name={CurrentUser.DisplayName} | token={tokenPreview}... | ApiClient.IsAuthenticated={ApiClient.Instance?.IsAuthenticated}");
                OnAuthStateChanged?.Invoke(CurrentUser);
            }
            else
            {
                Debug.LogWarning($"[Auth] Login fallido — HTTP {response.StatusCode}: {response.ErrorMessage}");
            }

            return response;
        }

        /// <summary>Establece el usuario directamente (usado por el flujo mock).</summary>
        public void SetUser(AuthenticatedUser user)
        {
            CurrentUser = user;
            OnAuthStateChanged?.Invoke(CurrentUser);
        }

        /// <summary>Cierra la sesión y limpia todos los tokens.</summary>
        public void Logout()
        {
            ApiClient.Instance?.ClearTokens();
            CurrentUser = null;
            OnAuthStateChanged?.Invoke(null);
        }
    }
}
