using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using XRLabs.Networking.Models;
using UnityEngine;

namespace XRLabs.Networking
{
    /// <summary>Los score events que una sesión dejó sin enviar, tal como están guardados en disco.</summary>
    public class PendingBatch
    {
        [JsonProperty("sessionId")]
        public string SessionId { get; set; }

        [JsonProperty("events")]
        public List<ScoreEvent> Events { get; set; } = new();
    }

    /// <summary>
    /// Cola en disco de los score events que el API no recibió (red caída, visor apagado, aplicación cerrada).
    /// Un fichero por sesión, <c>pending-&lt;sessionId&gt;.json</c>, en una carpeta que se inyecta (por defecto
    /// <c>persistentDataPath/Telemetry/pending</c>). Clase pura sobre esa carpeta: no depende de la escena ni del
    /// bridge, y serializa con Newtonsoft y la configuración por defecto, igual que <see cref="ApiClient"/>.
    /// Un fallo de disco se avisa con LogWarning y nunca se lanza: la telemetría no puede tumbar la experiencia.
    /// </summary>
    public class PendingEventStore
    {
        private const string FilePrefix = "pending-";
        private const string FileExtension = ".json";

        private readonly string _folder;

        public PendingEventStore(string folder = null)
        {
            _folder = string.IsNullOrEmpty(folder)
                ? Path.Combine(Application.persistentDataPath, "Telemetry", "pending")
                : folder;
        }

        public string Folder => _folder;

        /// <summary>
        /// Guarda los eventos pendientes de una sesión (reemplaza lo que hubiera). Con la lista vacía o null borra
        /// el fichero de esa sesión si existe.
        /// </summary>
        public void Save(string sessionId, IReadOnlyList<ScoreEvent> events)
        {
            if (string.IsNullOrEmpty(sessionId)) return;

            try
            {
                if (events == null || events.Count == 0)
                {
                    Remove(sessionId);
                    return;
                }

                Directory.CreateDirectory(_folder);
                var batch = new PendingBatch { SessionId = sessionId, Events = new List<ScoreEvent>(events) };
                var json = JsonConvert.SerializeObject(batch);

                // Se escribe a un temporal y se mueve: un corte a mitad (el visor se apaga) no deja un JSON a medias.
                var path = PathFor(sessionId);
                var temp = path + ".tmp";
                File.WriteAllText(temp, json, new UTF8Encoding(false));
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[PendingEventStore] No se pudo guardar la cola de la sesión '{sessionId}': {ex.Message}");
            }
        }

        /// <summary>
        /// Todos los lotes guardados, en orden de nombre de fichero. Un fichero que no se puede leer se salta con
        /// aviso y no se borra.
        /// </summary>
        public IReadOnlyList<PendingBatch> LoadAll()
        {
            var result = new List<PendingBatch>();
            if (!Directory.Exists(_folder)) return result;

            string[] files;
            try
            {
                files = Directory.GetFiles(_folder, FilePrefix + "*" + FileExtension);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[PendingEventStore] No se pudo listar '{_folder}': {ex.Message}");
                return result;
            }

            Array.Sort(files, StringComparer.Ordinal);
            foreach (var file in files)
            {
                try
                {
                    var batch = JsonConvert.DeserializeObject<PendingBatch>(File.ReadAllText(file, Encoding.UTF8));
                    if (batch == null || string.IsNullOrEmpty(batch.SessionId))
                    {
                        Debug.LogWarning($"[PendingEventStore] '{Path.GetFileName(file)}' no trae sessionId: se salta.");
                        continue;
                    }

                    batch.Events ??= new List<ScoreEvent>();
                    batch.Events.RemoveAll(e => e == null);
                    result.Add(batch);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[PendingEventStore] '{Path.GetFileName(file)}' no se puede leer y se salta: {ex.Message}");
                }
            }

            return result;
        }

        /// <summary>Borra el lote de esa sesión; si no existe, no hace nada.</summary>
        public void Remove(string sessionId)
        {
            if (string.IsNullOrEmpty(sessionId)) return;

            try
            {
                var path = PathFor(sessionId);
                if (File.Exists(path)) File.Delete(path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[PendingEventStore] No se pudo borrar la cola de la sesión '{sessionId}': {ex.Message}");
            }
        }

        private string PathFor(string sessionId) =>
            Path.Combine(_folder, FilePrefix + Sanitize(sessionId) + FileExtension);

        /// <summary>Deja solo [A-Za-z0-9_-]; lo demás pasa a '_' (el id viaja entero dentro del JSON).</summary>
        private static string Sanitize(string sessionId)
        {
            var sb = new StringBuilder(sessionId.Length);
            foreach (var c in sessionId)
            {
                bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
                sb.Append(ok ? c : '_');
            }
            return sb.ToString();
        }
    }
}
