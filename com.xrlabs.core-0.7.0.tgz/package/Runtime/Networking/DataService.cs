using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using XRLabs.Networking.Models;
using UnityEngine;

namespace XRLabs.Networking
{
    public class DataService : MonoBehaviour
    {
        public static DataService Instance { get; private set; }

        public event Action<List<UserGroupResponse>> OnGroupsLoaded;
        public event Action<List<ExperienceListItem>> OnExperiencesLoaded;

        private List<UserGroupResponse> _cachedGroups;
        private Dictionary<string, List<ExperienceListItem>> _cachedExperiences = new();

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        /// <summary>
        /// Obtiene los grupos del usuario enriquecidos con datos de grupo y curso.
        /// Llama /user-groups, luego /groups/{id} y /courses/{id} por cada entrada.
        /// </summary>
        public async UniTask<ApiResponse<List<UserGroupResponse>>> FetchUserGroups(string userId, bool forceRefresh = false)
        {
            if (!forceRefresh && _cachedGroups != null)
            {
                OnGroupsLoaded?.Invoke(_cachedGroups);
                return ApiResponse<List<UserGroupResponse>>.Ok(_cachedGroups);
            }

            var membershipsResult = await ApiClient.Instance.GetAsync<PaginatedWrapper<UserGroupMembership>>(
                $"/user-groups?userId={Escape(userId)}&pageSize=50");

            if (!membershipsResult.Success)
                return ApiResponse<List<UserGroupResponse>>.Fail(membershipsResult.StatusCode, membershipsResult.ErrorMessage);

            var memberships = membershipsResult.Data?.Data ?? new List<UserGroupMembership>();
            var enriched = new List<UserGroupResponse>();

            foreach (var membership in memberships)
            {
                if (!IsActive(membership) || string.IsNullOrEmpty(membership.GroupId)) continue;

                var groupResult = await ApiClient.Instance.GetAsync<GroupApiResponse>($"/groups/{Escape(membership.GroupId)}");
                if (!groupResult.Success || groupResult.Data == null) continue;

                var group = groupResult.Data;

                CourseData course = null;
                if (!string.IsNullOrEmpty(group.CourseId))
                {
                    var courseResult = await ApiClient.Instance.GetAsync<CourseData>($"/courses/{Escape(group.CourseId)}");
                    if (courseResult.Success)
                        course = courseResult.Data;
                }

                var groupExpsResult = await ApiClient.Instance.GetAsync<PaginatedWrapper<GroupExperienceData>>(
                    $"/group-experiences?groupId={Escape(membership.GroupId)}&userId={Escape(userId)}&pageSize=50");

                int expCount = 0;
                int completedCount = 0;
                if (groupExpsResult.Success && groupExpsResult.Data?.Data != null)
                {
                    expCount = groupExpsResult.Data.Data.Count;
                    foreach (var exp in groupExpsResult.Data.Data)
                        if (exp.IsCompleted) completedCount++;
                }

                enriched.Add(new UserGroupResponse
                {
                    Group = ToGroupData(group),
                    Course = course,
                    RoleInGroup = membership.RoleInGroup,
                    Status = membership.Status,
                    JoinedAt = membership.JoinedAt,
                    ExperienceCount = expCount,
                    CompletedCount = completedCount
                });
            }

            _cachedGroups = enriched;
            OnGroupsLoaded?.Invoke(_cachedGroups);
            return ApiResponse<List<UserGroupResponse>>.Ok(_cachedGroups);
        }

        /// <summary>
        /// Obtiene las experiencias de un grupo combinando progreso del usuario con detalles de la experiencia.
        /// Llama /group-experiences, luego /experiences/{id} por cada entrada.
        /// </summary>
        public async UniTask<ApiResponse<List<ExperienceListItem>>> FetchGroupExperiences(
            string groupId, string userId, bool forceRefresh = false)
        {
            if (string.IsNullOrEmpty(groupId))
                return ApiResponse<List<ExperienceListItem>>.Fail(0, "El grupo no tiene id.");

            if (!forceRefresh && _cachedExperiences.TryGetValue(groupId, out var cached))
            {
                OnExperiencesLoaded?.Invoke(cached);
                return ApiResponse<List<ExperienceListItem>>.Ok(cached);
            }

            var progressResult = await ApiClient.Instance.GetAsync<PaginatedWrapper<GroupExperienceData>>(
                $"/group-experiences?groupId={Escape(groupId)}&userId={Escape(userId)}&pageSize=50");

            if (!progressResult.Success)
                return ApiResponse<List<ExperienceListItem>>.Fail(progressResult.StatusCode, progressResult.ErrorMessage);

            var progressList = progressResult.Data?.Data ?? new List<GroupExperienceData>();
            var items = new List<ExperienceListItem>();

            foreach (var progress in progressList)
            {
                if (string.IsNullOrEmpty(progress?.ExperienceId)) continue;

                var expResult = await ApiClient.Instance.GetAsync<ExperienceData>($"/experiences/{Escape(progress.ExperienceId)}");
                if (!expResult.Success || expResult.Data == null) continue;

                items.Add(new ExperienceListItem
                {
                    Experience = expResult.Data,
                    GroupExperience = progress
                });
            }

            _cachedExperiences[groupId] = items;
            OnExperiencesLoaded?.Invoke(items);
            return ApiResponse<List<ExperienceListItem>>.Ok(items);
        }

        /// <summary>Verifica la versión del bundle de una experiencia.</summary>
        public async UniTask<ApiResponse<AddressableInfo>> CheckAddressableVersion(string experienceId)
        {
            return await ApiClient.Instance.GetAsync<AddressableInfo>($"/experiences/{Escape(experienceId)}/addressable");
        }

        public void ClearCache()
        {
            _cachedGroups = null;
            _cachedExperiences.Clear();
        }

        /// <summary>Una membresía cuenta si está activa, sin distinguir mayúsculas.</summary>
        internal static bool IsActive(UserGroupMembership membership) =>
            membership != null && ApiStatus.Is(membership.Status, ApiStatus.Active);

        /// <summary>El grupo del API en el modelo del menú: estado "ACTIVE" (en cualquier caso) → true.</summary>
        internal static GroupData ToGroupData(GroupApiResponse group) => new GroupData
        {
            Id = group.Id,
            Name = group.Name,
            Code = group.Code,
            Status = ApiStatus.Is(group.Status, ApiStatus.Active),
            StartDate = group.StartDate,
            EndDate = group.EndDate
        };

        private static string Escape(string id) => Uri.EscapeDataString(id ?? "");

        // --- Formas del API real que solo usa este servicio (internas: los tests las leen con InternalsVisibleTo).
        //     GET /courses/{id} se lee en CourseData y GET /group-experiences en GroupExperienceData: mismos nombres JSON.

        internal class PaginatedWrapper<T>
        {
            [JsonProperty("data")]
            public List<T> Data { get; set; }
        }

        internal class UserGroupMembership
        {
            [JsonProperty("userId")]
            public string UserId { get; set; }

            [JsonProperty("groupId")]
            public string GroupId { get; set; }

            [JsonProperty("roleInGroup")]
            public string RoleInGroup { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }

            [JsonProperty("joinedAt")]
            public string JoinedAt { get; set; }
        }

        internal class GroupApiResponse
        {
            [JsonProperty("id")]
            public string Id { get; set; }

            [JsonProperty("orgId")]
            public string OrgId { get; set; }

            [JsonProperty("courseId")]
            public string CourseId { get; set; }

            [JsonProperty("name")]
            public string Name { get; set; }

            [JsonProperty("code")]
            public string Code { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }

            [JsonProperty("startDate")]
            public string StartDate { get; set; }

            [JsonProperty("endDate")]
            public string EndDate { get; set; }
        }
    }
}
