using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using XRLabs.Networking.Models;
using UnityEngine;
using Random = UnityEngine.Random;

namespace XRLabs.Networking.Mock
{
    /// <summary>
    /// Reemplaza ApiClient en modo desarrollo. Se activa con ApiSettings.useMockData.
    /// Simula delays de red y retorna datos de demostración con la forma del backend: ids de texto y estados en
    /// MAYÚSCULAS. ApiTelemetryBridge le manda la telemetría de la experiencia cuando el mock está encendido y también
    /// cuando no hay ApiClient (escena abierta sin pasar por el Menu); nunca toca la red.
    /// </summary>
    public static class MockApiClient
    {
        // Ids de demostración con forma de cuid (25 caracteres), como los del backend. La experiencia es la excepción:
        // sigue siendo "10" para que un ExperienceSceneMap de v0.5.1 (experienceId: 10) la resuelva en modo mock sin
        // tocar el asset (D8; lo vigila un test).
        public const string DemoUserId = "cmockuser0000000000000001";
        public const string DemoOrganizationId = "cmockorg00000000000000001";
        public const string DemoRoleId = "cmockrole0000000000000001";
        public const string DemoGroupId = "cmockgroup000000000000001";
        public const string DemoCourseId = "cmockcourse00000000000001";
        public const string DemoSpecialtyId = "cmockspec0000000000000001";
        public const string DemoDepartmentId = "cmockdept0000000000000001";
        public const string DemoExperienceId = "10";

        /// <summary>
        /// Experiencias que el anfitrión añade al menú mock, además de la de demostración (en el paquete, las de su
        /// ExperienceSceneMap: <c>XRLabs.UI.MockExperienceCatalog</c>). Null o vacío = el menú de siempre (D8). Van
        /// antes que la de demostración, y una con el mismo id que ella la reemplaza; ningún id se repite.
        /// </summary>
        public static Func<IEnumerable<ExperienceData>> ExtraExperiencesProvider;

        private const float MinDelay = 0.5f;
        private const float MaxDelay = 1.5f;
        private const float ErrorChance = 0.0f; // 0 en desarrollo normal; subir a 0.1 para probar errores

        public static async UniTask<ApiResponse<LoginResponse>> Login(string pin, CancellationToken ct = default)
        {
            await SimulateDelay(ct);

            if (pin != "123456" && pin != "482916")
                return ApiResponse<LoginResponse>.Fail(401, "PIN inválido o expirado");

            if (ShouldSimulateError())
                return ApiResponse<LoginResponse>.Fail(500, "Error interno del servidor (simulado)");

            return ApiResponse<LoginResponse>.Ok(new LoginResponse
            {
                AccessToken = "mock_access_token_" + Guid.NewGuid().ToString("N")[..8],
                RefreshToken = "mock_refresh_token_" + Guid.NewGuid().ToString("N")[..8],
                User = MockUser()
            });
        }

        public static async UniTask<ApiResponse<List<UserGroupResponse>>> GetUserGroups(
            string userId, CancellationToken ct = default)
        {
            await SimulateDelay(ct);
            if (ShouldSimulateError()) return SimulatedServerError<List<UserGroupResponse>>();

            return ApiResponse<List<UserGroupResponse>>.Ok(new List<UserGroupResponse>
            {
                new UserGroupResponse
                {
                    Group = new GroupData
                    {
                        Id = DemoGroupId,
                        Name = "Perforación A-2025",
                        Code = "GRP-PERF-A25",
                        Status = true,
                        StartDate = "2025-03-01",
                        EndDate = "2025-12-31"
                    },
                    RoleInGroup = "MEMBER",
                    Status = ApiStatus.Active,
                    JoinedAt = "2025-03-01T08:00:00Z",
                    Course = new CourseData
                    {
                        Id = DemoCourseId,
                        Name = "Análisis de Fallas en Herramientas de Perforación",
                        Description = "Identificación y prevención de fallas en brocas, barras y shanks",
                        Status = true
                    },
                    Specialty = new SpecialtyData { Id = DemoSpecialtyId, Name = "Perforación", Code = "PERF" },
                    Department = new DepartmentData { Id = DemoDepartmentId, Name = "Minería" },
                    ExperienceCount = BuildGroupExperiences(DemoGroupId).Count,
                    CompletedCount = 0
                }
                // Grupos adicionales comentados — descomentar para probar UI con múltiples grupos
                /*
                ,new UserGroupResponse
                {
                    Group = new GroupData
                    {
                        Id = "cmockgroup000000000000002",
                        Name = "Mantenimiento B-2025",
                        Code = "GRP-MANT-B25",
                        Status = true,
                        StartDate = "2025-03-01",
                        EndDate = "2025-12-31"
                    },
                    RoleInGroup = "MEMBER",
                    Status = ApiStatus.Active,
                    JoinedAt = "2025-03-01T08:00:00Z",
                    Course = new CourseData
                    {
                        Id = "cmockcourse00000000000002",
                        Name = "Inspección de Brocas de Botones",
                        Description = "Reconocimiento visual de componentes, desgaste y criterios de inspección",
                        Status = true
                    },
                    Specialty = new SpecialtyData { Id = "cmockspec0000000000000002", Name = "Mantenimiento", Code = "MANT" },
                    Department = new DepartmentData { Id = DemoDepartmentId, Name = "Minería" },
                    ExperienceCount = 3,
                    CompletedCount = 0
                },
                new UserGroupResponse
                {
                    Group = new GroupData
                    {
                        Id = "cmockgroup000000000000003",
                        Name = "Seguridad C-2025",
                        Code = "GRP-SEG-C25",
                        Status = true,
                        StartDate = "2025-03-01",
                        EndDate = "2025-12-31"
                    },
                    RoleInGroup = "MEMBER",
                    Status = ApiStatus.Active,
                    JoinedAt = "2025-03-01T08:00:00Z",
                    Course = new CourseData
                    {
                        Id = "cmockcourse00000000000003",
                        Name = "Seguridad Operacional en Perforación",
                        Description = "Buenas prácticas para operación segura durante perforación minera",
                        Status = true
                    },
                    Specialty = new SpecialtyData { Id = "cmockspec0000000000000003", Name = "Seguridad Minera", Code = "SEG" },
                    Department = new DepartmentData { Id = DemoDepartmentId, Name = "Minería" },
                    ExperienceCount = 4,
                    CompletedCount = 2
                },
                new UserGroupResponse
                {
                    Group = new GroupData
                    {
                        Id = "cmockgroup000000000000004",
                        Name = "Mecánica D-2025",
                        Code = "GRP-MEC-D25",
                        Status = true,
                        StartDate = "2025-03-01",
                        EndDate = "2025-12-31"
                    },
                    RoleInGroup = "MEMBER",
                    Status = ApiStatus.Active,
                    JoinedAt = "2025-03-01T08:00:00Z",
                    Course = new CourseData
                    {
                        Id = "cmockcourse00000000000004",
                        Name = "Reconocimiento de Fallas Mecánicas",
                        Description = "Identificación de patrones de daño en herramientas y componentes mecánicos",
                        Status = true
                    },
                    Specialty = new SpecialtyData { Id = "cmockspec0000000000000004", Name = "Mecánica", Code = "MEC" },
                    Department = new DepartmentData { Id = DemoDepartmentId, Name = "Minería" },
                    ExperienceCount = 4,
                    CompletedCount = 0
                },
                new UserGroupResponse
                {
                    Group = new GroupData
                    {
                        Id = "cmockgroup000000000000005",
                        Name = "Operación E-2025",
                        Code = "GRP-OP-E25",
                        Status = true,
                        StartDate = "2025-03-01",
                        EndDate = "2025-12-31"
                    },
                    RoleInGroup = "MEMBER",
                    Status = ApiStatus.Active,
                    JoinedAt = "2025-03-01T08:00:00Z",
                    Course = new CourseData
                    {
                        Id = "cmockcourse00000000000005",
                        Name = "Procedimientos de Extracción de Brocas",
                        Description = "Procedimientos seguros para desacople, extracción y revisión posterior",
                        Status = true
                    },
                    Specialty = new SpecialtyData { Id = "cmockspec0000000000000005", Name = "Operación Mina", Code = "OPM" },
                    Department = new DepartmentData { Id = DemoDepartmentId, Name = "Minería" },
                    ExperienceCount = 5,
                    CompletedCount = 3
                }
                */
            });
        }

        public static async UniTask<ApiResponse<List<ExperienceListItem>>> GetGroupExperiences(
            string groupId, string userId, CancellationToken ct = default)
        {
            await SimulateDelay(ct);
            if (ShouldSimulateError()) return SimulatedServerError<List<ExperienceListItem>>();

            return ApiResponse<List<ExperienceListItem>>.Ok(BuildGroupExperiences(groupId));
        }

        /// <summary>
        /// Las experiencias del grupo en modo mock. Si el anfitrión ofrece las suyas
        /// (<see cref="ExtraExperiencesProvider"/>, las de su ExperienceSceneMap), van primero, en el orden en que las
        /// entrega el proveedor y como pendientes del grupo, y la de demostración va después; si comparten id, la
        /// del anfitrión reemplaza a la de demostración (nombre, descripción y escena del mapa), y ningún id sale dos
        /// veces. Así lo primero que ve quien prueba en un visor es la experiencia más nueva del anfitrión, no la de
        /// demostración (que es la de teclado). Sin experiencias del anfitrión, la de demostración sola (D8).
        /// </summary>
        public static List<ExperienceListItem> BuildGroupExperiences(string groupId)
        {
            var demo = DemoGroupExperiences(groupId);
            var extras = ExtraExperiencesProvider?.Invoke();
            if (extras == null) return demo;

            var items = new List<ExperienceListItem>();
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var experience in extras)
            {
                if (experience == null || string.IsNullOrEmpty(experience.Id) || !ids.Add(experience.Id)) continue;
                items.Add(new ExperienceListItem
                {
                    Experience = experience,
                    GroupExperience = new GroupExperienceData
                    {
                        GroupId = groupId, ExperienceId = experience.Id, Mandatory = false,
                        Status = ApiStatus.Pending, Attempts = 0
                    }
                });
            }
            if (items.Count == 0) return demo;

            foreach (var item in demo)
                if (!ids.Contains(item.Experience.Id)) items.Add(item);
            return items;
        }

        private static List<ExperienceListItem> DemoGroupExperiences(string groupId)
        {
            return new List<ExperienceListItem>
            {
                new ExperienceListItem
                {
                    Experience = new ExperienceData
                    {
                        Id = DemoExperienceId, Name = "Fallas en Brocas de Perforación",
                        Description = "Identificación de rajadura en borde, rotura anular y botones agrietados",
                        Type = "VR", Duration = 900, Score = 70f,
                        Status = ApiStatus.Available, Attempts = 3, Order = 1,
                        AvgScore = null, DifficultyRating = 0.32f
                    },
                    GroupExperience = new GroupExperienceData
                    {
                        GroupId = groupId, ExperienceId = DemoExperienceId, Mandatory = true,
                        Status = ApiStatus.Pending, FinalScore = null, Attempts = 0
                    },
                    Addressable = new AddressableInfo
                    {
                        BundleUrl = "mock://addressables/exp-10/v1.2/",
                        Version = "1.2", SizeMb = 245,
                        CatalogUrl = "mock://addressables/exp-10/v1.2/catalog.json"
                    }
                }
                // Experiencias adicionales comentadas — descomentar para probar UI con múltiples experiencias
                /*
                ,new ExperienceListItem
                {
                    Experience = new ExperienceData
                    {
                        Id = "11", Name = "Fallas en Barras de Perforación",
                        Description = "Fatiga superficial y picadura en roscas",
                        Type = "VR", Duration = 720, Score = 70f,
                        Status = ApiStatus.Available, Attempts = 3, Order = 2
                    },
                    GroupExperience = new GroupExperienceData
                    {
                        GroupId = groupId, ExperienceId = "11", Mandatory = true,
                        Status = ApiStatus.Pending, Attempts = 0
                    },
                    Addressable = new AddressableInfo
                    {
                        BundleUrl = "mock://addressables/exp-11/v1.0/",
                        Version = "1.0", SizeMb = 198,
                        CatalogUrl = "mock://addressables/exp-11/v1.0/catalog.json"
                    }
                },
                new ExperienceListItem
                {
                    Experience = new ExperienceData
                    {
                        Id = "12", Name = "Fallas en Shanks",
                        Description = "Identificación de desgaste y roturas en shanks",
                        Type = "VR", Duration = 660, Score = 70f,
                        Status = ApiStatus.Available, Attempts = 3, Order = 3
                    },
                    GroupExperience = new GroupExperienceData
                    {
                        GroupId = groupId, ExperienceId = "12", Mandatory = false,
                        Status = ApiStatus.Pending, Attempts = 0
                    },
                    Addressable = new AddressableInfo
                    {
                        BundleUrl = "mock://addressables/exp-12/v1.0/",
                        Version = "1.0", SizeMb = 210,
                        CatalogUrl = "mock://addressables/exp-12/v1.0/catalog.json"
                    }
                }
                */
            };
        }

        // ── Telemetría: lo que ApiTelemetryBridge manda en modo mock ─────────

        /// <summary>
        /// Una llamada de telemetría que recibió el mock: el método y la ruta que habría usado el API real, y el cuerpo
        /// tal como lo armó el bridge (<see cref="SessionStartRequest"/>, <see cref="ScoreEvent"/>,
        /// <see cref="SessionCompleteRequest"/> o <see cref="ActivityEvent"/>).
        /// </summary>
        public readonly struct TelemetryCall
        {
            public readonly string Method;
            public readonly string Path;
            public readonly object Body;

            public TelemetryCall(string method, string path, object body)
            {
                Method = method;
                Path = path;
                Body = body;
            }

            public override string ToString() => Method + " " + Path;
        }

        /// <summary>
        /// Se dispara con cada llamada de telemetría que recibe el mock (inicio y cierre de sesión, score events y
        /// activity log), en cuanto llega y antes de la demora simulada. Nadie lo escucha en producción: es lo que
        /// miran los tests para afirmar que el flujo de la experiencia llegó al cliente del API (2026-10-25).
        /// </summary>
        public static event Action<TelemetryCall> TelemetryReceived;

        private static void Receive(string method, string path, object body) =>
            TelemetryReceived?.Invoke(new TelemetryCall(method, path, body));

        /// <summary>
        /// Abre una sesión simulada. <paramref name="request"/> es el cuerpo que el bridge habría mandado al API; sin él
        /// se registra uno con solo el grupo.
        /// </summary>
        public static async UniTask<ApiResponse<SessionStartResponse>> StartSession(
            string experienceId, string groupId, CancellationToken ct = default, SessionStartRequest request = null)
        {
            Receive("POST", $"/experiences/{Uri.EscapeDataString(experienceId ?? string.Empty)}/sessions",
                request ?? new SessionStartRequest { GroupId = groupId });
            await SimulateDelay(ct);
            if (ShouldSimulateError()) return SimulatedServerError<SessionStartResponse>();

            return ApiResponse<SessionStartResponse>.Ok(new SessionStartResponse
            {
                SessionId = "cmocksess" + Guid.NewGuid().ToString("N")[..16],
                StartedAt = DateTime.UtcNow.ToString("o"),
                ExperienceId = experienceId,
                AttemptNumber = 1
            }, 201);
        }

        public static async UniTask<ApiResponse<object>> SendScoreEvent(
            ScoreEvent scoreEvent, CancellationToken ct = default)
        {
            Receive("POST", "/score-events", scoreEvent);
            await SimulateDelay(ct);
            Debug.Log($"[Mock] Score event '{scoreEvent?.EventId}' enviado (sesión {scoreEvent?.SessionId})");
            return ApiResponse<object>.Ok(new { received = 1 }, 201);
        }

        /// <summary>
        /// Cierra la sesión simulada. Como el backend (learning-service, <c>xr-sessions.service.ts</c>), el mock no calcula
        /// el puntaje: guarda el <c>finalScore</c> que manda el cliente, que sale del <c>ScoringSystem</c> de la escena
        /// (telemetria-extremo-a-extremo.md, actualización del 2026-10-25, tarde).
        /// </summary>
        public static async UniTask<ApiResponse<object>> CompleteSession(
            string sessionId, SessionCompleteRequest request, CancellationToken ct = default)
        {
            Receive("PATCH", $"/sessions/{Uri.EscapeDataString(sessionId ?? string.Empty)}/complete", request);
            await SimulateDelay(ct);
            Debug.Log($"[Mock] Sesión {sessionId} completada. Score: {request?.FinalScore}, errores: {request?.ErrorCount}");
            return ApiResponse<object>.Ok(new { sessionId, status = ApiStatus.Completed });
        }

        /// <summary>
        /// El activity log (POST /activity-log): inicio y cierre de la experiencia, errores y avisos de los pasos, pistas.
        /// El registro muestra la metadata (en un step_error, el paso y la clave del error), que es lo que se lee en el logcat.
        /// </summary>
        public static async UniTask<ApiResponse<object>> LogActivity(
            ActivityEvent activityEvent, CancellationToken ct = default)
        {
            Receive("POST", "/activity-log", activityEvent);
            await SimulateDelay(ct);
            string metadata = activityEvent?.Metadata != null ? " " + JsonConvert.SerializeObject(activityEvent.Metadata) : string.Empty;
            Debug.Log($"[Mock] Activity log '{activityEvent?.Action}' recibido (entidad {activityEvent?.Entity} {activityEvent?.EntityId}){metadata}");
            return ApiResponse<object>.Ok(new { received = 1 }, 201);
        }

        // --- Helpers ---

        private static UserData MockUser() => new UserData
        {
            Id = DemoUserId,
            FirstName = "Carlos",
            LastName = "Mendoza",
            Username = "cmendoza",
            Role = new RoleData { Id = DemoRoleId, Code = "student", Name = "Estudiante" },
            Organization = new OrganizationData
            {
                Id = DemoOrganizationId, Name = "XRLabs Demo", Slug = "xrlabs-demo",
                Logo = ""
            },
            PreferredLanguage = "es"
        };

        private static async UniTask SimulateDelay(CancellationToken ct)
        {
            float delay = Random.Range(MinDelay, MaxDelay);
            await UniTask.Delay(TimeSpan.FromSeconds(delay), cancellationToken: ct);
        }

        private static bool ShouldSimulateError()
        {
            return ErrorChance > 0 && Random.value < ErrorChance;
        }

        private static ApiResponse<T> SimulatedServerError<T>()
        {
            return ApiResponse<T>.Fail(500, "Error interno del servidor (simulado)");
        }
    }
}
