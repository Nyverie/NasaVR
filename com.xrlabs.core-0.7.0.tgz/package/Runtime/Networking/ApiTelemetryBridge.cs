using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using XRLabs.Networking.Mock;
using XRLabs.Networking.Models;
using UnityEngine;

namespace XRLabs.Networking
{
    /// <summary>
    /// Puente entre la telemetría del framework y el API REST.
    /// Endpoints verificados contra el OpenAPI del backend (2026-07):
    /// POST /experiences/{id}/sessions, POST /score-events (individual),
    /// PATCH /sessions/{id}/complete, POST /activity-log.
    /// Registra un ApiTelemetryChannel en el TelemetryHub al despertar.
    /// <para>
    /// 2026-10-25: el transporte lo decide el bridge. Con un ApiClient cuyo ApiSettings tiene <c>useMockData</c>
    /// apagado, todo va al API real; con el mock encendido, o sin ApiClient (la escena preparada abierta en el Editor
    /// sin pasar por el Menu), todo va a <see cref="MockApiClient"/> y nunca a la red: así la sesión, los errores de los
    /// pasos y el cierre recorren el mismo camino en pantalla que en el visor, sin excepciones y sin apuntar a ningún
    /// servidor. Lo que una sesión mock deja pendiente no se guarda en disco ni se reenvía la cola de las reales.
    /// </para>
    /// <para>
    /// Va solo en un objeto raíz (lo pone «Preparar escena» en <c>[ApiTelemetry]</c>): Awake hace DontDestroyOnLoad de
    /// su objeto y, si ya hay un bridge vivo, destruye su objeto entero.
    /// </para>
    /// </summary>
    public class ApiTelemetryBridge : MonoBehaviour
    {
        public static ApiTelemetryBridge Instance { get; private set; }

        [Tooltip("Encendido, los score events que no llegaron al API se guardan en disco (al fallar un envío, al pausar y al cerrar la aplicación) y se reenvían al abrir la próxima sesión. Apagado, la cola vive solo en memoria, como antes.")]
        [SerializeField] private bool persistPendingEvents = true;

        public string SessionId => _sessionId;
        public string ExperienceId => _experienceId;
        public string GroupId => _groupId;
        public bool SessionActive => _sessionActive;
        /// <summary>Verdadero si la sesión en curso (o la última) se abrió en el mock y no en el API real.</summary>
        public bool SessionIsMock => _sessionIsMock;

        /// <summary>
        /// Si la telemetría va hoy al mock: no hay ApiClient (escena abierta sin el Menu), no tiene ApiSettings, o el
        /// ApiSettings tiene <c>useMockData</c> encendido. Solo con un ApiClient configurado y el mock apagado se usa la red.
        /// </summary>
        public static bool UsesMock
        {
            get
            {
                var client = ApiClient.Instance;
                return client == null || client.Settings == null || client.Settings.useMockData;
            }
        }

        // El de ApiSettings por defecto: el flush periódico lo usa si no hay ApiClient del que leerlo.
        private const float DefaultFlushIntervalSeconds = 30f;

        private string _sessionId;
        private string _experienceId;
        private string _groupId;

        private readonly List<ScoreEvent> _pendingEvents = new();
        private CancellationTokenSource _flushCts;
        private bool _sessionActive;
        private bool _sessionIsMock;
        private bool _noClientNoticeShown;
        private ApiTelemetryChannel _channel;
        private PendingEventStore _store;
        private bool _resending;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            if (persistPendingEvents)
                _store = new PendingEventStore();

            _channel = new ApiTelemetryChannel(this);
            XRLabs.Core.Telemetry.TelemetryHub.Register(_channel);
        }

        private void OnDestroy()
        {
            _flushCts?.Cancel();
            _flushCts?.Dispose();
            if (_channel != null)
                XRLabs.Core.Telemetry.TelemetryHub.Unregister(_channel);
            if (Instance == this) Instance = null;
        }

        private void OnApplicationPause(bool paused)
        {
            // En el visor, quitárselo es lo habitual antes de que el sistema cierre la aplicación sin avisar.
            if (paused) PersistPending();
        }

        private void OnApplicationQuit()
        {
            PersistPending();
        }

        /// <summary>Registra el inicio de sesión en el API y activa el flush periódico. Ids de texto (cuid).</summary>
        public async UniTask<bool> StartSession(string experienceId, string groupId, string devicePlatform = "quest3")
        {
            _experienceId = experienceId;
            _groupId = groupId;
            // Lo que la sesión anterior dejó sin enviar pasa a disco antes de vaciar la cola: se reenvía abajo.
            if (_pendingEvents.Count > 0) PersistPending();
            _pendingEvents.Clear();
            _sessionActive = false;
            _sessionId = null;

            if (string.IsNullOrEmpty(experienceId))
            {
                Debug.LogWarning("[ApiTelemetry] StartSession sin experienceId: no se inicia la sesión API.");
                return false;
            }

            _sessionIsMock = UsesMock;
            NoticeIfNoClient();

            var request = new SessionStartRequest
            {
                GroupId = groupId,
                DeviceType = "vr_headset",
                Platform = devicePlatform,
                IpAddress = _sessionIsMock ? "0.0.0.0" : GetLocalIpAddress()
            };

            var response = _sessionIsMock
                ? await MockApiClient.StartSession(experienceId, groupId, destroyCancellationToken, request)
                : await ApiClient.Instance.PostAsync<SessionStartResponse>(
                    $"/experiences/{Uri.EscapeDataString(experienceId)}/sessions", request);

            if (!response.Success || response.Data == null)
            {
                Debug.LogWarning($"[ApiTelemetry] No se pudo iniciar sesión API{(_sessionIsMock ? " (mock)" : "")}: {response.ErrorMessage}");
                return false;
            }

            _sessionId = response.Data.SessionId;
            _sessionActive = true;
            Debug.Log($"[ApiTelemetry] Sesión iniciada{(_sessionIsMock ? " en el mock" : "")}: {_sessionId}, intento #{response.Data.AttemptNumber}");

            StartPeriodicFlush();
            // La cola en disco es de sesiones del API real: una sesión mock no la reenvía (ni la vacía).
            if (!_sessionIsMock) ResendStoredBatchesSafely().Forget();
            return true;
        }

        // Una vez por bridge: sin ApiClient no se sabe de qué API hablar, así que todo va al mock.
        private void NoticeIfNoClient()
        {
            if (_noClientNoticeShown || ApiClient.Instance != null) return;
            _noClientNoticeShown = true;
            Debug.Log("[ApiTelemetry] No hay ApiClient (la escena se abrió sin pasar por el Menu): la telemetría va al mock, sin red.");
        }

        /// <summary>Encola un score event para el próximo flush. Completa groupId/experienceId/sessionId.</summary>
        public void EnqueueScoreEvent(ScoreEvent scoreEvent)
        {
            if (!_sessionActive || scoreEvent == null) return;

            scoreEvent.GroupId = _groupId;
            scoreEvent.ExperienceId = _experienceId;
            scoreEvent.SessionId = _sessionId;
            _pendingEvents.Add(scoreEvent);
        }

        /// <summary>
        /// Envía los eventos acumulados. El API solo acepta eventos individuales
        /// (POST /score-events), así que se envían en serie; los que fallan se re-encolan.
        /// </summary>
        public async UniTask FlushEvents()
        {
            if (!_sessionActive || string.IsNullOrEmpty(_sessionId) || _pendingEvents.Count == 0)
                return;

            var batch = new List<ScoreEvent>(_pendingEvents);
            _pendingEvents.Clear();

            int sent = 0;
            var ct = destroyCancellationToken;
            foreach (var evt in batch)
            {
                var response = _sessionIsMock
                    ? await MockApiClient.SendScoreEvent(evt, ct)
                    : await ApiClient.Instance.PostAsync<object>("/score-events", evt);
                if (response.Success)
                {
                    sent++;
                }
                else
                {
                    _pendingEvents.Add(evt);
                    Debug.LogWarning($"[ApiTelemetry] Score event '{evt.EventId}' falló: {response.ErrorMessage}");
                }
            }

            if (sent > 0)
                Debug.Log($"[ApiTelemetry] {sent}/{batch.Count} score events enviados.");

            // El disco refleja la cola: lo re-encolado se guarda, y si todo salió se borra el fichero de un fallo anterior.
            PersistPending();
        }

        /// <summary>
        /// Guarda en disco lo que sigue en la cola de la sesión actual. Nada sin sesión, con la opción apagada o en una
        /// sesión mock (su id no existe en ningún backend: reenviarla daría 404 para siempre).
        /// </summary>
        private void PersistPending()
        {
            if (_store == null || _sessionIsMock || string.IsNullOrEmpty(_sessionId)) return;
            _store.Save(_sessionId, _pendingEvents);
        }

        private async UniTaskVoid ResendStoredBatchesSafely()
        {
            try
            {
                await ResendStoredBatches();
            }
            catch (Exception ex)
            {
                // Un reenvío que falla nunca debe contar como error de la aplicación: lo guardado se reintenta en la próxima sesión.
                Debug.LogWarning($"[ApiTelemetry] El reenvío de eventos guardados falló: {ex.Message}");
            }
        }

        /// <summary>
        /// Reenvía los lotes que sesiones anteriores dejaron en disco, uno a uno por POST /score-events (cada evento ya
        /// lleva su sessionId, experienceId y groupId, no se tocan). Un lote se borra solo si todos sus eventos
        /// llegaron; si alguno falla, en disco quedan los que faltan.
        /// </summary>
        private async UniTask ResendStoredBatches()
        {
            if (_store == null || _resending) return;

            _resending = true;
            try
            {
                int resent = 0;
                foreach (var stored in _store.LoadAll())
                {
                    // El lote de la sesión en curso es la cola en memoria; no se reenvía por aquí.
                    if (stored.SessionId == _sessionId) continue;

                    var remaining = new List<ScoreEvent>();
                    foreach (var evt in stored.Events)
                    {
                        var response = await ApiClient.Instance.PostAsync<object>("/score-events", evt);
                        if (response.Success)
                        {
                            resent++;
                        }
                        else
                        {
                            remaining.Add(evt);
                            Debug.LogWarning($"[ApiTelemetry] Reenvío del score event '{evt.EventId}' (sesión {stored.SessionId}) falló: {response.ErrorMessage}");
                        }
                    }

                    if (remaining.Count == 0) _store.Remove(stored.SessionId);
                    else _store.Save(stored.SessionId, remaining);
                }

                if (resent > 0)
                    Debug.Log($"[ApiTelemetry] {resent} score events guardados de sesiones anteriores reenviados.");
            }
            finally
            {
                _resending = false;
            }
        }

        /// <summary>
        /// Finaliza la sesión con los resultados completos. Reintenta hasta 3 veces con backoff.
        /// </summary>
        public async UniTask<bool> CompleteSession(SessionCompleteRequest result)
        {
            if (!_sessionActive || string.IsNullOrEmpty(_sessionId))
                return false;

            // Flush final antes de completar
            await FlushEvents();

            _sessionActive = false;
            _flushCts?.Cancel();

            var ct = destroyCancellationToken;
            for (int attempt = 0; attempt < 3; attempt++)
            {
                var response = _sessionIsMock
                    ? await MockApiClient.CompleteSession(_sessionId, result, ct)
                    : await ApiClient.Instance.PatchAsync<object>(
                        $"/sessions/{Uri.EscapeDataString(_sessionId)}/complete", result);

                if (response.Success)
                {
                    Debug.Log($"[ApiTelemetry] Sesión completada: score={result.FinalScore}");
                    return true;
                }

                Debug.LogWarning($"[ApiTelemetry] CompleteSession intento {attempt + 1} falló: {response.ErrorMessage}");

                if (attempt < 2)
                    await UniTask.Delay(TimeSpan.FromSeconds(Mathf.Pow(2, attempt)));
            }

            Debug.LogError("[ApiTelemetry] No se pudo completar la sesión tras 3 intentos.");
            return false;
        }

        /// <summary>
        /// Envía un log de actividad (fire-and-forget). Rellena userId/orgId
        /// (requeridos por el API) desde el usuario autenticado si vienen vacíos. En modo mock, sin usuario autenticado
        /// (escena abierta sin el Menu), usa el usuario de demostración del mock.
        /// </summary>
        public void LogActivity(ActivityEvent activityEvent)
        {
            if (activityEvent == null) return;

            bool mock = UsesMock;
            var user = AuthManager.Instance != null ? AuthManager.Instance.CurrentUser : null;
            if (string.IsNullOrEmpty(activityEvent.UserId))
                activityEvent.UserId = user?.Id ?? (mock ? MockApiClient.DemoUserId : null);
            if (string.IsNullOrEmpty(activityEvent.OrgId))
                activityEvent.OrgId = user?.OrgId ?? (mock ? MockApiClient.DemoOrganizationId : null);

            if (string.IsNullOrEmpty(activityEvent.UserId))
            {
                Debug.LogWarning("[ApiTelemetry] ActivityEvent sin userId — descartado (requerido por el API).");
                return;
            }

            FireAndForgetActivity(activityEvent, mock, destroyCancellationToken).Forget();
        }

        private async UniTaskVoid FireAndForgetActivity(ActivityEvent activityEvent, bool mock, CancellationToken ct)
        {
            if (mock) await MockApiClient.LogActivity(activityEvent, ct);
            else await ApiClient.Instance.PostAsync<object>("/activity-log", activityEvent);
        }

        private void StartPeriodicFlush()
        {
            _flushCts?.Cancel();
            _flushCts = new CancellationTokenSource();
            PeriodicFlushLoop(_flushCts.Token).Forget();
        }

        private async UniTaskVoid PeriodicFlushLoop(CancellationToken ct)
        {
            // Sin ApiClient (escena abierta sin el Menu, sesión mock) se usa el intervalo por defecto de ApiSettings.
            var client = ApiClient.Instance;
            var interval = client != null && client.Settings != null ? client.Settings.eventFlushIntervalSeconds : DefaultFlushIntervalSeconds;
            if (interval <= 0f) interval = DefaultFlushIntervalSeconds;
            while (!ct.IsCancellationRequested && _sessionActive)
            {
                await UniTask.Delay(TimeSpan.FromSeconds(interval), cancellationToken: ct)
                    .SuppressCancellationThrow();

                if (!ct.IsCancellationRequested)
                    await FlushEvents();
            }
        }

        private static string GetLocalIpAddress()
        {
            try
            {
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var ip in host.AddressList)
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        return ip.ToString();
            }
            catch { }
            return "0.0.0.0";
        }
    }
}
