using UnityEngine;

namespace XRLabs.Networking
{
    [CreateAssetMenu(fileName = "ApiSettings", menuName = "XR Platform/API Settings")]
    public class ApiSettings : ScriptableObject
    {
        [Header("Server")]
        public string baseUrl = "https://api.xrlabs.local";

        [Header("Timeouts")]
        public float requestTimeoutSeconds = 15f;
        public float uploadTimeoutSeconds = 60f;

        [Header("Retry")]
        public int maxRetries = 3;
        public float retryBaseDelaySeconds = 1f;

        [Header("Telemetry")]
        public float eventFlushIntervalSeconds = 30f;
        public int maxEventsPerBatch = 50;

        [Header("Debug")]
        public bool logRequests = true;
        public bool useMockData = false;
    }
}
