using XRLabs.Core.Telemetry;
using XRLabs.Networking.Models;

namespace XRLabs.Networking
{
    /// <summary>
    /// Canal del TelemetryHub que enruta eventos del framework al API:
    /// - QuizAnswerEvent → score event (POST /score-events) con metadata rica
    /// - HintShownEvent / ExplorationEvent / StepSignalEvent → activity-log (señales de aprendizaje), con
    ///   entity "Step" y entityId = el id del paso del guion (p. ej. COMP-02); la metadata repite stepId y, en
    ///   step_error/step_warning, trae la clave del error (key).
    /// Solo actúa si hay una sesión API activa.
    /// </summary>
    public class ApiTelemetryChannel : ITelemetryChannel
    {
        private readonly ApiTelemetryBridge _bridge;

        public ApiTelemetryChannel(ApiTelemetryBridge bridge)
        {
            _bridge = bridge;
        }

        public void Emit(TelemetryEvent telemetryEvent)
        {
            if (_bridge == null || !_bridge.SessionActive) return;

            switch (telemetryEvent)
            {
                case QuizAnswerEvent quiz:
                    _bridge.EnqueueScoreEvent(new ScoreEvent
                    {
                        EventId = $"case{quiz.CaseNumber}_q{quiz.QuestionIndex + 1}{(quiz.IsCorrect ? "" : "_fail")}",
                        Label = $"Caso {quiz.CaseNumber} - Q{quiz.QuestionIndex + 1} ({quiz.QuestionType})",
                        ScoreDelta = quiz.ScoreDelta,
                        Metadata = new ScoreEventData
                        {
                            CaseNumber = quiz.CaseNumber,
                            QuestionType = quiz.QuestionType,
                            QuestionText = quiz.QuestionText,
                            Options = quiz.Options,
                            CorrectAnswer = quiz.CorrectAnswerIndex,
                            UserAnswer = quiz.UserAnswerIndex,
                            IsCorrect = quiz.IsCorrect,
                            AttemptsUsed = quiz.AttemptsUsed,
                            ResponseTimeSeconds = quiz.ResponseTimeSeconds
                        }
                    });
                    break;

                case HintShownEvent hint:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = "hint_shown",
                        Entity = "Step",
                        EntityId = hint.StepId,
                        Metadata = new { stepId = hint.StepId, hintDelaySeconds = hint.HintDelaySeconds }
                    });
                    break;

                case ExplorationEvent expl:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = "exploration_summary",
                        Entity = "Step",
                        EntityId = expl.StepId,
                        Metadata = new
                        {
                            stepId = expl.StepId,
                            rotationDegrees = expl.RotationDegrees,
                            explorationSeconds = expl.ExplorationSeconds
                        }
                    });
                    break;

                case StepSignalEvent signal:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = signal.Kind == "error" ? "step_error" : "step_warning",
                        Entity = "Step",
                        EntityId = signal.StepId,
                        // 0.3 lote 4 (contrato-0.3.md §2.5): en un 'elegir', metadata.opcion = el objeto tocado.
                        Metadata = string.IsNullOrEmpty(signal.Option)
                            ? new { stepId = signal.StepId, stepIndex = signal.StepIndex, key = signal.Key }
                            : (object)new { stepId = signal.StepId, stepIndex = signal.StepIndex, key = signal.Key, opcion = signal.Option }
                    });
                    break;

                // 0.3 lote 2 (contrato-0.3.md §2.1 y §2.3). `action` del activity log es texto libre (CreateActivityEventDto:
                // IsString, MaxLength 100), así que van con su nombre y no como step_warning.
                case StepSkippedEvent skipped:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = "step_skipped",
                        Entity = "Step",
                        EntityId = skipped.StepId,
                        Metadata = new { stepId = skipped.StepId, stepIndex = skipped.StepIndex, motivo = skipped.Reason }
                    });
                    break;

                // 0.3 lote 1 (contrato-0.3.md §2.1): cambio de una variable de estado con 'registrar'. 'action' es texto
                // libre en el API (CreateActivityLogDto.action: @IsString()), así que va como state_changed, no como
                // step_warning con metadata.tipo.
                case StateChangedEvent changed:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = "state_changed",
                        Entity = "Step",
                        EntityId = changed.StepId,
                        Metadata = new { stepId = changed.StepId, variable = changed.Variable, antes = changed.Before, valor = changed.Value }
                    });
                    break;

                case TimeAdvancedEvent advanced:
                    _bridge.LogActivity(new ActivityEvent
                    {
                        Action = "time_advanced",
                        Entity = "Step",
                        EntityId = advanced.StepId,
                        Metadata = new { stepId = advanced.StepId, dias = advanced.Days, dia = advanced.Day }
                    });
                    break;

                // StepCompletedEvent: por ahora solo local (25+ steps generarían
                // demasiados requests individuales). Ver BACKEND_WISHLIST.md.
            }
        }
    }
}
