using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class CaseResult
    {
        [JsonProperty("caseNumber")]
        public int CaseNumber { get; set; }

        [JsonProperty("failureName")]
        public string FailureName { get; set; }

        [JsonProperty("typeCorrect")]
        public bool TypeCorrect { get; set; }

        [JsonProperty("causeCorrect")]
        public bool CauseCorrect { get; set; }

        [JsonProperty("recommendationCorrect")]
        public bool RecommendationCorrect { get; set; }

        [JsonProperty("caseTimeSeconds")]
        public int CaseTimeSeconds { get; set; }
    }
}
