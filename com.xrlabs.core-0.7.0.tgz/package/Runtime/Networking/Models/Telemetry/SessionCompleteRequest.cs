using System.Collections.Generic;
using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class SessionCompleteRequest
    {
        [JsonProperty("finalScore")]
        public float FinalScore { get; set; }

        [JsonProperty("totalTimeSeconds")]
        public int TotalTimeSeconds { get; set; }

        [JsonProperty("totalCorrect")]
        public int TotalCorrect { get; set; }

        [JsonProperty("totalIncorrect")]
        public int TotalIncorrect { get; set; }

        [JsonProperty("totalQuestions")]
        public int TotalQuestions { get; set; }

        [JsonProperty("cases")]
        public List<CaseResult> Cases { get; set; }

        [JsonProperty("interactionsCount")]
        public int InteractionsCount { get; set; }

        [JsonProperty("pauseCount")]
        public int PauseCount { get; set; }

        [JsonProperty("errorCount")]
        public int ErrorCount { get; set; }

        [JsonProperty("rating")]
        public int Rating { get; set; }

        /// <summary>
        /// Por qué terminó la sesión ("completed", "abandoned"...). Opcional: con null no viaja en el JSON, y el
        /// cuerpo es idéntico al que el backend aceptó el 2026-10-09.
        /// </summary>
        [JsonProperty("endReason", NullValueHandling = NullValueHandling.Ignore)]
        public string EndReason { get; set; }
    }
}
