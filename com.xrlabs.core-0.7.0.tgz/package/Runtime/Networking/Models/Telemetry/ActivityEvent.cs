using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Log de actividad para POST /api/activity-log (CreateActivityLogDto del backend).
    /// userId y orgId los rellena ApiTelemetryBridge desde el usuario autenticado si vienen vacíos.
    /// Ids de texto: el backend acepta texto o número (0 o vacío = sin valor).
    /// </summary>
    public class ActivityEvent
    {
        [JsonProperty("userId")]
        public string UserId { get; set; }

        [JsonProperty("orgId")]
        public string OrgId { get; set; }

        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("entity")]
        public string Entity { get; set; }

        [JsonProperty("entityId")]
        public string EntityId { get; set; }

        [JsonProperty("metadata")]
        public object Metadata { get; set; }

        [JsonProperty("ipAddress")]
        public string IpAddress { get; set; }
    }
}
