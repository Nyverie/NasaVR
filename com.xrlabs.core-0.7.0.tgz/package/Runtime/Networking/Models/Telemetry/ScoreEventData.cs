using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Metadata rica de un score event de quiz. Viaja dentro del campo libre
    /// metadata de CreateScoreEventDto — camelCase para consistencia con el API.
    /// </summary>
    public class ScoreEventData
    {
        [JsonProperty("schemaVersion")]
        public string SchemaVersion { get; set; } = "1.0";

        [JsonProperty("caseNumber")]
        public int CaseNumber { get; set; }

        /// <summary>Valores: "failure_type", "cause", "recommendation".</summary>
        [JsonProperty("questionType")]
        public string QuestionType { get; set; }

        [JsonProperty("questionText")]
        public string QuestionText { get; set; }

        [JsonProperty("options")]
        public string[] Options { get; set; }

        [JsonProperty("correctAnswer")]
        public int CorrectAnswer { get; set; }

        [JsonProperty("userAnswer")]
        public int UserAnswer { get; set; }

        [JsonProperty("isCorrect")]
        public bool IsCorrect { get; set; }

        [JsonProperty("attemptsUsed")]
        public int AttemptsUsed { get; set; }

        [JsonProperty("responseTimeSeconds")]
        public float ResponseTimeSeconds { get; set; }
    }
}
