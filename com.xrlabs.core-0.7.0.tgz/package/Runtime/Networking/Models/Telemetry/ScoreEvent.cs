using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Score event individual para POST /api/score-events (CreateScoreEventDto del backend).
    /// El contexto rico de la pregunta viaja en metadata (campo libre del API).
    /// </summary>
    public class ScoreEvent
    {
        /// <summary>El backend lo ignora (la sesión ya fija grupo y experiencia); se envía por compatibilidad.</summary>
        [JsonProperty("groupId")]
        public string GroupId { get; set; }

        /// <summary>El backend lo ignora (la sesión ya fija grupo y experiencia); se envía por compatibilidad.</summary>
        [JsonProperty("experienceId")]
        public string ExperienceId { get; set; }

        [JsonProperty("sessionId")]
        public string SessionId { get; set; }

        [JsonProperty("eventId")]
        public string EventId { get; set; }

        [JsonProperty("label")]
        public string Label { get; set; }

        [JsonProperty("scoreDelta")]
        public float ScoreDelta { get; set; }

        [JsonProperty("metadata")]
        public ScoreEventData Metadata { get; set; }
    }
}
