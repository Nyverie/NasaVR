using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class SessionStartResponse
    {
        /// <summary>Id de texto (cuid) de la sesión. El backend responde estos cuatro campos en snake_case.</summary>
        [JsonProperty("session_id")]
        public string SessionId { get; set; }

        [JsonProperty("started_at")]
        public string StartedAt { get; set; }

        [JsonProperty("experience_id")]
        public string ExperienceId { get; set; }

        [JsonProperty("attempt_number")]
        public int AttemptNumber { get; set; }
    }
}
