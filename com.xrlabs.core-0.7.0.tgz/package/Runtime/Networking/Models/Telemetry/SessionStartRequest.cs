using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class SessionStartRequest
    {
        [JsonProperty("groupId")]
        public string GroupId { get; set; }

        [JsonProperty("deviceType")]
        public string DeviceType { get; set; }

        [JsonProperty("platform")]
        public string Platform { get; set; }

        [JsonProperty("ipAddress")]
        public string IpAddress { get; set; }
    }
}
