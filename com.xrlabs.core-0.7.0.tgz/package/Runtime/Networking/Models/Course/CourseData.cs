using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class CourseData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("image")]
        public string Image { get; set; }

        [JsonProperty("status")]
        public bool Status { get; set; }
    }
}
