using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class DepartmentData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
