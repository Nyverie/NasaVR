using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class SpecialtyData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("image")]
        public string Image { get; set; }
    }
}
