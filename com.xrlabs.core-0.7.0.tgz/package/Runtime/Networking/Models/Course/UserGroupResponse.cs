using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class UserGroupResponse
    {
        [JsonProperty("group")]
        public GroupData Group { get; set; }

        [JsonProperty("role_in_group")]
        public string RoleInGroup { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("joined_at")]
        public string JoinedAt { get; set; }

        [JsonProperty("course")]
        public CourseData Course { get; set; }

        [JsonProperty("specialty")]
        public SpecialtyData Specialty { get; set; }

        [JsonProperty("department")]
        public DepartmentData Department { get; set; }

        [JsonProperty("experience_count")]
        public int ExperienceCount { get; set; }

        [JsonProperty("completed_count")]
        public int CompletedCount { get; set; }
    }
}
