namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Identidad del usuario autenticado. Compatible con flujo real (XR PIN) y mock.
    /// </summary>
    public class AuthenticatedUser
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
        /// <summary>Id de texto de la organización (cuid); null si el backend no lo envió.</summary>
        public string OrgId { get; set; }
        /// <summary>Id de texto del rol (cuid); null si el backend no lo envió.</summary>
        public string RoleId { get; set; }
    }
}
