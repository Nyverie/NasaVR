using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class RefreshRequest
    {
        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }
    }
}
