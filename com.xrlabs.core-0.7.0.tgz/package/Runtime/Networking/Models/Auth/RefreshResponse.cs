using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class RefreshResponse
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }
    }
}
