using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class ValidatePinRequest
    {
        [JsonProperty("pin")]
        public string Pin { get; set; }

        [JsonProperty("deviceId", NullValueHandling = NullValueHandling.Ignore)]
        public string DeviceId { get; set; }
    }

    public class XrTokenResponse
    {
        [JsonProperty("token")]
        public string Token { get; set; }

        [JsonProperty("expiresAt")]
        public string ExpiresAt { get; set; }

        [JsonProperty("user")]
        public XrUserData User { get; set; }
    }

    public class XrUserData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>Id de texto (cuid) de la organización de la membresía activa más reciente; null sin membresía.</summary>
        [JsonProperty("orgId")]
        public string OrgId { get; set; }

        /// <summary>Id de texto (cuid) del rol en esa organización; null sin membresía.</summary>
        [JsonProperty("roleId")]
        public string RoleId { get; set; }
    }
}
