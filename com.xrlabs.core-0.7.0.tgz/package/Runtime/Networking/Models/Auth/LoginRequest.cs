using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class LoginRequest
    {
        [JsonProperty("pin")]
        public string Pin { get; set; }
    }
}
