using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class LoginResponse
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }

        [JsonProperty("user")]
        public UserData User { get; set; }
    }
}
