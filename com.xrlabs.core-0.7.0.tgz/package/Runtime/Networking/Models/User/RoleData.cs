using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class RoleData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
