using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class UserData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        [JsonProperty("last_name")]
        public string LastName { get; set; }

        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("role")]
        public RoleData Role { get; set; }

        [JsonProperty("organization")]
        public OrganizationData Organization { get; set; }

        [JsonProperty("preferred_language")]
        public string PreferredLanguage { get; set; }

        public string FullName => $"{FirstName} {LastName}";
    }
}
