using System;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Estados que envía el backend. A los clientes XR les llegan en MAYÚSCULAS (contrato XR de platform-api); el
    /// portal y los datos viejos del mock usan minúsculas. Toda comparación de estado pasa por <see cref="Is"/>, que no
    /// distingue mayúsculas (D10).
    /// </summary>
    public static class ApiStatus
    {
        public const string Active = "ACTIVE";
        public const string Available = "AVAILABLE";
        public const string Pending = "PENDING";
        public const string InProgress = "IN_PROGRESS";
        public const string Completed = "COMPLETED";
        public const string Failed = "FAILED";

        /// <summary>True si <paramref name="status"/> es <paramref name="expected"/>, sin distinguir mayúsculas.</summary>
        public static bool Is(string status, string expected) =>
            string.Equals(status, expected, StringComparison.OrdinalIgnoreCase);
    }
}
