namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Wrapper genérico para todas las respuestas de la API.
    /// </summary>
    public class ApiResponse<T>
    {
        public bool Success { get; private set; }
        public T Data { get; private set; }
        public string ErrorMessage { get; private set; }
        public int StatusCode { get; private set; }

        public static ApiResponse<T> Ok(T data, int statusCode = 200)
        {
            return new ApiResponse<T> { Success = true, Data = data, StatusCode = statusCode };
        }

        public static ApiResponse<T> Fail(int statusCode, string message)
        {
            return new ApiResponse<T> { Success = false, ErrorMessage = message, StatusCode = statusCode };
        }
    }
}
