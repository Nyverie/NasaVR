using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Estructura de error retornada por la API.
    /// </summary>
    public class ApiError
    {
        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("error")]
        public string Error { get; set; }
    }
}
