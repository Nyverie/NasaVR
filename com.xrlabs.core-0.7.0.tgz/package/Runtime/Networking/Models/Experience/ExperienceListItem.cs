using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    public class ExperienceListItem
    {
        [JsonProperty("experience")]
        public ExperienceData Experience { get; set; }

        [JsonProperty("group_experience")]
        public GroupExperienceData GroupExperience { get; set; }

        [JsonProperty("addressable")]
        public AddressableInfo Addressable { get; set; }
    }
}
