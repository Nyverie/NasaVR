using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// GET /experiences/{id}/addressable. El backend responde en camelCase; hoy el contenido viaja dentro de la app y
    /// llega todo null o 0.
    /// </summary>
    public class AddressableInfo
    {
        [JsonProperty("bundleUrl")]
        public string BundleUrl { get; set; }

        [JsonProperty("version")]
        public string Version { get; set; }

        [JsonProperty("sizeMb")]
        public float SizeMb { get; set; }

        [JsonProperty("catalogUrl")]
        public string CatalogUrl { get; set; }
    }
}
