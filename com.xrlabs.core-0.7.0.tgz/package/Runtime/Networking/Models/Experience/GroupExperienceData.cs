using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Progreso del usuario en una experiencia de un grupo (GET /group-experiences?groupId=&amp;userId=).
    /// </summary>
    public class GroupExperienceData
    {
        /// <summary>Id de texto (cuid) del grupo.</summary>
        [JsonProperty("groupId")]
        public string GroupId { get; set; }

        /// <summary>Id de texto (cuid) de la experiencia.</summary>
        [JsonProperty("experienceId")]
        public string ExperienceId { get; set; }

        [JsonProperty("mandatory")]
        public bool Mandatory { get; set; }

        /// <summary>Valores: "PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"; se comparan sin distinguir mayúsculas.</summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("finalScore")]
        public float? FinalScore { get; set; }

        /// <summary>
        /// Intentos usados. El backend envía «attempts» y también la grafía histórica «attemps»: se lee
        /// «attempts» y, si no llega, «attemps».
        /// </summary>
        [JsonIgnore]
        public int Attempts
        {
            get => _attempts ?? _attemps ?? 0;
            set => _attempts = value;
        }

        [JsonProperty("startedAt")]
        public string StartedAt { get; set; }

        [JsonProperty("completedAt")]
        public string CompletedAt { get; set; }

        [JsonProperty("timeSpent")]
        public int? TimeSpent { get; set; }

        public bool IsCompleted => ApiStatus.Is(Status, ApiStatus.Completed);
        public bool IsPending => ApiStatus.Is(Status, ApiStatus.Pending);

        private int? _attempts;
        private int? _attemps;

        [JsonProperty("attempts")]
        private int? AttemptsJson { get => _attempts; set => _attempts = value; }

        // Solo se lee (sin getter, Newtonsoft no la escribe al serializar).
        [JsonProperty("attemps")]
        private int? LegacyAttemptsJson { set => _attemps = value; }
    }
}
