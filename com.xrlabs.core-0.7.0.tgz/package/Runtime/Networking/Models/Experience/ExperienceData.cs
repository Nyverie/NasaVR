using Newtonsoft.Json;

namespace XRLabs.Networking.Models
{
    /// <summary>
    /// Datos de una experiencia retornados por la API (GET /experiences/{id}).
    /// </summary>
    public class ExperienceData
    {
        /// <summary>Id de texto (cuid) de la experiencia.</summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("image")]
        public string Image { get; set; }

        /// <summary>Duración en segundos.</summary>
        [JsonProperty("duration")]
        public int Duration { get; set; }

        /// <summary>Puntaje mínimo para aprobar (no el máximo).</summary>
        [JsonProperty("score")]
        public float Score { get; set; }

        /// <summary>Valores: "AVAILABLE" y los demás de <see cref="ApiStatus"/>; se comparan sin distinguir mayúsculas.</summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// Intentos permitidos. El backend envía «attempts» y también la grafía histórica «attemps»: se lee
        /// «attempts» y, si no llega, «attemps».
        /// </summary>
        [JsonIgnore]
        public int Attempts
        {
            get => _attempts ?? _attemps ?? 0;
            set => _attempts = value;
        }

        [JsonProperty("order")]
        public int Order { get; set; }

        [JsonProperty("avgScore")]
        public float? AvgScore { get; set; }

        [JsonProperty("difficultyRating")]
        public float? DifficultyRating { get; set; }

        public int DurationMinutes => Duration / 60;
        public bool IsVR => string.Equals(Type, "VR", System.StringComparison.OrdinalIgnoreCase);

        private int? _attempts;
        private int? _attemps;

        [JsonProperty("attempts")]
        private int? AttemptsJson { get => _attempts; set => _attempts = value; }

        // Solo se lee (sin getter, Newtonsoft no la escribe al serializar).
        [JsonProperty("attemps")]
        private int? LegacyAttemptsJson { set => _attemps = value; }
    }
}
