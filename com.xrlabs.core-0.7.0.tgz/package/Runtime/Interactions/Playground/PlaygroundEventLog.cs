using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Panel 3D del playground que lista en vivo los eventos de todos los
    /// InteractableBase de la escena. Usa TextMesh (sin dependencias de UI).
    /// </summary>
    [RequireComponent(typeof(TextMesh))]
    public class PlaygroundEventLog : MonoBehaviour
    {
        [SerializeField] private int maxLines = 12;

        private TextMesh _text;
        private readonly Queue<string> _lines = new();

        private void Awake()
        {
            _text = GetComponent<TextMesh>();
            _text.text = "— Interaction Playground —\n(esperando eventos)";
        }

        private void OnEnable() => DropZone.DroppedAnywhere += OnDropped;

        private void OnDisable() => DropZone.DroppedAnywhere -= OnDropped;

        private void OnDropped(InteractableBase item, DropZone zone) =>
            Append($"<color=#FFD54A>{item.InteractionId} · DROP en {zone.ZoneId}</color>");

        private void Start()
        {
            foreach (var interactable in FindObjectsByType<InteractableBase>(FindObjectsSortMode.None))
            {
                var captured = interactable;
                captured.Hovered += i => Append($"{i.InteractionId} · hover");
                captured.SelectedEvent += i => Append($"{i.InteractionId} · select");
                captured.ReleasedEvent += i => Append($"{i.InteractionId} · release");
                captured.Activated += i => Append($"<color=#7CFC00>{i.InteractionId} · ACTIVATE</color>");
                captured.Deactivated += i => Append($"{i.InteractionId} · deactivate");

                switch (captured)
                {
                    case ScrubSurface scrub:
                        scrub.Completed += s => Append($"<color=#7CFC00>{s.InteractionId} · SCRUB 100%</color>");
                        break;
                    case HoldButton hold:
                        hold.Completed += h => Append($"<color=#7CFC00>{h.InteractionId} · HOLD completo</color>");
                        break;
                    case AimTool aim:
                        aim.AimTargetChanged += id =>
                            Append($"{aim.InteractionId} · apunta a {(string.IsNullOrEmpty(id) ? "nada" : id)}");
                        break;
                }
            }
        }

        private void Append(string line)
        {
            _lines.Enqueue($"[{Time.time:0.0}s] {line}");
            while (_lines.Count > maxLines) _lines.Dequeue();
            _text.text = "— Interaction Playground —\n" + string.Join("\n", _lines);
        }
    }
}
