using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Muestra solo lo que usa el paso en curso (2026-10-26, recorrido del dueño en el Quest 3 con la experiencia 12: «¿por
    /// qué hay tantos cubos? Y letras, no se entienden las letras, y con tanta información es difícil desplazarse»).
    /// Opción de la experiencia (<c>experiencia.visibilidadPorPaso</c> del guion, Documentation~/autoria.md §12): «Preparar
    /// escena» y el importador de la colocación ponen este componente en <c>[Colocacion]</c> y le escriben, por objeto y
    /// por zona, el primer y el último paso que lo usan y los pasos en que lo usan de verdad. Sin la opción no existe y la
    /// escena se comporta como siempre (D8).
    ///
    /// La regla, que escucha el <see cref="StepSystem"/> y recalcula entera en cada paso (por eso saltar adelante o atrás
    /// con el panel de depuración deja lo mismo que llegar jugando):
    /// - Un objeto que ningún paso usa (<c>firstStepId</c> vacío) se ve siempre, y su etiqueta nunca.
    /// - Un objeto que sí se usa se ve del primer al último paso que lo usa; fuera de ese tramo se apagan sus renderers y sus
    ///   colliders (el rayo y el clic no lo encuentran), salvo mientras está agarrado: se oculta al soltarlo.
    /// - La etiqueta flotante de un marcador y el recuadro con nombre de una zona solo se ven en los pasos que lo usan de
    ///   verdad (<c>labelStepIds</c>), no en todo el tramo.
    /// - Una zona no oculta su cuerpo: su trigger sigue donde está y solo cambia el dibujo (recuadro y nombre). Apagar el
    ///   collider de una zona con objetos dentro dejaría la cuenta de <see cref="DropZone"/> a medias; sin su dibujo ya no
    ///   se ve, y lo que acepta está oculto fuera de su tramo.
    ///
    /// Se ocultan renderers y colliders, no el GameObject: así el objeto sigue registrado (<see cref="SceneTarget"/>,
    /// <see cref="InteractableRegistry"/>) y las condiciones, el anillo y el coach lo encuentran sin esperar a un Start
    /// pendiente. Es el primer escalón de <c>visibleSi</c> del contrato 0.3 (contrato-0.3.md §2.10), que lo hará por el
    /// estado y no por el paso. Sin XR: solo lee <see cref="InteractableBase.IsSelected"/>.
    /// </summary>
    [DefaultExecutionOrder(-200)]
    public class StepVisibilityController : MonoBehaviour
    {
        /// <summary>Lo que el guion dice de un objeto o una zona de la colocación: dónde empieza su tramo y en qué pasos se usa.</summary>
        [Serializable]
        public class Entry
        {
            [Tooltip("Id del objeto o de la zona (el del guion y la colocación).")]
            public string id;
            [Tooltip("La raíz del objeto o de la zona en la escena (Objeto_<id> o Zona_<id>).")]
            public Transform target;
            [Tooltip("Una zona solo cambia su dibujo (recuadro y nombre); un objeto además se oculta fuera de su tramo.")]
            public bool isZone;
            [Tooltip("Id del primer paso que lo usa. Vacío = ningún paso lo usa: se ve siempre.")]
            public string firstStepId;
            [Tooltip("Id del último paso que lo usa.")]
            public string lastStepId;
            [Tooltip("Ids de los pasos que lo usan de verdad: en ellos (y solo en ellos) se ve su etiqueta y el recuadro de su zona.")]
            public List<string> labelStepIds = new();
        }

        // Nombres de los hijos que pone ColocacionImporter (LabelName y ZoneFloorName): el runtime no depende del editor.
        private const string LabelChild = "Etiqueta";
        private const string FloorChild = "Suelo";

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private List<Entry> entries = new();

        private sealed class Live
        {
            public Entry Source;
            public int First = -1;
            public int Last = -1;
            public readonly HashSet<int> LabelAt = new();
            public readonly List<Renderer> Renderers = new();
            public readonly List<Collider> Colliders = new();
            public InteractableBase[] Items = Array.Empty<InteractableBase>();
            public GameObject Label;
            public GameObject Floor;
            public bool BodyShown = true;
            public bool Deferred;

            public bool HasSpan => First >= 0;
        }

        private readonly List<Live> _live = new();
        private bool _built;
        private int _deferred;

        /// <summary>Las entradas con las que trabaja (para el editor y las pruebas).</summary>
        public IReadOnlyList<Entry> Entries => entries;

        // ── La regla, en funciones puras ──────────────────────────────────────

        /// <summary>
        /// ¿Se ve el cuerpo (marcador, modelo, collider) en el paso <paramref name="stepIndex"/>? Sin tramo
        /// (<paramref name="first"/> &lt; 0: ningún paso lo usa) siempre; con tramo, del primer al último paso inclusive.
        /// <paramref name="stepIndex"/> -1 es «aún no empezó ningún paso».
        /// </summary>
        public static bool IsBodyVisibleAt(int stepIndex, int first, int last) =>
            first < 0 || (stepIndex >= Mathf.Min(first, last) && stepIndex <= Mathf.Max(first, last));

        /// <summary>¿Se ve la etiqueta o el recuadro en el paso <paramref name="stepIndex"/>? Solo en los pasos que lo usan de verdad.</summary>
        public static bool IsLabelVisibleAt(int stepIndex, ICollection<int> labelSteps) =>
            labelSteps != null && labelSteps.Contains(stepIndex);

        // ── Ciclo de vida ─────────────────────────────────────────────────────

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem == null || stepSystem.Sequence == null) return;

            Build();
            stepSystem.StepStarted += OnStepStarted;
            Apply(stepSystem.IsRunning ? stepSystem.CurrentStepIndex : -1);
        }

        private void OnDisable()
        {
            if (stepSystem != null) stepSystem.StepStarted -= OnStepStarted;
            RestoreAll();
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => Apply(index);

        private void Update()
        {
            if (_deferred == 0) return;
            foreach (var live in _live)
            {
                if (!live.Deferred || IsHeld(live)) continue;
                live.Deferred = false;
                _deferred--;
                SetBody(live, false);
            }
        }

        // ── Resolución, una sola vez ──────────────────────────────────────────

        private void Build()
        {
            if (_built) return;
            _built = true;

            var indexOf = new Dictionary<string, int>();
            var steps = stepSystem.Sequence.steps;
            for (int i = 0; steps != null && i < steps.Count; i++)
                if (steps[i] != null && !string.IsNullOrEmpty(steps[i].stepId) && !indexOf.ContainsKey(steps[i].stepId))
                    indexOf[steps[i].stepId] = i;

            foreach (var entry in entries)
            {
                if (entry == null || entry.target == null) continue;
                var live = new Live { Source = entry };

                // Un id que el guion ya no tiene (la secuencia se reimportó sin reprepararla): sin tramo, se ve siempre.
                if (!string.IsNullOrEmpty(entry.firstStepId) && !string.IsNullOrEmpty(entry.lastStepId)
                    && indexOf.TryGetValue(entry.firstStepId, out int first) && indexOf.TryGetValue(entry.lastStepId, out int last))
                {
                    live.First = Mathf.Min(first, last);
                    live.Last = Mathf.Max(first, last);
                }
                foreach (var id in entry.labelStepIds ?? new List<string>())
                    if (id != null && indexOf.TryGetValue(id, out int at)) live.LabelAt.Add(at);

                var label = entry.target.Find(LabelChild);
                var floor = entry.target.Find(FloorChild);
                live.Label = label != null ? label.gameObject : null;
                live.Floor = floor != null ? floor.gameObject : null;

                if (!entry.isZone)
                {
                    foreach (var r in entry.target.GetComponentsInChildren<Renderer>(true))
                        if (r != null && r.enabled && !IsUnder(r.transform, label)) live.Renderers.Add(r);
                    foreach (var c in entry.target.GetComponentsInChildren<Collider>(true))
                        if (c != null && c.enabled) live.Colliders.Add(c);
                    live.Items = entry.target.GetComponentsInChildren<InteractableBase>(true);
                }
                _live.Add(live);
            }
        }

        private static bool IsUnder(Transform t, Transform parent) => parent != null && t.IsChildOf(parent);

        // ── Aplicar ───────────────────────────────────────────────────────────

        private void Apply(int stepIndex)
        {
            foreach (var live in _live)
            {
                bool body = IsBodyVisibleAt(stepIndex, live.First, live.Last);
                bool decoration = IsLabelVisibleAt(stepIndex, live.LabelAt);

                if (live.Label != null) live.Label.SetActive(decoration);
                if (live.Floor != null) live.Floor.SetActive(decoration);
                if (live.Source.isZone) continue;

                if (body)
                {
                    if (live.Deferred) { live.Deferred = false; _deferred--; }
                    SetBody(live, true);
                }
                else if (live.BodyShown && IsHeld(live))
                {
                    // Agarrado fuera de su tramo: se queda a la vista hasta que se suelte (Update).
                    if (!live.Deferred) { live.Deferred = true; _deferred++; }
                }
                else
                {
                    if (live.Deferred) { live.Deferred = false; _deferred--; }
                    SetBody(live, false);
                }
            }
        }

        private static bool IsHeld(Live live)
        {
            foreach (var item in live.Items)
                if (item != null && item.IsSelected) return true;
            return false;
        }

        private static void SetBody(Live live, bool shown)
        {
            if (live.BodyShown == shown) return;
            live.BodyShown = shown;
            foreach (var r in live.Renderers) if (r != null) r.enabled = shown;
            foreach (var c in live.Colliders) if (c != null) c.enabled = shown;
        }

        // Deja la escena como estaba al apagar el componente: todo a la vista, con los renderers y colliders que había.
        private void RestoreAll()
        {
            foreach (var live in _live)
            {
                if (live.Label != null) live.Label.SetActive(true);
                if (live.Floor != null) live.Floor.SetActive(true);
                if (live.Source.isZone) continue;
                if (live.Deferred) live.Deferred = false;
                SetBody(live, true);
            }
            _deferred = 0;
        }

        // ── Consulta (pruebas, depuración) ────────────────────────────────────

        /// <summary>¿Se ve ahora el cuerpo del objeto con ese id? Un id sin entrada o sin tramo siempre se ve.</summary>
        public bool IsBodyShown(string id)
        {
            foreach (var live in _live)
                if (live.Source.id == id) return live.BodyShown;
            return true;
        }
    }
}
