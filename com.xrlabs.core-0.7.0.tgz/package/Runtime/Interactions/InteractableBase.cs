using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;
using XRLabs.Core.Telemetry;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Contrato único de interacción del framework. Los consumidores (StepConditions,
    /// controllers, UI) escuchan estos eventos y NUNCA tipos del SDK XR — esa es la
    /// clave para soportar VR y modo plano con el mismo código de simulación.
    /// Cada evento se telemetriza automáticamente como InteractionEvent.
    /// </summary>
    public abstract class InteractableBase : MonoBehaviour
    {
        [Header("Identidad")]
        [Tooltip("Id estable para condiciones y telemetría. Vacío = usa el nombre del GameObject.")]
        [SerializeField] private string interactionId;

        public string InteractionId =>
            string.IsNullOrEmpty(interactionId) ? gameObject.name : interactionId;

        public event Action<InteractableBase> Hovered;
        public event Action<InteractableBase> Unhovered;
        public event Action<InteractableBase> SelectedEvent;
        public event Action<InteractableBase> ReleasedEvent;
        public event Action<InteractableBase> Activated;

        /// <summary>v0.6: se soltó el gatillo/activación (par de <see cref="Activated"/>).</summary>
        public event Action<InteractableBase> Deactivated;

        /// <summary>True mientras el objeto está agarrado/seleccionado.</summary>
        public bool IsSelected { get; private set; }

        /// <summary>
        /// v0.6: True entre <see cref="Activated"/> y <see cref="Deactivated"/> (o al soltar).
        /// Solo es significativo en interactuables que emiten Deactivated (agarrables, herramientas,
        /// HoldButton); en un TouchableHotspot (activación de un solo disparo) queda en true tras el toque.
        /// </summary>
        public bool IsActivated { get; private set; }

        // Registro por ID (v0.6): el coach y el feedback encuentran el objeto sin referencias directas.
        // Start/OnDestroy porque las subclases usan Awake/OnEnable/OnDisable.
        // También se registra en InteractableRegistry (id → InteractableBase) para las condiciones.
        protected virtual void Start()
        {
            SceneTargetRegistry.Register(InteractionId, transform);
            InteractableRegistry.Register(InteractionId, this);
        }

        protected virtual void OnDestroy()
        {
            SceneTargetRegistry.Unregister(InteractionId, transform);
            InteractableRegistry.Unregister(InteractionId, this);
        }

        protected void RaiseHovered()
        {
            Hovered?.Invoke(this);
            HoveredAnywhere?.Invoke(this);   // XR al día 2026-10-31
            EmitTelemetry("hover");
        }

        protected void RaiseUnhovered()
        {
            Unhovered?.Invoke(this);
            UnhoveredAnywhere?.Invoke(this);   // XR al día 2026-10-31
        }

        protected void RaiseSelected()
        {
            if (BlockedByLock()) return;   // 0.3 lote 6: un objeto bloqueado no se agarra
            IsSelected = true;
            SelectedEvent?.Invoke(this);
            SelectedAnywhere?.Invoke(this);   // XR al día 2026-10-31
            EmitTelemetry("select");
        }

        protected void RaiseReleased()
        {
            if (!IsSelected && Locked) return;   // 0.3 lote 6: el agarre se rechazó, no hay soltado
            ReleaseSerial++;
            IsSelected = false;
            IsActivated = false;
            ReleasedEvent?.Invoke(this);
            ReleasedAnywhere?.Invoke(this);   // XR al día 2026-10-31
            EmitTelemetry("release");
        }

        protected void RaiseActivated()
        {
            if (BlockedByLock()) return;   // 0.3 lote 6: el hotspot o botón bloqueado no se activa
            IsActivated = true;
            Activated?.Invoke(this);
            ActivatedAnywhere?.Invoke(this);   // XR al día 2026-10-31
            EmitTelemetry("activate");
        }

        protected void RaiseDeactivated()
        {
            IsActivated = false;
            Deactivated?.Invoke(this);
            EmitTelemetry("deactivate");
        }

        // ── XR al día 2026-10-31: los mismos eventos «en cualquier parte» ─────
        // Para el realce, el sonido y la háptica de InteractionFeedback (informe «OpenXR, Android XR y XRI al día», P3 y
        // P4): un solo componente escucha a todos los interactuables sin que cada uno lo tenga que llevar. Se emiten
        // después del evento de instancia y con las mismas reglas (un objeto bloqueado no emite seleccionado ni activado).

        public static event Action<InteractableBase> HoveredAnywhere;
        public static event Action<InteractableBase> UnhoveredAnywhere;
        public static event Action<InteractableBase> SelectedAnywhere;
        public static event Action<InteractableBase> ReleasedAnywhere;
        public static event Action<InteractableBase> ActivatedAnywhere;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetAnywhereStatics()
        {
            HoveredAnywhere = null;
            UnhoveredAnywhere = null;
            SelectedAnywhere = null;
            ReleasedAnywhere = null;
            ActivatedAnywhere = null;
        }

        // ── API para drivers de plataforma (modo plano, tests) ─────────────────
        // Permiten disparar el contrato sin pasar por XRI. Los consumidores siguen
        // escuchando los mismos eventos sin importar la fuente.

        public void DriverHover() => RaiseHovered();
        public void DriverUnhover() => RaiseUnhovered();
        public void DriverSelect() => RaiseSelected();
        public void DriverRelease() => RaiseReleased();
        public void DriverActivate() => RaiseActivated();
        public void DriverDeactivate() => RaiseDeactivated();

        // ── 0.3 lote 6: bloqueos (contrato-0.3.md §2.8) ───────────────────────
        // Los ids bloqueados son estáticos (los fija LockEnforcer): así vale también para objetos que aún no existen o están
        // inactivos, y para las herramientas de una pila (InteractableRegistry.Matches mira el SourceId).

        private static readonly HashSet<string> LockedIds = new();

        /// <summary>Alguien intentó agarrar o activar un objeto bloqueado (LockEnforcer da el feedback).</summary>
        public static event Action<InteractableBase> LockedInteractionAnywhere;

        /// <summary>Bloquea o desbloquea los interactuables con ese id.</summary>
        public static void SetObjectLocked(string id, bool locked)
        {
            if (string.IsNullOrEmpty(id)) return;
            if (locked) LockedIds.Add(id);
            else LockedIds.Remove(id);
        }

        public static bool IsObjectLocked(string id) => !string.IsNullOrEmpty(id) && LockedIds.Contains(id);

        /// <summary>True si un bloqueo activo nombra este objeto: no se agarra ni se activa.</summary>
        public bool Locked
        {
            get
            {
                if (LockedIds.Count == 0) return false;
                foreach (var id in LockedIds)
                    if (InteractableRegistry.Matches(id, this)) return true;
                return false;
            }
        }

        /// <summary>Número de soltados emitidos: DropZone lo usa para juzgar cada soltado una sola vez.</summary>
        internal int ReleaseSerial { get; private set; }

        private bool BlockedByLock()
        {
            if (!Locked) return false;
            LockedInteractionAnywhere?.Invoke(this);
            return true;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetLockStatics()
        {
            LockedIds.Clear();
            LockedInteractionAnywhere = null;
        }

        private void EmitTelemetry(string kind)
        {
            TelemetryHub.Emit(new InteractionEvent
            {
                StepId = TelemetryContext.CurrentStepId,
                InteractionId = InteractionId,
                Kind = kind
            });
        }
    }
}
