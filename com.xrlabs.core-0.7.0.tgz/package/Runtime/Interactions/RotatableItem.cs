using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Objeto que rota en su lugar mientras el usuario lo agarra (patrón torno/turntable),
    /// sin desplazarse — el reemplazo de producción del test RotateOnGrab (mouse).
    /// Usa XRGrabInteractable con tracking desactivado y aplica el delta de rotación
    /// del interactor manualmente. Expone TotalRotationDegrees para condiciones/telemetría.
    /// </summary>
    [RequireComponent(typeof(XRGrabInteractable))]
    public class RotatableItem : InteractableBase
    {
        [Header("Rotación")]
        [Tooltip("Multiplicador de la rotación del control respecto al objeto.")]
        [SerializeField] private float rotationSensitivity = 1.5f;

        public float TotalRotationDegrees { get; private set; }

        private XRGrabInteractable _grab;
        private IXRSelectInteractor _interactor;
        private Quaternion _lastInteractorRotation;

        private void Awake()
        {
            _grab = GetComponent<XRGrabInteractable>();
            // El objeto no debe moverse a la mano: solo rotar en su sitio.
            _grab.trackPosition = false;
            _grab.trackRotation = false;
            _grab.throwOnDetach = false;
        }

        private void OnEnable()
        {
            _grab.hoverEntered.AddListener(_ => RaiseHovered());
            _grab.hoverExited.AddListener(_ => RaiseUnhovered());
            _grab.selectEntered.AddListener(OnSelectEntered);
            _grab.selectExited.AddListener(OnSelectExited);
        }

        private void OnDisable()
        {
            _grab.hoverEntered.RemoveAllListeners();
            _grab.hoverExited.RemoveAllListeners();
            _grab.selectEntered.RemoveListener(OnSelectEntered);
            _grab.selectExited.RemoveListener(OnSelectExited);
        }

        private void Update()
        {
            if (_interactor == null) return;

            Quaternion current = _interactor.transform.rotation;
            Quaternion delta = current * Quaternion.Inverse(_lastInteractorRotation);
            _lastInteractorRotation = current;

            delta.ToAngleAxis(out float angle, out Vector3 axis);
            if (angle > 180f) angle -= 360f;

            float applied = angle * rotationSensitivity;
            transform.Rotate(axis, applied, Space.World);
            TotalRotationDegrees += Mathf.Abs(applied);
        }

        /// <summary>Aplica rotación externa (drivers flat: drag del pointer). Acumula en el contador.</summary>
        public void ApplyExternalRotation(Vector3 axis, float degrees)
        {
            transform.Rotate(axis, degrees, Space.World);
            TotalRotationDegrees += Mathf.Abs(degrees);
        }

        public void ResetRotationCounter()
        {
            TotalRotationDegrees = 0f;
        }

        private void OnSelectEntered(SelectEnterEventArgs args)
        {
            _interactor = args.interactorObject;
            _lastInteractorRotation = _interactor.transform.rotation;
            RaiseSelected();
        }

        private void OnSelectExited(SelectExitEventArgs args)
        {
            _interactor = null;
            RaiseReleased();
        }
    }
}
