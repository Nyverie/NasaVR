using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Feedback;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// XR al día 2026-10-31 (informe «OpenXR, Android XR y XRI al día», P3 y P4): el realce y el sonido de las interacciones,
    /// como componente propio porque el sistema de afordancias de XRI está deprecado desde la 3.0. Escucha el contrato
    /// (<see cref="InteractableBase.HoveredAnywhere"/> y compañía), no XRI, así que sirve igual para el rayo, la mano y el
    /// modo plano:
    /// <list type="bullet">
    /// <item>apuntado: tinte frío y emisión suave en los renderers del objeto, con <c>MaterialPropertyBlock</c> (no toca los
    /// materiales; se quita al salir);</item>
    /// <item>tomado: tinte cálido más fuerte mientras dura el agarre;</item>
    /// <item>agarrar, soltar y tocar: un clip corto sintetizado aquí (sin ficheros ni marcas) en la posición del objeto, y un
    /// pulso por <see cref="FeedbackSystem.Haptics"/> si la mano que interactúa no vibró ya por su <c>SimpleHapticFeedback</c>
    /// (el del rig vibra solo el mando que toca; esto cubre a los demás orígenes sin pulsar dos veces).</item>
    /// </list>
    /// Va en la raíz del rig XRI (lo agrega <c>XriRigBuilder</c>); en una escena sin rig no hace nada.
    /// </summary>
    public class InteractionFeedback : MonoBehaviour
    {
        public enum HighlightState { None, Hovered, Selected }

        public enum Cue { None, Grab, Release, Touch }

        [Header("Realce")]
        [SerializeField] private bool highlight = true;
        [SerializeField] private Color hoverColor = new(0.35f, 0.85f, 1f);
        [SerializeField] private Color selectColor = new(1f, 0.8f, 0.3f);
        [SerializeField, Range(0f, 1f)] private float hoverTint = 0.35f;
        [SerializeField, Range(0f, 1f)] private float selectTint = 0.55f;
        [Tooltip("Emisión del realce (solo se ve en materiales con emisión encendida; el tinte se ve siempre).")]
        [SerializeField, Min(0f)] private float emission = 0.6f;

        [Header("Sonido")]
        [SerializeField] private bool playSounds = true;
        [SerializeField, Range(0f, 1f)] private float volume = 0.45f;

        [Header("Vibración (si la mano no vibró ya)")]
        [SerializeField] private bool pulseHaptics = true;
        [SerializeField, Range(0f, 1f)] private float grabAmplitude = 0.4f;
        [SerializeField, Min(0f)] private float grabSeconds = 0.08f;
        [SerializeField, Range(0f, 1f)] private float touchAmplitude = 0.3f;
        [SerializeField, Min(0f)] private float touchSeconds = 0.05f;

        private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
        private static readonly int ColorId = Shader.PropertyToID("_Color");
        private static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

        private readonly Dictionary<InteractableBase, int> _hovers = new();
        private readonly Dictionary<InteractableBase, HighlightState> _states = new();
        private readonly List<Renderer> _renderers = new();
        private MaterialPropertyBlock _block;
        private AudioSource _audio;
        private AudioClip _grabClip, _releaseClip, _touchClip;

        /// <summary>Clips reproducidos desde que se habilitó (para pruebas y diagnóstico).</summary>
        public int CuesPlayed { get; private set; }

        public Cue LastCue { get; private set; }

        /// <summary>Pulsos enviados por este componente a <see cref="FeedbackSystem.Haptics"/>.</summary>
        public int PulsesSent { get; private set; }

        public HighlightState StateOf(InteractableBase target) =>
            target != null && _states.TryGetValue(target, out var s) ? s : HighlightState.None;

        private void Awake()
        {
            _block = new MaterialPropertyBlock();
            var audioObject = new GameObject("Audio de interacciones");
            audioObject.transform.SetParent(transform, false);
            _audio = audioObject.AddComponent<AudioSource>();
            _audio.playOnAwake = false;
            _audio.spatialBlend = 1f;
            _audio.minDistance = 0.5f;
            _audio.maxDistance = 8f;
            _audio.rolloffMode = AudioRolloffMode.Linear;
            // Clips de 50 a 110 ms, mono a 22 kHz (unos 2–5 KB cada uno), sintetizados: nada que licenciar.
            _grabClip = Synth("xrlabs-agarrar", (880f, 1320f, 0.06f));
            _releaseClip = Synth("xrlabs-soltar", (660f, 440f, 0.07f));
            _touchClip = Synth("xrlabs-tocar", (990f, 990f, 0.05f), (1480f, 1480f, 0.06f));
        }

        private void OnEnable()
        {
            InteractableBase.HoveredAnywhere += OnHovered;
            InteractableBase.UnhoveredAnywhere += OnUnhovered;
            InteractableBase.SelectedAnywhere += OnSelected;
            InteractableBase.ReleasedAnywhere += OnReleased;
            InteractableBase.ActivatedAnywhere += OnActivated;
        }

        private void OnDisable()
        {
            InteractableBase.HoveredAnywhere -= OnHovered;
            InteractableBase.UnhoveredAnywhere -= OnUnhovered;
            InteractableBase.SelectedAnywhere -= OnSelected;
            InteractableBase.ReleasedAnywhere -= OnReleased;
            InteractableBase.ActivatedAnywhere -= OnActivated;
            foreach (var target in new List<InteractableBase>(_states.Keys)) Apply(target, HighlightState.None);
            _states.Clear();
            _hovers.Clear();
        }

        private void OnDestroy()
        {
            if (_grabClip != null) Destroy(_grabClip);
            if (_releaseClip != null) Destroy(_releaseClip);
            if (_touchClip != null) Destroy(_touchClip);
        }

        private void OnHovered(InteractableBase target)
        {
            _hovers.TryGetValue(target, out int n);
            _hovers[target] = n + 1;
            if (StateOf(target) == HighlightState.None) Apply(target, HighlightState.Hovered);
        }

        private void OnUnhovered(InteractableBase target)
        {
            _hovers.TryGetValue(target, out int n);
            n = Math.Max(0, n - 1);
            if (n == 0) _hovers.Remove(target); else _hovers[target] = n;
            if (n == 0 && StateOf(target) == HighlightState.Hovered) Apply(target, HighlightState.None);
        }

        private void OnSelected(InteractableBase target)
        {
            Apply(target, HighlightState.Selected);
            Play(Cue.Grab, _grabClip, target);
            Pulse(target, grabAmplitude, grabSeconds);
        }

        private void OnReleased(InteractableBase target)
        {
            Apply(target, _hovers.ContainsKey(target) ? HighlightState.Hovered : HighlightState.None);
            Play(Cue.Release, _releaseClip, target);
        }

        private void OnActivated(InteractableBase target)
        {
            Play(Cue.Touch, _touchClip, target);
            Pulse(target, touchAmplitude, touchSeconds);
        }

        // ── Realce ────────────────────────────────────────────────────────────

        private void Apply(InteractableBase target, HighlightState state)
        {
            if (target == null) { _states.Remove(target); return; }
            if (state == HighlightState.None) _states.Remove(target); else _states[target] = state;
            if (!highlight) return;

            _renderers.Clear();
            target.GetComponentsInChildren(true, _renderers);
            foreach (var r in _renderers)
            {
                if (r == null || !(r is MeshRenderer || r is SkinnedMeshRenderer)) continue;
                var materials = r.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    if (state == HighlightState.None) { r.SetPropertyBlock(null, i); continue; }
                    var material = materials[i];
                    if (material == null) continue;
                    var color = state == HighlightState.Selected ? selectColor : hoverColor;
                    float tint = state == HighlightState.Selected ? selectTint : hoverTint;
                    _block.Clear();
                    if (material.HasProperty(BaseColorId))
                        _block.SetColor(BaseColorId, Color.Lerp(material.GetColor(BaseColorId), color, tint));
                    else if (material.HasProperty(ColorId))
                        _block.SetColor(ColorId, Color.Lerp(material.GetColor(ColorId), color, tint));
                    if (material.HasProperty(EmissionColorId))
                        _block.SetColor(EmissionColorId, color * emission);
                    r.SetPropertyBlock(_block, i);
                }
            }
        }

        // ── Sonido y vibración ───────────────────────────────────────────────

        private void Play(Cue cue, AudioClip clip, InteractableBase target)
        {
            if (!playSounds || clip == null || _audio == null) return;
            if (target != null) _audio.transform.position = target.transform.position;
            _audio.PlayOneShot(clip, volume);
            CuesPlayed++;
            LastCue = cue;
        }

        private void Pulse(InteractableBase target, float amplitude, float seconds)
        {
            if (!pulseHaptics || FeedbackSystem.Haptics == null || HandAlreadyVibrated(target)) return;
            FeedbackSystem.Haptics.Pulse(amplitude, seconds);
            PulsesSent++;
        }

        // Si un interactor de XRI con SimpleHapticFeedback está apuntando o tomando el objeto, ese mando ya vibró (y solo
        // él): un pulso más por FeedbackSystem iría a los dos mandos.
        private static bool HandAlreadyVibrated(InteractableBase target)
        {
            if (target == null) return false;
            var xri = target.GetComponent<XRBaseInteractable>();
            if (xri == null) return false;
            foreach (var interactor in xri.interactorsSelecting)
                if (interactor is Component c && c != null && c.GetComponentInChildren<SimpleHapticFeedback>(true) != null) return true;
            foreach (var interactor in xri.interactorsHovering)
                if (interactor is Component c && c != null && c.GetComponentInChildren<SimpleHapticFeedback>(true) != null) return true;
            return false;
        }

        // Tonos cortos con ataque de 4 ms y caída exponencial: (frecuencia inicial, final, segundos) por tramo.
        private static AudioClip Synth(string name, params (float from, float to, float seconds)[] parts)
        {
            const int rate = 22050;
            int total = 0;
            foreach (var p in parts) total += Mathf.CeilToInt(p.seconds * rate);
            var data = new float[total];
            int offset = 0;
            foreach (var p in parts)
            {
                int n = Mathf.CeilToInt(p.seconds * rate);
                double phase = 0;
                for (int i = 0; i < n; i++)
                {
                    float t = i / (float)n;
                    float f = Mathf.Lerp(p.from, p.to, t);
                    phase += 2 * Math.PI * f / rate;
                    float attack = Mathf.Clamp01(i / (rate * 0.004f));
                    float decay = Mathf.Exp(-5f * t);
                    data[offset + i] = (float)Math.Sin(phase) * attack * decay * 0.6f;
                }
                offset += n;
            }
            var clip = AudioClip.Create(name, total, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
