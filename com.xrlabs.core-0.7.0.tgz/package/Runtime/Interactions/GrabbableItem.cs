using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Objeto agarrable. Implementación XRI del contrato InteractableBase:
    /// traduce los eventos de XRGrabInteractable a los eventos del framework.
    /// En modo plano (F9), un FlatInteractionDriver disparará los mismos eventos.
    /// </summary>
    [RequireComponent(typeof(XRGrabInteractable))]
    public class GrabbableItem : InteractableBase, IDragSource
    {
        private XRGrabInteractable _grab;

        private void Awake()
        {
            _grab = GetComponent<XRGrabInteractable>();
        }

        private void OnEnable()
        {
            _grab.hoverEntered.AddListener(_ => RaiseHovered());
            _grab.hoverExited.AddListener(_ => RaiseUnhovered());
            _grab.selectEntered.AddListener(_ => OnSelectEntered());
            _grab.selectExited.AddListener(_ => RaiseReleased());
            _grab.activated.AddListener(_ => RaiseActivated());
            _grab.deactivated.AddListener(_ => RaiseDeactivated());
        }

        private void OnDisable()
        {
            _grab.hoverEntered.RemoveAllListeners();
            _grab.hoverExited.RemoveAllListeners();
            _grab.selectEntered.RemoveAllListeners();
            _grab.selectExited.RemoveAllListeners();
            _grab.activated.RemoveAllListeners();
            _grab.deactivated.RemoveAllListeners();
        }

        // 0.3 lote 6: un objeto bloqueado (contrato-0.3.md §2.8) no se agarra. XRI ya lo seleccionó: se cancela la selección
        // (el selectExited que sigue no emite soltado, porque InteractableBase no llegó a marcarlo seleccionado).
        private void OnSelectEntered()
        {
            if (!Locked)
            {
                RaiseSelected();
                return;
            }
            RaiseSelected();   // no selecciona: avisa a LockEnforcer del intento
            var manager = _grab.interactionManager;
            if (manager != null) manager.CancelInteractableSelection((IXRSelectInteractable)_grab);
        }

        /// <summary>Transform que mueve el modo plano al arrastrar (el propio objeto).</summary>
        public Transform DragTarget => transform;

        /// <summary>Habilita/deshabilita el grab (ej: durante inspección forzada).</summary>
        public void SetGrabEnabled(bool enabled)
        {
            if (_grab != null) _grab.enabled = enabled;
        }
    }
}
