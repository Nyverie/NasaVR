using UnityEngine;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Interactuable que el modo plano (FlatInteractionDriver) puede arrastrar con mouse/touch.
    /// <see cref="DragTarget"/> es el Transform que se mueve; puede ser null mientras no hay
    /// nada que arrastrar (ej: una SourcePile sin herramienta cargada).
    /// </summary>
    public interface IDragSource
    {
        Transform DragTarget { get; }
    }
}
