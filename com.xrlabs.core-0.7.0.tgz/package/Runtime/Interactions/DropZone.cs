using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using XRLabs.Core;
using XRLabs.Core.Telemetry;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Zona de soltado (collider trigger). Lleva la cuenta de los interactuables que están dentro
    /// y, cuando uno se SUELTA dentro, emite <see cref="Dropped"/> — la zona solo informa; quien
    /// juzga si es correcto es la condición (DropCondition).
    ///
    /// - Soltar fuera de toda zona NO es un error: ReturnToOrigin devuelve el objeto a su sitio.
    /// - <c>acceptedIds</c> filtra qué objetos "encajan" (vacío = todos): controla el resaltado
    ///   y si ReturnToOrigin lo devuelve. Dropped se emite igual para los no aceptados, para que
    ///   la condición pueda reportar el error.
    /// - Los ids se comparan con InteractionId o, para herramientas de una SourcePile, con su SourceId.
    /// - 0.3 lote 6 (contrato-0.3.md §3): un soltado se juzga UNA sola vez, en una zona: de las que contienen al objeto
    ///   (según su <c>measure</c>), la más pequeña que lo acepta; si ninguna lo acepta, la más pequeña. Antes cada zona que lo
    ///   contenía emitía su DroppedAnywhere (visto en PlayMode el 2026-10-31: «cubierta» y «capas» juzgaban el mismo soltado).
    ///   Solo se resalta la zona que va a juzgar. Una zona bloqueada (LockEnforcer) rechaza todo soltado: no emite Dropped,
    ///   emite <see cref="DropRejectedByLock"/> y el objeto vuelve.
    /// </summary>
    public class DropZone : MonoBehaviour
    {
        private static readonly List<DropZone> Zones = new();
        private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
        private static readonly int ColorId = Shader.PropertyToID("_Color");
        private static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

        [Header("Identidad")]
        [Tooltip("Id estable para condiciones y coach. Vacío = nombre del GameObject.")]
        [SerializeField] private string zoneId;

        [Tooltip("Ids de interactuables que esta zona acepta. Vacío = acepta todos.")]
        [SerializeField] private List<string> acceptedIds = new();

        // 0.3 lote 6
        [Tooltip("Cómo decide si el objeto está dentro al soltarlo: Contacto (algún collider toca el volumen) o Centro (el " +
                 "centro de los límites del objeto está dentro). `medir` de la colocación.")]
        [SerializeField] private DropMeasure measure = DropMeasure.Contact;

        [Header("Resaltado")]
        [Tooltip("Renderer que se tiñe mientras un objeto agarrado y aceptable está dentro. Opcional.")]
        [SerializeField] private Renderer highlightRenderer;
        [SerializeField] private Color highlightColor = new Color(0.3f, 1f, 0.4f, 1f);
        [Tooltip("Enganche para efectos propios (partículas, sonido). true = resaltar, false = apagar.")]
        [SerializeField] private UnityEvent<bool> onHighlightChanged = new();

        /// <summary>Zonas activas en la escena.</summary>
        public static IReadOnlyList<DropZone> All => Zones;

        /// <summary>Un interactuable se soltó dentro de CUALQUIER zona (para condiciones).</summary>
        public static event Action<InteractableBase, DropZone> DroppedAnywhere;

        /// <summary>Un interactuable se soltó dentro de esta zona.</summary>
        public event Action<InteractableBase, DropZone> Dropped;

        /// <summary>Cambió el resaltado (true = hay un objeto agarrado y aceptable dentro).</summary>
        public event Action<bool> HighlightChanged;

        public string ZoneId => string.IsNullOrEmpty(zoneId) ? gameObject.name : zoneId;
        public bool IsHighlighted { get; private set; }
        public IReadOnlyList<string> AcceptedIds => acceptedIds;

        private readonly Dictionary<InteractableBase, int> _inside = new();
        private MaterialPropertyBlock _block;

        // ── API pública ───────────────────────────────────────────────────────

        /// <summary>True si la zona acepta ese objeto (lista vacía = acepta todo).</summary>
        public bool Accepts(InteractableBase item)
        {
            if (Locked) return false;   // 0.3 lote 6
            return AcceptsIgnoringLock(item);
        }

        /// <summary>La lista <c>acceptedIds</c> sola, sin mirar el bloqueo (para elegir qué zona juzga).</summary>
        public bool AcceptsIgnoringLock(InteractableBase item)
        {
            if (item == null) return false;
            if (acceptedIds == null || acceptedIds.Count == 0) return true;
            foreach (var id in acceptedIds)
                if (InteractableRegistry.Matches(id, item)) return true;
            return false;
        }

        /// <summary>True si el interactuable está dentro del trigger ahora mismo.</summary>
        public bool Contains(InteractableBase item) =>
            item != null && _inside.ContainsKey(item);

        public int InsideCount
        {
            get
            {
                Prune();
                return _inside.Count;
            }
        }

        /// <summary>
        /// Evalúa dónde está un objeto respecto a todas las zonas: si está dentro de alguna y si
        /// alguna de las que lo contienen lo acepta.
        /// </summary>
        public static void Evaluate(InteractableBase item, out bool insideAnyZone, out bool acceptedByAny)
        {
            // 0.3 lote 6: lo decide la zona que juzga el soltado (la más pequeña que lo acepta; si ninguna, la más pequeña).
            var judge = JudgeFor(item);
            insideAnyZone = judge != null;
            acceptedByAny = judge != null && judge.Accepts(item);
        }

        // ── Seguimiento del trigger ───────────────────────────────────────────

        protected virtual void OnTriggerEnter(Collider other)
        {
            var item = other.GetComponentInParent<InteractableBase>();
            if (item != null) TrackEnter(item);
        }

        protected virtual void OnTriggerExit(Collider other)
        {
            var item = other.GetComponentInParent<InteractableBase>();
            if (item != null) TrackExit(item);
        }

        private void TrackEnter(InteractableBase item)
        {
            _inside.TryGetValue(item, out int count);
            _inside[item] = count + 1;
            if (count > 0) return;

            item.SelectedEvent += OnItemSelectionChanged;
            item.ReleasedEvent += OnItemReleased;
            RefreshHighlight();
        }

        private void TrackExit(InteractableBase item)
        {
            if (!_inside.TryGetValue(item, out int count)) return;
            if (count > 1)
            {
                _inside[item] = count - 1;
                return;
            }

            _inside.Remove(item);
            item.SelectedEvent -= OnItemSelectionChanged;
            item.ReleasedEvent -= OnItemReleased;
            RefreshHighlight();
        }

        private void OnItemSelectionChanged(InteractableBase item) => RefreshHighlight();

        private void OnItemReleased(InteractableBase item)
        {
            // 0.3 lote 6: todas las zonas que contienen al objeto reciben el mismo soltado; solo la que juzga lo emite, una vez.
            if (item != null && _inside.ContainsKey(item)
                && (!LastJudged.TryGetValue(item, out var last) || last.serial != item.ReleaseSerial))
            {
                var judge = ResolveJudge(item);
                if (judge != null)
                {
                    if (LastJudged.Count > 64) PruneLastJudged();
                    LastJudged[item] = (item.ReleaseSerial, judge);
                    judge.RaiseDropped(item);
                }
            }
            RefreshAllHighlights();
        }

        /// <summary>
        /// Emite el soltado manualmente (drivers y pruebas que no mueven colliders). No comprueba
        /// que el objeto esté dentro del trigger.
        /// </summary>
        public void RaiseDropped(InteractableBase item)
        {
            if (item == null) return;

            // 0.3 lote 6: zona u objeto bloqueado: el soltado no llega a la condición (contrato-0.3.md §2.8).
            if (Locked || item.Locked)
            {
                DropRejectedByLock?.Invoke(item, this);
                return;
            }

            TelemetryHub.Emit(new InteractionEvent
            {
                StepId = TelemetryContext.CurrentStepId,
                InteractionId = $"{ZoneId}<-{item.InteractionId}",
                Kind = "drop"
            });

            Dropped?.Invoke(item, this);
            DroppedAnywhere?.Invoke(item, this);
        }

        private void Update()
        {
            if (_inside.Count == 0) return;
            Prune();
            RefreshHighlight();   // 0.3 lote 6: con `medir: centro` o zonas solapadas, quién juzga cambia sin entrar ni salir
        }

        /// <summary>Quita objetos destruidos o desactivados dentro de la zona (no reciben OnTriggerExit).</summary>
        private void Prune()
        {
            List<InteractableBase> stale = null;
            foreach (var item in _inside.Keys)
            {
                if (item != null && item.isActiveAndEnabled) continue;
                (stale ??= new List<InteractableBase>()).Add(item);
            }
            if (stale == null) return;

            foreach (var item in stale)
            {
                _inside.Remove(item);
                if (item != null)
                {
                    item.SelectedEvent -= OnItemSelectionChanged;
                    item.ReleasedEvent -= OnItemReleased;
                }
            }
            RefreshHighlight();
        }

        // ── Resaltado ─────────────────────────────────────────────────────────

        private void RefreshHighlight()
        {
            bool shouldHighlight = false;
            foreach (var item in _inside.Keys)
            {
                // 0.3 lote 6: solo se resalta la zona que va a juzgar el soltado.
                if (item != null && item.IsSelected && Accepts(item) && ResolveJudge(item) == this)
                {
                    shouldHighlight = true;
                    break;
                }
            }
            SetHighlight(shouldHighlight);
        }

        private void SetHighlight(bool on)
        {
            if (IsHighlighted == on) return;
            IsHighlighted = on;

            if (highlightRenderer != null)
            {
                if (on)
                {
                    _block ??= new MaterialPropertyBlock();
                    highlightRenderer.GetPropertyBlock(_block);
                    _block.SetColor(BaseColorId, highlightColor);
                    _block.SetColor(ColorId, highlightColor);
                    _block.SetColor(EmissionColorId, highlightColor * 0.6f);
                    highlightRenderer.SetPropertyBlock(_block);
                }
                else
                {
                    highlightRenderer.SetPropertyBlock(null);
                }
            }

            onHighlightChanged?.Invoke(on);
            HighlightChanged?.Invoke(on);
        }

        // ── Ciclo de vida ─────────────────────────────────────────────────────

        protected virtual void OnEnable()
        {
            if (!Zones.Contains(this)) Zones.Add(this);
            SceneTargetRegistry.Register(ZoneId, transform);
        }

        protected virtual void OnDisable()
        {
            Zones.Remove(this);
            SceneTargetRegistry.Unregister(ZoneId, transform);

            foreach (var item in _inside.Keys)
            {
                if (item == null) continue;
                item.SelectedEvent -= OnItemSelectionChanged;
                item.ReleasedEvent -= OnItemReleased;
            }
            _inside.Clear();
            SetHighlight(false);
        }

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        // ── 0.3 lote 6: una zona por soltado, `medir` y bloqueos ──────────────

        private static readonly HashSet<string> LockedZoneIds = new();
        // El último soltado juzgado de cada objeto: lo que se decidió antes de que SnapZone lo moviera.
        private static readonly Dictionary<InteractableBase, (int serial, DropZone judge)> LastJudged = new();

        /// <summary>Un soltado cayó en una zona bloqueada, o el objeto estaba bloqueado (LockEnforcer da el feedback).</summary>
        public static event Action<InteractableBase, DropZone> DropRejectedByLock;

        public DropMeasure Measure => measure;

        /// <summary>True si un bloqueo activo nombra esta zona: rechaza todo soltado.</summary>
        public bool Locked => LockedZoneIds.Count > 0 && LockedZoneIds.Contains(ZoneId);

        /// <summary>Bloquea o desbloquea las zonas con ese id (LockEnforcer).</summary>
        public static void SetZoneLocked(string zoneId, bool locked)
        {
            if (string.IsNullOrEmpty(zoneId)) return;
            if (locked) LockedZoneIds.Add(zoneId);
            else LockedZoneIds.Remove(zoneId);
            RefreshAllHighlights();
        }

        public static bool IsZoneLocked(string zoneId) => !string.IsNullOrEmpty(zoneId) && LockedZoneIds.Contains(zoneId);

        /// <summary>
        /// True si el objeto está dentro según <see cref="Measure"/>: Contacto, que el trigger lo tenga; Centro, además, que
        /// el centro de los límites de sus colliders esté dentro del volumen.
        /// </summary>
        public bool Holds(InteractableBase item)
        {
            if (!Contains(item)) return false;
            if (measure == DropMeasure.Contact) return true;
            return ContainsPoint(BoundsCenter(item));
        }

        /// <summary>
        /// La zona que juzga un soltado del objeto ahora: de las activas que lo contienen, la más pequeña que lo acepta
        /// (por su lista, aunque esté bloqueada); si ninguna lo acepta, la más pequeña. Null si ninguna lo contiene.
        /// </summary>
        public static DropZone ResolveJudge(InteractableBase item)
        {
            if (item == null) return null;
            DropZone best = null;
            bool bestAccepts = false;
            float bestVolume = float.PositiveInfinity;
            foreach (var zone in Zones)
            {
                if (zone == null || !zone.isActiveAndEnabled || !zone.Holds(item)) continue;
                bool accepts = zone.AcceptsIgnoringLock(item);
                float volume = zone.Volume();
                bool better = best == null
                    || (accepts && !bestAccepts)
                    || (accepts == bestAccepts && volume < bestVolume);
                if (!better) continue;
                best = zone;
                bestAccepts = accepts;
                bestVolume = volume;
            }
            return best;
        }

        /// <summary>La zona que juzgó el último soltado del objeto, si ya se juzgó; si no, la que lo juzgaría ahora.</summary>
        public static DropZone JudgeFor(InteractableBase item)
        {
            if (item == null) return null;
            if (LastJudged.TryGetValue(item, out var last) && last.serial == item.ReleaseSerial && !item.IsSelected && last.judge != null)
                return last.judge;
            return ResolveJudge(item);
        }

        /// <summary>True si la zona que juzga el soltado del objeto está bloqueada (ReturnToOrigin lo devuelve).</summary>
        public static bool JudgedByLockedZone(InteractableBase item)
        {
            var judge = JudgeFor(item);
            return judge != null && judge.Locked;
        }

        private static void PruneLastJudged()
        {
            var dead = new List<InteractableBase>();
            foreach (var key in LastJudged.Keys) if (key == null) dead.Add(key);
            foreach (var key in dead) LastJudged.Remove(key);
        }

        private static void RefreshAllHighlights()
        {
            foreach (var zone in Zones)
                if (zone != null) zone.RefreshHighlight();
        }

        private float Volume()
        {
            var col = GetComponent<Collider>();
            if (col is BoxCollider box)
            {
                var scale = box.transform.lossyScale;
                return Mathf.Abs(box.size.x * scale.x * box.size.y * scale.y * box.size.z * scale.z);
            }
            if (col == null) return float.PositiveInfinity;
            var size = col.bounds.size;
            return size.x * size.y * size.z;
        }

        private bool ContainsPoint(Vector3 point)
        {
            var col = GetComponent<Collider>();
            if (col == null) return false;
            if (col is BoxCollider box)
            {
                var local = box.transform.InverseTransformPoint(point) - box.center;
                var half = box.size * 0.5f;
                return Mathf.Abs(local.x) <= half.x && Mathf.Abs(local.y) <= half.y && Mathf.Abs(local.z) <= half.z;
            }
            return (col.ClosestPoint(point) - point).sqrMagnitude < 1e-8f;
        }

        private static Vector3 BoundsCenter(InteractableBase item)
        {
            bool any = false;
            var bounds = new Bounds(item.transform.position, Vector3.zero);
            foreach (var col in item.GetComponentsInChildren<Collider>())
            {
                if (col == null || !col.enabled || col.isTrigger) continue;
                if (!any) { bounds = col.bounds; any = true; }
                else bounds.Encapsulate(col.bounds);
            }
            return any ? bounds.center : item.transform.position;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics()
        {
            Zones.Clear();
            DroppedAnywhere = null;
            DropRejectedByLock = null;   // 0.3 lote 6
            LockedZoneIds.Clear();
            LastJudged.Clear();
        }
    }

    /// <summary>0.3 lote 6: `medir` de una zona `soltar` (contrato-0.3.md §3).</summary>
    public enum DropMeasure
    {
        /// <summary>"contacto": algún collider del objeto toca el volumen (como hasta 0.2).</summary>
        Contact,
        /// <summary>"centro": el centro de los límites del objeto está dentro del volumen.</summary>
        Center
    }
}
