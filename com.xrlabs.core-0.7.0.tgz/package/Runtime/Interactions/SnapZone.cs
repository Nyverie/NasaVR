using UnityEngine;
using XRLabs.Core.Telemetry;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Zona de soltado que imanta: cuando un interactuable que la zona acepta se SUELTA dentro, lo lleva entero (su
    /// <c>transform</c>, no el collider que entró) al <see cref="snapPoint"/> y lo deja quieto. Emite InteractionEvent
    /// (kind="snap") al hub de telemetría.
    ///
    /// v0.6: es una <see cref="DropZone"/>: emite Dropped como cualquier zona, también para lo que no acepta (la condición
    /// juzga el error).
    ///
    /// 2026-10-25 (primera prueba en el Quest 3; auditoria-visor-2026-10-18.md, punto 1): hasta aquí imantaba en
    /// <c>OnTriggerEnter</c> cualquier collider que entrara, aceptado o no y aún agarrado, y movía ese collider. Con los
    /// marcadores es el <c>Placeholder</c> hijo, así que el cubo se separaba del objeto y de su etiqueta; y un collider ajeno
    /// (la mano) también habría saltado al punto. Ahora solo imanta al soltar, solo lo aceptado y moviendo el objeto entero;
    /// entrar en la zona no mueve nada.
    /// </summary>
    public class SnapZone : DropZone
    {
        [Tooltip("Punto al que se lleva el objeto aceptado al soltarlo dentro. Vacío = la zona no imanta (solo cuenta, como una DropZone).")]
        public Transform snapPoint;

        [Tooltip("Zona grande (un área, como el acopio): el objeto baja a la altura del snapPoint y queda derecho, pero conserva " +
                 "dónde se soltó en planta (recortado a la huella del BoxCollider de la zona). Apagado = va al snapPoint exacto.")]
        public bool keepHorizontalOffset;

        protected override void OnEnable()
        {
            base.OnEnable();
            Dropped += OnDroppedHere;
        }

        protected override void OnDisable()
        {
            Dropped -= OnDroppedHere;
            base.OnDisable();
        }

        // Dropped llega al soltar dentro (DropZone.OnItemReleased) o por RaiseDropped (drivers y pruebas). XRI ya devolvió el
        // Rigidbody a su estado de antes de agarrar (XRGrabInteractable.Drop, en OnSelectExiting, antes de selectExited), así
        // que lo que se deja aquí no lo pisa XRI.
        private void OnDroppedHere(InteractableBase item, DropZone zone)
        {
            if (snapPoint == null || item == null || !Accepts(item)) return;

            var target = item.transform;
            if (keepHorizontalOffset) target.SetPositionAndRotation(FloorPoint(target.position), Upright(target.rotation));
            else target.SetPositionAndRotation(snapPoint.position, snapPoint.rotation);

            // Imantado = quieto: un cuerpo dinámico se para y queda cinemático, para que no caiga ni lo empuje nada. La
            // velocidad solo se toca si no era cinemático (Unity avisa al escribirla en uno cinemático). Con el cuerpo
            // cinemático, el lanzamiento de XRI al final del cuadro de soltar (throwOnDetach) tampoco lo mueve.
            var body = target.GetComponent<Rigidbody>();
            if (body != null)
            {
                if (!body.isKinematic)
                {
                    body.linearVelocity = Vector3.zero;
                    body.angularVelocity = Vector3.zero;
                }
                body.isKinematic = true;
            }

            TelemetryHub.Emit(new InteractionEvent
            {
                StepId = TelemetryContext.CurrentStepId,
                InteractionId = $"{ZoneId}<-{item.InteractionId}",
                Kind = "snap"
            });
        }

        // 2026-10-25 (segundo recorrido en el Quest 3): en el acopio, que recibe cuatro materiales, imantar al centro los
        // apilaba en el mismo punto. Aquí cada uno queda donde se soltó en planta, dentro de la huella, y en el suelo.
        private Vector3 FloorPoint(Vector3 released)
        {
            var local = transform.InverseTransformPoint(released);
            if (TryGetComponent(out BoxCollider box))
            {
                Vector3 half = box.size * 0.5f;
                local.x = Mathf.Clamp(local.x, box.center.x - half.x, box.center.x + half.x);
                local.z = Mathf.Clamp(local.z, box.center.z - half.z, box.center.z + half.z);
            }
            local.y = transform.InverseTransformPoint(snapPoint.position).y;
            return transform.TransformPoint(local);
        }

        // Derecho sobre el suelo: conserva solo el giro alrededor de la vertical (un balde soltado inclinado queda de pie).
        private static Quaternion Upright(Quaternion rotation) =>
            Quaternion.Euler(0f, rotation.eulerAngles.y, 0f);
    }
}
