using UnityEngine;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Herramienta "cargada" que una <see cref="SourcePile"/> pone en la mano: un interactuable
    /// ligero que sigue a la mano (XR) o al puntero (modo plano) y que las DropZone ven como
    /// cualquier otro objeto. Su <see cref="SourceId"/> dice de qué pila viene, así una condición
    /// distingue "estiércol" de "hojas" aunque ambos sean el mismo prefab.
    /// </summary>
    public class CarriedItem : InteractableBase, IDragSource
    {
        private Transform _follow;
        private Vector3 _localOffset;

        /// <summary>Id de la pila de origen (SourcePile.SourceId).</summary>
        public string SourceId { get; private set; }

        public SourcePile Pile { get; private set; }

        public Transform DragTarget => transform;

        public void Setup(SourcePile pile, string sourceId)
        {
            Pile = pile;
            SourceId = sourceId;
        }

        /// <summary>Hace que la herramienta siga a un Transform (la mano) con un desfase local.</summary>
        public void Follow(Transform target, Vector3 localOffset = default)
        {
            _follow = target;
            _localOffset = localOffset;
            if (_follow != null) transform.position = _follow.TransformPoint(_localOffset);
        }

        public void StopFollowing() => _follow = null;

        /// <summary>Mueve la herramienta (drivers no-XR).</summary>
        public void MoveTo(Vector3 worldPosition) => transform.position = worldPosition;

        private void LateUpdate()
        {
            if (_follow != null) transform.position = _follow.TransformPoint(_localOffset);
        }
    }
}
