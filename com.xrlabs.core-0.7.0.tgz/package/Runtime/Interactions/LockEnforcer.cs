using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// 0.3 lote 6: aplica los <c>bloqueos</c> del guion (contrato-0.3.md §2.8), que el importador deja en
    /// <see cref="SimulationSequence.locks"/>. Un bloqueo rige desde que empieza el paso <c>desde</c> (o desde el inicio)
    /// hasta que se completa el paso <c>hasta</c>. Mientras rige:
    /// - la zona rechaza todo soltado: no llega a la condición y ReturnToOrigin devuelve el objeto;
    /// - el objeto no responde: no se agarra (XRI cancela la selección) y el hotspot o botón no se activa.
    /// El feedback: si el bloqueo trae <c>clave</c> y el paso en curso la declara en sus errores, se reporta como error del
    /// paso (StepSystem.ReportError: corrección, cuenta y <c>step_error</c>); si no, no se dice ni cuenta.
    /// Lo añade «Preparar escena» en [Simulation] solo si el guion trae bloqueos.
    /// </summary>
    public class LockEnforcer : MonoBehaviour
    {
        [Tooltip("StepSystem cuya secuencia trae los bloqueos. Vacío = el del mismo GameObject.")]
        [SerializeField] private StepSystem stepSystem;

        /// <summary>Se tocó algo bloqueado (bloqueo, objeto). Se emite aunque el paso no declare la clave.</summary>
        public event Action<StepLock, InteractableBase> LockHit;

        private SimulationSequence _sequence;
        private readonly HashSet<StepLock> _active = new();
        // Posición en el recorrido: 2·índice al empezar un paso, 2·índice + 1 al completarlo; -1 antes de empezar.
        private int _position = -1;
        private bool _finished;
        private bool _bound;

        /// <summary>Bloqueos que rigen ahora.</summary>
        public IReadOnlyCollection<StepLock> ActiveLocks => _active;

        /// <summary>Usa otra secuencia y otro StepSystem (pruebas, o escenas montadas a mano).</summary>
        public void Configure(SimulationSequence sequence, StepSystem steps)
        {
            Unbind();
            _sequence = sequence;
            stepSystem = steps;
            Bind();
            Refresh();
        }

        /// <summary>Recalcula qué bloqueos rigen en una posición dada (pruebas y saltos).</summary>
        public void SetPosition(int stepIndex, bool completed)
        {
            _finished = false;
            _position = stepIndex < 0 ? -1 : stepIndex * 2 + (completed ? 1 : 0);
            Refresh();
        }

        private void Awake()
        {
            if (stepSystem == null) stepSystem = GetComponent<StepSystem>();
        }

        private void OnEnable()
        {
            if (_sequence == null && stepSystem != null) _sequence = stepSystem.Sequence;
            Bind();
            Refresh();
        }

        private void OnDisable()
        {
            Unbind();
            ReleaseAll();
        }

        private void Bind()
        {
            if (_bound) return;
            _bound = true;
            DropZone.DropRejectedByLock += OnDropRejected;
            InteractableBase.LockedInteractionAnywhere += OnLockedInteraction;
            if (stepSystem == null) return;
            stepSystem.StepStarted += OnStepStarted;
            stepSystem.StepCompleted += OnStepCompleted;
            stepSystem.StepsFinished += OnStepsFinished;
        }

        private void Unbind()
        {
            if (!_bound) return;
            _bound = false;
            DropZone.DropRejectedByLock -= OnDropRejected;
            InteractableBase.LockedInteractionAnywhere -= OnLockedInteraction;
            if (stepSystem == null) return;
            stepSystem.StepStarted -= OnStepStarted;
            stepSystem.StepCompleted -= OnStepCompleted;
            stepSystem.StepsFinished -= OnStepsFinished;
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => SetPosition(index, false);

        private void OnStepCompleted(StepDefinition step, int index, float elapsed) => SetPosition(index, true);

        private void OnStepsFinished()
        {
            _finished = true;
            Refresh();
        }

        private void Refresh()
        {
            if (_sequence == null && stepSystem != null) _sequence = stepSystem.Sequence;
            var locks = _sequence != null ? _sequence.locks : null;
            var steps = _sequence != null ? _sequence.steps : null;

            var now = new HashSet<StepLock>();
            if (locks != null && !_finished)
            {
                foreach (var l in locks)
                {
                    if (l == null) continue;
                    int until = StepLock.ResolveIndex(steps, l.untilStepId, last: true);
                    if (until < 0) continue;   // el validador ya lo marca como error
                    int from = string.IsNullOrEmpty(l.fromStepId) ? -1 : StepLock.ResolveIndex(steps, l.fromStepId, last: false);
                    int fromPosition = from < 0 ? -1 : from * 2;
                    if (_position >= fromPosition && _position <= until * 2) now.Add(l);
                }
            }

            // Primero se sueltan los que dejan de regir; después se fijan los que rigen (dos bloqueos pueden nombrar lo mismo).
            foreach (var l in _active)
                if (!now.Contains(l)) SetLocked(l, false);
            _active.Clear();
            foreach (var l in now)
            {
                _active.Add(l);
                SetLocked(l, true);
            }
        }

        private void ReleaseAll()
        {
            foreach (var l in _active) SetLocked(l, false);
            _active.Clear();
        }

        private static void SetLocked(StepLock l, bool locked)
        {
            if (l.IsZone) DropZone.SetZoneLocked(l.zoneId, locked);
            else InteractableBase.SetObjectLocked(l.objectId, locked);
        }

        private void OnDropRejected(InteractableBase item, DropZone zone)
        {
            // La zona primero: es lo que la persona intentó (soltar ahí).
            if (zone != null && zone.Locked && TryFind(l => l.IsZone && l.zoneId == zone.ZoneId, out var byZone))
                Hit(byZone, item);
            else if (item != null && TryFind(l => !l.IsZone && InteractableRegistry.Matches(l.objectId, item), out var byObject))
                Hit(byObject, item);
        }

        private void OnLockedInteraction(InteractableBase item)
        {
            if (item != null && TryFind(l => !l.IsZone && InteractableRegistry.Matches(l.objectId, item), out var l))
                Hit(l, item);
        }

        private bool TryFind(Predicate<StepLock> match, out StepLock found)
        {
            foreach (var l in _active)
            {
                if (!match(l)) continue;
                found = l;
                return true;
            }
            found = null;
            return false;
        }

        private void Hit(StepLock l, InteractableBase item)
        {
            LockHit?.Invoke(l, item);
            if (string.IsNullOrEmpty(l.errorKey) || stepSystem == null) return;
            var step = stepSystem.CurrentStep;
            if (step == null) return;
            step.GetErrorLine(l.errorKey, out bool declared);
            if (declared) stepSystem.ReportError(l.errorKey);
        }
    }
}
