using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    /// <summary>Qué cuenta como "mantener" el botón.</summary>
    public enum HoldMode
    {
        /// <summary>Mientras está agarrado/seleccionado (grip, o press del mouse/touch en modo plano).</summary>
        Select,
        /// <summary>Mientras está activado (gatillo).</summary>
        Activate,
        /// <summary>Cualquiera de los dos.</summary>
        SelectOrActivate
    }

    /// <summary>Qué pasa con el valor al dejar de mantener.</summary>
    public enum HoldReleaseBehaviour
    {
        /// <summary>Conserva el valor (se retoma al volver a mantener).</summary>
        Keep,
        /// <summary>Vuelve a 0 al soltar.</summary>
        Reset,
        /// <summary>Baja poco a poco (decaySeconds de 1 a 0).</summary>
        Decay
    }

    /// <summary>
    /// Botón de mantener (time-lapse "avanzar días"): mantenerlo sube un valor 0–1 durante
    /// <c>holdSeconds</c>. El interactuable solo informa el valor; la HoldCondition juzga.
    /// </summary>
    [RequireComponent(typeof(XRSimpleInteractable))]
    public class HoldButton : InteractableBase
    {
        [Header("Mantener")]
        [SerializeField] private HoldMode holdMode = HoldMode.SelectOrActivate;

        [Tooltip("Segundos manteniendo para llegar de 0 a 1.")]
        [SerializeField, Min(0.01f)] private float holdSeconds = 3f;

        [SerializeField] private HoldReleaseBehaviour releaseBehaviour = HoldReleaseBehaviour.Keep;

        [Tooltip("Solo con Decay: segundos para bajar de 1 a 0.")]
        [SerializeField, Min(0.01f)] private float decaySeconds = 2f;

        /// <summary>Valor 0–1.</summary>
        public float Value { get; private set; }

        /// <summary>True si el valor llegó a 1 (hasta ResetValue()).</summary>
        public bool IsFull { get; private set; }

        public float HoldSeconds => holdSeconds;

        /// <summary>True mientras se cumple el modo de mantener.</summary>
        public bool IsHeld => holdMode switch
        {
            HoldMode.Select => IsSelected,
            HoldMode.Activate => IsActivated,
            _ => IsSelected || IsActivated
        };

        /// <summary>Cambió el valor 0–1.</summary>
        public event Action<float> ValueChanged;

        /// <summary>El valor llegó a 1 (una vez hasta ResetValue()).</summary>
        public event Action<HoldButton> Completed;

        private XRSimpleInteractable _xr;
        private bool _wasHeld;

        private void Awake() => _xr = GetComponent<XRSimpleInteractable>();

        private void OnEnable()
        {
            _xr.hoverEntered.AddListener(OnHoverEntered);
            _xr.hoverExited.AddListener(OnHoverExited);
            _xr.selectEntered.AddListener(OnSelectEntered);
            _xr.selectExited.AddListener(OnSelectExited);
            _xr.activated.AddListener(OnActivated);
            _xr.deactivated.AddListener(OnDeactivated);
        }

        private void OnDisable()
        {
            _xr.hoverEntered.RemoveListener(OnHoverEntered);
            _xr.hoverExited.RemoveListener(OnHoverExited);
            _xr.selectEntered.RemoveListener(OnSelectEntered);
            _xr.selectExited.RemoveListener(OnSelectExited);
            _xr.activated.RemoveListener(OnActivated);
            _xr.deactivated.RemoveListener(OnDeactivated);
        }

        private void OnHoverEntered(HoverEnterEventArgs _) => RaiseHovered();
        private void OnHoverExited(HoverExitEventArgs _) => RaiseUnhovered();
        private void OnSelectEntered(SelectEnterEventArgs _) => RaiseSelected();
        private void OnSelectExited(SelectExitEventArgs _) => RaiseReleased();
        private void OnActivated(ActivateEventArgs _) => RaiseActivated();
        private void OnDeactivated(DeactivateEventArgs _) => RaiseDeactivated();

        private void Update() => Tick(Time.deltaTime);

        /// <summary>Avanza el valor dt segundos (Update lo llama; los tests lo llaman directo).</summary>
        public void Tick(float dt)
        {
            bool held = IsHeld;

            if (_wasHeld && !held && releaseBehaviour == HoldReleaseBehaviour.Reset)
                SetValue(0f);
            _wasHeld = held;

            if (held)
            {
                SetValue(Value + dt / holdSeconds);
            }
            else if (releaseBehaviour == HoldReleaseBehaviour.Decay && Value > 0f)
            {
                SetValue(Value - dt / decaySeconds);
            }
        }

        /// <summary>Vuelve a 0 y permite volver a completar.</summary>
        public void ResetValue()
        {
            IsFull = false;
            SetValue(0f);
        }

        private void SetValue(float value)
        {
            value = Mathf.Clamp01(value);
            if (Mathf.Approximately(value, Value)) return;

            Value = value;
            ValueChanged?.Invoke(Value);

            if (Value >= 1f && !IsFull)
            {
                IsFull = true;
                Completed?.Invoke(this);
            }
        }
    }
}
