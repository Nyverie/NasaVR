using UnityEngine;
using UnityEngine.InputSystem;

namespace XRLabs.Interactions
{
    public class InspectTestInputSystem : MonoBehaviour
    {
        public InspectController inspectController;

    #if UNITY_EDITOR
        // Atajos de teclado I/O: solo para pruebas de escritorio en el Editor.
        private void Update()
        {
            if (Keyboard.current == null) return;

            if (Keyboard.current.iKey.wasPressedThisFrame)
            {
                Debug.Log("I presionada");
                inspectController.StartInspection();
            }

            if (Keyboard.current.oKey.wasPressedThisFrame)
            {
                Debug.Log("O presionada");
                inspectController.EndInspection();
            }
        }
    #endif
    }
}
