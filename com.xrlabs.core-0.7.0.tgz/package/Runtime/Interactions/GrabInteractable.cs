using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    /// <summary>Wrapper legado de logging. Reemplazado por GrabbableItem.</summary>
    [System.Obsolete("Usar GrabbableItem — implementa el contrato InteractableBase con eventos y telemetría.")]
    public class GrabInteractable : MonoBehaviour
    {
        private XRGrabInteractable grab;

        private void Awake()
        {
            grab = GetComponent<XRGrabInteractable>();
        }

        private void OnEnable()
        {
            grab.selectEntered.AddListener(OnGrabbed);
            grab.selectExited.AddListener(OnReleased);
        }

        private void OnDisable()
        {
            grab.selectEntered.RemoveListener(OnGrabbed);
            grab.selectExited.RemoveListener(OnReleased);
        }

        private void OnGrabbed(SelectEnterEventArgs args)
        {
            Debug.Log($"{name} agarrado");
        }

        private void OnReleased(SelectExitEventArgs args)
        {
            Debug.Log($"{name} soltado");
        }
    }
}
