using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Punto tocable (hotspot). Se activa por hover-touch o select del XRI.
    /// Versión con contrato del framework — el HotspotMarker de Simulations
    /// migrará a esta base cuando se re-cablee la escena (ver F7).
    /// </summary>
    [RequireComponent(typeof(XRSimpleInteractable))]
    public class TouchableHotspot : InteractableBase
    {
        [Header("Comportamiento")]
        [Tooltip("Si está activo, el hotspot se dispara con solo tocarlo (hover del poke); si no, requiere select.")]
        [SerializeField] private bool triggerOnTouch = true;

        [Tooltip("Un hotspot ya tocado no vuelve a disparar hasta ResetHotspot().")]
        [SerializeField] private bool oneShot = true;

        public bool WasTouched { get; private set; }

        private XRSimpleInteractable _interactable;

        private void Awake()
        {
            _interactable = GetComponent<XRSimpleInteractable>();
        }

        private void OnEnable()
        {
            _interactable.hoverEntered.AddListener(_ => HandleTouch(fromHover: true));
            _interactable.hoverExited.AddListener(_ => RaiseUnhovered());
            _interactable.selectEntered.AddListener(_ => HandleTouch(fromHover: false));
        }

        private void OnDisable()
        {
            _interactable.hoverEntered.RemoveAllListeners();
            _interactable.hoverExited.RemoveAllListeners();
            _interactable.selectEntered.RemoveAllListeners();
        }

        // ── XR al día 2026-10-31: el rayo «pega» al hotspot ─────────────────────
        // Informe «OpenXR, Android XR y XRI al día», P6: un XRInteractableSnapVolume en un hijo, con una esfera trigger
        // algo mayor que el hotspot, hace que el rayo del NearFarInteractor salte al objetivo cuando pasa cerca (el
        // CurveInteractionCaster consulta los snap volumes por defecto). Solo con un visor activo: en el modo plano el
        // FlatInteractionDriver tomaría la esfera como parte del hotspot y taparía lo que hay detrás. XRI no cuenta los
        // triggers entre los colliders del interactuable, así que el toque cercano sigue usando el collider de siempre.

        public const string SnapVolumeName = "SnapVolume";

        protected override void Start()
        {
            base.Start();
            if (XRSettings.isDeviceActive) EnsureSnapVolume();
        }

        /// <summary>Crea (una sola vez) el snap volume del hotspot y lo devuelve.</summary>
        public XRInteractableSnapVolume EnsureSnapVolume()
        {
            var existing = GetComponentInChildren<XRInteractableSnapVolume>(true);
            if (existing != null) return existing;
            if (_interactable == null) _interactable = GetComponent<XRSimpleInteractable>();

            var bounds = new Bounds(transform.position, Vector3.zero);
            bool any = false;
            foreach (var c in GetComponentsInChildren<Collider>(true))
            {
                if (c.isTrigger) continue;
                if (!any) { bounds = c.bounds; any = true; } else bounds.Encapsulate(c.bounds);
            }

            var snapObject = new GameObject(SnapVolumeName) { layer = 2 };   // Ignore Raycast: los Physics.Raycast por defecto no la ven
            snapObject.transform.SetParent(transform, false);
            var sphere = snapObject.AddComponent<SphereCollider>();
            sphere.isTrigger = true;
            var scale = transform.lossyScale;
            float maxScale = Mathf.Max(0.0001f, Mathf.Abs(scale.x), Mathf.Abs(scale.y), Mathf.Abs(scale.z));
            float worldRadius = Mathf.Clamp(Mathf.Max(bounds.extents.x, bounds.extents.y, bounds.extents.z) * 1.6f, 0.06f, 0.35f);
            sphere.radius = worldRadius / maxScale;
            sphere.center = transform.InverseTransformPoint(bounds.center);
            var snap = snapObject.AddComponent<XRInteractableSnapVolume>();
            snap.interactableObject = _interactable;
            snap.snapCollider = sphere;
            return snap;
        }

        public void ResetHotspot()
        {
            WasTouched = false;
        }

        /// <summary>Dispara el touch respetando oneShot. Usable por drivers no-XR.</summary>
        public void Touch()
        {
            if (oneShot && WasTouched) return;

            WasTouched = true;
            RaiseActivated();
        }

        private void HandleTouch(bool fromHover)
        {
            if (fromHover)
            {
                RaiseHovered();
                if (!triggerOnTouch) return;
            }

            Touch();
        }
    }
}
