using System;
using System.Collections;
using UnityEngine;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Recuerda la pose inicial del objeto y lo devuelve (animado) al soltarlo en un lugar que
    /// no lo acepta. Va en el mismo GameObject que el InteractableBase.
    ///
    /// Al soltar:
    /// - fuera de toda DropZone            → vuelve (soltar fuera NO es un error)
    /// - dentro de una zona que lo acepta  → se queda, salvo <c>returnAfterAcceptedDrop</c>
    /// - dentro de zonas que no lo aceptan → vuelve (<c>returnWhenZoneRejects</c>)
    /// - 0.3 lote 6: objeto bloqueado, o zona que juzga bloqueada → vuelve siempre
    /// </summary>
    public class ReturnToOrigin : MonoBehaviour
    {
        [Tooltip("Duración de la animación de regreso.")]
        [SerializeField, Min(0f)] private float returnSeconds = 0.4f;

        [Tooltip("Si está activo, también vuelve tras soltarse en una zona que lo acepta " +
                 "(ej: una herramienta que se usa y se devuelve a la mesa).")]
        [SerializeField] private bool returnAfterAcceptedDrop;

        [Tooltip("Si está activo, vuelve cuando se suelta en una zona que NO lo acepta.")]
        [SerializeField] private bool returnWhenZoneRejects = true;

        [Tooltip("Espera tras soltar antes de volver (para que se vea dónde quedó).")]
        [SerializeField, Min(0f)] private float delaySeconds;

        public Vector3 OriginPosition { get; private set; }
        public Quaternion OriginRotation { get; private set; }
        public bool IsReturning { get; private set; }

        /// <summary>El objeto terminó de volver a su pose de origen.</summary>
        public event Action<ReturnToOrigin> Returned;

        private InteractableBase _item;
        private Coroutine _routine;

        private void Awake() => SetOrigin();

        private void OnEnable()
        {
            _item = GetComponent<InteractableBase>();
            if (_item == null)
            {
                Debug.LogWarning($"[ReturnToOrigin] '{name}' no tiene InteractableBase; solo funcionará con ReturnNow().", this);
                return;
            }
            _item.ReleasedEvent += OnReleased;
            _item.SelectedEvent += OnSelected;
        }

        private void OnDisable()
        {
            if (_item != null)
            {
                _item.ReleasedEvent -= OnReleased;
                _item.SelectedEvent -= OnSelected;
            }
            CancelReturn();
        }

        /// <summary>Toma la pose actual como origen.</summary>
        public void SetOrigin() => SetOrigin(transform.position, transform.rotation);

        public void SetOrigin(Vector3 position, Quaternion rotation)
        {
            OriginPosition = position;
            OriginRotation = rotation;
        }

        /// <summary>Vuelve al origen ahora (animado), sin evaluar zonas.</summary>
        public void ReturnNow()
        {
            CancelReturn();
            _routine = StartCoroutine(ReturnRoutine(0f));
        }

        private void OnSelected(InteractableBase item) => CancelReturn();

        private void OnReleased(InteractableBase item)
        {
            DropZone.Evaluate(item, out bool inZone, out bool accepted);

            bool shouldReturn = !inZone
                || (accepted ? returnAfterAcceptedDrop : returnWhenZoneRejects);
            // 0.3 lote 6: un objeto bloqueado, o soltado en una zona bloqueada, vuelve siempre (contrato-0.3.md §2.8).
            if (item != null && (item.Locked || DropZone.JudgedByLockedZone(item))) shouldReturn = true;
            if (!shouldReturn) return;

            CancelReturn();
            _routine = StartCoroutine(ReturnRoutine(delaySeconds));
        }

        private void CancelReturn()
        {
            if (_routine != null)
            {
                StopCoroutine(_routine);
                _routine = null;
            }
            RestorePhysics();
            IsReturning = false;
        }

        private Rigidbody _rb;
        private bool _rbWasKinematic;
        private bool _rbOverridden;

        private IEnumerator ReturnRoutine(float delay)
        {
            // Un frame: XRI aún está devolviendo el Rigidbody a su estado normal al soltar.
            yield return null;
            if (delay > 0f) yield return new WaitForSeconds(delay);

            // Se volvió a agarrar mientras esperábamos.
            if (_item != null && _item.IsSelected)
            {
                _routine = null;
                yield break;
            }

            IsReturning = true;
            TakePhysics();

            Vector3 fromPos = transform.position;
            Quaternion fromRot = transform.rotation;
            float t = 0f;
            while (t < returnSeconds)
            {
                t += Time.deltaTime;
                float k = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(t / returnSeconds));
                transform.SetPositionAndRotation(
                    Vector3.Lerp(fromPos, OriginPosition, k),
                    Quaternion.Slerp(fromRot, OriginRotation, k));
                yield return null;
            }

            transform.SetPositionAndRotation(OriginPosition, OriginRotation);
            RestorePhysics();
            IsReturning = false;
            _routine = null;
            Returned?.Invoke(this);
        }

        /// <summary>Congela la física mientras se anima para que no luche con la gravedad.</summary>
        private void TakePhysics()
        {
            _rb = GetComponent<Rigidbody>();
            if (_rb == null || _rbOverridden) return;

            _rbWasKinematic = _rb.isKinematic;
            if (!_rb.isKinematic)
            {
                _rb.linearVelocity = Vector3.zero;
                _rb.angularVelocity = Vector3.zero;
            }
            _rb.isKinematic = true;
            _rbOverridden = true;
        }

        private void RestorePhysics()
        {
            if (!_rbOverridden || _rb == null)
            {
                _rbOverridden = false;
                return;
            }

            _rb.isKinematic = _rbWasKinematic;
            if (!_rbWasKinematic)
            {
                _rb.linearVelocity = Vector3.zero;
                _rb.angularVelocity = Vector3.zero;
            }
            _rbOverridden = false;
        }
    }
}
