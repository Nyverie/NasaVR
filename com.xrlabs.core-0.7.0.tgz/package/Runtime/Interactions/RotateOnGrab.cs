using UnityEngine;
using UnityEngine.InputSystem;

namespace XRLabs.Interactions
{
    public class RotateOnGrab : MonoBehaviour
    {
        public float rotationSpeed = 100f;

        private InspectController inspect;

        private void Awake()
        {
            inspect = GetComponent<InspectController>();
        }

    #if UNITY_EDITOR
        // Rotación con mouse: solo para pruebas de escritorio en el Editor.
        private void Update()
        {
            if (inspect == null || !inspect.IsInspecting()) return;

            if (Mouse.current == null) return;

            Vector2 mouseDelta = Mouse.current.delta.ReadValue();

            float x = mouseDelta.x;
            float y = mouseDelta.y;

            transform.Rotate(Vector3.up, -x * rotationSpeed * Time.deltaTime);
            transform.Rotate(Vector3.right, y * rotationSpeed * Time.deltaTime);
        }
    #endif
    }
}
