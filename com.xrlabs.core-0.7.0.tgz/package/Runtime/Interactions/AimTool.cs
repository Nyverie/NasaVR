using System;
using System.Collections.Generic;
using UnityEngine;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Herramienta de apuntar (manguera, pistola de agua, linterna, regadera): mientras está
    /// agarrada Y activada (gatillo) lanza un rayo desde la punta cada frame y acumula los
    /// segundos que apunta a cada objetivo (por id). Solo informa; la AimCondition juzga.
    ///
    /// Id del objetivo: InteractionId del interactuable, TargetId del SceneTarget o ZoneId de la DropZone
    /// que golpea el rayo. Un collider sólido sin id bloquea el rayo; un trigger sin id se ignora.
    /// Modo plano: el driver mantiene el press y apunta con <see cref="SetExternalRay"/> (rayo del puntero).
    /// </summary>
    public class AimTool : GrabbableItem
    {
        [Header("Apuntado")]
        [Tooltip("Punta del rayo (sale por su forward). Vacío = este Transform.")]
        [SerializeField] private Transform tip;

        [SerializeField, Min(0.1f)] private float maxDistance = 6f;
        [SerializeField] private LayerMask aimMask = ~0;

        [Tooltip("Exigir el gatillo (activar) además de agarrar. Desactivado: basta con tenerla agarrada.")]
        [SerializeField] private bool requireActivate = true;

        /// <summary>Se acumuló tiempo sobre un objetivo: (id, segundos totales sobre ese objetivo).</summary>
        public event Action<string, float> AimProgress;

        /// <summary>Cambió el objetivo apuntado (null = ninguno).</summary>
        public event Action<string> AimTargetChanged;

        /// <summary>Tick en cualquier AimTool: (herramienta, id, segundos de este tick). Para condiciones.</summary>
        public static event Action<AimTool, string, float> AimTickAnywhere;

        /// <summary>True mientras está agarrada (y activada, si se exige).</summary>
        public bool IsAiming => IsSelected && (!requireActivate || IsActivated);

        /// <summary>Id del objetivo que se apunta ahora (null si ninguno).</summary>
        public string CurrentTargetId { get; private set; }

        public Transform Tip => tip != null ? tip : transform;

        private readonly Dictionary<string, float> _seconds = new();
        private static readonly RaycastHit[] HitBuffer = new RaycastHit[32];
        private Ray _externalRay;
        private bool _hasExternalRay;

        /// <summary>Segundos acumulados sobre un objetivo.</summary>
        public float GetSeconds(string targetId) =>
            !string.IsNullOrEmpty(targetId) && _seconds.TryGetValue(targetId, out float s) ? s : 0f;

        public void ResetSeconds() => _seconds.Clear();

        /// <summary>Apunta con un rayo externo (puntero en modo plano) en vez de la punta.</summary>
        public void SetExternalRay(Ray ray)
        {
            _externalRay = ray;
            _hasExternalRay = true;
        }

        public void ClearExternalRay() => _hasExternalRay = false;

        private void Update() => Tick(Time.deltaTime);

        /// <summary>Un paso de apuntado de dt segundos: rayo, id del objetivo y acumulación.</summary>
        public void Tick(float dt)
        {
            if (!IsAiming)
            {
                SetCurrent(null);
                return;
            }

            Ray ray = _hasExternalRay ? _externalRay : new Ray(Tip.position, Tip.forward);
            string id = FindTargetId(ray);
            SetCurrent(id);
            if (id == null || dt <= 0f) return;

            float total = GetSeconds(id) + dt;
            _seconds[id] = total;
            AimProgress?.Invoke(id, total);
            AimTickAnywhere?.Invoke(this, id, dt);
        }

        private string FindTargetId(Ray ray)
        {
            int count = Physics.RaycastNonAlloc(ray, HitBuffer, maxDistance, aimMask, QueryTriggerInteraction.Collide);

            // Ordenar por distancia (RaycastNonAlloc no garantiza orden).
            Array.Sort(HitBuffer, 0, count, DistanceComparer.Instance);

            for (int i = 0; i < count; i++)
            {
                var col = HitBuffer[i].collider;
                if (col == null || col.transform.IsChildOf(transform)) continue;

                string id = InteractableRegistry.ResolveTargetId(col);
                if (!string.IsNullOrEmpty(id)) return id;
                if (!col.isTrigger) return null; // un sólido sin id tapa lo de atrás
            }
            return null;
        }

        private void SetCurrent(string id)
        {
            if (id == CurrentTargetId) return;
            CurrentTargetId = id;
            AimTargetChanged?.Invoke(id);
        }

        private sealed class DistanceComparer : IComparer<RaycastHit>
        {
            public static readonly DistanceComparer Instance = new();
            public int Compare(RaycastHit a, RaycastHit b) => a.distance.CompareTo(b.distance);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() => AimTickAnywhere = null;
    }
}
