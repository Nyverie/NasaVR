using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Haptics;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Implementación XRI de la vibración del FeedbackSystem: envía el pulso a los
    /// HapticImpulsePlayer del rig (mandos). Colocar en el rig o en cualquier GO de escena.
    /// Sin players asignados, los busca en la escena al habilitarse.
    /// </summary>
    public class XRHapticsProvider : MonoBehaviour, IHapticsProvider
    {
        [SerializeField] private List<HapticImpulsePlayer> players = new();

        private void OnEnable()
        {
            if (players.Count == 0)
                players.AddRange(FindObjectsByType<HapticImpulsePlayer>(FindObjectsInactive.Exclude, FindObjectsSortMode.None));

            FeedbackSystem.Haptics = this;
        }

        private void OnDisable()
        {
            if (ReferenceEquals(FeedbackSystem.Haptics, this))
                FeedbackSystem.Haptics = null;
        }

        public void Pulse(float amplitude, float durationSeconds)
        {
            if (amplitude <= 0f || durationSeconds <= 0f) return;
            foreach (var player in players)
                if (player != null && player.isActiveAndEnabled)
                    player.SendHapticImpulse(amplitude, durationSeconds);
        }
    }
}
