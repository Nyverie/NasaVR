using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace XRLabs.Interactions
{
    /// <summary>Cómo se mide el recorrido frotando.</summary>
    public enum ScrubMetric
    {
        /// <summary>Distancia 3D recorrida.</summary>
        Distance3D,
        /// <summary>|Δ a lo largo del eje X local| + 0.5 × |Δ a lo largo del eje Y local| (vaivén horizontal).</summary>
        Lateral
    }

    /// <summary>
    /// Superficie que se frota (lijar, limpiar, remover): acumula el recorrido de una herramienta
    /// agarrada o de la mano/control mientras se mueve DENTRO de su trigger, y lo normaliza a 0–1
    /// según <c>requiredDistance</c>. La ScrubCondition juzga el progreso.
    /// Modo plano: el FlatInteractionDriver arrastra sobre la superficie (<see cref="DriverScrub"/>)
    /// o el usuario arrastra una herramienta por encima.
    /// </summary>
    public class ScrubSurface : InteractableBase
    {
        [Header("Progreso")]
        [Tooltip("Recorrido total (metros) que equivale a progreso 1.")]
        [SerializeField, Min(0.01f)] private float requiredDistance = 1f;
        [SerializeField] private ScrubMetric metric = ScrubMetric.Distance3D;

        [Tooltip("Movimientos por frame menores a esto (metros) se ignoran como temblor de la mano.")]
        [SerializeField, Min(0f)] private float jitterThreshold = 0.0005f;

        [Header("Quién frota")]
        [Tooltip("Ids de herramientas válidas (InteractionId). Vacío = cualquiera.")]
        [SerializeField] private List<string> toolIds = new();

        [Tooltip("Las herramientas (InteractableBase) solo cuentan mientras están agarradas.")]
        [SerializeField] private bool requireToolSelected = true;

        [Tooltip("La mano/control (XR interactor) también frota, sin herramienta.")]
        [SerializeField] private bool allowHands = true;

        /// <summary>Progreso normalizado 0–1.</summary>
        public float Progress => Mathf.Clamp01(_distance / requiredDistance);

        public float AccumulatedDistance => _distance;
        public float RequiredDistance => requiredDistance;
        public bool IsCompleted { get; private set; }

        /// <summary>Cambió el progreso (0–1).</summary>
        public event Action<float> ProgressChanged;

        /// <summary>El progreso llegó a 1 (una vez hasta ResetProgress()).</summary>
        public event Action<ScrubSurface> Completed;

        private readonly Dictionary<Collider, Vector3> _movers = new();
        private readonly List<Collider> _scratch = new();
        private float _distance;

        // ── API ───────────────────────────────────────────────────────────────

        /// <summary>Suma recorrido directamente (metros, ya medido).</summary>
        public void AddDistance(float meters)
        {
            if (meters <= 0f || IsCompleted) return;

            float before = Progress;
            _distance += meters;
            if (!Mathf.Approximately(before, Progress)) ProgressChanged?.Invoke(Progress);

            if (Progress >= 1f)
            {
                IsCompleted = true;
                Completed?.Invoke(this);
                RaiseActivated(); // telemetría: la superficie quedó terminada
            }
        }

        /// <summary>Frota con un desplazamiento en mundo. Aplica la métrica y el umbral de temblor.</summary>
        public void DriverScrub(Vector3 worldDelta)
        {
            float amount = Measure(worldDelta);
            if (amount < jitterThreshold) return;
            AddDistance(amount);
        }

        public void ResetProgress()
        {
            _distance = 0f;
            IsCompleted = false;
            ProgressChanged?.Invoke(0f);
        }

        private float Measure(Vector3 worldDelta)
        {
            if (metric == ScrubMetric.Distance3D) return worldDelta.magnitude;
            return Mathf.Abs(Vector3.Dot(worldDelta, transform.right))
                 + Mathf.Abs(Vector3.Dot(worldDelta, transform.up)) * 0.5f;
        }

        // ── Seguimiento de colliders ──────────────────────────────────────────

        private void OnTriggerEnter(Collider other)
        {
            if (!_movers.ContainsKey(other)) _movers[other] = PositionOf(other);
        }

        private void OnTriggerExit(Collider other) => _movers.Remove(other);

        private void OnDisable() => _movers.Clear();

        private void Update()
        {
            if (_movers.Count == 0) return;

            _scratch.Clear();
            _scratch.AddRange(_movers.Keys);
            foreach (var col in _scratch)
            {
                if (col == null || !col.enabled)
                {
                    _movers.Remove(col);
                    continue;
                }

                Vector3 pos = PositionOf(col);
                Vector3 delta = pos - _movers[col];
                _movers[col] = pos;

                if (delta.sqrMagnitude > 0f && IsValidMover(col))
                    DriverScrub(delta);
            }
        }

        private static Vector3 PositionOf(Collider col) => col.transform.position;

        /// <summary>
        /// Si este collider frota la superficie al moverse dentro de su trigger: una herramienta (<see cref="InteractableBase"/>)
        /// válida y, si hace falta, agarrada; o, con <c>allowHands</c>, una mano o un mando, es decir, un collider que cuelga
        /// de un <c>IXRInteractor</c> (en el rig XRI del paquete, la esfera <c>HandTrigger</c> de cada
        /// <c>NearFarInteractor</c>; auditoría del visor, corrección 3).
        /// </summary>
        public bool IsValidMover(Collider col)
        {
            if (col == null) return false;
            var item = col.GetComponentInParent<InteractableBase>();
            if (item != null)
            {
                if (item == this) return false;
                if (requireToolSelected && !item.IsSelected) return false;
                if (toolIds != null && toolIds.Count > 0)
                {
                    foreach (var id in toolIds)
                        if (InteractableRegistry.Matches(id, item)) return true;
                    return false;
                }
                return true;
            }

            return allowHands && col.GetComponentInParent<IXRInteractor>() != null;
        }
    }
}
