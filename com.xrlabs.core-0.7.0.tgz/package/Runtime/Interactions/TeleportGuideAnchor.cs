using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Ancla de teletransporte orientada y señalizada (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md §3). El
    /// dueño en el Quest 3: «no sabía cómo teletransportarme» y «quizás puntos de teletransportación que orienten cuál es la
    /// mejor posición». Va en cada zona <c>teleport</c> de la colocación junto a su <c>TeleportationAnchor</c> (XRI, con
    /// <c>MatchOrientation.TargetUpAndForward</c>), cuyo <c>teleportAnchorTransform</c> es el hijo <see cref="ArrivalName"/>
    /// girado hacia <c>mirarHacia</c>: al llegar, la cámara mira a la tarea.
    ///
    /// En el suelo dibuja un anillo, dos huellas y una flecha en la dirección de llegada (LineRenderer procedurales, sin
    /// prefabs). Cuando el paso en curso está en <see cref="StepIds"/> (los pasos para los que este sitio es el mejor, que
    /// calcula el importador con el guion), el dibujo se enciende y pulsa; si no, queda tenue. El suelo libre sigue siendo
    /// teletransportable: el ancla solo se suma. Lo configura <c>ColocacionImporter</c>; nada aquí se edita a mano.
    /// </summary>
    [AddComponentMenu("XRLabs/Teleport Guide Anchor")]
    public class TeleportGuideAnchor : MonoBehaviour, IStepGuideAnchor
    {
        public const string ArrivalName = "Llegada";
        public const string MarkerName = "Senal";

        [SerializeField, Tooltip("Pasos (stepId) para los que este sitio es el mejor.")]
        private List<string> stepIds = new();

        [SerializeField, Tooltip("Id de lo que se mira al llegar (mirarHacia de la colocación o el valor por defecto).")]
        private string faceTargetId;

        [SerializeField, Tooltip("El punto de llegada, girado hacia la tarea (teleportAnchorTransform del TeleportationAnchor).")]
        private Transform arrival;

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private Color idleColor = new Color(0.55f, 0.85f, 0.9f, 0.35f);
        [SerializeField] private Color activeColor = new Color(1f, 0.85f, 0.2f, 1f);
        [SerializeField, Min(0.2f)] private float ringRadius = 0.45f;
        [SerializeField, Min(0.1f)] private float pulsePeriod = 1.2f;

        private readonly List<LineRenderer> _lines = new();
        private Material _material;
        private float _clock;

        public List<string> StepIds => stepIds;
        public string FaceTargetId { get => faceTargetId; set => faceTargetId = value; }
        public Transform Arrival { get => arrival; set => arrival = value; }
        public StepSystem Steps { get => stepSystem; set => stepSystem = value; }

        /// <summary>Si ahora está encendida (el paso en curso es uno de los suyos).</summary>
        public bool Highlighted { get; private set; }

        public Vector3 GuidePosition => arrival != null ? arrival.position : transform.position;

        public bool IsRecommendedFor(string stepId) => !string.IsNullOrEmpty(stepId) && stepIds.Contains(stepId);

        /// <summary>
        /// La petición que hace XRI al soltar el arco sobre esta ancla (la misma cuenta que <c>TeleportationAnchor</c>):
        /// llegada en <see cref="Arrival"/> con la orientación del ancla. Los tests la mandan al <c>TeleportationProvider</c>.
        /// </summary>
        public TeleportRequest BuildRequest()
        {
            var anchor = GetComponent<TeleportationAnchor>();
            var target = arrival != null ? arrival : transform;
            return new TeleportRequest
            {
                destinationPosition = target.position,
                destinationRotation = target.rotation,
                matchOrientation = anchor != null ? anchor.matchOrientation : MatchOrientation.TargetUpAndForward,
            };
        }

        private void OnEnable()
        {
            StepGuideAnchors.Register(this);
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem != null)
            {
                stepSystem.StepStarted += OnStepStarted;
                stepSystem.StepsFinished += OnFinished;
            }
            EnsureMarker();
            SetHighlighted(stepSystem != null && stepSystem.CurrentStep != null && IsRecommendedFor(stepSystem.CurrentStep.stepId));
        }

        private void OnDisable()
        {
            StepGuideAnchors.Unregister(this);
            if (stepSystem != null)
            {
                stepSystem.StepStarted -= OnStepStarted;
                stepSystem.StepsFinished -= OnFinished;
            }
        }

        private void OnDestroy()
        {
            if (_material != null) Destroy(_material);
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => SetHighlighted(step != null && IsRecommendedFor(step.stepId));
        private void OnFinished() => SetHighlighted(false);

        /// <summary>Enciende o apaga la señal (lo llama el cambio de paso; los tests, a mano).</summary>
        public void SetHighlighted(bool on)
        {
            Highlighted = on;
            _clock = 0f;
            ApplyColor(on ? activeColor : idleColor, on ? 1.4f : 1f);
        }

        private void Update()
        {
            if (!Highlighted) return;
            _clock += Time.deltaTime;
            float wave = 0.5f + 0.5f * Mathf.Sin(_clock * Mathf.PI * 2f / pulsePeriod);
            var color = Color.Lerp(activeColor * 0.6f, activeColor, wave);
            color.a = 1f;
            ApplyColor(color, 1.2f + 0.4f * wave);
        }

        private void ApplyColor(Color color, float width)
        {
            foreach (var line in _lines)
            {
                if (line == null) continue;
                line.startColor = line.endColor = color;
                line.widthMultiplier = 0.03f * width;
            }
        }

        // ── Dibujo ─────────────────────────────────────────────────────────

        private void EnsureMarker()
        {
            if (_lines.Count > 0) return;
            var basis = arrival != null ? arrival : transform;
            var marker = transform.Find(MarkerName);
            if (marker == null)
            {
                marker = new GameObject(MarkerName).transform;
                marker.SetParent(transform, false);
            }
            marker.position = new Vector3(basis.position.x, transform.position.y + 0.015f, basis.position.z);
            var forward = Vector3.ProjectOnPlane(basis.forward, Vector3.up);
            marker.rotation = Quaternion.LookRotation(forward.sqrMagnitude > 1e-6f ? forward.normalized : Vector3.forward, Vector3.up);

            var shader = Shader.Find("Sprites/Default");
            if (shader != null && _material == null) _material = new Material(shader);

            // Anillo.
            var ring = new List<Vector3>();
            const int segments = 40;
            for (int i = 0; i <= segments; i++)
            {
                float a = i * Mathf.PI * 2f / segments;
                ring.Add(new Vector3(Mathf.Cos(a) * ringRadius, 0f, Mathf.Sin(a) * ringRadius));
            }
            AddLine(marker, "Anillo", ring, loop: false);
            // Huellas: dos óvalos mirando hacia delante.
            AddLine(marker, "HuellaIzquierda", Oval(new Vector3(-0.1f, 0f, -0.02f)), loop: true);
            AddLine(marker, "HuellaDerecha", Oval(new Vector3(0.1f, 0f, 0.04f)), loop: true);
            // Flecha de dirección delante del anillo.
            float tip = ringRadius + 0.32f;
            AddLine(marker, "Flecha", new List<Vector3>
            {
                new Vector3(0f, 0f, ringRadius + 0.04f), new Vector3(0f, 0f, tip),
                new Vector3(-0.13f, 0f, tip - 0.14f), new Vector3(0f, 0f, tip), new Vector3(0.13f, 0f, tip - 0.14f),
            }, loop: false);
        }

        private static List<Vector3> Oval(Vector3 center)
        {
            var points = new List<Vector3>();
            const int segments = 16;
            for (int i = 0; i < segments; i++)
            {
                float a = i * Mathf.PI * 2f / segments;
                points.Add(center + new Vector3(Mathf.Cos(a) * 0.045f, 0f, Mathf.Sin(a) * 0.11f));
            }
            return points;
        }

        private void AddLine(Transform parent, string name, List<Vector3> points, bool loop)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var line = go.AddComponent<LineRenderer>();
            line.useWorldSpace = false;
            line.loop = loop;
            line.alignment = LineAlignment.TransformZ;
            go.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            // Con la rotación de 90° en X los puntos (x, 0, z) del suelo pasan a (x, z, 0) locales.
            var local = new Vector3[points.Count];
            for (int i = 0; i < points.Count; i++) local[i] = new Vector3(points[i].x, points[i].z, 0f);
            line.positionCount = local.Length;
            line.SetPositions(local);
            line.numCapVertices = 2;
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            line.receiveShadows = false;
            if (_material != null) line.sharedMaterial = _material;
            _lines.Add(line);
        }
    }
}
