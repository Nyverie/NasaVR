using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Registro id → InteractableBase. Las condiciones (ScriptableObjects, que no pueden
    /// referenciar objetos de escena) encuentran aquí el objeto por su InteractionId al
    /// Initialize(). InteractableBase se registra solo (Start) y se retira en OnDestroy.
    /// Varios objetos pueden compartir id (ej: herramientas clonadas): TryGet devuelve el más reciente.
    /// </summary>
    public static class InteractableRegistry
    {
        private static readonly Dictionary<string, List<InteractableBase>> ById = new();

        public static void Register(string id, InteractableBase item)
        {
            if (string.IsNullOrEmpty(id) || item == null) return;
            if (!ById.TryGetValue(id, out var list))
                ById[id] = list = new List<InteractableBase>();
            if (!list.Contains(item)) list.Add(item);
        }

        public static void Unregister(string id, InteractableBase item)
        {
            if (string.IsNullOrEmpty(id)) return;
            if (!ById.TryGetValue(id, out var list)) return;
            list.Remove(item);
            if (list.Count == 0) ById.Remove(id);
        }

        /// <summary>El interactuable vivo más recientemente registrado con ese id.</summary>
        public static bool TryGet(string id, out InteractableBase item) => TryGet<InteractableBase>(id, out item);

        /// <summary>El interactuable vivo de tipo T más recientemente registrado con ese id.</summary>
        public static bool TryGet<T>(string id, out T item) where T : InteractableBase
        {
            item = null;
            if (string.IsNullOrEmpty(id) || !ById.TryGetValue(id, out var list)) return false;

            for (int i = list.Count - 1; i >= 0; i--)
            {
                if (list[i] == null)
                {
                    list.RemoveAt(i);
                    continue;
                }
                if (list[i] is T typed)
                {
                    item = typed;
                    return true;
                }
            }
            return false;
        }

        /// <summary>Todos los interactuables vivos con ese id (copia).</summary>
        public static List<InteractableBase> GetAll(string id)
        {
            var result = new List<InteractableBase>();
            if (string.IsNullOrEmpty(id) || !ById.TryGetValue(id, out var list)) return result;
            foreach (var item in list)
                if (item != null) result.Add(item);
            return result;
        }

        /// <summary>
        /// Id con el que el coach/las condiciones conocen lo que golpea un rayo o un collider:
        /// InteractionId del interactuable, o TargetId del SceneTarget, o ZoneId de la DropZone.
        /// Null si el objeto no tiene id.
        /// </summary>
        public static string ResolveTargetId(Component component)
        {
            if (component == null) return null;

            var item = component.GetComponentInParent<InteractableBase>();
            if (item != null) return item.InteractionId;

            var target = component.GetComponentInParent<SceneTarget>();
            if (target != null) return target.TargetId;

            var zone = component.GetComponentInParent<DropZone>();
            if (zone != null) return zone.ZoneId;

            return null;
        }

        /// <summary>
        /// True si el id pedido corresponde al interactuable: por su InteractionId o, si es una
        /// herramienta cargada desde una SourcePile, por el SourceId de la pila.
        /// </summary>
        public static bool Matches(string wantedId, InteractableBase item)
        {
            if (string.IsNullOrEmpty(wantedId) || item == null) return false;
            if (item.InteractionId == wantedId) return true;
            return item is CarriedItem carried && carried.SourceId == wantedId;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() => ById.Clear();
    }
}
