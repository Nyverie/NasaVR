using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>Qué significa tocar una opción de <see cref="ChoiceByTargetCondition"/>.</summary>
    public enum ChoiceOutcome
    {
        /// <summary>La opción correcta: completa el paso.</summary>
        Correct,
        /// <summary>Opción equivocada: reporta un error con su clave y el paso se repite.</summary>
        Error,
        /// <summary>Opción dudosa pero reversible: reporta un aviso con su clave y se puede volver a elegir.</summary>
        Warning
    }

    /// <summary>Una opción: el hotspot que se toca, qué resultado tiene y, si no es la correcta, qué clave reporta.</summary>
    [Serializable]
    public class ChoiceOption
    {
        [Tooltip("InteractionId del TouchableHotspot que representa esta opción.")]
        public string targetId;

        public ChoiceOutcome outcome = ChoiceOutcome.Error;

        [Tooltip("Clave que se reporta (error o aviso); el StepDefinition decide la frase (errorLines). La correcta no la usa.")]
        public string signalKey;

        // 0.3 lote 1 (contrato 0.3 §2.5): efectos de estado al tocarla, antes de la corrección o del éxito.
        [Tooltip("alElegir: efectos sobre el estado que se aplican al tocar esta opción. Vacío: como antes.")]
        public List<StateEffect> onChoose = new();

        // 0.3 lote 4 (contrato-0.3.md §2.5): con 'segun' en la condición, la opción es la correcta si su valor es el de la variable.
        [Tooltip("valor: con 'segun', esta opción es la correcta cuando la variable vale esto. Vacío sin 'segun'.")]
        public string stateValue;
    }

    /// <summary>0.3 lote 4: la clave de error que se reporta, con <c>segun</c>, cuando la variable vale <see cref="value"/>.</summary>
    [Serializable]
    public class ChoiceStateError
    {
        public string value;
        public string signalKey;
    }

    /// <summary>
    /// Elegir entre varios objetos tocándolos: el equivalente por objeto de <c>KeyChoiceStepCondition</c>, que es por
    /// teclado y en un visor no hay teclado. Tocar la opción <see cref="ChoiceOutcome.Correct"/> completa el paso; tocar
    /// una <see cref="ChoiceOutcome.Error"/> reporta su clave con <c>ReportError</c> y una <see cref="ChoiceOutcome.Warning"/>
    /// con <c>ReportWarning</c>, y en los dos casos el hotspot tocado se resetea para poder volver a elegirlo.
    ///
    /// Existe desde 2026-10-10 (lote A3, Documentation~/contrato-0.2.md §6.5). Calcada de
    /// <see cref="TouchableHotspotCondition"/>: Initialize busca por <see cref="InteractableRegistry"/> los hotspots de
    /// cada opción, les hace <c>ResetHotspot()</c> (para que <c>oneShot</c> no bloquee un paso repetido) y se suscribe a
    /// <c>Activated</c>, que dispara tanto el XRI como el <c>FlatInteractionDriver</c>. Si alguna opción todavía no tiene
    /// hotspot, reintenta cada 0,5 s desde <see cref="IsCompleted"/>: el objeto puede instanciarse después.
    /// Tras completar, ignora el resto de toques.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Choice By Target")]
    public class ChoiceByTargetCondition : StepCondition, IStepSignalDetails
    {
        // Mismo intervalo que TouchableHotspotCondition.
        private const float RetryIntervalSeconds = 0.5f;

        [Tooltip("Las opciones del paso. Al menos una debe ser Correct.")]
        [SerializeField] private List<ChoiceOption> options = new();

        // Una suscripción por (opción, hotspot): el manejador sabe qué opción disparó.
        private sealed class Subscription
        {
            public ChoiceOption Option;
            public TouchableHotspot Hotspot;
            public Action<InteractableBase> Handler;
        }

        #region 0.3 lote 4: segun y errorPorEstado (contrato-0.3.md §2.5)

        [Tooltip("segun: variable de texto del estado que decide la opción correcta (la de 'valor' igual). Vacío: el 'resultado' de cada opción, como antes.")]
        [SerializeField] private string stateVariable;

        [Tooltip("errorPorEstado: la clave de error por valor de la variable. Tocar una opción que no es la correcta reporta la del estado, no la de la opción.")]
        [SerializeField] private List<ChoiceStateError> errorsByState = new();

        // Las opciones de los errores y avisos reportados, en orden: metadata.opcion de step_error (IStepSignalDetails).
        private readonly Queue<string> _signalOptions = new();

        /// <summary>La variable de 'segun', o vacío.</summary>
        public string StateVariable => stateVariable;

        /// <summary>Para herramientas y tests: configura 'segun' y 'errorPorEstado'.</summary>
        public void ConfigureByState(string variable, IEnumerable<ChoiceStateError> errors)
        {
            stateVariable = variable;
            errorsByState = errors != null ? new List<ChoiceStateError>(errors) : new List<ChoiceStateError>();
        }

        /// <summary>La clave de error de ese valor de la variable, o null.</summary>
        public string ErrorKeyForState(string value)
        {
            if (errorsByState == null) return null;
            foreach (var e in errorsByState)
                if (e != null && e.value == value) return e.signalKey;
            return null;
        }

        string IStepSignalDetails.TakeSignalOption() => _signalOptions.Count > 0 ? _signalOptions.Dequeue() : null;

        // La tabla de estado: la del SimulationStateHost o, si no hay, la del StepSystem de la simulación.
        private static SimulationState CurrentStateTable()
        {
            var state = SimulationStateHost.CurrentState;
            if (state != null) return state;
            var sim = SimulationManager.Instance;
            return sim != null && sim.Steps != null ? sim.Steps.State : null;
        }

        // Con 'segun': correcta si su valor es el de la variable al tocar (antes de su alElegir); si no, error con la
        // clave del estado. Devuelve false si la condición no usa 'segun'.
        private bool HandleByState(Subscription subscription)
        {
            if (string.IsNullOrEmpty(stateVariable)) return false;

            var state = CurrentStateTable();
            string current = state != null ? state.GetText(stateVariable) : null;
            if (state == null)
                Debug.LogWarning($"[ChoiceByTargetCondition] 'segun' = '{stateVariable}' y la escena no tiene tabla de estado.");

            ApplyOnChoose(subscription.Option);

            if (current != null && subscription.Option.stateValue == current)
            {
                _completed = true;
                return true;
            }

            string key = ErrorKeyForState(current);
            if (string.IsNullOrEmpty(key)) key = subscription.Option.signalKey;
            _signalOptions.Enqueue(subscription.Option.targetId);
            ReportError(key);
            subscription.Hotspot.ResetHotspot();
            return true;
        }

        #endregion

        private readonly List<Subscription> _subscriptions = new();
        private bool _completed;
        private float _nextSearchTime;

        public override void Initialize()
        {
            _completed = false;
            _signalOptions.Clear();   // 0.3 lote 4: las opciones van a la par de las señales, que el StepSystem limpia al empezar
            Unsubscribe();
            Subscribe();

            foreach (var option in options)
                if (option != null && !IsListening(option))
                    Debug.LogWarning($"[ChoiceByTargetCondition] No hay ningún TouchableHotspot con id '{option.targetId}' (se reintenta).");
        }

        public override bool IsCompleted()
        {
            if (_completed) return true;

            if (Time.unscaledTime >= _nextSearchTime && !AllOptionsListening())
                Subscribe();

            return _completed;
        }

        public override void Cleanup()
        {
            Unsubscribe();
            _completed = false;
            _signalOptions.Clear();   // 0.3 lote 4
        }

        private void Subscribe()
        {
            _nextSearchTime = Time.unscaledTime + RetryIntervalSeconds;

            foreach (var option in options)
            {
                if (option == null) continue;

                foreach (var item in InteractableRegistry.GetAll(option.targetId))
                {
                    if (item is not TouchableHotspot hotspot || IsSubscribed(option, hotspot)) continue;

                    var subscription = new Subscription { Option = option, Hotspot = hotspot };
                    subscription.Handler = _ => OnActivated(subscription);

                    hotspot.ResetHotspot();
                    hotspot.Activated += subscription.Handler;
                    _subscriptions.Add(subscription);
                }
            }
        }

        private void Unsubscribe()
        {
            foreach (var subscription in _subscriptions)
                if (subscription.Hotspot != null) subscription.Hotspot.Activated -= subscription.Handler;
            _subscriptions.Clear();
        }

        private void OnActivated(Subscription subscription)
        {
            if (_completed) return;
            if (HandleByState(subscription)) return;   // 0.3 lote 4: segun

            ApplyOnChoose(subscription.Option);   // 0.3 lote 1

            switch (subscription.Option.outcome)
            {
                case ChoiceOutcome.Correct:
                    _completed = true;
                    break;

                case ChoiceOutcome.Error:
                    _signalOptions.Enqueue(subscription.Option.targetId);   // 0.3 lote 4: metadata.opcion
                    ReportError(subscription.Option.signalKey);
                    subscription.Hotspot.ResetHotspot();
                    break;

                case ChoiceOutcome.Warning:
                    _signalOptions.Enqueue(subscription.Option.targetId);   // 0.3 lote 4: metadata.opcion
                    ReportWarning(subscription.Option.signalKey);
                    subscription.Hotspot.ResetHotspot();
                    break;
            }
        }

        private bool IsSubscribed(ChoiceOption option, TouchableHotspot hotspot)
        {
            foreach (var subscription in _subscriptions)
                if (subscription.Option == option && subscription.Hotspot == hotspot) return true;
            return false;
        }

        private bool IsListening(ChoiceOption option)
        {
            foreach (var subscription in _subscriptions)
                if (subscription.Option == option) return true;
            return false;
        }

        private bool AllOptionsListening()
        {
            foreach (var option in options)
                if (option != null && !IsListening(option)) return false;
            return true;
        }

        // 0.3 lote 1: alElegir sobre la tabla de estado de la escena (si la experiencia no usa estado, no hay tabla).
        private static void ApplyOnChoose(ChoiceOption option)
        {
            if (option?.onChoose == null || option.onChoose.Count == 0) return;
            var state = CurrentStateTable();   // 0.3 lote 4: también la del StepSystem si no hay host
            if (state == null)
            {
                Debug.LogWarning($"[ChoiceByTargetCondition] La opción '{option.targetId}' tiene alElegir y la escena no tiene SimulationStateHost.");
                return;
            }
            state.Apply(option.onChoose);
        }
    }
}
