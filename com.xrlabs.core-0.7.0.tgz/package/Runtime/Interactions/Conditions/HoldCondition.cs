using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Se cumple cuando el HoldButton <c>buttonId</c> alcanza <c>threshold</c> (0–1). Si el botón
    /// decae al soltarlo, la condición recuerda que ya llegó (no depende del frame en que se consulte).
    /// <c>resetOnStart</c> pone el botón en 0 al iniciar el paso. Rearm conserva el valor.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Hold")]
    public class HoldCondition : StepCondition
    {
        public string buttonId;
        [Range(0.05f, 1f)] public float threshold = 1f;
        public bool resetOnStart = true;

        private HoldButton _button;
        private bool _reached;
        private bool _pendingReset;

        public override void Initialize()
        {
            Unbind();
            _reached = false;
            _pendingReset = resetOnStart;
            TryBind();
        }

        public override bool IsCompleted()
        {
            if (_button == null) TryBind();
            if (_button != null && _button.Value >= threshold) _reached = true;
            return _reached;
        }

        public override void Cleanup()
        {
            Unbind();
            _reached = false;
            _pendingReset = false;
        }

        public override void Rearm()
        {
            _pendingReset = false;
            TryBind(); // sin reset: conserva el valor
        }

        private void TryBind()
        {
            if (_button != null) return;
            if (!InteractableRegistry.TryGet(buttonId, out _button)) return;

            if (_pendingReset)
            {
                _button.ResetValue();
                _pendingReset = false;
            }
            _button.ValueChanged += OnValueChanged;
        }

        private void Unbind()
        {
            if (_button != null) _button.ValueChanged -= OnValueChanged;
            _button = null;
        }

        private void OnValueChanged(float value)
        {
            if (value >= threshold) _reached = true;
        }

        private void OnDisable() => Unbind();
    }
}
