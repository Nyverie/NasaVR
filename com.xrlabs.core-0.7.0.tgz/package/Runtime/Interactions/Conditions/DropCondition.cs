using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>Resultado de juzgar un soltado.</summary>
    public enum DropOutcome
    {
        /// <summary>No cuenta ni es error (ej: soltar donde no hay regla). El objeto vuelve a su sitio.</summary>
        Ignored,
        /// <summary>Soltado correcto: suma al conteo si el objeto no estaba contado ya.</summary>
        Accepted,
        /// <summary>Error reportado (el paso se corrige y se repite).</summary>
        Error,
        /// <summary>Aviso reportado (no bloquea; si además era aceptable, también suma).</summary>
        Warning
    }

    /// <summary>Regla de error/aviso para un soltado. Campo vacío = comodín.</summary>
    [Serializable]
    public class DropRule
    {
        [Tooltip("Id del objeto (InteractionId, o SourceId si viene de una pila). Vacío = cualquiera.")]
        public string itemId;

        [Tooltip("Id de la zona. Vacío = cualquiera.")]
        public string zoneId;

        [Tooltip("Clave que se reporta; el StepDefinition decide la frase (errorLines).")]
        public string errorKey;

        public StepSignalKind kind = StepSignalKind.Error;

        public bool Matches(InteractableBase item, DropZone zone) =>
            (string.IsNullOrEmpty(itemId) || InteractableRegistry.Matches(itemId, item))
            && (string.IsNullOrEmpty(zoneId) || zone.ZoneId == zoneId);
    }

    /// <summary>0.3 lote 5: la clave de 'errores' que «Continuar» reporta si este objeto aún no está colocado.</summary>
    [Serializable]
    public class DropMissingKey
    {
        public string itemId;
        public string errorKey;
    }

    /// <summary>
    /// Se cumple cuando <c>requiredCount</c> objetos DISTINTOS han sido soltados de forma válida (objeto aceptado dentro de
    /// zona aceptada). Cuenta objetos, no soltados: volver a soltar un objeto que ya cuenta no suma ni es error (Judge lo
    /// sigue juzgando Accepted; el conjunto lo absorbe). Si además <c>acceptedItemIds</c> nombra los objetos y
    /// <c>requiredCount</c> los pide todos (≥ los ids distintos de la lista), «cumplida» exige que cada id de la lista esté
    /// cubierto por algún objeto contado: el guion de COMP-02 dice cuáles (estiércol, rastrojos, agua, cal o ceniza) y cuántos
    /// (4), y cuatro objetos cualquiera de una lista con un id repetido no bastan. Con <c>requiredCount</c> menor que la
    /// lista (cualquiera de paja, ichu o manta) basta ese número de objetos distintos. Un objeto de una pila
    /// (<see cref="CarriedItem"/>) es nuevo en cada soltado (la pila entrega uno nuevo cada vez y, con un proxy de escena,
    /// reusa el mismo GameObject), así que cada soltado suyo cuenta como antes: «sembrar tres semillas» sigue siendo tres.
    /// Aún no se rastrea sacar un objeto de la zona: uno ya contado que se suelta luego en otra zona (error) o fuera de toda
    /// zona (la condición no lo ve) sigue en el conjunto.
    ///
    /// Orden de juicio de cada soltado (item, zona):
    /// 1. Reglas, en orden: la PRIMERA que coincide gana (aunque el soltado fuera aceptable: así se
    ///    expresan pares incorrectos como "estiércol en la zona de agua"). Error → ReportError, no
    ///    cuenta. Aviso → ReportWarning; si además item y zona eran aceptados, cuenta igual.
    /// 2. Sin regla: si item y zona son aceptados → cuenta.
    /// 3. Sin regla y no aceptado: se ignora (no es error; el objeto vuelve a su sitio),
    ///    salvo que <c>defaultErrorKey</c> tenga valor: entonces es un error con esa clave.
    ///    Excepción (2026-10-25): un objeto que no es de este paso soltado en una zona de este paso se ignora aunque
    ///    haya <c>defaultErrorKey</c>. La clave por defecto es «fuera» (claveFuera: «Eso va al área de acopio, no
    ///    ahí»), y decirla con el objeto dentro del acopio confunde: en el segundo recorrido del Quest 3 dio cinco
    ///    «fuera-acopio» seguidos en COMP-02. La zona no lo acepta, así que ReturnToOrigin lo devuelve igual.
    /// Soltar fuera de toda zona nunca llega aquí (no hay zona): no es error.
    ///
    /// Rearm (tras corregir un error): conserva el conteo si <c>keepProgressOnRearm</c> (por defecto:
    /// las capas ya colocadas siguen colocadas).
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Drop")]
    public class DropCondition : StepCondition
    {
        [Header("Aceptado")]
        [Tooltip("Ids de objetos válidos (InteractionId o SourceId de pila). Vacío = cualquiera.")]
        public List<string> acceptedItemIds = new();

        [Tooltip("Ids de zonas válidas (ZoneId). Vacío = cualquiera.")]
        public List<string> acceptedZoneIds = new();

        [Min(1)] public int requiredCount = 1;

        [Header("Errores")]
        [Tooltip("Se evalúan en orden; la primera que coincide gana.")]
        public List<DropRule> rules = new();

        [Tooltip("Clave de error para un soltado no aceptado sin regla. Vacío = se ignora.")]
        public string defaultErrorKey;

        [Header("Rearm")]
        [Tooltip("Tras un error, conserva los soltados ya correctos.")]
        public bool keepProgressOnRearm = true;

        // 0.3 lote 5 (contrato-0.3.md §2.6): reacciones, faltantes y zonas distintas. Vacíos = como 0.2 (D8).
        [Header("0.3: reacciones, faltantes, zonas distintas")]
        [Tooltip("Objetos con frase propia al aceptarse su soltado: se reporta como info con la clave «reaccion.<objeto>» " +
                 "(el importador pone la frase en errorLines con esa clave).")]
        public List<string> reactionItemIds = new();

        [Tooltip("Objeto → clave de 'errores' que «Continuar» dice si ese objeto falta. En el orden de acceptedItemIds.")]
        public List<DropMissingKey> missingKeys = new();

        [Tooltip("Un soltado cuenta solo si su zona aún no tenía uno («una dosis por planta»). El rechazado vuelve a su sitio.")]
        public bool distinctZones;

        /// <summary>Prefijo de la clave de una reacción: «reaccion.<objeto>».</summary>
        public const string ReactionKeyPrefix = "reaccion.";

        /// <summary>Objetos distintos soltados de forma válida en el paso actual.</summary>
        public int Count => _counted.Count;

        // Objetos ya contados, por identidad de instancia (no por InteractionId: dos objetos de escena pueden compartir
        // nombre). Un CarriedItem usa una clave nueva (negativa) en cada soltado: ver el resumen de la clase.
        private readonly HashSet<int> _counted = new();
        // Ids de acceptedItemIds cubiertos por algún objeto contado.
        private readonly HashSet<string> _covered = new();
        private int _nextCarriedKey = -1;
        private bool _listening;
        // 0.3 lote 5: zonas que ya tienen un soltado contado (para 'distintas').
        private readonly HashSet<int> _usedZones = new();

        public override void Initialize()
        {
            _counted.Clear();
            _covered.Clear();
            _usedZones.Clear();
            _nextCarriedKey = -1;
            Listen();
        }

        public override bool IsCompleted()
        {
            if (_counted.Count < requiredCount) return false;
            return !MustCoverEveryListedId() || _covered.Count >= DistinctListedIds();
        }

        // «Cuáles»: el paso pide tantos objetos como ids distintos nombra la lista, así que son esos.
        private bool MustCoverEveryListedId()
        {
            int listed = DistinctListedIds();
            return listed > 0 && requiredCount >= listed;
        }

        private int DistinctListedIds()
        {
            if (acceptedItemIds == null) return 0;
            var distinct = new HashSet<string>();
            foreach (var id in acceptedItemIds)
                if (!string.IsNullOrEmpty(id)) distinct.Add(id);
            return distinct.Count;
        }

        private void CountItem(InteractableBase item)
        {
            _counted.Add(item is CarriedItem ? _nextCarriedKey-- : item.GetInstanceID());
            if (acceptedItemIds == null) return;
            foreach (var id in acceptedItemIds)
                if (!string.IsNullOrEmpty(id) && InteractableRegistry.Matches(id, item)) _covered.Add(id);
        }

        public override void Cleanup() => StopListening();

        public override void Rearm()
        {
            if (!keepProgressOnRearm)
            {
                base.Rearm();
                return;
            }
            Listen(); // conserva Count
        }

        /// <summary>Juzga un soltado sin efectos secundarios (los tests y la UI de depuración lo usan).</summary>
        public DropOutcome Judge(InteractableBase item, DropZone zone, out string key)
        {
            key = null;
            if (item == null || zone == null) return DropOutcome.Ignored;

            if (rules != null)
            {
                foreach (var rule in rules)
                {
                    if (rule == null || !rule.Matches(item, zone)) continue;

                    // La primera regla que coincide gana.
                    key = rule.errorKey;
                    return rule.kind == StepSignalKind.Error ? DropOutcome.Error : DropOutcome.Warning;
                }
            }

            if (IsAcceptable(item, zone)) return DropOutcome.Accepted;

            // Un objeto ajeno al paso en una zona del paso no está «fuera»: se ignora (ver el resumen de la clase).
            if (!ItemListed(item) && ZoneListed(zone)) return DropOutcome.Ignored;

            if (!string.IsNullOrEmpty(defaultErrorKey))
            {
                key = defaultErrorKey;
                return DropOutcome.Error;
            }

            return DropOutcome.Ignored;
        }

        private bool IsAcceptable(InteractableBase item, DropZone zone) => ItemListed(item) && ZoneListed(zone);

        private bool ItemListed(InteractableBase item) =>
            ListAccepts(acceptedItemIds, id => InteractableRegistry.Matches(id, item));

        private bool ZoneListed(DropZone zone) => ListAccepts(acceptedZoneIds, id => zone.ZoneId == id);

        private static bool ListAccepts(List<string> ids, Func<string, bool> match)
        {
            if (ids == null || ids.Count == 0) return true;
            foreach (var id in ids)
                if (match(id)) return true;
            return false;
        }

        private void OnDropped(InteractableBase item, DropZone zone)
        {
            var outcome = Judge(item, zone, out string key);
            switch (outcome)
            {
                case DropOutcome.Error:
                    ReportError(key);
                    break;
                case DropOutcome.Warning:
                    ReportWarning(key);
                    if (IsAcceptable(item, zone)) CountAccepted(item, zone);
                    break;
                case DropOutcome.Accepted:
                    CountAccepted(item, zone);
                    break;
            }
        }

        #region 0.3 lote 5: reacciones, faltantes y zonas distintas (contrato-0.3.md §2.6)

        /// <summary>
        /// Un soltado aceptado: con 'distintas', una zona que ya tiene uno lo rechaza (no cuenta ni es error; el objeto
        /// vuelve a su sitio). Si cuenta por primera vez y el objeto tiene reacción, la reporta como info (no bloquea ni
        /// cuenta; el StepSystem hace esperar al éxito si ese soltado cierra el paso).
        /// </summary>
        private void CountAccepted(InteractableBase item, DropZone zone)
        {
            bool already = !(item is CarriedItem) && _counted.Contains(item.GetInstanceID());
            if (already) return;   // volver a soltar uno que ya cuenta: nada (como antes)

            if (distinctZones && zone != null && !_usedZones.Add(zone.GetInstanceID()))
            {
                if (item.TryGetComponent<ReturnToOrigin>(out var back)) back.ReturnNow();
                return;
            }

            CountItem(item);
            var reaction = ReactionFor(item);
            if (reaction != null) ReportInfo(ReactionKeyPrefix + reaction);
        }

        private string ReactionFor(InteractableBase item)
        {
            if (reactionItemIds == null) return null;
            foreach (var id in reactionItemIds)
                if (!string.IsNullOrEmpty(id) && InteractableRegistry.Matches(id, item)) return id;
            return null;
        }

        /// <summary>«Continuar»: cumplida, cierra; si no, la clave del primer objeto de la lista aún sin colocar.</summary>
        public override bool TryConfirm(out string clave)
        {
            clave = null;
            if (IsCompleted()) return true;
            var missing = MissingKeys();
            if (missing.Count > 0) clave = missing[0];
            return false;
        }

        /// <summary>Las claves de 'faltantes' de cada objeto de la lista aún sin colocar, en el orden de la lista.</summary>
        public override IReadOnlyList<string> MissingKeys()
        {
            var keys = new List<string>();
            foreach (var id in MissingItemIds())
            {
                var key = MissingKeyFor(id);
                if (!string.IsNullOrEmpty(key) && !keys.Contains(key)) keys.Add(key);
            }
            return keys;
        }

        /// <summary>Los ids de la lista que ningún objeto contado cubre aún, en orden y sin repetir.</summary>
        public List<string> MissingItemIds()
        {
            var ids = new List<string>();
            if (acceptedItemIds == null) return ids;
            foreach (var id in acceptedItemIds)
                if (!string.IsNullOrEmpty(id) && !_covered.Contains(id) && !ids.Contains(id)) ids.Add(id);
            return ids;
        }

        private string MissingKeyFor(string itemId)
        {
            if (missingKeys == null) return null;
            foreach (var entry in missingKeys)
                if (entry != null && entry.itemId == itemId) return entry.errorKey;
            return null;
        }

        #endregion

        private void Listen()
        {
            if (_listening) return;
            DropZone.DroppedAnywhere += OnDropped;
            _listening = true;
        }

        private void StopListening()
        {
            if (!_listening) return;
            DropZone.DroppedAnywhere -= OnDropped;
            _listening = false;
        }

        private void OnDisable() => StopListening();
    }
}
