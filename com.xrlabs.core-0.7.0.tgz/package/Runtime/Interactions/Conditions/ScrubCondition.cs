using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Se cumple cuando la ScrubSurface <c>surfaceId</c> alcanza <c>threshold</c> de progreso (0–1).
    /// La superficie se busca por id en InteractableRegistry (al inicio o, si aún no existe, en cada consulta).
    /// <c>resetOnStart</c> pone la superficie en 0 al iniciar el paso.
    /// Rearm conserva el progreso ya frotado.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Scrub")]
    public class ScrubCondition : StepCondition
    {
        public string surfaceId;
        [Range(0.05f, 1f)] public float threshold = 1f;
        public bool resetOnStart = true;

        private ScrubSurface _surface;
        private bool _pendingReset;

        public override void Initialize()
        {
            _surface = null;
            _pendingReset = resetOnStart;
            TryBind();
        }

        public override bool IsCompleted()
        {
            TryBind();
            return _surface != null && _surface.Progress >= threshold;
        }

        public override void Cleanup()
        {
            _surface = null;
            _pendingReset = false;
        }

        public override void Rearm()
        {
            _pendingReset = false;
            TryBind(); // sin reset: conserva el progreso
        }

        private void TryBind()
        {
            if (_surface != null) return;
            if (!InteractableRegistry.TryGet(surfaceId, out _surface)) return;

            if (_pendingReset)
            {
                _surface.ResetProgress();
                _pendingReset = false;
            }
        }
    }
}
