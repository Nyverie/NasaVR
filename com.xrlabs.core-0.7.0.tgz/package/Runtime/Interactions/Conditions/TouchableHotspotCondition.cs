using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Se cumple cuando se activa un <see cref="TouchableHotspot"/> con el id esperado: el toque del poke o del select
    /// en el visor, y el clic del <c>FlatInteractionDriver</c> en pantalla (los dos terminan en <c>Activated</c>).
    ///
    /// Existe desde 2026-10-10 (lote A1, Documentation~/autoria.md §3.4.1) por el puente plano/visor que faltaba:
    /// <c>HotspotTouchCondition</c> consulta el registro que llenan los <c>HotspotMarker</c>, y esos solo se disparan por el
    /// trigger de un interactor XR, así que un paso «tocar» no se podía completar con el ratón. Esta condición escucha el
    /// contrato <see cref="InteractableBase"/> y no cambia ni <c>HotspotMarker</c> ni <c>HotspotTouchCondition</c>, que
    /// siguen para Fallas de Brocas (D8).
    ///
    /// Initialize busca por <see cref="InteractableRegistry"/> los hotspots con ese id, les hace <c>ResetHotspot()</c>
    /// (para que <c>oneShot</c> no bloquee un paso repetido) y se suscribe. Si todavía no hay ninguno, reintenta cada
    /// 0,5 s desde <see cref="IsCompleted"/>, como <c>RotationTrackingCondition</c>: el objeto puede instanciarse después.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Touchable Hotspot")]
    public class TouchableHotspotCondition : StepCondition
    {
        // Mismo intervalo que RotationTrackingCondition.targetRetryIntervalSeconds.
        private const float RetryIntervalSeconds = 0.5f;

        [Tooltip("InteractionId del TouchableHotspot que hay que tocar.")]
        [SerializeField] private string interactionId = string.Empty;

        private readonly List<TouchableHotspot> _listening = new();
        private bool _activated;
        private float _nextSearchTime;

        public override void Initialize()
        {
            _activated = false;
            Unsubscribe();
            Subscribe();

            if (_listening.Count == 0)
                Debug.LogWarning($"[TouchableHotspotCondition] No hay ningún TouchableHotspot con id '{interactionId}' (se reintenta).");
        }

        public override bool IsCompleted()
        {
            if (_activated) return true;

            if (_listening.Count == 0 && Time.unscaledTime >= _nextSearchTime)
                Subscribe();

            return _activated;
        }

        public override void Cleanup()
        {
            Unsubscribe();
            _activated = false;
        }

        private void Subscribe()
        {
            _nextSearchTime = Time.unscaledTime + RetryIntervalSeconds;

            foreach (var item in InteractableRegistry.GetAll(interactionId))
            {
                if (item is not TouchableHotspot hotspot || _listening.Contains(hotspot)) continue;

                hotspot.ResetHotspot();
                hotspot.Activated += OnActivated;
                _listening.Add(hotspot);
            }
        }

        private void Unsubscribe()
        {
            foreach (var hotspot in _listening)
                if (hotspot != null) hotspot.Activated -= OnActivated;
            _listening.Clear();
        }

        private void OnActivated(InteractableBase _) => _activated = true;
    }
}
