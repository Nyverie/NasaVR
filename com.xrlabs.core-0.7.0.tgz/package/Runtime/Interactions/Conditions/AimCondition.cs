using System;
using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Interactions
{
    /// <summary>Objetivo equivocado: apuntarlo durante un rato reporta un error/aviso.</summary>
    [Serializable]
    public class AimWrongTarget
    {
        public string targetId;
        public string errorKey;
        public StepSignalKind kind = StepSignalKind.Error;

        [Tooltip("Segundos apuntando al objetivo equivocado antes de reportar (evita falsos positivos al barrer).")]
        [Min(0f)] public float graceSeconds = 1f;
    }

    /// <summary>
    /// Se cumple cuando una AimTool acumula <c>secondsRequired</c> apuntando al objetivo
    /// <c>targetId</c> DURANTE el paso (lo apuntado antes no cuenta). <c>toolId</c> limita a una
    /// herramienta concreta (vacío = cualquiera).
    ///
    /// Rearm conserva los segundos acumulados (apuntar bien un rato no se pierde por un error).
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Aim")]
    public class AimCondition : StepCondition
    {
        public string targetId;
        [Min(0.1f)] public float secondsRequired = 3f;

        [Tooltip("InteractionId de la AimTool. Vacío = cualquiera.")]
        public string toolId;

        [Tooltip("Objetivos incorrectos y su clave de error.")]
        public List<AimWrongTarget> wrongTargets = new();

        public float Seconds { get; private set; }

        private readonly Dictionary<string, float> _wrongSeconds = new();
        private readonly HashSet<string> _wrongReported = new();
        private bool _listening;

        public override void Initialize()
        {
            Seconds = 0f;
            _wrongSeconds.Clear();
            _wrongReported.Clear();
            Listen();
        }

        public override bool IsCompleted() => Seconds >= secondsRequired;

        public override void Cleanup() => StopListening();

        public override void Rearm()
        {
            _wrongSeconds.Clear();
            _wrongReported.Clear();
            Listen(); // conserva Seconds
        }

        private void OnAimTick(AimTool tool, string id, float dt)
        {
            if (!string.IsNullOrEmpty(toolId) && !InteractableRegistry.Matches(toolId, tool)) return;

            if (id == targetId)
            {
                Seconds += dt;
                return;
            }

            if (wrongTargets == null) return;
            foreach (var wrong in wrongTargets)
            {
                if (wrong == null || wrong.targetId != id) continue;

                float total = (_wrongSeconds.TryGetValue(id, out float s) ? s : 0f) + dt;
                _wrongSeconds[id] = total;
                if (total >= wrong.graceSeconds && _wrongReported.Add(id))
                {
                    if (wrong.kind == StepSignalKind.Error) ReportError(wrong.errorKey);
                    else ReportWarning(wrong.errorKey);
                }
                return;
            }
        }

        private void Listen()
        {
            if (_listening) return;
            AimTool.AimTickAnywhere += OnAimTick;
            _listening = true;
        }

        private void StopListening()
        {
            if (!_listening) return;
            AimTool.AimTickAnywhere -= OnAimTick;
            _listening = false;
        }

        private void OnDisable() => StopListening();
    }
}
