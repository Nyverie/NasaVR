using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    /// <summary>
    /// Pila de material (carry): al agarrarla pone en la mano una herramienta "cargada"
    /// (<see cref="CarriedItem"/>) que lleva el <see cref="SourceId"/> de la pila; al soltarla sobre
    /// una DropZone esta emite Dropped con esa herramienta, y la condición lee de qué pila viene.
    /// La pila misma no se mueve. Es genérica: pila de estiércol, cubo de agua, bolsa de semillas…
    ///
    /// La herramienta puede ser un prefab (<c>toolPrefab</c>), un objeto de escena que se
    /// muestra/oculta (<c>sceneProxy</c>) o, si no hay ninguno, una esfera simple.
    /// En modo plano el FlatInteractionDriver arrastra la herramienta (IDragSource).
    ///
    /// En el visor: se mantiene el botón de agarre (gatillo lateral) sobre la pila —de cerca, o apuntándole de lejos— y la
    /// herramienta aparece en la mano; se lleva con la mano y se suelta el botón sobre la zona (la herramienta, con su
    /// collider trigger, es lo que debe quedar dentro de la zona). Soltar fuera de toda zona la retira sin más.
    /// </summary>
    [RequireComponent(typeof(XRSimpleInteractable))]
    public class SourcePile : InteractableBase, IDragSource
    {
        [Header("Origen")]
        [Tooltip("Id que lleva la herramienta cargada. Vacío = InteractionId de la pila.")]
        [SerializeField] private string sourceId;

        [Header("Herramienta cargada")]
        [Tooltip("Prefab que se instancia en la mano. Opcional.")]
        [SerializeField] private GameObject toolPrefab;

        [Tooltip("Objeto de escena que se muestra en la mano en vez de instanciar. Opcional (se oculta de nuevo al soltar).")]
        [SerializeField] private GameObject sceneProxy;

        [Tooltip("Tamaño de la esfera por defecto (si no hay prefab ni proxy).")]
        [SerializeField, Min(0.01f)] private float defaultToolSize = 0.12f;
        [SerializeField] private Color defaultToolColor = new Color(0.45f, 0.3f, 0.15f, 1f);

        [Tooltip("Desfase local respecto a la mano.")]
        [SerializeField] private Vector3 handOffset = Vector3.zero;

        [Tooltip("Segundos que la herramienta sigue visible tras soltarla (los efectos de soltado se ven mejor).")]
        [SerializeField, Min(0f)] private float lingerSeconds;

        public string SourceId => string.IsNullOrEmpty(sourceId) ? InteractionId : sourceId;

        /// <summary>Herramienta en la mano ahora mismo (null si no hay).</summary>
        public CarriedItem Carried { get; private set; }

        public bool IsCarrying => Carried != null;

        public Transform DragTarget => Carried != null ? Carried.transform : null;

        /// <summary>Se puso una herramienta en la mano.</summary>
        public event Action<SourcePile, CarriedItem> CarryStarted;

        /// <summary>La herramienta se soltó (ya se emitió su ReleasedEvent y el Dropped de la zona).</summary>
        public event Action<SourcePile, CarriedItem> CarryEnded;

        private XRSimpleInteractable _xr;
        private Transform _pendingHand;
        private bool _proxyIsScene;

        private void Awake() => _xr = GetComponent<XRSimpleInteractable>();

        private void OnEnable()
        {
            _xr.hoverEntered.AddListener(OnXrHoverEntered);
            _xr.hoverExited.AddListener(OnXrHoverExited);
            _xr.selectEntered.AddListener(OnXrSelectEntered);
            _xr.selectExited.AddListener(OnXrSelectExited);
            SelectedEvent += BeginCarry;
            ReleasedEvent += EndCarry;
        }

        private void OnDisable()
        {
            _xr.hoverEntered.RemoveListener(OnXrHoverEntered);
            _xr.hoverExited.RemoveListener(OnXrHoverExited);
            _xr.selectEntered.RemoveListener(OnXrSelectEntered);
            _xr.selectExited.RemoveListener(OnXrSelectExited);
            SelectedEvent -= BeginCarry;
            ReleasedEvent -= EndCarry;
            DiscardCarried();
        }

        private void OnXrHoverEntered(HoverEnterEventArgs _) => RaiseHovered();
        private void OnXrHoverExited(HoverExitEventArgs _) => RaiseUnhovered();

        private void OnXrSelectEntered(SelectEnterEventArgs args)
        {
            _pendingHand = ResolveHand(args.interactorObject.transform,
                args.interactorObject.GetAttachTransform(args.interactableObject));
            RaiseSelected();
            _pendingHand = null;
        }

        /// <summary>
        /// Distancia (m) a partir de la cual el punto de anclaje del interactor se considera «lejano»: con un
        /// <c>NearFarInteractor</c> (rig del paquete) o un rayo, al agarrar de lejos XRI lleva ese punto al lugar del rayo
        /// donde pega en la pila, y la mano real queda a metros de él.
        /// </summary>
        public const float FarAttachDistance = 0.3f;

        /// <summary>
        /// A qué transform sigue la palada. 2026-10-26 (recorrido del dueño en el Quest 3, «no pude realizar las operaciones
        /// con la pala»): el punto de anclaje de un agarre lejano está en la superficie de la pila, así que la palada nacía
        /// ahí, medio hundida en el montón, a varios metros de la mano, y había que barrer el rayo para llevarla; parecía que
        /// no pasaba nada. Con el anclaje cerca de la mano (agarre de cerca, o interactor directo) se sigue el anclaje; con
        /// el anclaje lejos, la herramienta va a la mano (el transform del interactor, que sigue al mando). Función pura.
        /// </summary>
        public static Transform ResolveHand(Transform interactor, Transform attach, float farDistance = FarAttachDistance)
        {
            if (attach == null) return interactor;
            if (interactor == null) return attach;
            return (attach.position - interactor.position).sqrMagnitude > farDistance * farDistance ? interactor : attach;
        }

        private void OnXrSelectExited(SelectExitEventArgs _) => RaiseReleased();

        // ── Carry ─────────────────────────────────────────────────────────────

        private void BeginCarry(InteractableBase _)
        {
            if (Carried != null) return;

            Vector3 start = _pendingHand != null ? _pendingHand.TransformPoint(handOffset) : transform.position + Vector3.up * 0.2f;
            Carried = CreateTool(start);
            Carried.Setup(this, SourceId);
            if (_pendingHand != null) Carried.Follow(_pendingHand, handOffset);

            CarryStarted?.Invoke(this, Carried);
        }

        private void EndCarry(InteractableBase _)
        {
            if (Carried == null) return;

            var tool = Carried;
            Carried = null;
            tool.StopFollowing();

            // Primero el soltado (las DropZone lo ven dentro), después se retira la herramienta.
            tool.DriverRelease();
            CarryEnded?.Invoke(this, tool);

            if (_proxyIsScene)
                StartCoroutine(HideAfter(tool.gameObject, lingerSeconds));
            else
                Destroy(tool.gameObject, lingerSeconds);
        }

        private System.Collections.IEnumerator HideAfter(GameObject proxy, float seconds)
        {
            yield return seconds > 0f ? new WaitForSeconds(seconds) : null;
            if (proxy != null) proxy.SetActive(false);
        }

        private void DiscardCarried()
        {
            if (Carried == null) return;
            var tool = Carried;
            Carried = null;
            if (_proxyIsScene) tool.gameObject.SetActive(false);
            else Destroy(tool.gameObject);
        }

        private CarriedItem CreateTool(Vector3 position)
        {
            GameObject go;
            _proxyIsScene = false;

            if (sceneProxy != null)
            {
                go = sceneProxy;
                _proxyIsScene = true;
                go.transform.position = position;
                go.SetActive(true);
            }
            else if (toolPrefab != null)
            {
                go = Instantiate(toolPrefab, position, Quaternion.identity);
                go.name = $"{SourceId}_carried";
            }
            else
            {
                go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                go.name = $"{SourceId}_carried";
                go.transform.position = position;
                go.transform.localScale = Vector3.one * defaultToolSize;
                var rend = go.GetComponent<Renderer>();
                if (rend != null) rend.material.color = defaultToolColor;
            }

            // Las zonas lo detectan por trigger: collider trigger + Rigidbody cinemático.
            var colliders = go.GetComponentsInChildren<Collider>();
            if (colliders.Length == 0)
            {
                var sphere = go.AddComponent<SphereCollider>();
                sphere.radius = 0.5f;
                sphere.isTrigger = true;
            }
            else
            {
                foreach (var col in colliders) col.isTrigger = true;
            }

            var rb = go.GetComponent<Rigidbody>();
            if (rb == null) rb = go.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;

            var carried = go.GetComponent<CarriedItem>();
            if (carried == null) carried = go.AddComponent<CarriedItem>();
            return carried;
        }
    }
}
