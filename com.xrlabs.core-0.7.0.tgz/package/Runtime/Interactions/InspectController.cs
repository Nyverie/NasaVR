using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRLabs.Interactions
{
    public class InspectController : MonoBehaviour
    {
        public Transform inspectPoint;

        private Vector3 originalPosition;
        private Quaternion originalRotation;

        private Rigidbody rb;
        private XRGrabInteractable grab;

        private bool isInspecting;

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
            grab = GetComponent<XRGrabInteractable>();
        }

        public void StartInspection()
        {
            if (inspectPoint == null) return;

            originalPosition = transform.position;
            originalRotation = transform.rotation;

            // mover al punto
            transform.position = inspectPoint.position;
            transform.rotation = inspectPoint.rotation;

            // bloquear física
            rb.isKinematic = true;

            // desactivar grab
            grab.enabled = false;

            isInspecting = true;

            Debug.Log("INSPECT MODE ON");
        }

        public void EndInspection()
        {
            transform.position = originalPosition;
            transform.rotation = originalRotation;

            rb.isKinematic = false;
            grab.enabled = true;

            isInspecting = false;

            Debug.Log("INSPECT MODE OFF");
        }

        public bool IsInspecting()
        {
            return isInspecting;
        }
    }
}
