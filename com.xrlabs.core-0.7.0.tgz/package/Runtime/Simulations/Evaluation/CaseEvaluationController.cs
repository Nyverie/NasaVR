using System;
using XRLabs.Core;
using XRLabs.Core.Telemetry;
using XRLabs.UI;
using UnityEngine;

namespace XRLabs.Simulations
{
    public class CaseEvaluationController : MonoBehaviour
    {
        [SerializeField] private EvaluationQuizPanel quizPanel;
        [SerializeField] private SessionManager sessionManager;
        [SerializeField] private AudioClip correctSfx;
        [SerializeField] private AudioClip incorrectSfx;

        public bool IsCaseCompleted { get; private set; }
        public CaseData CurrentCase => _currentCase;
        public int LastCaseTimeSeconds { get; private set; }
        public int LastCaseCorrectAnswers { get; private set; }
        public int LastCaseTotalQuestions { get; private set; }

        public event Action<CaseData> OnCaseCompleted;
        public event Action<int, int, int, int> OnQuestionProgressChanged;

        private CaseData _currentCase;
        private int _currentQuestionIndex;
        private bool[] _questionResults = Array.Empty<bool>();
        private float _caseStartTime;
        private float _questionShownTime;
        private bool _quizStarted;

        private void Awake()
        {
            if (quizPanel == null)
                Debug.LogError("[CaseEvaluationController] Falta la referencia al quizPanel.");

            if (sessionManager == null)
                sessionManager = FindObjectOfType<SessionManager>();

            HideQuiz();
        }

        public void SetSessionManager(SessionManager manager)
        {
            if (manager != null)
                sessionManager = manager;
        }

        public void StartCase(CaseData caseData)
        {
            if (caseData == null)
            {
                Debug.LogWarning("[CaseEvaluationController] StartCase recibio un CaseData nulo.");
                return;
            }

            _currentCase = caseData;
            _currentQuestionIndex = 0;
            _quizStarted = false;
            IsCaseCompleted = false;
            LastCaseTimeSeconds = 0;
            LastCaseCorrectAnswers = 0;
            LastCaseTotalQuestions = Mathf.Max(0, caseData.TotalQuestions);
            _caseStartTime = Time.time;
            _questionResults = new bool[Mathf.Max(3, caseData.TotalQuestions)];

            HideQuiz();
            NotifyQuestionProgressChanged();
        }

        public void StartQuizForCurrentCase()
        {
            if (_currentCase == null)
            {
                Debug.LogWarning("[CaseEvaluationController] No hay caso actual para iniciar quiz.");
                return;
            }

            if (quizPanel == null)
            {
                Debug.LogWarning("[CaseEvaluationController] No hay quizPanel asignado.");
                return;
            }

            _quizStarted = true;
            ShowCurrentQuestion();
        }

        public void ShowQuiz()
        {
            if (quizPanel != null)
                quizPanel.gameObject.SetActive(true);
        }

        public void HideQuiz()
        {
            _quizStarted = false;
            quizPanel?.HideQuiz();
        }

        public void ResetForNextCase()
        {
            _currentCase = null;
            _currentQuestionIndex = 0;
            _quizStarted = false;
            IsCaseCompleted = false;
            LastCaseTimeSeconds = 0;
            LastCaseCorrectAnswers = 0;
            LastCaseTotalQuestions = 0;
            _questionResults = Array.Empty<bool>();
            HideQuiz();
        }

        public void CompleteCase()
        {
            if (_currentCase == null || IsCaseCompleted)
                return;

            IsCaseCompleted = true;
            _quizStarted = false;
            LastCaseTimeSeconds = Mathf.RoundToInt(Time.time - _caseStartTime);
            LastCaseCorrectAnswers = CountCorrectAnswers();
            LastCaseTotalQuestions = Mathf.Max(0, _currentCase.TotalQuestions);

            var result = new CaseResultData
            {
                CaseNumber = _currentCase.caseNumber,
                FailureName = _currentCase.failureName,
                TypeCorrect = GetResult(0),
                CauseCorrect = GetResult(1),
                RecommendationCorrect = GetResult(2),
                CaseTimeSeconds = LastCaseTimeSeconds
            };

            Debug.Log($"[EVAL] Case result: case={_currentCase.caseNumber}, correct={LastCaseCorrectAnswers}, total={LastCaseTotalQuestions}, time={LastCaseTimeSeconds}");

            sessionManager?.RegisterCaseResult(result);
            HideQuiz();
            OnCaseCompleted?.Invoke(_currentCase);
        }

        public bool TryGetResults(
            out bool typeCorrect,
            out bool causeCorrect,
            out bool recommendationCorrect,
            out int caseTimeSeconds)
        {
            typeCorrect = GetResult(0);
            causeCorrect = GetResult(1);
            recommendationCorrect = GetResult(2);
            caseTimeSeconds = LastCaseTimeSeconds;

            return _currentCase != null;
        }

        private void ShowCurrentQuestion()
        {
            if (!_quizStarted || _currentCase == null || quizPanel == null)
                return;

            var question = _currentCase.GetQuestion(_currentQuestionIndex);
            if (question == null)
            {
                CompleteCase();
                return;
            }

            Debug.Log($"[QUIZ FLOW] ShowQuestion called for case {_currentCase.caseNumber} question {_currentQuestionIndex + 1}");
            _questionShownTime = Time.time;
            VOManager.Instance?.PlayInstruction(question.questionVO);
            quizPanel.ShowQuestion(
                question,
                _currentQuestionIndex + 1,
                _currentCase.TotalQuestions,
                HandleAnswerConfirmed);
        }

        private void HandleAnswerConfirmed(int selectedIndex)
        {
            if (_currentCase == null)
                return;

            var question = _currentCase.GetQuestion(_currentQuestionIndex);
            if (question == null)
            {
                CompleteCase();
                return;
            }

            bool isCorrect = selectedIndex == question.correctOptionIndex;
            VOManager.Instance?.PlaySFX(isCorrect ? correctSfx : incorrectSfx);

            if (_currentQuestionIndex >= 0 && _currentQuestionIndex < _questionResults.Length)
                _questionResults[_currentQuestionIndex] = isCorrect;

            Debug.Log($"[EVAL] Question result: selected={selectedIndex}, correct={question.correctOptionIndex}, isCorrect={isCorrect}, case={_currentCase.caseNumber}, question={_currentQuestionIndex + 1}");

            sessionManager?.RegisterAnswer(isCorrect);
            NotifyQuestionProgressChanged(_currentQuestionIndex + 1);

            // Un solo evento tipado al hub: llega al archivo local (LocalFileTelemetryChannel,
            // mismo formato que antes) y al API (ApiTelemetryChannel → POST /score-events).
            TelemetryHub.Emit(new QuizAnswerEvent
            {
                StepId = TelemetryContext.CurrentStepId,
                CaseNumber = _currentCase.caseNumber,
                QuestionIndex = _currentQuestionIndex,
                QuestionType = QuizAnswerEvent.TypeForIndex(_currentQuestionIndex),
                QuestionText = question.questionText,
                Options = new[] { question.optionA, question.optionB, question.optionC, question.optionD },
                CorrectAnswerIndex = question.correctOptionIndex,
                UserAnswerIndex = selectedIndex,
                IsCorrect = isCorrect,
                AttemptsUsed = 1,
                ResponseTimeSeconds = Time.time - _questionShownTime,
                ScoreDelta = isCorrect ? 10 : 0
            });

            string feedbackMessage = isCorrect
                ? question.correctFeedback
                : question.incorrectFeedback;

            quizPanel.ShowFeedback(
                isCorrect,
                feedbackMessage,
                selectedIndex,
                question.correctOptionIndex,
                AdvanceQuestion);
        }

        private void AdvanceQuestion()
        {
            _currentQuestionIndex++;

            if (_currentCase == null || _currentQuestionIndex >= _currentCase.TotalQuestions)
            {
                CompleteCase();
                return;
            }

            ShowCurrentQuestion();
        }

        private bool GetResult(int index)
        {
            return index >= 0 &&
                   _questionResults != null &&
                   index < _questionResults.Length &&
                   _questionResults[index];
        }

        private void NotifyQuestionProgressChanged()
        {
            NotifyQuestionProgressChanged(_currentQuestionIndex);
        }

        private void NotifyQuestionProgressChanged(int answeredQuestions)
        {
            if (_currentCase == null)
                return;

            int elapsedSeconds = Mathf.RoundToInt(Time.time - _caseStartTime);
            OnQuestionProgressChanged?.Invoke(
                Mathf.Clamp(answeredQuestions, 0, _currentCase.TotalQuestions),
                _currentCase.TotalQuestions,
                CountCorrectAnswers(),
                elapsedSeconds);
        }

        private int CountCorrectAnswers()
        {
            int count = 0;

            if (_questionResults == null)
                return count;

            int totalQuestions = _currentCase != null ? _currentCase.TotalQuestions : _questionResults.Length;
            int max = Mathf.Clamp(totalQuestions, 0, _questionResults.Length);

            for (int i = 0; i < max; i++)
            {
                if (_questionResults[i])
                    count++;
            }

            return count;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        public int DEBUG_CurrentQuestionIndex => _currentQuestionIndex;
        public int DEBUG_AttemptsOnCurrentQuestion => 0;
        public CaseData DEBUG_CurrentCase => _currentCase;

        public void DEBUG_SelectAnswer(bool isCorrect)
        {
            if (_currentCase == null)
                return;

            var question = _currentCase.GetQuestion(_currentQuestionIndex);
            if (question == null)
                return;

            int selectedIndex = isCorrect
                ? question.correctOptionIndex
                : question.correctOptionIndex == 0 ? 1 : 0;

            HandleAnswerConfirmed(selectedIndex);
        }
#endif
    }
}
