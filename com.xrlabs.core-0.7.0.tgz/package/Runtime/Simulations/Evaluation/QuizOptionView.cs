﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    public class QuizOptionView : MonoBehaviour
    {
        [SerializeField] private Button button;
        [SerializeField] private Image background;
        [SerializeField] private TextMeshProUGUI label;

        private Action _onClicked;
        private Color _defaultColor;
        private Color _selectedColor;
        private Color _correctColor;
        private Color _incorrectColor;

        public bool IsValid()
        {
            return button != null && background != null && label != null;
        }

        public void Configure(
            Action onClicked,
            Color defaultColor,
            Color selectedColor,
            Color correctColor,
            Color incorrectColor)
        {
            _onClicked = onClicked;
            _defaultColor = defaultColor;
            _selectedColor = selectedColor;
            _correctColor = correctColor;
            _incorrectColor = incorrectColor;

            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(HandleClicked);

            SetDefaultVisual();
        }

        public void SetText(string text)
        {
            label.text = text;
        }

        public void SetInteractable(bool interactable)
        {
            button.interactable = interactable;
        }

        public void SetDefaultVisual()
        {
            background.color = _defaultColor;
        }

        public void SetSelectedVisual()
        {
            background.color = _selectedColor;
        }

        public void SetCorrectVisual()
        {
            background.color = _correctColor;
        }

        public void SetIncorrectVisual()
        {
            background.color = _incorrectColor;
        }

        private void HandleClicked()
        {
            _onClicked?.Invoke();
        }
    }
}