using UnityEngine;
using UnityEngine.Serialization;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Configuración completa de un caso evaluativo.
    /// Las 3 preguntas se editan directamente aquí — no se necesitan assets separados.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Evaluation/Case Data")]
    public class CaseData : ScriptableObject
    {
        [Header("Identificación")]
        public int caseNumber;
        public string failureName;

        [Header("Modelo 3D")]
        [Tooltip("Prefab del modelo con la falla. Se muestra durante la inspección libre.")]
        [FormerlySerializedAs("drillBitPrefab")]
        public GameObject modelPrefab;

        [Header("Presentación visual")]
        [Tooltip("Offset local aplicado desde el punto de presentación. Usar ajustes pequeños para centrar la falla sin mover el anchor.")]
        public Vector3 presentationPositionOffset = Vector3.zero;

        [Tooltip("Rotación adicional aplicada sobre el punto de presentación para orientar la falla hacia el usuario.")]
        public Vector3 presentationRotationOffset = Vector3.zero;

        [Tooltip("Tamaño máximo del modelo para este caso. 0 usa el valor global del EvaluationSessionController.")]
        public float presentationMaxSizeOverride = 0f;

        [Header("Preguntas — configurar las 3 aquí")]
        [Tooltip("Q1 = tipo de falla, Q2 = causa, Q3 = recomendación")]
        public QuestionData[] questions = new QuestionData[3];

        [Header("Intro del caso")]
        [TextArea(2, 4)]
        public string caseIntroText;
        public AudioClip caseIntroVO;
        public Sprite caseImage;

        public QuestionData GetQuestion(int index)
        {
            if (questions == null || index < 0 || index >= questions.Length)
                return null;
            return questions[index];
        }

        public int TotalQuestions => questions != null ? questions.Length : 0;
    }
}
