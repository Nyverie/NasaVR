using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Pregunta MC con 4 opciones. Clase serializable — se configura directamente
    /// dentro del CaseData sin necesitar un archivo .asset separado.
    /// </summary>
    [System.Serializable]
    public class QuestionData
    {
        [TextArea(2, 4)]
        public string questionText;

        [Header("Opciones")]
        public string optionA;
        public string optionB;
        public string optionC;
        public string optionD;

        [Header("Respuesta")]
        [Tooltip("Índice de la opción correcta: 0=A, 1=B, 2=C, 3=D")]
        [Range(0, 3)]
        public int correctOptionIndex;

        [Header("Feedback")]
        [TextArea(1, 2)]
        public string correctFeedback = "¡Correcto!";
        [TextArea(1, 2)]
        public string incorrectFeedback = "Incorrecto. Revisá las características de la falla.";

        [Header("Audio (opcional)")]
        public AudioClip questionVO;

        public string GetOption(int index) => index switch
        {
            0 => optionA,
            1 => optionB,
            2 => optionC,
            3 => optionD,
            _ => string.Empty
        };
    }
}
