using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    public class EvaluationQuizPanel : MonoBehaviour
    {
        [Header("Question")]
        [SerializeField] private TextMeshProUGUI questionCounterText;
        [SerializeField] private TextMeshProUGUI questionText;

        [Header("Options")]
        [SerializeField] private QuizOptionView[] optionViews = new QuizOptionView[4];
        [SerializeField] private Color defaultOptionColor = Color.white;
        [SerializeField] private Color selectedOptionColor = new Color(0.85f, 0.92f, 1f, 1f);
        [SerializeField] private Color correctOptionColor = new Color(0.65f, 0.95f, 0.70f, 1f);
        [SerializeField] private Color incorrectOptionColor = new Color(1f, 0.75f, 0.75f, 1f);

        [Header("Feedback")]
        [SerializeField] private GameObject feedbackPanel;
        [SerializeField] private TextMeshProUGUI feedbackText;
        [SerializeField] private CanvasGroup canvasGroup;

        [Header("Confirm")]
        [SerializeField] private Button confirmButton;
        [SerializeField] private TextMeshProUGUI confirmButtonText;
        [SerializeField] private string confirmLabel = "Confirmar";
        [SerializeField] private string continueLabel = "Continuar";

        private Action<int> _onAnswerConfirmed;
        private Action _onContinueRequested;
        private int _selectedOptionIndex = -1;
        private bool _showingFeedback;
        private bool _configurationValid;
        private bool _initialized;

        private void Awake()
        {
            if (!EnsureInitialized())
            {
                enabled = false;
                gameObject.SetActive(false);
                return;
            }

            HideQuiz();
        }

        private void Start()
        {
            ApplyLayoutDefaults();
        }

        /// <summary>
        /// Aplica separación visual entre los botones de opción si el VerticalLayoutGroup
        /// no tiene spacing configurado. Evita tocar el prefab/escena directamente.
        /// </summary>
        private void ApplyLayoutDefaults()
        {
            if (questionText != null)
            {
                questionText.enableWordWrapping = true;
                questionText.enableAutoSizing = true;
                questionText.fontSizeMin = 22f;
                questionText.fontSizeMax = Mathf.Max(questionText.fontSize, 30f);
            }

            if (feedbackText != null)
            {
                feedbackText.enableWordWrapping = true;
                feedbackText.enableAutoSizing = true;
                feedbackText.fontSizeMin = 18f;
                feedbackText.fontSizeMax = Mathf.Max(feedbackText.fontSize, 24f);
            }

            if (confirmButtonText != null)
            {
                confirmButtonText.enableAutoSizing = true;
                confirmButtonText.fontSizeMin = 18f;
                confirmButtonText.fontSizeMax = Mathf.Max(confirmButtonText.fontSize, 24f);
            }

            if (optionViews == null || optionViews.Length == 0 || optionViews[0] == null)
                return;

            // El contenedor de opciones es el padre inmediato del primer optionView.
            Transform optionsContainer = optionViews[0].transform.parent;
            if (optionsContainer == null)
                return;

            var vLayout = optionsContainer.GetComponent<VerticalLayoutGroup>();
            if (vLayout != null && vLayout.spacing < 12f)
            {
                // Añadir separación entre botones. El valor 12 está en unidades locales del contenedor
                // (~2–3 cm en mundo VR a la escala típica de este canvas).
                vLayout.spacing = 12f;
                vLayout.padding = new RectOffset(
                    vLayout.padding.left,
                    vLayout.padding.right,
                    Mathf.Max(vLayout.padding.top, 8),
                    Mathf.Max(vLayout.padding.bottom, 8));
            }
        }

        public void ShowQuestion(
            QuestionData question,
            int questionNumber,
            int totalQuestions,
            Action<int> onAnswerConfirmed)
        {
            if (!EnsureInitialized() || question == null)
            {
                Debug.LogWarning("[EvaluationQuizPanel] No se puede mostrar la pregunta.");
                return;
            }

            gameObject.SetActive(true);
            SetCanvasGroupVisible(true);
            Debug.Log($"[QUIZ VISIBILITY] ShowQuestion called: Pregunta {questionNumber}/{totalQuestions}");

            _onAnswerConfirmed = onAnswerConfirmed;
            _onContinueRequested = null;
            _selectedOptionIndex = -1;
            _showingFeedback = false;

            if (questionCounterText != null)
                questionCounterText.text = $"Pregunta {questionNumber} de {totalQuestions}";

            questionText.text = question.questionText;

            for (int i = 0; i < optionViews.Length; i++)
            {
                optionViews[i].SetText(question.GetOption(i));
                optionViews[i].SetInteractable(true);
                optionViews[i].SetDefaultVisual();
            }

            feedbackPanel.SetActive(false);
            feedbackText.text = string.Empty;

            confirmButton.interactable = false;
            SetConfirmButtonLabel(confirmLabel);
        }

        public void ShowFeedback(
            bool isCorrect,
            string message,
            int selectedOptionIndex,
            int correctOptionIndex,
            Action onContinueRequested)
        {
            if (!_configurationValid)
                return;

            _showingFeedback = true;
            _onContinueRequested = onContinueRequested;

            SetOptionsInteractable(false);

            if (selectedOptionIndex >= 0 && selectedOptionIndex < optionViews.Length)
            {
                if (isCorrect)
                    optionViews[selectedOptionIndex].SetCorrectVisual();
                else
                    optionViews[selectedOptionIndex].SetIncorrectVisual();
            }

            if (!isCorrect &&
                correctOptionIndex >= 0 &&
                correctOptionIndex < optionViews.Length &&
                correctOptionIndex != selectedOptionIndex)
            {
                optionViews[correctOptionIndex].SetCorrectVisual();
            }

            feedbackText.text = message;
            feedbackPanel.SetActive(true);

            confirmButton.interactable = true;
            SetConfirmButtonLabel(continueLabel);
        }

        public void HideQuiz()
        {
            EnsureInitialized();

            _selectedOptionIndex = -1;
            _showingFeedback = false;
            _onAnswerConfirmed = null;
            _onContinueRequested = null;

            if (feedbackPanel != null)
                feedbackPanel.SetActive(false);

            if (feedbackText != null)
                feedbackText.text = string.Empty;

            Debug.Log("[QUIZ VISIBILITY] HideQuiz called");

            if (canvasGroup != null)
            {
                SetCanvasGroupVisible(false);
            }
            else
            {
                gameObject.SetActive(false);
            }
        }

        public void Hide()
        {
            HideQuiz();
        }

        private void ConfigureOptionViews()
        {
            for (int i = 0; i < optionViews.Length; i++)
            {
                int optionIndex = i;
                optionViews[i].Configure(
                    () => HandleOptionSelected(optionIndex),
                    defaultOptionColor,
                    selectedOptionColor,
                    correctOptionColor,
                    incorrectOptionColor);
            }
        }

        private void ConfigureConfirmButton()
        {
            confirmButton.onClick.RemoveAllListeners();
            confirmButton.onClick.AddListener(HandleConfirmButtonPressed);
        }

        private void HandleOptionSelected(int optionIndex)
        {
            if (_showingFeedback)
                return;

            _selectedOptionIndex = optionIndex;

            for (int i = 0; i < optionViews.Length; i++)
                optionViews[i].SetDefaultVisual();

            optionViews[optionIndex].SetSelectedVisual();
            confirmButton.interactable = true;
        }

        private void HandleConfirmButtonPressed()
        {
            if (_showingFeedback)
            {
                _showingFeedback = false;
                feedbackPanel.SetActive(false);

                var continueAction = _onContinueRequested;
                _onContinueRequested = null;
                continueAction?.Invoke();
                return;
            }

            if (_selectedOptionIndex < 0)
            {
                Debug.LogWarning("[EvaluationQuizPanel] Selecciona una opcion antes de confirmar.");
                return;
            }

            SetOptionsInteractable(false);
            confirmButton.interactable = false;
            _onAnswerConfirmed?.Invoke(_selectedOptionIndex);
        }

        private void SetOptionsInteractable(bool interactable)
        {
            for (int i = 0; i < optionViews.Length; i++)
                optionViews[i].SetInteractable(interactable);
        }

        private void SetConfirmButtonLabel(string label)
        {
            if (confirmButtonText != null)
                confirmButtonText.text = label;
        }

        private bool EnsureInitialized()
        {
            if (_initialized)
                return _configurationValid;

            if (canvasGroup == null)
                canvasGroup = GetComponent<CanvasGroup>();

            _configurationValid = ValidateConfiguration();

            if (!_configurationValid)
                return false;

            ConfigureOptionViews();
            ConfigureConfirmButton();

            _initialized = true;
            Debug.Log("[QUIZ VISIBILITY] EvaluationQuizPanel initialized");
            return true;
        }

        private void SetCanvasGroupVisible(bool visible)
        {
            if (canvasGroup == null)
                return;

            canvasGroup.alpha = visible ? 1f : 0f;
            canvasGroup.interactable = visible;
            canvasGroup.blocksRaycasts = visible;
            Debug.Log($"[QUIZ VISIBILITY] CanvasGroup {(visible ? "visible" : "hidden")}");
        }

        private bool ValidateConfiguration()
        {
            if (questionText == null)
            {
                Debug.LogError("[EvaluationQuizPanel] Falta Question Text.");
                return false;
            }

            if (confirmButton == null)
            {
                Debug.LogError("[EvaluationQuizPanel] Falta Confirm Button.");
                return false;
            }

            if (feedbackPanel == null || feedbackText == null)
            {
                Debug.LogError("[EvaluationQuizPanel] Falta Feedback Panel o Feedback Text.");
                return false;
            }

            if (optionViews == null || optionViews.Length != 4)
            {
                Debug.LogError("[EvaluationQuizPanel] Debes asignar exactamente 4 opciones.");
                return false;
            }

            for (int i = 0; i < optionViews.Length; i++)
            {
                if (optionViews[i] == null || !optionViews[i].IsValid())
                {
                    Debug.LogError($"[EvaluationQuizPanel] La opcion {i} no esta bien configurada.");
                    return false;
                }
            }

            return true;
        }
    }
}
