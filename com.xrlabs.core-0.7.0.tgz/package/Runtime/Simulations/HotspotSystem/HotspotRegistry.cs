using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Singleton que mantiene el estado de todos los HotspotMarkers de la escena.
    /// Las StepConditions consultan aquí para saber si se cumplió la interacción.
    /// </summary>
    public class HotspotRegistry : MonoBehaviour
    {
        public static HotspotRegistry Instance { get; private set; }

        [Header("Touch cooldown")]
        [SerializeField] private string cooldownZone = "guided_parts";
        [SerializeField] private float secondsBetweenTouches = 5f;

        private readonly Dictionary<string, HotspotMarker> _hotspots = new();
        private float _nextAllowedTouchAt;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void Register(HotspotMarker marker)
        {
            if (marker == null || string.IsNullOrEmpty(marker.HotspotId)) return;
            _hotspots[marker.HotspotId] = marker;
        }

        public void Unregister(HotspotMarker marker)
        {
            if (marker == null) return;

            if (_hotspots.TryGetValue(marker.HotspotId, out var registeredMarker) &&
                registeredMarker == marker)
            {
                _hotspots.Remove(marker.HotspotId);
            }
        }

        public void NotifyTouched(HotspotMarker marker)
        {
            // Hook para debug o eventos futuros
            if (marker != null && marker.Zone == cooldownZone && secondsBetweenTouches > 0f)
                _nextAllowedTouchAt = Time.time + secondsBetweenTouches;

            Debug.Log($"[HotspotRegistry] Tocado: {marker.HotspotId} (zona: {marker.Zone})");
        }

        public bool CanTouch(HotspotMarker marker)
        {
            if (marker == null || marker.Zone != cooldownZone || secondsBetweenTouches <= 0f)
                return true;

            return Time.time >= _nextAllowedTouchAt;
        }

        /// <summary>Retorna true si el hotspot con ese ID fue tocado.</summary>
        public bool IsHotspotTouched(string id)
        {
            return _hotspots.TryGetValue(id, out var marker) && marker.IsTouched;
        }

        public void ResetHotspot(string id)
        {
            if (_hotspots.TryGetValue(id, out var marker))
                marker.Reset();
        }

        /// <summary>Retorna true si todos los hotspots de la zona fueron tocados.</summary>
        public bool AreAllHotspotsInZoneTouched(string zone)
        {
            RemoveDestroyedHotspots();

            var zoneHotspots = _hotspots.Values.Where(h => h != null && h.Zone == zone).ToList();
            return zoneHotspots.Count > 0 && zoneHotspots.All(h => h.IsTouched);
        }

        /// <summary>Resetea todos los hotspots de una zona para reutilización.</summary>
        public void ResetZone(string zone)
        {
            RemoveDestroyedHotspots();

            foreach (var marker in _hotspots.Values.Where(h => h != null && h.Zone == zone))
                marker.Reset();

            if (zone == cooldownZone)
                _nextAllowedTouchAt = 0f;
        }

        /// <summary>Cuántos hotspots de la zona han sido tocados.</summary>
        public (int touched, int total) GetZoneProgress(string zone)
        {
            RemoveDestroyedHotspots();

            var zoneHotspots = _hotspots.Values.Where(h => h != null && h.Zone == zone).ToList();
            return (zoneHotspots.Count(h => h.IsTouched), zoneHotspots.Count);
        }

        public bool AreAllHotspotsInZoneTouched(string zone, int expectedCount)
        {
            RemoveDestroyedHotspots();

            var zoneHotspots = _hotspots.Values.Where(h => h != null && h.Zone == zone).ToList();
            return zoneHotspots.Count >= expectedCount && zoneHotspots.All(h => h.IsTouched);
        }

        private void RemoveDestroyedHotspots()
        {
            var destroyedIds = _hotspots
                .Where(pair => pair.Value == null)
                .Select(pair => pair.Key)
                .ToList();

            foreach (var id in destroyedIds)
                _hotspots.Remove(id);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        /// <summary>Solo debug. Retorna todos los IDs de hotspots registrados.</summary>
        public List<string> DEBUG_GetAllHotspotIds() => new List<string>(_hotspots.Keys);

        /// <summary>Solo debug. Simula el toque de un hotspot por ID.</summary>
        public void DEBUG_SimulateTouch(string hotspotId)
        {
            if (_hotspots.TryGetValue(hotspotId, out var marker))
                marker.Touch();
            else
                Debug.LogWarning($"[HotspotRegistry] DEBUG_SimulateTouch: ID '{hotspotId}' no encontrado.");
        }
#endif
    }
}
