using System;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Marks an inspection point on a 3D model and reports touches to HotspotRegistry.
    /// </summary>
    public class HotspotMarker : MonoBehaviour
    {
        [Header("Identification")]
        [SerializeField] private string hotspotId;
        [SerializeField] private string zone;

        [Header("Visuals")]
        [SerializeField] private GameObject normalState;
        [SerializeField] private GameObject touchedState;

        public string HotspotId => hotspotId;
        public string Zone => zone;
        public bool IsTouched { get; private set; }

        public event Action<HotspotMarker> OnTouched;

        private void Awake()
        {
            HotspotRegistry.Instance?.Register(this);
            SetVisualState(false);
        }

        private void OnDestroy()
        {
            HotspotRegistry.Instance?.Unregister(this);
        }

        public void Touch()
        {
            if (IsTouched) return;

            if (HotspotRegistry.Instance != null && !HotspotRegistry.Instance.CanTouch(this))
                return;

            IsTouched = true;
            SetVisualState(true);
            OnTouched?.Invoke(this);
            HotspotRegistry.Instance?.NotifyTouched(this);
        }

        public void Reset()
        {
            IsTouched = false;
            SetVisualState(false);
        }

        public void SetInteractionVisible(bool visible)
        {
            var markerCollider = GetComponent<Collider>();
            if (markerCollider != null)
                markerCollider.enabled = visible;

            if (!visible)
            {
                if (normalState) normalState.SetActive(false);
                if (touchedState) touchedState.SetActive(false);
                return;
            }

            SetVisualState(IsTouched);
        }

        private void SetVisualState(bool touched)
        {
            if (normalState) normalState.SetActive(!touched);
            if (touchedState) touchedState.SetActive(touched);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (IsInteractor(other))
            {
                Touch();
            }
        }

        private static bool IsInteractor(Collider other)
        {
            if (other == null)
                return false;

            string objectTag = other.gameObject.tag;
            string objectName = other.name;

            // Verificar también el padre: en Meta ISDK el poke interactor puede tener
            // hijos con colliders sin nombre descriptivo propio.
            string parentName = other.transform.parent != null
                ? other.transform.parent.name
                : string.Empty;

            return string.Equals(objectTag, "XRController", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(objectTag, "Player", StringComparison.OrdinalIgnoreCase) ||
                   ContainsInteractorKeyword(objectName) ||
                   ContainsInteractorKeyword(parentName);
        }

        /// <summary>
        /// Devuelve true si el nombre contiene alguna palabra clave de interactor XR/VR.
        /// Cubre: controladores clásicos, manos, Meta Quest PokeInteractor y fingertips.
        /// </summary>
        private static bool ContainsInteractorKeyword(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;

            return name.IndexOf("Controller",  StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("Hand",        StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("Poke",        StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("Finger",      StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("Interactor",  StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
