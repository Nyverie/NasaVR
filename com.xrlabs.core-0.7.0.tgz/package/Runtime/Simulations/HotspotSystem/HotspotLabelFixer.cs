using TMPro;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Hace que todos los labels TMP hijos miren siempre hacia la cámara principal.
    /// Soluciona el texto "OK" / "?" al revés cuando la broca se rota en VR.
    /// Colocar en el GO raíz de la broca (Broca_Grababble).
    /// </summary>
    public class HotspotLabelFixer : MonoBehaviour
    {
        private Camera _camera;
        private TextMeshPro[] _labels;

        private void Start()
        {
            _camera = Camera.main;
            // Recolecta todos los TMP del prefab (QuestionMark y CheckMark de cada hotspot)
            _labels = GetComponentsInChildren<TextMeshPro>(true);
        }

        private void LateUpdate()
        {
            if (_labels == null || _labels.Length == 0)
                return;

            if (_camera == null)
            {
                _camera = Camera.main;
                if (_camera == null) return;
            }

            Vector3 cameraPos = _camera.transform.position;

            foreach (var label in _labels)
            {
                if (label == null) continue;

                // Solo actualizar labels activos en jerarquía
                if (!label.gameObject.activeInHierarchy) continue;

                Vector3 toCamera = cameraPos - label.transform.position;
                if (toCamera.sqrMagnitude < 0.0001f) continue;

                // TextMeshPro 3D renderiza texto hacia +Z del transform.
                // Para que sea legible desde la cámara, +Z debe apuntar HACIA la cámara.
                label.transform.rotation = Quaternion.LookRotation(toCamera.normalized, Vector3.up);
            }
        }
    }
}
