using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.Controls;
using UnityEngine.UI;
using XRLabs.Core;
using XRController = UnityEngine.InputSystem.XR.XRController;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Panel de desarrollo del HUD (2026-10-25, primera corrida de la muestra de compostaje en un Quest 3). El dueño pidió
    /// desde el casco «apretando algún botón en modo dev poder saltar los audios y los pasos y saber dónde me encuentro,
    /// como en Unity»: en el Editor eso lo hace el <c>SimDebugHUD</c> (F1/F2/F4), pero es IMGUI y en el visor no existe.
    /// Este panel es uGUI, vive en el mismo canvas del HUD (que <c>HudPlacement</c> pasa al mundo en el visor) y el rayo de
    /// los mandos pulsa sus botones.
    ///
    /// Enseña dónde está la persona («Paso n de m · id · título [fase]») y qué viene después, y trae cuatro botones:
    /// saltar la frase en curso, completar el paso, ir al paso anterior y al siguiente. Atajos de mando: B (secundario
    /// derecho) completa el paso e Y (secundario izquierdo) salta la frase.
    ///
    /// Solo existe en desarrollo (<c>Debug.isDebugBuild</c> o el Editor): en una build de entrega se oculta con su
    /// CanvasGroup, no se suscribe a nada y no lee los mandos. Como <see cref="ManualStepButton"/>, nunca apaga su propio
    /// objeto (su Start tiene que correr).
    /// </summary>
    public class DevStepPanel : MonoBehaviour
    {
        // ◄ y ► (U+25C4, U+25BA) y no ◀ ▶: LiberationSans, la fuente por defecto de TextMeshPro, no trae estos últimos y
        // en el visor saldrían como cuadrados.
        public const string SkipLineLabel = "Saltar frase";
        public const string CompleteStepLabel = "Completar paso";
        public const string PreviousLabel = "◄ Anterior";
        public const string NextLabel = "Siguiente ►";
        public const string ShortcutsHint = "B: completar · Y: saltar frase";

        // Nombre del control en los perfiles de mando de OpenXR (Meta Touch y compañía); si un perfil no lo llama así, se
        // busca por su uso.
        private const string SecondaryButtonName = "secondaryButton";
        private const string SecondaryButtonUsage = "{SecondaryButton}";

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private CanvasGroup group;
        [SerializeField] private TMP_Text statusText;
        [SerializeField] private TMP_Text nextText;
        [SerializeField] private Button skipLineButton;
        [SerializeField] private Button completeStepButton;
        [SerializeField] private Button previousButton;
        [SerializeField] private Button nextButton;

        private bool _dev;
        private bool _wired;
        private string _status = string.Empty;
        private string _next = string.Empty;

        /// <summary>True en el Editor y en las builds de desarrollo: ahí, y solo ahí, el panel se enseña.</summary>
        public static bool IsDevBuild => UnityEngine.Debug.isDebugBuild || Application.isEditor;

        public bool IsShowing { get; private set; }

        /// <summary>La línea «Paso n de m · id · título [fase]» tal como se enseña (también sin componente de texto).</summary>
        public string StatusText => _status;

        /// <summary>La línea «Siguiente: id» (o «Siguiente: fin»).</summary>
        public string NextText => _next;

        private void Awake()
        {
            if (group == null && !TryGetComponent(out group)) group = gameObject.AddComponent<CanvasGroup>();
            _dev = IsDevBuild;
            SetVisible(_dev);
            if (!_dev) enabled = false;   // en una build de entrega no hay Update ni Start: no escucha nada
        }

        private void Start()
        {
            if (!_dev) return;
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();

            // Los botones se enlazan en Start, no en Awake: así ya están asignados los campos de la escena (o de la prueba).
            Listen(skipLineButton, SkipLine);
            Listen(completeStepButton, CompleteStep);
            Listen(previousButton, PreviousStep);
            Listen(nextButton, NextStep);
            _wired = true;

            if (stepSystem != null)
            {
                stepSystem.StepStarted += HandleStepStarted;
                stepSystem.JumpedToStep += HandleJumped;
                stepSystem.PhaseChanged += HandlePhase;
                stepSystem.StepsFinished += Refresh;
            }
            Refresh();
        }

        private void OnDestroy()
        {
            if (_wired)
            {
                Unlisten(skipLineButton, SkipLine);
                Unlisten(completeStepButton, CompleteStep);
                Unlisten(previousButton, PreviousStep);
                Unlisten(nextButton, NextStep);
            }
            if (stepSystem == null) return;
            stepSystem.StepStarted -= HandleStepStarted;
            stepSystem.JumpedToStep -= HandleJumped;
            stepSystem.PhaseChanged -= HandlePhase;
            stepSystem.StepsFinished -= Refresh;
        }

        private void Update()
        {
            if (!_dev) return;
            // En pantalla no hay mandos: XRController.rightHand/leftHand son null y no pasa nada.
            if (WasSecondaryPressed(XRController.rightHand)) CompleteStep();   // B
            if (WasSecondaryPressed(XRController.leftHand)) SkipLine();        // Y
        }

        // ── Acciones (las de los botones; públicas para las pruebas) ──────────

        /// <summary>Corta la frase del coach en curso. Sin frase sonando no hace nada.</summary>
        public void SkipLine() => VOManager.Instance?.Skip();

        /// <summary>Da por hecho el paso en curso, sin esperar su condición ni las frases que faltan.</summary>
        public void CompleteStep()
        {
            if (stepSystem == null || !stepSystem.IsRunning) return;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            stepSystem.DebugForceAdvanceCurrentStep();
#else
            stepSystem.CompleteCurrentStep();
#endif
        }

        public void PreviousStep() => JumpBy(-1);

        public void NextStep() => JumpBy(+1);

        // Salta un paso hacia atrás o hacia delante, acotado a [0, TotalSteps-1]. En el borde no hace nada (no reinicia el
        // paso en curso); antes de empezar tampoco (saltar arrancaría los pasos sin StartSteps); con la experiencia
        // terminada, «Anterior» vuelve al último paso.
        private void JumpBy(int delta)
        {
            if (stepSystem == null) return;
            int total = stepSystem.TotalSteps;
            int current = stepSystem.CurrentStepIndex;
            if (total <= 0) return;
            if (!stepSystem.IsRunning && current < total) return;
            int target = Mathf.Clamp(current + delta, 0, total - 1);
            if (delta > 0 ? target <= current : target >= current) return;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            stepSystem.DebugJumpToStep(target);
#else
            stepSystem.JumpToStep(target);
#endif
        }

        // ── Texto ─────────────────────────────────────────────────────────────

        /// <summary>Recalcula las dos líneas. Lee el paso por índice y no CurrentStep: en JumpedToStep el índice ya es el
        /// del destino y el paso todavía es el de origen.</summary>
        public void Refresh()
        {
            if (stepSystem == null)
            {
                SetTexts("Sin StepSystem en la escena", string.Empty);
                return;
            }

            int total = stepSystem.TotalSteps;
            int index = stepSystem.CurrentStepIndex;
            string status;
            if (!stepSystem.IsRunning)
                status = index >= total && total > 0
                    ? $"Terminado · {total} de {total} pasos"
                    : $"Paso — de {total} · sin empezar";
            else
            {
                var step = stepSystem.Sequence != null ? stepSystem.Sequence.GetStep(index) : null;
                status = $"Paso {index + 1} de {total} · {IdOf(step)}";
                if (step != null && !string.IsNullOrWhiteSpace(step.titleText)) status += " · " + step.titleText.Trim();
                string phase = PhaseLabel(stepSystem.Phase);
                if (phase.Length > 0) status += $" [{phase}]";
            }

            var following = stepSystem.IsRunning && stepSystem.Sequence != null ? stepSystem.Sequence.GetStep(index + 1) : null;
            string next = following != null ? "Siguiente: " + IdOf(following) : "Siguiente: fin";
            SetTexts(status, next);
        }

        /// <summary>La fase del paso en texto corto.</summary>
        public static string PhaseLabel(StepSystem.StepPhase phase) => phase switch
        {
            StepSystem.StepPhase.Intro => "intro",
            StepSystem.StepPhase.Active => "escuchando",
            StepSystem.StepPhase.Correcting => "corrigiendo",
            StepSystem.StepPhase.Confirming => "confirmando",
            _ => string.Empty
        };

        private static string IdOf(StepDefinition step) =>
            step == null ? "—" : string.IsNullOrEmpty(step.stepId) ? step.name : step.stepId;

        private void SetTexts(string status, string next)
        {
            _status = status;
            _next = next;
            if (statusText != null) statusText.text = status;
            if (nextText != null) nextText.text = next;
        }

        private void HandleStepStarted(StepDefinition step, int index, int total) => Refresh();

        private void HandleJumped(int from, int to) => Refresh();

        private void HandlePhase(StepSystem.StepPhase phase) => Refresh();

        // ── Utilidades ────────────────────────────────────────────────────────

        private static bool WasSecondaryPressed(XRController controller)
        {
            if (controller == null) return false;
            var button = controller.TryGetChildControl(SecondaryButtonName) as ButtonControl
                         ?? controller.TryGetChildControl(SecondaryButtonUsage) as ButtonControl;
            return button != null && button.wasPressedThisFrame;
        }

        private static void Listen(Button button, UnityEngine.Events.UnityAction action)
        {
            if (button != null) button.onClick.AddListener(action);
        }

        private static void Unlisten(Button button, UnityEngine.Events.UnityAction action)
        {
            if (button != null) button.onClick.RemoveListener(action);
        }

        private void SetVisible(bool visible)
        {
            IsShowing = visible;
            if (group == null) return;
            group.alpha = visible ? 1f : 0f;
            group.interactable = visible;
            group.blocksRaycasts = visible;
        }
    }
}
