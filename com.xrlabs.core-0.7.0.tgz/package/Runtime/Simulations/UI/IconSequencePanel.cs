using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Panel que muestra una secuencia de iconos iluminándolos uno a uno,
    /// sincronizado con el VO del paso guiado.
    /// </summary>
    public class IconSequencePanel : MonoBehaviour
    {
        [System.Serializable]
        public class IconEntry
        {
            public Image icon;
            public TMPro.TextMeshProUGUI label;
            [Tooltip("Segundos desde el inicio del VO para iluminar este icono")]
            public float triggerTime;
        }

        [SerializeField] private List<IconEntry> icons;
        [SerializeField] private Color activeColor = Color.white;
        [SerializeField] private Color inactiveColor = new Color(1f, 1f, 1f, 0.3f);

        private Coroutine _sequenceCoroutine;

        private void Awake()
        {
            ResetAll();
        }

        /// <summary>Inicia la secuencia de iluminación desde el principio.</summary>
        public void PlaySequence()
        {
            ResetAll();
            if (_sequenceCoroutine != null) StopCoroutine(_sequenceCoroutine);
            _sequenceCoroutine = StartCoroutine(SequenceRoutine());
        }

        public void StopSequence()
        {
            if (_sequenceCoroutine != null) StopCoroutine(_sequenceCoroutine);
        }

        public void HighlightAt(int index)
        {
            for (int i = 0; i < icons.Count; i++)
                SetIconActive(i, i == index);
        }

        private void ResetAll()
        {
            for (int i = 0; i < icons.Count; i++)
                SetIconActive(i, false);
        }

        private void SetIconActive(int index, bool active)
        {
            var entry = icons[index];
            if (entry.icon) entry.icon.color = active ? activeColor : inactiveColor;
            if (entry.label) entry.label.color = active ? activeColor : inactiveColor;
        }

        private IEnumerator SequenceRoutine()
        {
            float elapsed = 0f;
            int nextIndex = 0;

            while (nextIndex < icons.Count)
            {
                elapsed += Time.deltaTime;

                if (elapsed >= icons[nextIndex].triggerTime)
                {
                    SetIconActive(nextIndex, true);
                    nextIndex++;
                }

                yield return null;
            }
        }
    }
}
