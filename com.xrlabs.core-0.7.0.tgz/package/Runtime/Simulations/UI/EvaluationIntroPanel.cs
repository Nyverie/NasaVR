using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    public class EvaluationIntroPanel : MonoBehaviour
    {
        [SerializeField] private Button startButton;
        [SerializeField] private TMP_Text titleText;
        [SerializeField] private TMP_Text descriptionText;
        [SerializeField] private CanvasGroup canvasGroup;

        private Action _onStart;

        private void Awake()
        {
            if (canvasGroup == null)
                canvasGroup = GetComponent<CanvasGroup>();

            Configure(null);
            Hide();
        }

        private void OnDestroy()
        {
            if (startButton != null)
                startButton.onClick.RemoveListener(HandleStartPressed);
        }

        public void Configure(Action onStart)
        {
            _onStart = onStart;

            if (startButton == null)
            {
                Debug.LogWarning("[EvaluationIntroPanel] Falta Start Button.");
                return;
            }

            startButton.onClick.RemoveListener(HandleStartPressed);
            startButton.onClick.AddListener(HandleStartPressed);
        }

        public void Configure(Action onStart, string title, string description)
        {
            Configure(onStart);

            if (titleText != null)
                titleText.text = title;

            if (descriptionText != null)
                descriptionText.text = description;
        }

        public void Show(Action onStart)
        {
            Configure(onStart);
            gameObject.SetActive(true);

            if (canvasGroup != null)
            {
                canvasGroup.alpha = 1f;
                canvasGroup.interactable = true;
                canvasGroup.blocksRaycasts = true;
            }

            if (startButton != null)
                startButton.interactable = true;
        }

        public void Hide()
        {
            if (canvasGroup != null)
            {
                canvasGroup.alpha = 0f;
                canvasGroup.interactable = false;
                canvasGroup.blocksRaycasts = false;
            }

            gameObject.SetActive(false);
        }

        public void HandleStartPressed()
        {
            var startAction = _onStart;
            _onStart = null;

            if (startButton != null)
                startButton.interactable = false;

            Hide();
            startAction?.Invoke();
        }
    }
}
