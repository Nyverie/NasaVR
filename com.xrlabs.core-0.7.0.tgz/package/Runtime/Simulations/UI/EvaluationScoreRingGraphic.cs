using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    public class EvaluationScoreRingGraphic : MaskableGraphic
    {
        private const int SegmentCount = 96;

        [SerializeField] private float progress;
        [SerializeField] private float thickness = 0.13f;
        [SerializeField] private Color trackColor = new Color(1f, 1f, 1f, 0.18f);
        [SerializeField] private Color fillColor = new Color(0.60f, 0.95f, 0.45f, 1f);

        public void SetProgress(float value)
        {
            progress = Mathf.Clamp01(value);
            SetVerticesDirty();
        }

        public void SetThickness(float value)
        {
            thickness = Mathf.Max(0.01f, value);
            SetVerticesDirty();
        }

        public void SetColors(Color track, Color fill)
        {
            trackColor = track;
            fillColor = fill;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();

            Rect rect = rectTransform.rect;
            Vector2 center = rect.center;
            float radius = Mathf.Min(rect.width, rect.height) * 0.5f;
            float outerRadius = radius;
            float innerRadius = Mathf.Max(0f, radius - thickness);

            AddRing(vh, center, innerRadius, outerRadius, 1f, trackColor);
            AddRing(vh, center, innerRadius, outerRadius, progress, fillColor);
        }

        private static void AddRing(
            VertexHelper vh,
            Vector2 center,
            float innerRadius,
            float outerRadius,
            float amount,
            Color color)
        {
            if (amount <= 0f)
                return;

            int segments = Mathf.Max(1, Mathf.CeilToInt(SegmentCount * Mathf.Clamp01(amount)));
            float arc = 360f * Mathf.Clamp01(amount);

            for (int i = 0; i < segments; i++)
            {
                float start = 90f - arc * (i / (float)segments);
                float end = 90f - arc * ((i + 1f) / segments);

                Vector2 outerStart = center + PointOnCircle(start, outerRadius);
                Vector2 outerEnd = center + PointOnCircle(end, outerRadius);
                Vector2 innerEnd = center + PointOnCircle(end, innerRadius);
                Vector2 innerStart = center + PointOnCircle(start, innerRadius);

                AddQuad(vh, outerStart, outerEnd, innerEnd, innerStart, color);
            }
        }

        private static Vector2 PointOnCircle(float degrees, float radius)
        {
            float radians = degrees * Mathf.Deg2Rad;
            return new Vector2(Mathf.Cos(radians) * radius, Mathf.Sin(radians) * radius);
        }

        private static void AddQuad(VertexHelper vh, Vector2 a, Vector2 b, Vector2 c, Vector2 d, Color color)
        {
            UIVertex vertex = UIVertex.simpleVert;
            vertex.color = color;

            vertex.position = a;
            UIVertex v0 = vertex;
            vertex.position = b;
            UIVertex v1 = vertex;
            vertex.position = c;
            UIVertex v2 = vertex;
            vertex.position = d;
            UIVertex v3 = vertex;

            vh.AddUIVertexQuad(new[] { v0, v1, v2, v3 });
        }
    }
}
