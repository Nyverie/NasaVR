using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Pantalla de resultados finales de la experiencia: score, tiempo, aciertos/errores.
    /// Se activa cuando SessionManager recibe el evento de fin de simulación.
    /// </summary>
    public class ResultsPanel : MonoBehaviour
    {
        [Header("Score")]
        [SerializeField] private TMPro.TextMeshProUGUI scoreText;
        [SerializeField] private TMPro.TextMeshProUGUI scoreLabel;
        [SerializeField] private Image scoreBar;

        [Header("Stats")]
        [SerializeField] private TMPro.TextMeshProUGUI correctText;
        [SerializeField] private TMPro.TextMeshProUGUI incorrectText;
        [SerializeField] private TMPro.TextMeshProUGUI timeText;

        [Header("Aprobación")]
        [SerializeField] private GameObject passedBanner;
        [SerializeField] private GameObject failedBanner;
        [SerializeField] private int passingScore = 70;

        [Header("Rating")]
        [SerializeField] private StarRatingPanel starRatingPanel;

        [Header("Navegación")]
        [SerializeField] private Button backButton;
        [SerializeField] private string mainMenuScene = "Menu";

        private void Awake()
        {
            gameObject.SetActive(false);
            if (backButton) backButton.onClick.AddListener(GoToMenu);
        }

        public void Show(float finalScore, int totalTimeSeconds, int totalCorrect, int totalIncorrect)
        {
            gameObject.SetActive(true);

            int scoreInt = Mathf.RoundToInt(finalScore);

            if (scoreText) scoreText.text = $"{scoreInt}";
            if (scoreBar) scoreBar.fillAmount = Mathf.Clamp01(finalScore / 100f);

            if (correctText) correctText.text = totalCorrect.ToString();
            if (incorrectText) incorrectText.text = totalIncorrect.ToString();

            if (timeText)
            {
                int minutes = totalTimeSeconds / 60;
                int seconds = totalTimeSeconds % 60;
                timeText.text = $"{minutes:00}:{seconds:00}";
            }

            bool passed = scoreInt >= passingScore;
            if (passedBanner) passedBanner.SetActive(passed);
            if (failedBanner) failedBanner.SetActive(!passed);

            starRatingPanel?.Show();
        }

        private void GoToMenu()
        {
            XRLabs.UI.SceneTransitionManager.LoadScene(mainMenuScene);
        }
    }
}
