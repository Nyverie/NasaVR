using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Muestra el progreso de casos en la evaluación (ej: "Caso 2 de 3 — Rotura anular").
    /// </summary>
    public class CaseProgressPanel : MonoBehaviour
    {
        [SerializeField] private TMPro.TextMeshProUGUI progressText;
        [SerializeField] private TMPro.TextMeshProUGUI caseNameText;
        [SerializeField] private TMPro.TextMeshProUGUI questionProgressText;
        [SerializeField] private TMPro.TextMeshProUGUI correctAnswersText;
        [SerializeField] private TMPro.TextMeshProUGUI elapsedTimeText;
        [SerializeField] private Image[] caseIndicators;
        [SerializeField] private Color completedColor = Color.green;
        [SerializeField] private Color activeColor = Color.yellow;
        [SerializeField] private Color pendingColor = Color.gray;

        public void Initialize(TMPro.TextMeshProUGUI progress, TMPro.TextMeshProUGUI caseName, Image[] indicators)
        {
            progressText = progress;
            caseNameText = caseName;
            caseIndicators = indicators;
        }

        public void Show()
        {
            gameObject.SetActive(true);
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

        public void ResetProgress()
        {
            if (progressText)
                progressText.text = string.Empty;

            if (caseNameText)
                caseNameText.text = string.Empty;

            if (questionProgressText)
                questionProgressText.text = string.Empty;

            if (correctAnswersText)
                correctAnswersText.text = string.Empty;

            if (elapsedTimeText)
                elapsedTimeText.text = string.Empty;

            if (caseIndicators == null)
                return;

            for (int i = 0; i < caseIndicators.Length; i++)
            {
                if (caseIndicators[i] != null)
                    caseIndicators[i].color = pendingColor;
            }
        }

        public void SetProgress(int currentCase, int totalCases, string caseName)
        {
            if (progressText)
                progressText.text = $"Caso {currentCase} de {totalCases}";

            if (caseNameText)
                caseNameText.text = caseName;

            if (caseIndicators == null)
                return;

            for (int i = 0; i < caseIndicators.Length; i++)
            {
                if (caseIndicators[i] == null) continue;
                int caseIndex = i + 1;
                caseIndicators[i].color = caseIndex < currentCase ? completedColor
                    : caseIndex == currentCase ? activeColor
                    : pendingColor;
            }
        }

        public void UpdateQuestionProgress(
            int answeredQuestions,
            int totalQuestions,
            int correctAnswers,
            int elapsedSeconds)
        {
            if (questionProgressText)
                questionProgressText.text = $"Preguntas {answeredQuestions}/{totalQuestions}";

            if (correctAnswersText)
                correctAnswersText.text = $"Correctas {correctAnswers}";

            if (elapsedTimeText)
            {
                int safeSeconds = Mathf.Max(0, elapsedSeconds);
                int minutes = safeSeconds / 60;
                int seconds = safeSeconds % 60;
                elapsedTimeText.text = $"Tiempo del caso {minutes:00}:{seconds:00}";
            }
        }
    }
}
