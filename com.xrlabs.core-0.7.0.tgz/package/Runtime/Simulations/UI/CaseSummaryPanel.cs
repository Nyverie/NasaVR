using System;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Muestra el resultado de un caso evaluativo tras completarlo (qué acertó, qué no).
    /// Conectar en Inspector: los tres iconos de resultado y el botón de continuar.
    /// </summary>
    public class CaseSummaryPanel : MonoBehaviour
    {
        [Header("Título")]
        [SerializeField] private TMPro.TextMeshProUGUI caseNameText;
        [SerializeField] private TMPro.TextMeshProUGUI timeText;

        [Header("Resultados por pregunta")]
        [SerializeField] private Image typoResult;
        [SerializeField] private Image causeResult;
        [SerializeField] private Image recommendationResult;

        [Header("Iconos")]
        [SerializeField] private Sprite correctIcon;
        [SerializeField] private Sprite incorrectIcon;
        [SerializeField] private Color correctColor = Color.green;
        [SerializeField] private Color incorrectColor = Color.red;

        [Header("Navegación")]
        [SerializeField] private Button continueButton;

        public void Initialize(
            TMPro.TextMeshProUGUI caseName,
            TMPro.TextMeshProUGUI time,
            Image type,
            Image cause,
            Image recommendation,
            Button continueAction)
        {
            caseNameText = caseName;
            timeText = time;
            typoResult = type;
            causeResult = cause;
            recommendationResult = recommendation;
            continueButton = continueAction;
        }

        private void Awake()
        {
            gameObject.SetActive(false);
            if (continueButton) continueButton.onClick.RemoveAllListeners();
        }

        /// <summary>Muestra el resumen del caso y llama onContinue al presionar continuar.</summary>
        public void ShowCaseSummary(CaseData caseData, Action onContinue)
        {
            // El CaseData no contiene resultados — los resultados vienen del CaseResult en SessionManager.
            // Este panel se alimenta con los datos visibles del caso; los resultados ya están en CaseEvaluationController.
            gameObject.SetActive(true);

            if (caseNameText) caseNameText.text = caseData.failureName;

            if (continueButton)
            {
                continueButton.onClick.RemoveAllListeners();
                continueButton.onClick.AddListener(() =>
                {
                    gameObject.SetActive(false);
                    onContinue?.Invoke();
                });
            }
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

        /// <summary>Muestra los resultados detallados de las tres preguntas.</summary>
        public void SetResults(bool typoCorrect, bool causeCorrect, bool recommendationCorrect, int caseTimeSeconds)
        {
            SetResultIcon(typoResult, typoCorrect);
            SetResultIcon(causeResult, causeCorrect);
            SetResultIcon(recommendationResult, recommendationCorrect);

            if (timeText)
            {
                int minutes = caseTimeSeconds / 60;
                int seconds = caseTimeSeconds % 60;
                timeText.text = $"Tiempo del caso: {minutes:00}:{seconds:00}";
            }
        }

        private void SetResultIcon(Image img, bool correct)
        {
            if (img == null) return;
            img.sprite = correct ? correctIcon : incorrectIcon;
            img.color = correct ? correctColor : incorrectColor;
        }
    }
}
