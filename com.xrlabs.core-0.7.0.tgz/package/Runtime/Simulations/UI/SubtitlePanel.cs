using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Subtítulo del coach. Escucha VOManager.LineStarted/LineEnded: el texto se revela como
    /// máquina de escribir sincronizado con la duración real de la frase, en modo error se
    /// pone naranja y se sacude. Siempre aparece, haya o no audio.
    /// Skip() (botón de UI, tecla o acción XR) salta la frase.
    /// </summary>
    public class SubtitlePanel : MonoBehaviour
    {
        [Header("Referencias")]
        [SerializeField] private CanvasGroup canvasGroup;
        [SerializeField] private TMP_Text bodyText;
        [SerializeField] private TMP_Text speakerText;
        [SerializeField] private Image portraitImage;
        [Tooltip("Borde/acento que cambia de color según el modo (normal/error).")]
        [SerializeField] private Graphic accentGraphic;
        [Tooltip("Lo que se sacude en error. Vacío = este transform.")]
        [SerializeField] private RectTransform shakeTarget;

        [Header("Colores")]
        [SerializeField] private Color normalAccent = new(0.16f, 0.76f, 0.78f, 1f);
        [SerializeField] private Color errorAccent = new(1f, 0.55f, 0.15f, 1f);
        [SerializeField] private Color normalText = Color.white;
        [SerializeField] private Color errorText = new(1f, 0.85f, 0.7f, 1f);

        [Header("Tiempos")]
        [Tooltip("Velocidad relativa del texto respecto del audio (la web usa 1.08: el texto termina un poco antes).")]
        [SerializeField, Min(0.1f)] private float revealSpeed = 1.08f;
        [SerializeField, Min(0f)] private float hideDelaySeconds = 1.2f;
        [SerializeField, Min(0f)] private float fadeSeconds = 0.2f;
        [SerializeField, Min(0f)] private float shakeSeconds = 0.28f;
        [SerializeField, Min(0f)] private float shakeAmplitude = 8f;

        [Header("Saltar frase (opcional)")]
        [SerializeField] private KeyCode skipKey = KeyCode.None;
        [SerializeField] private InputActionReference skipAction;

        private LinePlayback _line;
        private float _lineStart;
        private float _hideAt = -1f;
        private float _shakeUntil;
        private Vector2 _shakeOrigin;
        private float _targetAlpha;

        private void Awake()
        {
            if (shakeTarget == null) shakeTarget = transform as RectTransform;
            if (shakeTarget != null) _shakeOrigin = shakeTarget.anchoredPosition;
            if (canvasGroup != null) canvasGroup.alpha = 0f;
        }

        private void OnEnable()
        {
            if (skipAction != null && skipAction.action != null)
            {
                skipAction.action.performed += HandleSkipAction;
                skipAction.action.Enable();
            }
        }

        private void Start()
        {
            // VOManager puede despertar después que este panel: suscribirse en Start.
            if (VOManager.Instance != null)
            {
                VOManager.Instance.LineStarted += HandleLineStarted;
                VOManager.Instance.LineEnded += HandleLineEnded;
            }
        }

        private void OnDisable()
        {
            if (skipAction != null && skipAction.action != null)
                skipAction.action.performed -= HandleSkipAction;
        }

        private void OnDestroy()
        {
            if (VOManager.Instance != null)
            {
                VOManager.Instance.LineStarted -= HandleLineStarted;
                VOManager.Instance.LineEnded -= HandleLineEnded;
            }
        }

        private void Update()
        {
            if (skipKey != KeyCode.None && InputKeyCompat.IsKeyDown(skipKey))
                Skip();

            UpdateReveal();
            UpdateShake();
            UpdateFade();
        }

        /// <summary>Salta la frase actual. Conectar a un botón o al clic del panel.</summary>
        public void Skip()
        {
            if (_line != null && !_line.IsDone)
                VOManager.Instance?.Skip();
        }

        private void HandleSkipAction(InputAction.CallbackContext _) => Skip();

        private void HandleLineStarted(LinePlayback line)
        {
            _line = line;
            _lineStart = Time.unscaledTime;
            _hideAt = -1f;
            _targetAlpha = string.IsNullOrEmpty(line.Text) ? 0f : 1f;

            if (bodyText != null)
            {
                bodyText.text = line.Text;
                bodyText.color = line.IsError ? errorText : normalText;
                bodyText.maxVisibleCharacters = 0;
            }

            if (speakerText != null && VOManager.Instance != null)
                speakerText.text = VOManager.Instance.SpeakerName;

            if (portraitImage != null && VOManager.Instance != null && VOManager.Instance.SpeakerPortrait != null)
                portraitImage.sprite = VOManager.Instance.SpeakerPortrait;

            if (accentGraphic != null)
                accentGraphic.color = line.IsError ? errorAccent : normalAccent;

            if (line.IsError)
                _shakeUntil = Time.unscaledTime + shakeSeconds;
        }

        private void HandleLineEnded(LinePlayback line)
        {
            if (line != _line) return;

            if (bodyText != null) bodyText.maxVisibleCharacters = int.MaxValue;

            // Si la cortó otra frase, el LineStarted siguiente toma el panel; no ocultar.
            if (!line.WasInterrupted)
                _hideAt = Time.unscaledTime + hideDelaySeconds;
        }

        private void UpdateReveal()
        {
            if (_line == null || _line.IsDone || bodyText == null) return;

            float duration = Mathf.Max(0.01f, _line.Duration);
            float progress = Mathf.Clamp01((Time.unscaledTime - _lineStart) / duration * revealSpeed);
            bodyText.maxVisibleCharacters = Mathf.CeilToInt(progress * _line.Text.Length);
        }

        private void UpdateShake()
        {
            if (shakeTarget == null) return;

            if (Time.unscaledTime < _shakeUntil)
            {
                float t = 1f - (_shakeUntil - Time.unscaledTime) / Mathf.Max(0.01f, shakeSeconds);
                float offset = Mathf.Sin(t * Mathf.PI * 6f) * shakeAmplitude * (1f - t);
                shakeTarget.anchoredPosition = _shakeOrigin + new Vector2(offset, 0f);
            }
            else
            {
                shakeTarget.anchoredPosition = _shakeOrigin;
            }
        }

        private void UpdateFade()
        {
            if (_hideAt > 0f && Time.unscaledTime >= _hideAt)
            {
                _targetAlpha = 0f;
                _hideAt = -1f;
            }

            if (canvasGroup == null) return;

            float step = fadeSeconds <= 0f ? 1f : Time.unscaledDeltaTime / fadeSeconds;
            canvasGroup.alpha = Mathf.MoveTowards(canvasGroup.alpha, _targetAlpha, step);
            canvasGroup.blocksRaycasts = canvasGroup.alpha > 0.01f;
        }
    }
}
