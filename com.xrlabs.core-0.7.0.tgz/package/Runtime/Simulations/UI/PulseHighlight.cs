using System.Collections;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Efecto de pulso visual sobre un objeto para indicar al usuario que debe interactuar con él.
    /// Escala el GameObject y opcionalmente anima la emisión vía MaterialPropertyBlock
    /// (no instancia materiales: preserva el SRP batching).
    /// </summary>
    public class PulseHighlight : MonoBehaviour
    {
        private static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

        [SerializeField] private float pulseScale = 1.15f;
        [SerializeField] private float pulsePeriod = 1.0f;
        [SerializeField] private bool useEmission;
        [SerializeField] private Color emissionColor = Color.yellow;

        private Vector3 _originalScale;
        private Renderer _renderer;
        private MaterialPropertyBlock _propertyBlock;
        private Coroutine _pulseCoroutine;
        private bool _isPulsing;

        private void Awake()
        {
            _originalScale = transform.localScale;
            _renderer = GetComponent<Renderer>();

            if (useEmission && _renderer != null)
                _propertyBlock = new MaterialPropertyBlock();
        }

        public void StartPulse()
        {
            if (_isPulsing) return;
            _isPulsing = true;
            _pulseCoroutine = StartCoroutine(PulseRoutine());
        }

        public void StopPulse()
        {
            _isPulsing = false;
            if (_pulseCoroutine != null) StopCoroutine(_pulseCoroutine);
            transform.localScale = _originalScale;
            SetEmission(Color.black);
        }

        private IEnumerator PulseRoutine()
        {
            float halfPeriod = pulsePeriod * 0.5f;

            while (_isPulsing)
            {
                float elapsed = 0f;
                while (elapsed < halfPeriod)
                {
                    elapsed += Time.deltaTime;
                    float t = elapsed / halfPeriod;
                    transform.localScale = _originalScale * Mathf.Lerp(1f, pulseScale, t);
                    SetEmission(Color.Lerp(Color.black, emissionColor, t));
                    yield return null;
                }

                elapsed = 0f;
                while (elapsed < halfPeriod)
                {
                    elapsed += Time.deltaTime;
                    float t = elapsed / halfPeriod;
                    transform.localScale = _originalScale * Mathf.Lerp(pulseScale, 1f, t);
                    SetEmission(Color.Lerp(emissionColor, Color.black, t));
                    yield return null;
                }
            }
        }

        private void SetEmission(Color color)
        {
            if (!useEmission || _renderer == null || _propertyBlock == null) return;

            _renderer.GetPropertyBlock(_propertyBlock);
            _propertyBlock.SetColor(EmissionColorId, color);
            _renderer.SetPropertyBlock(_propertyBlock);
        }

        private void OnDisable()
        {
            StopPulse();
        }
    }
}
