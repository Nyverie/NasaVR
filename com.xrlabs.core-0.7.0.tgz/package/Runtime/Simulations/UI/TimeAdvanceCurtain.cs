using System.Collections;
using TMPro;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// 0.3 lote 2 (contrato-0.3.md §2.3): la cortinilla de los pasos <c>avanzar</c>. Negro a pantalla completa en el canvas
    /// del HUD con la etiqueta al centro («Semana 2»): entra en el primer tercio del fundido, enseña la etiqueta cuando el
    /// StepSystem ya sumó los días (con la pantalla en negro, para que lo que cambia el estado no se vea saltar) y sale en el
    /// último tercio. El tiempo lo lleva el StepSystem; aquí solo se anima el alfa. Se oculta con su CanvasGroup, nunca
    /// apagando el objeto (la lección de <see cref="ManualStepButton"/>). En el visor cubre el HUD del mundo; el fundido
    /// del teletransporte queda para el lote del visor.
    /// </summary>
    public class TimeAdvanceCurtain : MonoBehaviour
    {
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private CanvasGroup group;
        [SerializeField] private TMP_Text label;

        private StepSystem _subscribed;
        private Coroutine _fade;

        /// <summary>Alfa actual de la cortinilla (0 = no se ve; 1 = negro).</summary>
        public float Alpha => group != null ? group.alpha : 0f;

        /// <summary>El texto que enseña la etiqueta.</summary>
        public string LabelText => label != null ? label.text : string.Empty;

        public StepSystem StepSystem
        {
            get => stepSystem;
            set { stepSystem = value; Subscribe(); }
        }

        private void Awake()
        {
            if (group == null && !TryGetComponent(out group)) group = gameObject.AddComponent<CanvasGroup>();
            group.alpha = 0f;
            group.blocksRaycasts = false;
            group.interactable = false;
            if (label != null) label.text = string.Empty;
        }

        private void OnEnable() => Subscribe();

        private void OnDisable() => Unsubscribe();

        private void Subscribe()
        {
            if (!isActiveAndEnabled) return;
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem == _subscribed) return;
            Unsubscribe();
            _subscribed = stepSystem;
            if (_subscribed == null) return;
            _subscribed.TimeAdvanceStarted += HandleStarted;
            _subscribed.TimeAdvanced += HandleAdvanced;
            _subscribed.TimeAdvanceFinished += HandleFinished;
        }

        private void Unsubscribe()
        {
            if (_subscribed == null) return;
            _subscribed.TimeAdvanceStarted -= HandleStarted;
            _subscribed.TimeAdvanced -= HandleAdvanced;
            _subscribed.TimeAdvanceFinished -= HandleFinished;
            _subscribed = null;
        }

        private void HandleStarted(StepDefinition step, float seconds)
        {
            if (label != null) label.text = string.Empty;
            group.blocksRaycasts = true;
            FadeTo(1f, seconds / 3f);
        }

        private void HandleAdvanced(StepDefinition step, int days, int day, string text)
        {
            if (label != null) label.text = text ?? string.Empty;
        }

        private void HandleFinished(StepDefinition step)
        {
            group.blocksRaycasts = false;
            FadeTo(0f, Mathf.Max(0f, step != null ? step.advanceFadeSeconds / 3f : 0.5f));
        }

        private void FadeTo(float target, float seconds)
        {
            if (_fade != null) StopCoroutine(_fade);
            _fade = StartCoroutine(Fade(target, seconds));
        }

        private IEnumerator Fade(float target, float seconds)
        {
            float start = group.alpha;
            float t = 0f;
            while (seconds > 0f && t < seconds)
            {
                t += Time.unscaledDeltaTime;
                group.alpha = Mathf.Lerp(start, target, Mathf.Clamp01(t / seconds));
                yield return null;
            }
            group.alpha = target;
            if (target <= 0f && label != null) label.text = string.Empty;
            _fade = null;
        }
    }
}
