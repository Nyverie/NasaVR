using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    public class EvaluationResultIconGraphic : MaskableGraphic
    {
        private const int SegmentCount = 48;

        [SerializeField] private bool passed = true;
        [SerializeField] private Color resultColor = new Color(0.60f, 0.95f, 0.45f, 1f);

        public void SetState(bool isPassed, Color color)
        {
            passed = isPassed;
            resultColor = color;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();

            Rect rect = rectTransform.rect;
            Vector2 center = rect.center;
            float size = Mathf.Min(rect.width, rect.height);
            Color background = resultColor;
            background.a = 0.95f;

            AddCircle(vh, center, size * 0.5f, background);

            Color markColor = Color.white;
            float lineThickness = size * 0.11f;

            if (passed)
            {
                AddLine(vh, center + new Vector2(-0.18f, -0.01f) * size, center + new Vector2(-0.05f, -0.16f) * size, lineThickness, markColor);
                AddLine(vh, center + new Vector2(-0.05f, -0.16f) * size, center + new Vector2(0.23f, 0.15f) * size, lineThickness, markColor);
            }
            else
            {
                AddLine(vh, center + new Vector2(-0.16f, -0.16f) * size, center + new Vector2(0.16f, 0.16f) * size, lineThickness, markColor);
                AddLine(vh, center + new Vector2(-0.16f, 0.16f) * size, center + new Vector2(0.16f, -0.16f) * size, lineThickness, markColor);
            }
        }

        private static void AddCircle(VertexHelper vh, Vector2 center, float radius, Color color)
        {
            int centerIndex = vh.currentVertCount;
            UIVertex vertex = UIVertex.simpleVert;
            vertex.color = color;
            vertex.position = center;
            vh.AddVert(vertex);

            for (int i = 0; i <= SegmentCount; i++)
            {
                float angle = i / (float)SegmentCount * Mathf.PI * 2f;
                vertex.position = center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius;
                vh.AddVert(vertex);
            }

            for (int i = 1; i <= SegmentCount; i++)
                vh.AddTriangle(centerIndex, centerIndex + i, centerIndex + i + 1);
        }

        private static void AddLine(VertexHelper vh, Vector2 start, Vector2 end, float thickness, Color color)
        {
            Vector2 direction = (end - start).normalized;
            Vector2 normal = new Vector2(-direction.y, direction.x) * (thickness * 0.5f);

            AddQuad(vh, start + normal, end + normal, end - normal, start - normal, color);
        }

        private static void AddQuad(VertexHelper vh, Vector2 a, Vector2 b, Vector2 c, Vector2 d, Color color)
        {
            UIVertex vertex = UIVertex.simpleVert;
            vertex.color = color;

            vertex.position = a;
            UIVertex v0 = vertex;
            vertex.position = b;
            UIVertex v1 = vertex;
            vertex.position = c;
            UIVertex v2 = vertex;
            vertex.position = d;
            UIVertex v3 = vertex;

            vh.AddUIVertexQuad(new[] { v0, v1, v2, v3 });
        }
    }
}
