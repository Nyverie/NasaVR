using TMPro;
using UnityEngine;
using UnityEngine.UI;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// El botón «Comenzar» de los pasos <c>manual</c> en modo plano (2026-10-17). El storyboard dice «pulsa el botón
    /// Comenzar» y el contrato 0.2 solo daba una tecla (<see cref="ManualKeyStepCondition"/>): en pantalla no había nada
    /// que pulsar. Se enseña cuando el paso en curso **ya escucha** (fase Active: tras la introducción, cuando el coach
    /// pide la acción) y su condición es manual; el clic la completa y la tecla sigue valiendo. Durante la introducción
    /// no se enseña: la condición todavía no se inicializó y un clic ahí se perdería.
    ///
    /// Se oculta con un CanvasGroup y nunca desactivando su GameObject: la primera versión apagaba su propio objeto en
    /// Awake, con lo que su Start no corría, no se suscribía y el botón no aparecía jamás en Play (lo vio el dueño; las
    /// capturas del Editor fuera de Play lo mostraban activo y engañaron la verificación).
    /// En el visor hará falta su equivalente en un canvas del mundo (a5-experiencia-compostaje.md §4).
    ///
    /// 0.3 lote 5 (contrato-0.3.md §2.7): el mismo botón es «Continuar» en los pasos con <c>continuar</c>: se enseña mientras
    /// el paso escucha, con la frase de <c>etiqueta</c>, y el clic llama a <see cref="StepSystem.TryConfirm"/> (cierra el
    /// paso o hace que el coach diga qué falta). En el visor se pulsa con el rayo, como «Comenzar».
    /// </summary>
    public class ManualStepButton : MonoBehaviour
    {
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private Button button;
        [SerializeField] private CanvasGroup group;
        [SerializeField] private TMP_Text label;
        [SerializeField] private string labelText = "Comenzar";

        private ManualKeyStepCondition _waiting;
        private bool _continuing;   // 0.3 lote 5: el botón es «Continuar»

        /// <summary>El paso enseña el botón solo si lo que espera es una ManualKeyStepCondition.</summary>
        public static ManualKeyStepCondition ManualConditionOf(StepDefinition step) =>
            step != null ? step.completionCondition as ManualKeyStepCondition : null;

        public bool IsShowing => _waiting != null || _continuing;

        /// <summary>0.3 lote 5: el paso enseña el botón como «Continuar» (paso Interaction con 'continuar').</summary>
        public static bool ContinueOf(StepDefinition step) => step != null && step.AcceptsContinue;

        /// <summary>0.3 lote 5: el botón se enseña en este paso (manual o con 'continuar').</summary>
        public static bool ShowsFor(StepDefinition step) => ContinueOf(step) || ManualConditionOf(step) != null;

        /// <summary>El texto que lleva el botón ahora (para las pruebas).</summary>
        public string LabelText => label != null ? label.text : null;

        private void Awake()
        {
            if (button == null) button = GetComponent<Button>();
            if (group == null && !TryGetComponent(out group)) group = gameObject.AddComponent<CanvasGroup>();
            if (label != null) label.text = labelText;
            if (button != null) button.onClick.AddListener(Press);
            Hide();
        }

        private void Start()
        {
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();
            if (stepSystem == null) return;
            stepSystem.PhaseChanged += HandlePhase;
            stepSystem.StepCompleted += HandleStepEnded;
            stepSystem.StepsFinished += Hide;
            HandlePhase(stepSystem.Phase);
        }

        private void OnDestroy()
        {
            if (button != null) button.onClick.RemoveListener(Press);
            if (stepSystem == null) return;
            stepSystem.PhaseChanged -= HandlePhase;
            stepSystem.StepCompleted -= HandleStepEnded;
            stepSystem.StepsFinished -= Hide;
        }

        private void HandlePhase(StepSystem.StepPhase phase)
        {
            if (phase == StepSystem.StepPhase.Active) Show(stepSystem.CurrentStep);
            else Hide();
        }

        private void HandleStepEnded(StepDefinition step, int index, float seconds) => Hide();

        /// <summary>Lo que hace el clic: completar la condición manual del paso en curso. Público para las pruebas.</summary>
        public void Press()
        {
            if (_continuing)
            {
                // 0.3 lote 5: «Continuar». Si falta algo, el StepSystem pasa a corregir y el botón se oculta por la fase.
                if (stepSystem != null) stepSystem.TryConfirm();
                return;
            }
            if (_waiting == null) return;
            _waiting.Complete();
            Hide();
        }

        private void Show(StepDefinition step)
        {
            _continuing = ContinueOf(step);
            _waiting = _continuing ? null : ManualConditionOf(step);
            if (label != null) label.text = _continuing ? ContinueLabelFor(step) : labelText;
            SetVisible(_waiting != null || _continuing);
        }

        private void Hide()
        {
            _waiting = null;
            _continuing = false;
            SetVisible(false);
        }

        // 0.3 lote 5: el texto de 'etiqueta' (por defecto ui.continuar) en el idioma activo; «Continuar» si no se resuelve.
        private static string ContinueLabelFor(StepDefinition step)
        {
            var id = step.continueLabel.IsEmpty ? "ui.continuar" : step.continueLabel.id;
            var vo = VOManager.Instance;
            if (vo != null && vo.TryResolve(id, out var resolved) && !string.IsNullOrEmpty(resolved.Text)) return resolved.Text;
            return "Continuar";
        }

        private void SetVisible(bool visible)
        {
            if (group == null) return;
            group.alpha = visible ? 1f : 0f;
            group.interactable = visible;
            group.blocksRaycasts = visible;
        }
    }
}
