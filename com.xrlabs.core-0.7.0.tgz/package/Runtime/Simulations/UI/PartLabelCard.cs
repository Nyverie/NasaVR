using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Etiqueta flotante que se posiciona sobre una parte del modelo 3D y hace billboarding.
    /// Conectar en Inspector: labelText, anchorTransform (parte del modelo a etiquetar).
    /// </summary>
    public class PartLabelCard : MonoBehaviour
    {
        [SerializeField] private TMPro.TextMeshProUGUI labelText;
        [SerializeField] private Transform anchor;
        [SerializeField] private Vector3 offset = new Vector3(0f, 0.2f, 0f);
        [SerializeField] private bool faceCamera = true;

        private Transform _mainCamera;

        private void Start()
        {
            _mainCamera = Camera.main?.transform;
        }

        private void LateUpdate()
        {
            if (anchor != null)
                transform.position = anchor.position + offset;

            if (faceCamera && _mainCamera != null)
                transform.rotation = Quaternion.LookRotation(transform.position - _mainCamera.position);
        }

        public void SetLabel(string text)
        {
            if (labelText) labelText.text = text;
        }

        public void Show() => gameObject.SetActive(true);
        public void Hide() => gameObject.SetActive(false);
    }
}
