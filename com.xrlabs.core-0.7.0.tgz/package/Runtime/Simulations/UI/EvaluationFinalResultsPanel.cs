using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
#endif

namespace XRLabs.Simulations
{
    [ExecuteAlways]
    public class EvaluationFinalResultsPanel : MonoBehaviour
    {
        [Header("Score")]
        [SerializeField] private TextMeshProUGUI scoreText;
        [SerializeField] private TextMeshProUGUI scoreMaxText;
        [SerializeField] private Image scoreFillImage;
        [SerializeField] private Image scoreAccentImage;

        [Header("Status")]
        [SerializeField] private TextMeshProUGUI statusText;
        [SerializeField] private Image statusBackground;
        [SerializeField] private GameObject passedVisualRoot;
        [SerializeField] private GameObject failedVisualRoot;

        [Header("Stats")]
        [SerializeField] private TextMeshProUGUI correctText;
        [SerializeField] private TextMeshProUGUI timeText;
        [SerializeField] private TextMeshProUGUI performanceText;
        [SerializeField] private TextMeshProUGUI feedbackText;

        [Header("Rules")]
        [SerializeField] private int maxScore = 20;
        [SerializeField] private int passingScore = 14;
        [SerializeField] private int highPerformanceScore = 18;

        [Header("Labels")]
        [SerializeField] private string passedLabel = "Aprobado";
        [SerializeField] private string failedLabel = "Desaprobado";
        [SerializeField] private string highPerformanceLabel = "Dominio alto";
        [SerializeField] private string passedPerformanceLabel = "Dominio logrado";
        [SerializeField] private string failedPerformanceLabel = "Necesita refuerzo";
        [SerializeField] private string passedFeedback = "Buen resultado. Mantienes criterio correcto en diagnóstico y recomendación.";
        [SerializeField] private string failedFeedback = "Revisa los criterios de tipo de falla, causa probable y recomendación.";

        [Header("Colors")]
        [SerializeField] private Color passedColor = new Color(0.60f, 0.95f, 0.45f, 1f);
        [SerializeField] private Color failedColor = new Color(1f, 0.42f, 0.35f, 1f);
        [SerializeField] private float statusBackgroundAlpha = 0.25f;

        [Header("Navigation")]
        [SerializeField] private Button continueButton;
        [SerializeField] private TextMeshProUGUI continueButtonText;
        [SerializeField] private string continueButtonLabel = "Finalizar evaluaci\u00f3n";

        [Header("Summary Image")]
        [Tooltip("Imagen UI (Image component) donde se muestra el resumen. Asignar desde el Inspector el hijo 'FinalSummaryImage' del prefab.")]
        [SerializeField] private Image finalSummaryImage;
        [Tooltip("Sprite del resumen de las 3 fallas. Si se asigna, se aplica al finalSummaryImage al mostrar resultados.")]
        [SerializeField] private Sprite finalSummarySprite;

        [Header("Runtime Polish")]
        [SerializeField] private bool applyRuntimePolish = true;
        [SerializeField] private Color panelBackgroundColor = new Color(0.035f, 0.14f, 0.18f, 0.96f);
        [SerializeField] private Color cardBackgroundColor = new Color(1f, 1f, 1f, 0.14f);
        [SerializeField] private Color secondaryTextColor = new Color(1f, 1f, 1f, 0.76f);
        [SerializeField] private Color buttonColor = new Color(0.02f, 0.54f, 0.68f, 1f);
        [SerializeField] private Color scoreTrackColor = new Color(1f, 1f, 1f, 0.18f);

        [Header("Editor Preview")]
        [SerializeField] private bool previewDesignInEditor = true;
        [SerializeField] private bool keepVisibleInEditor = true;
        [SerializeField, Range(0f, 20f)] private float editorPreviewScore = 18f;
        [SerializeField] private int editorPreviewCorrect = 7;
        [SerializeField] private int editorPreviewTotalQuestions = 8;
        [SerializeField] private int editorPreviewTimeSeconds = 272;

        private Action<float> _onContinue;
        private CanvasGroup _canvasGroup;
        private EvaluationScoreRingGraphic _scoreRing;
        private Coroutine _scoreAnimation;
        private Coroutine _fadeAnimation;

        public float LastScore { get; private set; }
        public bool LastPassed { get; private set; }
        public int LastTotalQuestions { get; private set; }

        private void Awake()
        {
            NormalizeDefaultCopy();
            CacheGeneratedReferences();

            if (Application.isPlaying)
            {
                ConfigureRuntimePolish();
                CacheGeneratedReferences();
                ConfigureContinueButton();
                Hide();
            }
            else
            {
                ApplyEditorPreviewIfNeeded();
            }
        }

        private void OnEnable()
        {
            if (!Application.isPlaying)
                ApplyEditorPreviewIfNeeded();
        }

        [ContextMenu("Apply Editable Design Preview")]
        private void ApplyEditableDesignPreview()
        {
            NormalizeDefaultCopy();
            ConfigureRuntimePolish(true);
            ApplyEditorPreviewContent();
            MarkSceneDirtyInEditor();
        }

        private void OnDestroy()
        {
            if (continueButton != null)
                continueButton.onClick.RemoveListener(HandleContinuePressed);
        }

        public float ShowResults(
            int totalCorrect,
            int totalIncorrect,
            int totalTimeSeconds,
            Action<float> onContinue)
        {
            _onContinue = onContinue;

            int totalQuestions = Mathf.Max(0, totalCorrect + totalIncorrect);
            float score = CalculateScore(totalCorrect, totalQuestions);
            bool passed = score >= passingScore;

            Debug.Log($"[FINAL PANEL] ShowResults received: correct={totalCorrect}, total={totalQuestions}, score={score:0.##}, passed={passed}");

            LastScore = score;
            LastPassed = passed;
            LastTotalQuestions = totalQuestions;

            gameObject.SetActive(true);
            CacheGeneratedReferences();

            SetText(scoreText, FormatScore(score));
            SetText(scoreMaxText, $"/{Mathf.Max(1, maxScore)} pts");
            SetText(statusText, passed ? passedLabel : failedLabel);
            SetText(correctText, $"{totalCorrect}/{totalQuestions}");
            SetText(timeText, FormatTime(totalTimeSeconds));
            SetText(performanceText, GetPerformanceLabel(score));
            SetText(feedbackText, GetFeedback(passed));
            ApplyStateReport(passed);   // 0.3 lote 4: los indicadores con enInforme
            SetText(continueButtonText, continueButtonLabel);

            if (continueButton != null)
                continueButton.interactable = true;

            ApplyFinalSummarySprite();

            ApplyResultColors(passed);
            AnimateEntry();
            AnimateScoreProgress(Mathf.Clamp01(score / Mathf.Max(1, maxScore)));

            return score;
        }

        #region 0.3 lote 4: indicadores con enInforme (contrato-0.3.md §2.9)

        [Header("Informe del estado (0.3)")]
        [Tooltip("Dónde van los indicadores con enInforme. Vacío: se añaden al texto de retroalimentación.")]
        [SerializeField] private TextMeshProUGUI reportText;

        private XRLabs.Core.SimulationSequence _reportSequence;
        private XRLabs.Core.SimulationState _reportState;

        /// <summary>Las líneas del informe del último ShowResults («Etiqueta: valor» por indicador con enInforme), o vacío.</summary>
        public string ReportText { get; private set; } = string.Empty;

        /// <summary>Para herramientas y tests: de dónde salen los indicadores y su valor final (null = los de la escena).</summary>
        public void UseReportSource(XRLabs.Core.SimulationSequence sequence, XRLabs.Core.SimulationState state)
        {
            _reportSequence = sequence;
            _reportState = state;
        }

        private void ApplyStateReport(bool passed)
        {
            var sequence = _reportSequence;
            var state = _reportState;
            if (sequence == null || state == null)
            {
                var sim = XRLabs.Core.SimulationManager.Instance;
                var steps = sim != null ? sim.Steps : FindFirstObjectByType<XRLabs.Core.StepSystem>();
                if (steps != null)
                {
                    sequence ??= steps.Sequence;
                    state ??= steps.State;
                }
            }

            var lines = XRLabs.Core.IndicatorFormat.ReportLines(sequence, state, ResolveReportText);
            ReportText = lines.Count > 0 ? string.Join("\n", lines) : string.Empty;
            if (ReportText.Length == 0) return;
            if (reportText != null) SetText(reportText, ReportText);
            else SetText(feedbackText, GetFeedback(passed) + "\n" + ReportText);
        }

        private static string ResolveReportText(string lineId)
        {
            var vo = XRLabs.Core.VOManager.Instance;
            return vo != null && vo.TryResolve(lineId, out var resolved) ? resolved.Text : null;
        }

        #endregion

        public void Hide()
        {
            _onContinue = null;

            if (Application.isPlaying)
                gameObject.SetActive(false);
        }

        private float CalculateScore(int totalCorrect, int totalQuestions)
        {
            if (totalQuestions <= 0)
                return 0;

            int normalizedMaxScore = Mathf.Max(1, maxScore);
            float ratio = Mathf.Clamp01(totalCorrect / (float)totalQuestions);
            return Mathf.Clamp(ratio * normalizedMaxScore, 0f, normalizedMaxScore);
        }

        private string GetPerformanceLabel(float score)
        {
            if (score >= highPerformanceScore)
                return highPerformanceLabel;

            if (score >= passingScore)
                return passedPerformanceLabel;

            return failedPerformanceLabel;
        }

        private string GetFeedback(bool passed)
        {
            string baseFeedback = passed ? passedFeedback : failedFeedback;
            return $"{baseFeedback}\nM\u00ednimo para aprobar: {passingScore}/{Mathf.Max(1, maxScore)}.";
        }

        private void ApplyResultColors(bool passed)
        {
            Color resultColor = passed ? passedColor : failedColor;

            if (scoreText != null)
                scoreText.color = resultColor;

            if (scoreAccentImage != null)
                scoreAccentImage.color = resultColor;

            if (_scoreRing != null)
                _scoreRing.SetColors(scoreTrackColor, resultColor);

            if (statusBackground != null)
            {
                Color background = resultColor;
                background.a = statusBackgroundAlpha;
                statusBackground.color = background;
            }

            if (passedVisualRoot != null)
                passedVisualRoot.SetActive(passed);

            if (failedVisualRoot != null)
                failedVisualRoot.SetActive(!passed);
        }

        private void ConfigureRuntimePolish(bool force = false)
        {
            if (!force && !applyRuntimePolish)
                return;

            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
                _canvasGroup = gameObject.AddComponent<CanvasGroup>();

            ConfigurePanelBackground();
            ConfigureHeader();
            ConfigureScoreBlock();
            ConfigureStatusBadge();
            ConfigureStatsRow();
            ConfigureFeedback();
            ConfigureButtonVisuals();
            CacheGeneratedReferences();
            ConfigureFinalSummaryImage();
        }

        private void CacheGeneratedReferences()
        {
            if (_canvasGroup == null)
                _canvasGroup = GetComponent<CanvasGroup>();

            if (_scoreRing == null)
                _scoreRing = GetComponentInChildren<EvaluationScoreRingGraphic>(true);

            if (finalSummaryImage == null)
            {
                Transform summaryImage = FindDeepChild(transform, "FinalSummaryImage");
                if (summaryImage != null)
                    finalSummaryImage = summaryImage.GetComponent<Image>();
            }

            if (passedVisualRoot == null)
            {
                Transform passedRoot = FindDeepChild(transform, "PassedVisualRoot");
                if (passedRoot != null)
                    passedVisualRoot = passedRoot.gameObject;
            }

            if (failedVisualRoot == null)
            {
                Transform failedRoot = FindDeepChild(transform, "FailedVisualRoot");
                if (failedRoot != null)
                    failedVisualRoot = failedRoot.gameObject;
            }
        }

        private void ApplyEditorPreviewIfNeeded()
        {
            if (!previewDesignInEditor)
                return;

            ApplyEditableDesignPreview();
        }

        private void ApplyEditorPreviewContent()
        {
            if (keepVisibleInEditor && !gameObject.activeSelf)
                gameObject.SetActive(true);

            int previewTotal = Mathf.Max(1, editorPreviewTotalQuestions);
            int previewCorrect = Mathf.Clamp(editorPreviewCorrect, 0, previewTotal);
            float previewScore = Mathf.Clamp(editorPreviewScore, 0f, Mathf.Max(1, maxScore));
            bool passed = previewScore >= passingScore;

            SetText(scoreText, FormatScore(previewScore));
            SetText(scoreMaxText, $"/{Mathf.Max(1, maxScore)} pts");
            SetText(statusText, passed ? passedLabel : failedLabel);
            SetText(correctText, $"{previewCorrect}/{previewTotal}");
            SetText(timeText, FormatTime(editorPreviewTimeSeconds));
            SetText(performanceText, GetPerformanceLabel(previewScore));
            SetText(feedbackText, GetFeedback(passed));
            SetText(continueButtonText, continueButtonLabel);

            ApplyResultColors(passed);

            float previewProgress = Mathf.Clamp01(previewScore / Mathf.Max(1, maxScore));
            if (scoreFillImage != null)
                scoreFillImage.fillAmount = previewProgress;

            if (_scoreRing != null)
                _scoreRing.SetProgress(previewProgress);

            if (_canvasGroup != null)
                _canvasGroup.alpha = 1f;
        }

        private void ConfigurePanelBackground()
        {
            var background = GetComponent<Image>();
            if (background != null)
            {
                background.color = panelBackgroundColor;
                background.raycastTarget = true;
            }

            var shadow = GetComponent<Shadow>();
            if (shadow == null)
                shadow = gameObject.AddComponent<Shadow>();

            shadow.effectColor = new Color(0f, 0f, 0f, 0.28f);
            shadow.effectDistance = new Vector2(0.05f, -0.05f);
        }

        private void ConfigureHeader()
        {
            TextMeshProUGUI header = FindText("HeaderText");
            if (header == null)
                return;

            SetText(header, "Evaluaci\u00f3n completada");
            header.fontSize = 0.42f;
            header.fontStyle = FontStyles.Bold;
            header.color = Color.white;
            header.alignment = TextAlignmentOptions.Center;
            SetRect(header.rectTransform, new Vector2(0f, -2.08f), new Vector2(6.6f, 0.55f));
            EnsureTextShadow(header, 0.018f, 0.7f);
        }

        private void ConfigureScoreBlock()
        {
            RectTransform scoreRoot = GetNamedRect("ScoreCircle");
            if (scoreRoot == null)
                return;

            SetRect(scoreRoot, new Vector2(-2.15f, -0.72f), new Vector2(1.85f, 1.85f));

            if (scoreFillImage != null)
                scoreFillImage.enabled = false;

            _scoreRing = EnsureScoreRing(scoreRoot);
            _scoreRing.SetProgress(0f);
            _scoreRing.SetColors(scoreTrackColor, passedColor);

            if (scoreText != null)
            {
                scoreText.fontSize = 0.62f;
                scoreText.fontStyle = FontStyles.Bold;
                scoreText.alignment = TextAlignmentOptions.Center;
                SetRect(scoreText.rectTransform, new Vector2(0f, 0.04f), new Vector2(1.1f, 0.82f));
                EnsureTextShadow(scoreText, 0.012f, 0.55f);
            }

            if (scoreMaxText != null)
            {
                scoreMaxText.fontSize = 0.2f;
                scoreMaxText.fontStyle = FontStyles.Bold;
                scoreMaxText.color = secondaryTextColor;
                scoreMaxText.alignment = TextAlignmentOptions.Center;
                scoreMaxText.enableAutoSizing = true;
                scoreMaxText.fontSizeMin = 0.14f;
                scoreMaxText.fontSizeMax = 0.2f;
                SetRect(scoreMaxText.rectTransform, new Vector2(0f, 0.48f), new Vector2(1.25f, 0.32f));
            }
        }

        private void ConfigureStatusBadge()
        {
            if (statusBackground == null)
                return;

            var badgeRect = statusBackground.rectTransform;
            SetRect(badgeRect, new Vector2(-2.15f, 0.55f), new Vector2(2.2f, 0.54f));
            statusBackground.color = WithAlpha(passedColor, statusBackgroundAlpha);

            if (statusText != null)
            {
                statusText.fontSize = 0.28f;
                statusText.fontStyle = FontStyles.Bold;
                statusText.color = Color.white;
                statusText.alignment = TextAlignmentOptions.Center;
                SetRect(statusText.rectTransform, new Vector2(0.18f, 0f), new Vector2(1.55f, 0.46f));
            }

            if (passedVisualRoot == null)
                passedVisualRoot = CreateResultVisual(statusBackground.transform, "PassedVisualRoot", true, passedColor);

            if (failedVisualRoot == null)
                failedVisualRoot = CreateResultVisual(statusBackground.transform, "FailedVisualRoot", false, failedColor);

            SetIconRect(passedVisualRoot);
            SetIconRect(failedVisualRoot);
        }

        private void ConfigureStatsRow()
        {
            RectTransform statsRow = GetNamedRect("StatsRow");
            if (statsRow == null)
                return;

            SetRect(statsRow, new Vector2(1.28f, -0.48f), new Vector2(4.55f, 1.18f));

            RectTransform correctCard = GetNamedRect("CorrectCard");
            RectTransform timeCard = GetNamedRect("TimeCard");
            RectTransform performanceCard = GetNamedRect("PerformanceCard");

            if (correctCard != null)
                correctCard.SetSiblingIndex(0);
            if (timeCard != null)
                timeCard.SetSiblingIndex(1);
            if (performanceCard != null)
                performanceCard.SetSiblingIndex(2);

            var layout = statsRow.GetComponent<HorizontalLayoutGroup>();
            if (layout == null)
                layout = statsRow.gameObject.AddComponent<HorizontalLayoutGroup>();

            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = false;
            layout.childControlHeight = false;
            layout.childForceExpandWidth = false;
            layout.childForceExpandHeight = false;
            layout.spacing = 0.2f;
            layout.padding = new RectOffset(0, 0, 0, 0);

            TextMeshProUGUI correctLabel = FindText("CorrectLabel");
            TextMeshProUGUI timeLabel = FindText("TimeLabel");
            TextMeshProUGUI performanceLabel = FindText("PerformanceLabel");

            SetText(correctLabel, "Correctas");
            SetText(timeLabel, "Tiempo total");
            SetText(performanceLabel, "Resultado");

            ConfigureStatCard(correctCard, correctText, correctLabel, 1.35f);
            ConfigureStatCard(timeCard, timeText, timeLabel, 1.35f);
            ConfigureStatCard(performanceCard, performanceText, performanceLabel, 1.65f);
        }

        private void ConfigureStatCard(RectTransform card, TextMeshProUGUI value, TextMeshProUGUI label, float width)
        {
            if (card == null)
                return;

            card.anchorMin = new Vector2(0.5f, 0.5f);
            card.anchorMax = new Vector2(0.5f, 0.5f);
            card.pivot = new Vector2(0.5f, 0.5f);
            card.sizeDelta = new Vector2(width, 0.92f);
            card.localScale = Vector3.one;

            var layoutElement = card.GetComponent<LayoutElement>();
            if (layoutElement == null)
                layoutElement = card.gameObject.AddComponent<LayoutElement>();
            layoutElement.preferredWidth = width;
            layoutElement.preferredHeight = 0.92f;

            var image = card.GetComponent<Image>();
            if (image != null)
                image.color = cardBackgroundColor;

            var outline = card.GetComponent<Outline>();
            if (outline == null)
                outline = card.gameObject.AddComponent<Outline>();
            outline.effectColor = new Color(1f, 1f, 1f, 0.08f);
            outline.effectDistance = new Vector2(0.012f, -0.012f);

            if (value != null)
            {
                value.fontStyle = FontStyles.Bold;
                value.color = Color.white;
                value.alignment = TextAlignmentOptions.Center;
                value.enableAutoSizing = true;
                value.fontSizeMin = 0.16f;
                value.fontSizeMax = value == performanceText ? 0.24f : 0.36f;
                SetRect(value.rectTransform, new Vector2(0f, 0.16f), new Vector2(width - 0.16f, 0.45f));
                EnsureTextShadow(value, 0.01f, 0.45f);
            }

            if (label != null)
            {
                label.fontSize = 0.16f;
                label.fontStyle = FontStyles.Bold;
                label.color = secondaryTextColor;
                label.alignment = TextAlignmentOptions.Center;
                SetRect(label.rectTransform, new Vector2(0f, -0.27f), new Vector2(width - 0.16f, 0.3f));
            }
        }

        private void ConfigureFeedback()
        {
            if (feedbackText == null)
                return;

            feedbackText.fontSize = 0.22f;
            feedbackText.enableAutoSizing = true;
            feedbackText.fontSizeMin = 0.16f;
            feedbackText.fontSizeMax = 0.24f;
            feedbackText.color = new Color(1f, 1f, 1f, 0.92f);
            feedbackText.alignment = TextAlignmentOptions.Center;
            SetRect(feedbackText.rectTransform, new Vector2(0f, 1.23f), new Vector2(6.65f, 0.62f));
        }

        private void ConfigureButtonVisuals()
        {
            if (continueButton == null)
                return;

            var buttonRect = continueButton.GetComponent<RectTransform>();
            if (buttonRect != null)
                SetRect(buttonRect, new Vector2(0f, 2.08f), new Vector2(2.85f, 0.56f));

            var image = continueButton.GetComponent<Image>();
            if (image != null)
            {
                image.color = buttonColor;
                Sprite builtinSprite = Resources.GetBuiltinResource<Sprite>("UI/Skin/UISprite.psd");
                if (builtinSprite != null)
                {
                    image.sprite = builtinSprite;
                    image.type = Image.Type.Sliced;
                }
            }

            var colors = continueButton.colors;
            colors.normalColor = buttonColor;
            colors.highlightedColor = new Color(0.08f, 0.68f, 0.82f, 1f);
            colors.pressedColor = new Color(0.01f, 0.36f, 0.46f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.disabledColor = new Color(0.35f, 0.44f, 0.48f, 0.65f);
            colors.fadeDuration = 0.08f;
            continueButton.colors = colors;

            if (continueButtonText != null)
            {
                continueButtonText.fontSize = 0.22f;
                continueButtonText.fontStyle = FontStyles.Bold;
                continueButtonText.color = Color.white;
                continueButtonText.alignment = TextAlignmentOptions.Center;
                continueButtonText.enableAutoSizing = true;
                continueButtonText.fontSizeMin = 0.16f;
                continueButtonText.fontSizeMax = 0.22f;
                StretchToParent(continueButtonText.rectTransform);
            }
        }

        private void ConfigureFinalSummaryImage()
        {
            if (finalSummaryImage == null)
                return;

            finalSummaryImage.raycastTarget = false;
            finalSummaryImage.preserveAspect = true;
            finalSummaryImage.color = Color.white;

            var imageRect = finalSummaryImage.rectTransform;
            if (imageRect != null)
                SetRect(imageRect, new Vector2(1.28f, 0.62f), new Vector2(4.45f, 0.82f));

            ApplyFinalSummarySprite();
        }

        private void ApplyFinalSummarySprite()
        {
            if (finalSummaryImage == null)
                return;

            if (finalSummarySprite != null)
                finalSummaryImage.sprite = finalSummarySprite;

            finalSummaryImage.enabled = finalSummaryImage.sprite != null;
        }

        private EvaluationScoreRingGraphic EnsureScoreRing(RectTransform scoreRoot)
        {
            const string ringName = "GeneratedScoreRing";
            Transform ringTransform = FindDirectChild(scoreRoot, ringName);
            RectTransform ringRect;

            if (ringTransform == null)
            {
                var ringObject = new GameObject(ringName, typeof(RectTransform), typeof(CanvasRenderer));
                ringObject.transform.SetParent(scoreRoot, false);
                ringRect = ringObject.GetComponent<RectTransform>();
                ringRect.SetAsFirstSibling();
            }
            else
            {
                ringRect = ringTransform.GetComponent<RectTransform>();
            }

            SetRect(ringRect, Vector2.zero, new Vector2(1.72f, 1.72f));
            var ring = ringRect.GetComponent<EvaluationScoreRingGraphic>();
            if (ring == null)
                ring = ringRect.gameObject.AddComponent<EvaluationScoreRingGraphic>();

            ring.raycastTarget = false;
            ring.SetThickness(0.13f);
            return ring;
        }

        private GameObject CreateResultVisual(Transform parent, string objectName, bool passed, Color color)
        {
            Transform existing = FindDirectChild(parent, objectName);
            GameObject visualObject = existing != null
                ? existing.gameObject
                : new GameObject(objectName, typeof(RectTransform), typeof(CanvasRenderer));

            visualObject.transform.SetParent(parent, false);

            var graphic = visualObject.GetComponent<EvaluationResultIconGraphic>();
            if (graphic == null)
                graphic = visualObject.AddComponent<EvaluationResultIconGraphic>();

            graphic.raycastTarget = false;
            graphic.SetState(passed, color);
            return visualObject;
        }

        private void SetIconRect(GameObject iconRoot)
        {
            if (iconRoot == null)
                return;

            var rect = iconRoot.GetComponent<RectTransform>();
            if (rect == null)
                return;

            SetRect(rect, new Vector2(-0.82f, 0f), new Vector2(0.34f, 0.34f));
        }

        private void AnimateEntry()
        {
            if (!applyRuntimePolish || _canvasGroup == null || !gameObject.activeInHierarchy)
                return;

            if (_fadeAnimation != null)
                StopCoroutine(_fadeAnimation);

            _fadeAnimation = StartCoroutine(FadeInPanel());
        }

        private IEnumerator FadeInPanel()
        {
            _canvasGroup.alpha = 0f;
            float elapsed = 0f;

            while (elapsed < 0.18f)
            {
                elapsed += Time.unscaledDeltaTime;
                _canvasGroup.alpha = Mathf.Clamp01(elapsed / 0.18f);
                yield return null;
            }

            _canvasGroup.alpha = 1f;
            _fadeAnimation = null;
        }

        private void AnimateScoreProgress(float targetProgress)
        {
            if (_scoreAnimation != null)
                StopCoroutine(_scoreAnimation);

            if (scoreFillImage != null)
                scoreFillImage.fillAmount = targetProgress;

            if (_scoreRing == null || !gameObject.activeInHierarchy)
                return;

            _scoreAnimation = StartCoroutine(FillScoreRing(targetProgress));
        }

        private IEnumerator FillScoreRing(float targetProgress)
        {
            _scoreRing.SetProgress(0f);
            float elapsed = 0f;

            while (elapsed < 0.42f)
            {
                elapsed += Time.unscaledDeltaTime;
                float t = Mathf.Clamp01(elapsed / 0.42f);
                _scoreRing.SetProgress(Mathf.SmoothStep(0f, targetProgress, t));
                yield return null;
            }

            _scoreRing.SetProgress(targetProgress);
            _scoreAnimation = null;
        }

        private void NormalizeDefaultCopy()
        {
            if (passedFeedback == "Buen resultado. Mantienes criterio correcto en diagnostico y recomendacion.")
                passedFeedback = "Buen resultado. Mantienes criterio correcto en diagn\u00f3stico y recomendaci\u00f3n.";

            if (failedFeedback == "Revisa los criterios de tipo de falla, causa probable y recomendacion.")
                failedFeedback = "Revisa los criterios de tipo de falla, causa probable y recomendaci\u00f3n.";

            if (continueButtonLabel == "Finalizar")
                continueButtonLabel = "Finalizar evaluaci\u00f3n";
        }

        private void ConfigureContinueButton()
        {
            if (continueButton == null)
                return;

            continueButton.onClick.RemoveListener(HandleContinuePressed);
            continueButton.onClick.AddListener(HandleContinuePressed);
        }

        private void HandleContinuePressed()
        {
            var continueAction = _onContinue;
            _onContinue = null;
            if (continueButton != null)
                continueButton.interactable = false;

            continueAction?.Invoke(LastScore);
        }

        private static void SetText(TextMeshProUGUI text, string value)
        {
            if (text != null)
                text.text = value;
        }

        private TextMeshProUGUI FindText(string objectName)
        {
            Transform child = FindDeepChild(transform, objectName);
            return child != null ? child.GetComponent<TextMeshProUGUI>() : null;
        }

        private RectTransform GetNamedRect(string objectName)
        {
            Transform child = FindDeepChild(transform, objectName);
            return child != null ? child.GetComponent<RectTransform>() : null;
        }

        private static Transform FindDeepChild(Transform parent, string objectName)
        {
            if (parent == null)
                return null;

            string normalizedName = NormalizeName(objectName);
            for (int i = 0; i < parent.childCount; i++)
            {
                Transform child = parent.GetChild(i);
                if (NormalizeName(child.name) == normalizedName)
                    return child;

                Transform match = FindDeepChild(child, objectName);
                if (match != null)
                    return match;
            }

            return null;
        }

        private static Transform FindDirectChild(Transform parent, string objectName)
        {
            if (parent == null)
                return null;

            string normalizedName = NormalizeName(objectName);
            for (int i = 0; i < parent.childCount; i++)
            {
                Transform child = parent.GetChild(i);
                if (NormalizeName(child.name) == normalizedName)
                    return child;
            }

            return null;
        }

        private static string NormalizeName(string value) =>
            string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();

        private static void SetRect(RectTransform rect, Vector2 anchoredPosition, Vector2 size)
        {
            if (rect == null)
                return;

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = size;
            rect.localScale = Vector3.one;
        }

        private static void StretchToParent(RectTransform rect)
        {
            if (rect == null)
                return;

            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = Vector2.zero;
            rect.localScale = Vector3.one;
        }

        private static void EnsureTextShadow(TextMeshProUGUI text, float distance, float alpha)
        {
            if (text == null)
                return;

            var shadow = text.GetComponent<Shadow>();
            if (shadow == null)
                shadow = text.gameObject.AddComponent<Shadow>();

            shadow.effectColor = new Color(0f, 0f, 0f, alpha);
            shadow.effectDistance = new Vector2(distance, -distance);
        }

        private static Color WithAlpha(Color color, float alpha)
        {
            color.a = alpha;
            return color;
        }

        private void MarkSceneDirtyInEditor()
        {
#if UNITY_EDITOR
            if (Application.isPlaying)
                return;

            EditorUtility.SetDirty(this);
            if (gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(gameObject.scene);
#endif
        }

        private static string FormatTime(int totalSeconds)
        {
            int safeSeconds = Mathf.Max(0, totalSeconds);
            int minutes = safeSeconds / 60;
            int seconds = safeSeconds % 60;
            return $"{minutes:00}:{seconds:00}";
        }

        private static string FormatScore(float score)
        {
            float rounded = Mathf.Round(score);
            if (Mathf.Approximately(score, rounded))
                return rounded.ToString("0");

            return score.ToString("0.0");
        }
    }
}
