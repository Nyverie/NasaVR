using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Panel de checklist que muestra tareas pendientes/completadas en la guía.
    /// Marcar ítems con SetItemCompleted(index). Popula los ítems desde código o en Start.
    /// </summary>
    public class ChecklistPanel : MonoBehaviour
    {
        [System.Serializable]
        public class ChecklistItem
        {
            public TMPro.TextMeshProUGUI label;
            public Image checkIcon;
            public Color pendingColor = Color.white;
            public Color completedColor = Color.green;
        }

        [SerializeField] private List<ChecklistItem> items;
        [SerializeField] private Sprite checkSprite;
        [SerializeField] private Sprite pendingSprite;

        private void Awake()
        {
            ResetAll();
        }

        public void SetItemCompleted(int index, bool completed = true)
        {
            if (index < 0 || index >= items.Count) return;
            var item = items[index];
            if (item.label) item.label.color = completed ? item.completedColor : item.pendingColor;
            if (item.checkIcon)
            {
                item.checkIcon.sprite = completed ? checkSprite : pendingSprite;
                item.checkIcon.color = completed ? item.completedColor : item.pendingColor;
            }
        }

        public int ItemCount => items != null ? items.Count : 0;

        /// <summary>Muestra u oculta un ítem (para paneles con más ranuras que tareas).</summary>
        public void SetItemVisible(int index, bool visible)
        {
            if (index < 0 || index >= items.Count) return;
            var item = items[index];
            if (item.label == null) return;

            // La fila es el padre del label (label + icono); si el label cuelga directo del panel, se oculta solo el label.
            Transform row = item.label.transform.parent;
            GameObject go = row != null && row != transform ? row.gameObject : item.label.gameObject;
            go.SetActive(visible);
        }

        public void SetItemLabel(int index, string text)
        {
            if (index >= 0 && index < items.Count && items[index].label)
                items[index].label.text = text;
        }

        public void ResetAll()
        {
            for (int i = 0; i < items.Count; i++)
                SetItemCompleted(i, false);
        }
    }
}
