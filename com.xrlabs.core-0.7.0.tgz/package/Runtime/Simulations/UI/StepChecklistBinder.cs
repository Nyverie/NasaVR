using System.Collections.Generic;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Llena un ChecklistPanel con las tareas de la secuencia (pasos con countsAsTask, en
    /// orden) y las marca al completarse. Los textos se resuelven por idioma: taskLabel puede
    /// ser un ID de LineLibrary o texto plano. Al saltar capítulos marca las tareas previas.
    /// </summary>
    public class StepChecklistBinder : MonoBehaviour
    {
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private ChecklistPanel checklist;

        [Tooltip("Mostrar solo las tareas de la sección actual (como la web). Si no, todas.")]
        [SerializeField] private bool onlyCurrentSection;

        private readonly List<StepDefinition> _tasks = new();
        private readonly HashSet<StepDefinition> _done = new();

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindAnyObjectByType<StepSystem>();
            if (stepSystem == null || checklist == null) return;

            stepSystem.StepStarted += HandleStepStarted;
            stepSystem.TaskCompleted += HandleTaskCompleted;
            stepSystem.JumpedToStep += HandleJumped;
            LanguageService.Changed += HandleLanguageChanged;
        }

        private void OnDisable()
        {
            if (stepSystem != null)
            {
                stepSystem.StepStarted -= HandleStepStarted;
                stepSystem.TaskCompleted -= HandleTaskCompleted;
                stepSystem.JumpedToStep -= HandleJumped;
            }
            LanguageService.Changed -= HandleLanguageChanged;
        }

        private void HandleStepStarted(StepDefinition step, int index, int total)
        {
            if (_tasks.Count == 0) CollectTasks();
            Refresh();
        }

        private void HandleTaskCompleted(StepDefinition step, int done, int total)
        {
            _done.Add(step);
            Refresh();
        }

        private void HandleJumped(int from, int to)
        {
            var sequence = stepSystem.Sequence;
            if (sequence == null) return;
            if (_tasks.Count == 0) CollectTasks();

            _done.Clear();
            for (int i = 0; i < to && i < sequence.TotalSteps; i++)
            {
                var step = sequence.GetStep(i);
                if (step != null && step.countsAsTask) _done.Add(step);
            }
        }

        private void HandleLanguageChanged(CoachLanguage _) => Refresh();

        private void CollectTasks()
        {
            _tasks.Clear();
            var sequence = stepSystem.Sequence;
            if (sequence == null || sequence.steps == null) return;
            foreach (var step in sequence.steps)
                if (step != null && step.countsAsTask) _tasks.Add(step);
        }

        private void Refresh()
        {
            var visible = VisibleTasks();
            int slots = checklist.ItemCount;

            for (int i = 0; i < slots; i++)
            {
                bool used = i < visible.Count;
                checklist.SetItemVisible(i, used);
                if (!used) continue;

                checklist.SetItemLabel(i, ResolveLabel(visible[i]));
                checklist.SetItemCompleted(i, _done.Contains(visible[i]));
            }

            if (visible.Count > slots)
                Debug.LogWarning($"[Checklist] Hay {visible.Count} tareas visibles y el panel tiene {slots} ítems.");
        }

        private List<StepDefinition> VisibleTasks()
        {
            if (!onlyCurrentSection || stepSystem.CurrentStep == null) return _tasks;

            string section = stepSystem.GetSectionNameFor(stepSystem.CurrentStepIndex);
            var sequence = stepSystem.Sequence;
            var result = new List<StepDefinition>();
            for (int i = 0; i < sequence.TotalSteps; i++)
            {
                var step = sequence.GetStep(i);
                if (step != null && step.countsAsTask && stepSystem.GetSectionNameFor(i) == section)
                    result.Add(step);
            }
            return result;
        }

        private static string ResolveLabel(StepDefinition step)
        {
            string label = string.IsNullOrEmpty(step.taskLabel) ? step.stepId : step.taskLabel;
            if (VOManager.Instance != null && VOManager.Instance.TryResolve(label, out var resolved) &&
                !string.IsNullOrEmpty(resolved.Text))
                return resolved.Text;
            return label;
        }
    }
}
