using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// 0.3 lote 4 (contrato-0.3.md §2.9): el panel fijo de indicadores del HUD. Muestra, por cada indicador de la
    /// <see cref="SimulationSequence.indicators"/> que se ve en el paso en curso (<c>desde</c>/<c>hasta</c>), «etiqueta: valor»
    /// (por <c>textos</c> si la variable es de texto; con <c>unidad</c> y <c>decimales</c> si es numérica), y se rehace con
    /// <see cref="SimulationState.Changed"/>, al empezar un paso y al saltar. Lo que cambia destella
    /// <see cref="FlashSeconds"/> s, sin sonido. Sin indicadores visibles, el panel se oculta con su CanvasGroup (nunca
    /// apagando el objeto, la lección de <see cref="ManualStepButton"/>). Lo pone «Preparar escena» en el [HUD] solo si el
    /// guion declara <c>indicadores</c> (SubtitleHudBuilder).
    /// </summary>
    public class IndicatorPanel : MonoBehaviour
    {
        /// <summary>Lo que dura el destello de un valor que cambia.</summary>
        public const float FlashSeconds = 0.6f;

        private const string FlashColor = "#FFD54A";

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private CanvasGroup group;
        [SerializeField] private TMP_Text valuesText;

        private SimulationState _state;
        private readonly Dictionary<string, float> _flashUntil = new();
        private readonly List<string> _visible = new();
        private bool _subscribedSteps;

        /// <summary>El texto que se muestra (una línea por indicador visible).</summary>
        public string Text => valuesText != null ? valuesText.text : string.Empty;

        /// <summary>Los ids de los indicadores visibles ahora, en orden.</summary>
        public IReadOnlyList<string> VisibleIds => _visible;

        /// <summary>True mientras el valor de ese indicador destella.</summary>
        public bool IsFlashing(string indicatorId) =>
            indicatorId != null && _flashUntil.TryGetValue(indicatorId, out var until) && Time.unscaledTime < until;

        /// <summary>Para el builder y los tests: enlaza el panel a un StepSystem.</summary>
        public void Bind(StepSystem steps)
        {
            UnsubscribeSteps();
            stepSystem = steps;
            SubscribeSteps();
            Refresh();
        }

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            SubscribeSteps();
            Refresh();
        }

        private void OnDisable()
        {
            UnsubscribeSteps();
            SetState(null);
        }

        private void Update()
        {
            // La tabla puede recrearse (SimulationStateHost.Build, StepSystem al empezar): se sigue a la vigente.
            var current = stepSystem != null ? stepSystem.State : null;
            if (current != _state) Refresh();
            else if (_flashUntil.Count > 0) ExpireFlashes();
        }

        /// <summary>Rehace el texto con el estado y el paso actuales.</summary>
        public void Refresh()
        {
            SetState(stepSystem != null ? stepSystem.State : null);
            Render();
        }

        private void Render()
        {
            _visible.Clear();
            var sequence = stepSystem != null ? stepSystem.Sequence : null;
            var sb = new StringBuilder();
            if (sequence?.indicators != null && _state != null)
            {
                int stepIndex = stepSystem.CurrentStepIndex;
                foreach (var indicator in sequence.indicators)
                {
                    if (indicator == null || !_state.Has(indicator.variable)) continue;
                    if (!IndicatorFormat.IsVisibleAt(indicator, sequence, stepIndex)) continue;
                    _visible.Add(indicator.id);
                    if (sb.Length > 0) sb.Append('\n');
                    string label = IndicatorFormat.Label(indicator, _state, ResolveText);
                    string value = IndicatorFormat.Value(indicator, _state, ResolveText);
                    if (!string.IsNullOrEmpty(label)) sb.Append(label).Append(": ");
                    if (IsFlashing(indicator.id)) sb.Append("<color=").Append(FlashColor).Append("><b>").Append(value).Append("</b></color>");
                    else sb.Append(value);
                }
            }

            if (valuesText != null) valuesText.text = sb.ToString();
            if (group != null)
            {
                group.alpha = _visible.Count > 0 ? 1f : 0f;
                group.blocksRaycasts = false;
                group.interactable = false;
            }
        }

        private void ExpireFlashes()
        {
            List<string> expired = null;
            foreach (var pair in _flashUntil)
                if (Time.unscaledTime >= pair.Value) (expired ??= new List<string>()).Add(pair.Key);
            if (expired == null) return;
            foreach (var id in expired) _flashUntil.Remove(id);
            Render();
        }

        private void OnStateChanged(StateChange change)
        {
            var sequence = stepSystem != null ? stepSystem.Sequence : null;
            if (sequence?.indicators != null)
                foreach (var indicator in sequence.indicators)
                    if (indicator != null && indicator.variable == change.Variable && !string.IsNullOrEmpty(indicator.id))
                        _flashUntil[indicator.id] = Time.unscaledTime + FlashSeconds;
            Render();
        }

        private void SetState(SimulationState state)
        {
            if (state == _state) return;
            if (_state != null) _state.Changed -= OnStateChanged;
            _state = state;
            if (_state != null) _state.Changed += OnStateChanged;
        }

        private void SubscribeSteps()
        {
            if (_subscribedSteps || stepSystem == null) return;
            stepSystem.StepStarted += OnStepStarted;
            stepSystem.JumpedToStep += OnJumped;
            _subscribedSteps = true;
        }

        private void UnsubscribeSteps()
        {
            if (!_subscribedSteps || stepSystem == null) { _subscribedSteps = false; return; }
            stepSystem.StepStarted -= OnStepStarted;
            stepSystem.JumpedToStep -= OnJumped;
            _subscribedSteps = false;
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => Refresh();

        private void OnJumped(int from, int to) => Refresh();

        // El texto de una frase soloTexto del VOManager; sin él, el id (IndicatorFormat lo usa de respaldo).
        private static string ResolveText(string lineId)
        {
            var vo = VOManager.Instance;
            return vo != null && vo.TryResolve(lineId, out var resolved) ? resolved.Text : null;
        }
    }
}
