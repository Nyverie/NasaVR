using UnityEngine;
using UnityEngine.UI;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Botón «¿Qué hago?» del HUD (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md §4): repite la instrucción del
    /// paso y enciende la guía al instante (<see cref="StepGuidance.RequestHelp"/>). Solo se ve en los pasos interactivos.
    /// En pantalla, la tecla H hace lo mismo y en el visor, además del rayo sobre el botón, el botón Menú del mando
    /// izquierdo (los dos los atiende <see cref="StepGuidance"/>). Lo crea <c>SubtitleHudBuilder</c>.
    /// </summary>
    [AddComponentMenu("XRLabs/What To Do Button")]
    [RequireComponent(typeof(Button))]
    public class WhatToDoButton : MonoBehaviour
    {
        public const string Label = "¿Qué hago?";

        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private CanvasGroup group;

        private Button _button;

        public StepSystem Steps { get => stepSystem; set => stepSystem = value; }

        private void Awake()
        {
            _button = GetComponent<Button>();
            if (group == null) group = GetComponent<CanvasGroup>();
        }

        private void OnEnable()
        {
            _button.onClick.AddListener(Press);
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem != null) stepSystem.StepStarted += OnStepStarted;
            Refresh(stepSystem != null ? stepSystem.CurrentStep : null);
        }

        private void OnDisable()
        {
            _button.onClick.RemoveListener(Press);
            if (stepSystem != null) stepSystem.StepStarted -= OnStepStarted;
        }

        private void OnStepStarted(StepDefinition step, int index, int total) => Refresh(step);

        private void Refresh(StepDefinition step)
        {
            bool visible = step != null && step.stepType == StepType.Interaction;
            if (group == null) return;
            group.alpha = visible ? 1f : 0f;
            group.interactable = visible;
            group.blocksRaycasts = visible;
        }

        /// <summary>Lo que hace el clic.</summary>
        public void Press()
        {
            var guidance = StepGuidance.Instance != null ? StepGuidance.Instance : FindFirstObjectByType<StepGuidance>();
            if (guidance != null) guidance.RequestHelp();
        }
    }
}
