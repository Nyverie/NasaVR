using System;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Panel de valoración de 1 a 5 estrellas. Al confirmar, notifica al SessionManager.
    /// </summary>
    public class StarRatingPanel : MonoBehaviour
    {
        [SerializeField] private Button[] starButtons;
        [SerializeField] private Image[] starImages;
        [SerializeField] private Sprite starFilled;
        [SerializeField] private Sprite starEmpty;
        [SerializeField] private Color filledColor = Color.yellow;
        [SerializeField] private Color emptyColor = Color.gray;
        [SerializeField] private Button confirmButton;
        [SerializeField] private XRLabs.UI.SessionManager sessionManager;

        public event Action<int> OnRatingConfirmed;

        private int _selectedRating;

        private void Awake()
        {
            gameObject.SetActive(false);
            _selectedRating = 0;

            for (int i = 0; i < starButtons.Length; i++)
            {
                int rating = i + 1;
                starButtons[i].onClick.RemoveAllListeners();
                starButtons[i].onClick.AddListener(() => SelectRating(rating));
            }

            if (confirmButton)
            {
                confirmButton.onClick.RemoveAllListeners();
                confirmButton.onClick.AddListener(ConfirmRating);
                confirmButton.interactable = false;
            }
        }

        public void Show()
        {
            gameObject.SetActive(true);
            SelectRating(0);
        }

        private void SelectRating(int rating)
        {
            _selectedRating = rating;
            UpdateStarVisuals(rating);
            if (confirmButton) confirmButton.interactable = rating > 0;
        }

        private void ConfirmRating()
        {
            if (_selectedRating <= 0) return;
            sessionManager?.SetRating(_selectedRating);
            OnRatingConfirmed?.Invoke(_selectedRating);
            gameObject.SetActive(false);
        }

        private void UpdateStarVisuals(int rating)
        {
            for (int i = 0; i < starImages.Length; i++)
            {
                if (starImages[i] == null) continue;
                bool filled = i < rating;
                starImages[i].sprite = filled ? starFilled : starEmpty;
                starImages[i].color = filled ? filledColor : emptyColor;
            }
        }
    }
}
