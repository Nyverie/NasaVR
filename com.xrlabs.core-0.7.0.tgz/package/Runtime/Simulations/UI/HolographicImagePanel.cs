using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Panel flotante VR que muestra imágenes de referencia (broca sana vs dañada).
    /// Usar en Canvas WorldSpace. Soporta fade in/out y navegación entre imágenes.
    /// </summary>
    public class HolographicImagePanel : MonoBehaviour
    {
        [Header("UI")]
        [SerializeField] private Image displayImage;
        [SerializeField] private TMPro.TextMeshProUGUI captionText;
        [SerializeField] private CanvasGroup canvasGroup;

        [Header("Animación")]
        [SerializeField] private float fadeDuration = 0.3f;

        [Header("Billboarding")]
        [SerializeField] private bool faceCamera = true;

        private Transform _mainCamera;
        private Coroutine _fadeCoroutine;

        private void Awake()
        {
            if (canvasGroup == null) canvasGroup = GetComponent<CanvasGroup>();
            if (canvasGroup) canvasGroup.alpha = 0f;
            gameObject.SetActive(false);
        }

        private void Start()
        {
            _mainCamera = Camera.main?.transform;
        }

        private void LateUpdate()
        {
            if (faceCamera && _mainCamera != null)
                transform.rotation = Quaternion.LookRotation(transform.position - _mainCamera.position);
        }

        public void Show(Sprite sprite, string caption = "")
        {
            gameObject.SetActive(true);
            if (displayImage) displayImage.sprite = sprite;
            if (captionText) captionText.text = caption;

            if (_fadeCoroutine != null) StopCoroutine(_fadeCoroutine);
            _fadeCoroutine = StartCoroutine(FadeTo(1f));
        }

        public void Hide()
        {
            if (!gameObject.activeInHierarchy)
            {
                if (canvasGroup) canvasGroup.alpha = 0f;
                return;
            }
            if (_fadeCoroutine != null) StopCoroutine(_fadeCoroutine);
            _fadeCoroutine = StartCoroutine(FadeOutAndDisable());
        }

        private IEnumerator FadeTo(float target)
        {
            if (canvasGroup == null) yield break;
            float start = canvasGroup.alpha;
            float elapsed = 0f;
            while (elapsed < fadeDuration)
            {
                elapsed += Time.deltaTime;
                canvasGroup.alpha = Mathf.Lerp(start, target, elapsed / fadeDuration);
                yield return null;
            }
            canvasGroup.alpha = target;
        }

        private IEnumerator FadeOutAndDisable()
        {
            yield return FadeTo(0f);
            gameObject.SetActive(false);
        }
    }
}
