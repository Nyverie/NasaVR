using XRLabs.Core;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Escucha los eventos del StepSystem y muestra u oculta los paneles UI
    /// según el PanelType declarado en cada StepDefinition.
    /// Colocar en un GO en escena y asignar las referencias en el Inspector.
    /// </summary>
    public class PanelStepHandler : MonoBehaviour
    {
        [Header("Referencias de escena")]
        [SerializeField] private StepSystem stepSystem;
        [SerializeField] private HolographicImagePanel imagePanel;
        [SerializeField] private IconSequencePanel iconSequencePanel;

        private void OnEnable()
        {
            if (stepSystem != null)
            {
                stepSystem.StepStarted   += OnStepStarted;
                stepSystem.StepCompleted += OnStepCompleted;
            }
        }

        private void OnDisable()
        {
            if (stepSystem != null)
            {
                stepSystem.StepStarted   -= OnStepStarted;
                stepSystem.StepCompleted -= OnStepCompleted;
            }
        }

        private void OnStepStarted(StepDefinition step, int index, int total)
        {
            switch (step.panelType)
            {
                case PanelType.Image:
                    iconSequencePanel?.gameObject.SetActive(false);
                    if (step.displayImage != null)
                        imagePanel?.Show(step.displayImage, step.titleText);
                    break;

                case PanelType.IconSequence:
                    imagePanel?.Hide();
                    iconSequencePanel?.gameObject.SetActive(true);
                    iconSequencePanel?.PlaySequence();
                    break;

                case PanelType.None:
                case PanelType.PartLabel:
                case PanelType.Checklist:
                default:
                    imagePanel?.Hide();
                    iconSequencePanel?.gameObject.SetActive(false);
                    break;
            }
        }

        private void OnStepCompleted(StepDefinition step, int index, float elapsed)
        {
            // El siguiente OnStepStarted se encarga de transicionar.
            // Solo ocultamos si el paso tenía panel para no dejar nada colgado.
            if (step.panelType == PanelType.Image || step.panelType == PanelType.IconSequence)
            {
                imagePanel?.Hide();
                iconSequencePanel?.StopSequence();
                iconSequencePanel?.gameObject.SetActive(false);
            }
        }
    }
}
