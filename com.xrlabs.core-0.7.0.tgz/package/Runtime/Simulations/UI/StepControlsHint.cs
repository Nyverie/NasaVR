using TMPro;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// La ayuda de mandos dice qué control pide el paso en curso (UX visor 2026-10-31; Documentation~/decisiones-ux-visor.md
    /// §4): delante de la línea fija de siempre pone, resaltado, «Ahora: mantén el GATILLO LATERAL para agarrar» o «Ahora:
    /// apunta y pulsa el GATILLO» según el tipo de paso (<see cref="ControlHints.For"/>). Cuando el coach repite la
    /// instrucción por inactividad (<see cref="StepGuidance.InstructionRepeated"/>) el resalte se agranda. Va en el texto de
    /// la ayuda de mandos; lo agrega <c>SubtitleHudBuilder</c>.
    /// </summary>
    [AddComponentMenu("XRLabs/Step Controls Hint")]
    [RequireComponent(typeof(TMP_Text))]
    public class StepControlsHint : MonoBehaviour
    {
        [SerializeField] private StepSystem stepSystem;
        [SerializeField, TextArea] private string baseText;

        private TMP_Text _text;
        private StepGuidance _guidance;
        private bool _emphasis;

        public StepSystem Steps { get => stepSystem; set => stepSystem = value; }
        public string BaseText { get => baseText; set => baseText = value; }

        /// <summary>El control que se resalta ahora.</summary>
        public ControlHint Current { get; private set; }

        private void Awake() => _text = GetComponent<TMP_Text>();

        private void OnEnable()
        {
            if (stepSystem == null) stepSystem = FindFirstObjectByType<StepSystem>();
            if (stepSystem != null) stepSystem.StepStarted += OnStepStarted;
            _guidance = StepGuidance.Instance != null ? StepGuidance.Instance : FindFirstObjectByType<StepGuidance>();
            if (_guidance != null) _guidance.InstructionRepeated += OnRepeated;
            Show(stepSystem != null ? stepSystem.CurrentStep : null);
        }

        private void OnDisable()
        {
            if (stepSystem != null) stepSystem.StepStarted -= OnStepStarted;
            if (_guidance != null) _guidance.InstructionRepeated -= OnRepeated;
        }

        private void OnStepStarted(StepDefinition step, int index, int total) { _emphasis = false; Show(step); }

        private void OnRepeated(StepDefinition step) { _emphasis = true; Show(step); }

        /// <summary>Escribe la línea para un paso (null = solo la línea fija).</summary>
        public void Show(StepDefinition step)
        {
            if (_text == null) _text = GetComponent<TMP_Text>();
            if (string.IsNullOrEmpty(baseText)) baseText = _text.text;
            Current = ControlHints.For(step);
            string label = ControlHints.Label(Current);
            if (string.IsNullOrEmpty(label)) { _text.text = baseText; return; }
            string size = _emphasis ? "<size=130%>" : "<size=115%>";
            _text.text = size + "<b><color=#FFD54A>" + label + "</color></b></size>\n" + baseText;
        }
    }
}
