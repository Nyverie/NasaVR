using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Condition completed when the user touches/signals a specific hotspot.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Hotspot Touch")]
    public class HotspotTouchCondition : StepCondition
    {
        [Tooltip("Unique hotspot ID that must be touched")]
        [SerializeField] private string hotspotId;

        public override void Initialize()
        {
            if (string.IsNullOrEmpty(hotspotId))
                Debug.LogWarning("[HotspotTouchCondition] hotspotId is empty.");

            HotspotRegistry.Instance?.ResetHotspot(hotspotId);
        }

        public override bool IsCompleted()
        {
            return HotspotRegistry.Instance != null &&
                   HotspotRegistry.Instance.IsHotspotTouched(hotspotId);
        }

        public override void Cleanup() { }
    }
}
