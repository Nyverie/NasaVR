using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Condición que se completa cuando el usuario gira un objeto al menos N grados en total.
    /// Acumula el ángulo frame a frame; funciona para rotaciones en cualquier dirección.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Rotation Tracking")]
    public class RotationTrackingCondition : StepCondition
    {
        [Tooltip("Tag del GameObject a rastrear")]
        [SerializeField] private string targetTag = "DrillBit";

        [Tooltip("Grados totales de rotación necesarios para completar el paso")]
        [SerializeField] private float requiredAngleDegrees = 360f;

        [Tooltip("Segundos entre reintentos de búsqueda del target si aún no existe (evita FindWithTag por frame)")]
        [SerializeField] private float targetRetryIntervalSeconds = 0.5f;

        private Transform _target;
        private Quaternion _lastRotation;
        private float _accumulatedAngle;
        private float _nextTargetSearchTime;

        /// <summary>Grados acumulados de rotación en el paso actual (para telemetría de exploración).</summary>
        public float AccumulatedAngle => _accumulatedAngle;

        public override void Initialize()
        {
            TryResolveTarget();

            if (_target == null)
                Debug.LogWarning($"[RotationTrackingCondition] No se encontró objeto con tag '{targetTag}'");

            _lastRotation = _target != null ? _target.rotation : Quaternion.identity;
            _accumulatedAngle = 0f;
        }

        public override bool IsCompleted()
        {
            if (_target == null && Time.unscaledTime >= _nextTargetSearchTime)
            {
                TryResolveTarget();
                _lastRotation = _target != null ? _target.rotation : Quaternion.identity;
            }

            if (_target == null) return false;

            float delta = Quaternion.Angle(_lastRotation, _target.rotation);
            _accumulatedAngle += delta;
            _lastRotation = _target.rotation;

            return _accumulatedAngle >= requiredAngleDegrees;
        }

        public override void Cleanup()
        {
            if (_accumulatedAngle > 0f)
            {
                Core.Telemetry.TelemetryHub.Emit(new Core.Telemetry.ExplorationEvent
                {
                    StepId = Core.Telemetry.TelemetryContext.CurrentStepId,
                    RotationDegrees = _accumulatedAngle
                });
            }

            _target = null;
        }

        private void TryResolveTarget()
        {
            _nextTargetSearchTime = Time.unscaledTime + Mathf.Max(0.1f, targetRetryIntervalSeconds);
            var go = GameObject.FindWithTag(targetTag);
            _target = go != null ? go.transform : null;
        }
    }
}
