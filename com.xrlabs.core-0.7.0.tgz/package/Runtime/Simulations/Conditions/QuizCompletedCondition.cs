using XRLabs.Core;
using UnityEngine;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Se completa cuando cualquier CaseEvaluationController activo marca su caso como completado.
    /// Esto evita depender de un controlador arbitrario si la escena tiene mas de uno.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Quiz Completed")]
    public class QuizCompletedCondition : StepCondition
    {
        private CaseEvaluationController[] _controllers;

        public override void Initialize()
        {
            _controllers = Object.FindObjectsByType<CaseEvaluationController>(FindObjectsSortMode.None);
            if (_controllers == null || _controllers.Length == 0)
                Debug.LogWarning("[QuizCompletedCondition] No se encontro CaseEvaluationController en la escena.");
        }

        public override bool IsCompleted()
        {
            if (_controllers == null)
                return false;

            for (int i = 0; i < _controllers.Length; i++)
            {
                if (_controllers[i] != null && _controllers[i].IsCaseCompleted)
                    return true;
            }

            return false;
        }

        public override void Cleanup()
        {
            _controllers = null;
        }
    }
}
