using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Condición que se completa tras explorar una zona por N segundos O haber rotado el objeto suficiente.
    /// Usada en los pasos de inspección libre antes del quiz evaluativo.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/Timed Exploration")]
    public class TimedExplorationCondition : StepCondition
    {
        [Tooltip("Segundos de exploración mínima requerida")]
        [SerializeField] private float requiredSeconds = 15f;

        [Tooltip("Si está activo, también completa al alcanzar este ángulo de rotación")]
        [SerializeField] private bool allowRotationShortcut = true;

        [Tooltip("Grados de rotación suficientes para saltarse el timer")]
        [SerializeField] private float shortcutAngle = 360f;

        [Tooltip("Tag del objeto a rotar (solo si allowRotationShortcut está activo)")]
        [SerializeField] private string rotationTargetTag = "DrillBit";

        [Tooltip("Segundos entre reintentos de búsqueda del target si aún no existe (evita FindWithTag por frame)")]
        [SerializeField] private float targetRetryIntervalSeconds = 0.5f;

        private float _startTime;
        private Transform _rotationTarget;
        private Quaternion _lastRotation;
        private float _accumulatedAngle;
        private float _nextTargetSearchTime;

        /// <summary>Segundos de exploración transcurridos (para telemetría).</summary>
        public float ElapsedExplorationSeconds => Time.time - _startTime;

        /// <summary>Grados acumulados de rotación (para telemetría).</summary>
        public float AccumulatedAngle => _accumulatedAngle;

        public override void Initialize()
        {
            _startTime = Time.time;
            _accumulatedAngle = 0f;

            if (allowRotationShortcut)
                TryResolveTarget();
        }

        public override bool IsCompleted()
        {
            if (Time.time - _startTime >= requiredSeconds)
                return true;

            if (allowRotationShortcut && _rotationTarget != null)
            {
                float delta = Quaternion.Angle(_lastRotation, _rotationTarget.rotation);
                _accumulatedAngle += delta;
                _lastRotation = _rotationTarget.rotation;

                if (_accumulatedAngle >= shortcutAngle)
                    return true;
            }
            else if (allowRotationShortcut && _rotationTarget == null && Time.unscaledTime >= _nextTargetSearchTime)
            {
                TryResolveTarget();
            }

            return false;
        }

        public override void Cleanup()
        {
            Core.Telemetry.TelemetryHub.Emit(new Core.Telemetry.ExplorationEvent
            {
                StepId = Core.Telemetry.TelemetryContext.CurrentStepId,
                RotationDegrees = _accumulatedAngle,
                ExplorationSeconds = ElapsedExplorationSeconds
            });

            _rotationTarget = null;
        }

        private void TryResolveTarget()
        {
            _nextTargetSearchTime = Time.unscaledTime + Mathf.Max(0.1f, targetRetryIntervalSeconds);
            var go = GameObject.FindWithTag(rotationTargetTag);
            _rotationTarget = go != null ? go.transform : null;
            _lastRotation = _rotationTarget != null ? _rotationTarget.rotation : Quaternion.identity;
        }
    }
}
