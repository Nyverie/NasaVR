using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Simulations
{
    /// <summary>
    /// Condition completed when every hotspot in a zone has been touched.
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Conditions/All Hotspots Touched")]
    public class AllHotspotsTouchedCondition : StepCondition
    {
        [Tooltip("Zone whose hotspots must all be completed")]
        [SerializeField] private string zone;

        [Tooltip("Seconds to wait after all hotspots are touched before completing the step")]
        [SerializeField] private float completionDelaySeconds;

        [Tooltip("Minimum number of hotspots that must exist in the zone")]
        [SerializeField] private int expectedHotspotCount = 1;

        private float _allTouchedAt = -1f;
        private bool _missingRegistryWarningLogged;
        private bool _allTouchedLogged;

        public override void Initialize()
        {
            if (string.IsNullOrEmpty(zone))
                Debug.LogWarning("[AllHotspotsTouchedCondition] zone is empty.");

            _allTouchedAt = -1f;
            _missingRegistryWarningLogged = false;
            _allTouchedLogged = false;
            HotspotRegistry.Instance?.ResetZone(zone);
        }

        public override bool IsCompleted()
        {
            if (HotspotRegistry.Instance == null)
            {
                if (!_missingRegistryWarningLogged)
                {
                    _missingRegistryWarningLogged = true;
                    Debug.LogWarning("[AllHotspotsTouchedCondition] No HotspotRegistry found in scene.");
                }

                _allTouchedAt = -1f;
                return false;
            }

            if (!HotspotRegistry.Instance.AreAllHotspotsInZoneTouched(zone, expectedHotspotCount))
            {
                _allTouchedAt = -1f;
                return false;
            }

            if (_allTouchedAt < 0f)
            {
                _allTouchedAt = Time.time;

                if (!_allTouchedLogged)
                {
                    _allTouchedLogged = true;
                    Debug.Log($"[AllHotspotsTouchedCondition] All hotspots touched in zone '{zone}'. Waiting {completionDelaySeconds:0.0}s.");
                }
            }

            return Time.time - _allTouchedAt >= completionDelaySeconds;
        }

        public override void Cleanup()
        {
            _allTouchedAt = -1f;
            _missingRegistryWarningLogged = false;
            _allTouchedLogged = false;
        }
    }
}
