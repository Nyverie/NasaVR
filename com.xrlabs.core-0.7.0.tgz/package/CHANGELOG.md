# Changelog

Formato: [Keep a Changelog](https://keepachangelog.com/) + [SemVer](https://semver.org/).

## [Unreleased]

## [0.7.0] — 2026-10-31

### Cambiado — XR al día: paquetes OpenXR del anfitrión, OpenXR por visor, háptica, realce y sonido (2026-10-31)
- Fuente: informe `investigacion/reports/2026-10-31-openxr-androidxr-xri-al-dia.md` de Coresearch; detalle, fuentes y lo que queda en [`Documentation~/platform-support.md`](Documentation~/platform-support.md), sección «Actualización XR del 2026-10-31». Solo el plan de esta semana (bajo riesgo): XRI sigue en 3.3.1 y los mínimos de `package.json` no cambian.
- `Host~`: `com.unity.xr.openxr` 1.18.0 → 1.19.0 (poses de ojo con la cabeza en movimiento), `com.unity.xr.androidxr-openxr` 1.4.1 → 1.5.1 (AR Foundation 6.7.1 transitiva), `com.unity.xr.hands` 1.10.0 declarado (antes 1.7.3 transitiva), `com.unity.inputsystem` 1.19.0 → 1.20.1.
- `VisorBuildPlan`/`VisorOpenXr`: el Galaxy XR ya no apaga el Oculus Touch Controller Profile, que es el de sus mandos 6DoF (H2); los dos visores encienden Hand Tracking Subsystem, Hand Interaction Profile y Foveated Rendering, el Quest además Meta Hand Tracking Aim (H3, H4); la latencia pasa a Prioritize Input Polling (`PrioritizeInputPolling`); el Microsoft Hand Interaction Profile deja de encenderse por el nombre.
- Rig XRI (H1, la háptica estaba muerta): `HapticImpulsePlayer` por mando, `SimpleHapticFeedback` en el NearFar (apuntar suave, tomar claro, soltar breve) y en el rayo de teletransporte, `XRHapticsProvider` en la raíz con los dos players; `InteractionFeedback` y un `XRInputModalityManager` con grupos de mano vacíos y sin los mandos en sus huecos. `XriRigBuilder.HasHaptics()` y `HasInteractionFeedback()` entran en `IsUpToDate`; prefab regenerado en batch.
- `InteractionFeedback` (`Runtime/Interactions`, nuevo): realce por `MaterialPropertyBlock` al apuntar y al tomar, clip corto sintetizado al agarrar, soltar y tocar, y pulso por `FeedbackSystem.Haptics` si la mano no vibró ya. `InteractableBase` emite `HoveredAnywhere`, `UnhoveredAnywhere`, `SelectedAnywhere`, `ReleasedAnywhere` y `ActivatedAnywhere`. `TouchableHotspot.EnsureSnapVolume()` (con visor activo, en `Start`): `XRInteractableSnapVolume` para que el rayo pegue al hotspot.
- Tests: 4 EditMode (`VisorBuildPlanTests` ×2, `XriRigPrefabTests` ×2) y 3 PlayMode (`InteractionFeedbackPlayTests`) (426 / 129 sobre el lote 7, el arte y el terreno).

### Cambiado — la muestra del INIA tiene terreno low-poly `CampoCompostaje` en vez del suelo liso y la planta de concreto (2026-10-31)
- «No se entiende nada con los cubos»: `Tools~/arte/generar_terreno.py` (Blender 5.1 en batch, determinista) construye el terreno de `arte-compostaje.md` §3 con primitivas: suelo de 24 × 22 m en rejilla de 1 m con la ladera abierta detrás de A, cerros bajos, berma y surcos de B; parches de color de A–D (pasto ralo, húmedo, protegida) y de tierra apisonada bajo la pila y bajo cada zona a la que la lleva el lote 1; pirca detrás de C y D, corral de palos con la puerta hacia D, pileta con caño, cobertizo abierto con techo de ichu, matas de ichu, tolas y piedras fuera del área de juego. 3 624 triángulos, 6 materiales. Lee `colocacion.json` y falla si el relieve levanta algo de la colocación (también la `compostera` en A–D) o si una caja entra a menos de 0,3 m de una zona o recuadro. Escribe `Samples~/ExperienciaCompostaje/Entorno/Modelos/CampoCompostaje.fbx` y `Entorno/terreno.json`.
- `EntornoBuilder`: con `terreno.json` en la carpeta Entorno, el entorno es `Terreno` (el FBX, 1 cm bajo las zonas, materiales URP Lit de color plano por nombre), `Colliders` (cajas de la pirca, el corral y el cobertizo), `Suelo` sin malla con el collider fino y la `TeleportationArea` de siempre sobre el rectángulo plano (nadie aterriza dentro de la ladera) y el sol sin sombras. Precedencia: `entorno.json` (planta del artista, experiencia 12), `terreno.json`, y si no, el suelo liso con la planta de antes. Los FBX y texturas de la planta salen de `Samples~/ExperienciaCompostaje/Entorno/` (siguen en la muestra de la planta).
- Desvíos de la ficha por el lote 1 (la compostera aparece sobre la zona elegida): punto de agua en (7, 4,05) y no en (5,6, 4,6), corral 0,9 m a la derecha, cobertizo más abajo, sin la pirca entre C y D ni las bermas cercanas de B; anotados en §3.
- Tests: `EntornoCompostajeTests` ampliado (el terreno está y no la planta, ≤ 6 000 triángulos y ≤ 6 materiales URP Lit, la malla cae donde dice el manifiesto, ningún collider a menos de 0,3 m de una zona o recuadro —también las de la compostera en A–D— y la altura del terreno bajo todas ellas es 0 ± 2 cm, nada entre 0,5 y 2 cm) (408 / 118).

### Añadido — low-poly de los 33 objetos del lote 7 en la muestra del INIA (2026-10-31)
- «No se entiende nada con los cubos»: `Tools~/arte/generar_lowpoly.py` construye 17 modelos nuevos (3 272 triángulos; ≤ 600 y ≤ 3 materiales cada uno, origen en la base, metros) para COMP-08 a COMP-13: termómetro de dial, pala, la pila destapada (`MezclaPila`), el olor fuerte, las tres muestras (normal, inmadura con restos, madura lisa), la zaranda inclinada, la ensacadora con tolva, sinfín, boca y balanza, la palada de compost, el saco vacío de 25 kg, el tablero del botón verde, el saco lleno con su costura, el frutal, la hilera de cuatro hortalizas sobre las zonas `planta-1` a `4`, el puñado de compost y la tierra. Las nueve respuestas (fases, «¿Está listo?», restos gruesos) son el `Cartel.fbx` de la humedad con su marco de color y el texto TMP por las dos caras; paladas y puñados comparten prefab. 26 prefabs nuevos con su `Ajuste` (`GenerarPrefabsLowpoly.cs`), 5 materiales URP Lit más (`LP_Olor` y `LP_HojaClara` nuevos en la paleta); unos 600 KB.
- Los 33 objetos dejan de ser cubo sin tocar ningún `modelo` (el guion ya los nombraba): comprobado en la escena re-preparada, cada uno lleva la instancia de su prefab, los agarrables conservan `GrabbableItem` (y las palas `AimTool`) con la caja del modelo, y botones, hotspots y superficies, su interactuable. Los del lote 7 miran a +Z de Unity (+Y de Blender), hacia la persona: la boca de la ensacadora cae sobre la zona `boca-descarga`. `--render-nuevos` hace una fila con ellos (Workbench).
- `ArteLowpolyTests`: 55 objetos en la precondición y sin excepciones; las palas, paladas, saco, termómetro y puñados en las comprobaciones de agarre, los carteles nuevos como hotspots con su texto, muestra y botón verde que se mantienen y las cuatro superficies (sin tests nuevos: 417 / 120). `arte-compostaje.md` §8.1.1 con la tabla id → fichero → triángulos → qué falta.

### Añadido — contrato 0.3, lote 7: la muestra del INIA entera, COMP-00 a COMP-13 (2026-10-31)
- `Samples~/ExperienciaCompostaje/guion.json`: las catorce pantallas del storyboard en 0.3, 136 pasos al desenrollar. COMP-02 dice la función de cada material al colocarlo (`reacciones`) y, con «Continuar», cuáles faltan (`faltantes`; se sigue cerrando solo, decisión a). COMP-03 y COMP-05: la pila bloqueada hasta picar y la cubierta hasta el respiradero (`bloqueos`, con sus correcciones del storyboard). COMP-04: grupo de cinco ciclos (contador `ciclo`, `porIteracion` de `altura`, «Ciclo n de cinco» por vuelta, indicador «Ciclo n de 5, altura»). COMP-06: bloque `prueba-puno` con los tres casos (muy mojada, seca, bien), `segun` y `errorPorEstado` (decisión c) y los remedios de secar y regar. COMP-07: la cubierta con el centro sobre el tubo corrige (zona `boca-tubo`, `medir: centro`) y «Continuar» sin cubrir también. COMP-08: bucle de seis semanas con el calendario que fija Coresearch (decisión b: 45, 62, 72, 55, 38 y 25 °C; pico de 72 °C en la tercera), medir con el termómetro, «¿En qué fase está?» según `fase`, «demasiado caliente» por encima de 70 °C; COMP-09 dentro del bucle en las semanas 2, 4 y 6 (destapar, voltear con la pala, prueba del puño, cubrir; sin volteo, olor fuerte). COMP-10 (dos muestras según `madurez`), COMP-11 (zaranda y restos), COMP-12 (ensacadora con el botón bloqueado hasta cargar la tolva y colocar el saco; balanza a 25 kg) y COMP-13 (frutal con la zona del tronco que mide el centro, una dosis por planta con `distintas`, cubrir con tierra). Cuatro indicadores (humedad y temperatura todo el recorrido, capas en COMP-04, balanza desde COMP-12; tres en el informe). Sin paso de cierre: el éxito de COMP-13 cierra y sale el informe final.
- 146 frases (124 dichas), 75 voces nuevas con el proveedor provisional del sistema (`say`, Paulina); 15 frases que el storyboard no trae, marcadas «Añadida por la muestra» en su `nota` y listadas en el `LEEME.md` de la muestra. `colocacion.json`: 33 objetos, 13 zonas y 2 anclas nuevas (junto a la pila, dentro del conjunto `compostera`; el tamizado y el ensacado a la izquierda del inicio; la parcela a la derecha).
- Arreglado: completar un `avanzar` en pleno fundido (F2, capítulos) sin nadie suscrito a `TimeAdvanced` no sumaba los días ni aplicaba su `alIniciar` (iban como argumentos de `TimeAdvanced?.Invoke`, que no se evalúan con el evento vacío). Lo destapó el recorrido de la muestra.
- Tests: 5 EditMode nuevos en `ExperienciaCompostajeTests` (calendario de seis semanas, tres casos de COMP-06, «Continuar»/bloqueos/zonas, voz de cada frase dicha tras desenrollar, frases de COMP-08 a 13 literales; el orden de las catorce pantallas reemplaza al de las ocho) y 2 PlayMode (`MuestraCompostajeRecorridoPlayTests`: la muestra importada y recorrida de principio a fin, con el estado final y `complete_experience` con `metadata.estado`; y el del arreglo) (413 / 120).

### Añadido — contrato 0.3, lote 4: `elegir` según el estado e indicadores (2026-10-31)
- `elegir` con `segun` (§2.5): las opciones llevan `valor` en vez de `resultado`; la correcta es la del valor de la variable al tocar (antes de su `alElegir`) y tocar otra reporta `errorPorEstado[estado]`, no la clave de la opción. `ChoiceByTargetCondition` (`stateVariable`, `errorsByState`, `ChoiceOption.stateValue`; lee la tabla del `SimulationStateHost` o, sin él, la del `StepSystem`). En un salto se repite el `alElegir` de la opción del valor de ese momento (`StepStateEffects.chooseBy`/`onChooseByValue`, `ChooseEffectsFor`).
- Telemetría: `step_error`/`step_warning` de cualquier `elegir` por objeto llevan `metadata.opcion` = el objeto tocado (`IStepSignalDetails`, `StepSignalEvent.Option`), sin tocar `StepSignal` ni `StepCondition`; `complete_experience` lleva `metadata.estado` con los valores finales cuando la experiencia usa estado (el pendiente del lote 2).
- `indicadores` (§2.9): `SimulationSequence.indicators` (`StateIndicator`, `IndicatorFormat`, C# puro) y `IndicatorPanel` (`Runtime/Simulations/UI`, nuevo): «etiqueta: valor» por `textos` (texto) o con `unidad`/`decimales` (numérica), acotado por `desde`/`hasta`, rehecho con `Changed`, al empezar un paso y al saltar; el valor que cambia destella 0,6 s. `SubtitleHudBuilder.SyncIndicatorPanel` lo pone en el `[HUD]` (arriba a la derecha, texto 28–36 como el nombre del subtítulo, sin tapar el rayo, bajo la cortinilla) solo si el guion declara indicadores, y lo quita si dejan de estar. `EvaluationFinalResultsPanel` muestra los de `enInforme` (`ReportText`; en `reportText` o, sin él, tras la retroalimentación).
- Esquema (`segun`/`errorPorEstado`/`valor`, `indicadores`), `GuionDocument`, `GuionValidator` (`segun` sin declarar o numérica, mezclar `valor` y `resultado`, valor sin opción o repetido, `errorPorEstado` que falta, incompleto o sin frase; indicador con id repetido, variable sin declarar, etiqueta o textos sin frase, `textos` incompleto o en una numérica, `unidad`/`decimales` en una de texto, `desde`/`hasta` que no son paso ni grupo o al revés; avisos: frase que no es `soloTexto`, más de cuatro indicadores; un 0.1/0.2 que los usa entra en el aviso de esquema) y `GuionImporter` (`desde`/`hasta` de grupo resueltos a su primer y su último paso).
- Tests: 26 EditMode (`GuionEstadoVistaTests`: validador, importador, HUD y formato) y 5 PlayMode (`ElegirSegunIndicadoresPlayTests`: `segun` elige según el estado, `errorPorEstado` da la corrección del estado, el indicador cambia y destella, `enInforme` en el panel final, `metadata.opcion` y `metadata.estado` contra el mock) (399 / 114).

### Añadido — contrato 0.3, lote 5: «Continuar» que dice qué falta y `llevar` con reacciones, faltantes y zonas distintas (2026-10-31)
- `StepCondition.TryConfirm(out clave)` (virtual; por defecto no confirma) y `MissingKeys()` (vacía por defecto). `StepSystem.TryConfirm()`: en un paso `Interaction` con `continuar`, con la condición cumplida (o si ella confirma) cierra el paso y deja `CompletedByContinue`; si no, reporta un error con la clave de lo que falta (la del primer objeto de `objetos` sin colocar, si no `claveIncompleto`) y sigue el camino de siempre (corrección, cuenta un error, se repite, `alError`); la corrección dice, seguidas, las frases de todo lo que falta (la lista entera, con voz horneada). En pantalla, Intro es «Continuar» solo con el coach callado (con una frase sonando, Intro la salta, como antes). Evento `ContinueRejected`.
- `ManualStepButton` generalizado: en un paso con `continuar` es «Continuar» (texto de `etiqueta`, por defecto `ui.continuar`) y su clic llama a `StepSystem.TryConfirm`; en los manuales sigue siendo «Comenzar». En el visor se pulsa con el rayo. `ManualKeyStepCondition.TryConfirm` completa el paso.
- `DropCondition`: `reactionItemIds` (al contar por primera vez un objeto con reacción reporta info `reaccion.<objeto>`; si ese soltado cierra el paso, el éxito espera a la reacción), `missingKeys` (objeto → clave de `errores`, en el orden de `objetos`) con `TryConfirm`, `MissingKeys` y `MissingItemIds`, y `distinctZones` (un soltado cuenta solo si su zona aún no tenía uno; el rechazado no es error y vuelve con `ReturnToOrigin.ReturnNow`).
- Guion 0.3: `continuar` (`etiqueta`, `claveIncompleto`) en el paso y `reacciones`, `faltantes`, `distintas` en la condición de `llevar`: esquema, `GuionDocument`, `GuionValidator` (cierres 2.6 y 2.7: objeto que no está en `objetos`, frase o clave que falta, `continuar` fuera de llevar/elegir/frotar/mantener/apuntar, sin `faltantes` ni `claveIncompleto`, etiqueta que no existe; aviso con `distintas` y menos zonas que `cantidad`; todo entra en el aviso de esquema de un 0.1/0.2) y `GuionImporter` (`StepDefinition.hasContinue`, `continueLabel`, `continueIncompleteKey`; reacciones en `errorLines` con la clave `reaccion.<objeto>`; reimportar sin ellas las borra).
- Tests: 9 EditMode (`ContinuarLlevarTests`) y 4 PlayMode (`ContinuarLlevarPlayTests`: con dos de cuatro materiales «Continuar» dice los dos que faltan y no completa; con los cuatro completa; la reacción suena al soltar y el éxito la espera; `distintas` rechaza dos materiales en la misma zona) (382 / 113).

### Añadido — low-poly provisional de las muestras de compostaje (2026-10-31)
- Tras el recorrido en el Quest 3 («no se entiende nada con los cubos»): `Tools~/arte/generar_lowpoly.py` (Blender 5.1 en batch) construye con primitivas propias, sin texturas y con color por material, 41 modelos (19 del INIA y 22 de la planta; ≤ 600 triángulos y ≤ 3 materiales cada uno, origen en la base, metros, frente a −Y) y los exporta a `Samples~/<muestra>/Modelos/Fuente/*.fbx`; `Tools~/arte/GenerarPrefabsLowpoly.cs` (copiado y borrado por `Tools~/arte/regenerar.sh`) hace en Unity los materiales URP Lit (`Materiales/M_LP_*.mat`) y un prefab por `modelo` con su hijo `Ajuste` (que compensa la escala de la colocación en la planta) y, en carteles y sacos, el texto con TMP por las dos caras. Sin colliders: el importador ajusta la caja.
- Muestra del INIA: los 22 objetos tienen modelo (20 dejan de ser cubo; `BaldeAgua` pasa del tanque del artista a un balde con asa y agua; `Palo` sigue con el cuartón). Planta: 31 `modelo` (conos, montones, ramas, manta, piedras, pulverizador del EM·1 y su bomba, tarjetas de dosis y del empujador, carteles de cuatro caras de las fases y del olor, zaranda, saco, sacos vacíos, manguera, empujador, astillas, consola, reloj, cámara térmica, ensacadora y su botón) cubren 38 de sus 58 objetos; siguen como cubo el cubo de práctica, los carriles, el área marcada y la pila. No cambia ningún `modelo` de los guiones ni de las colocaciones.
- `Documentation~/arte-compostaje.md`: §7 al día y sección 8, «Low-poly provisional (2026-10-31)», con la tabla id → fichero → triángulos → qué falta para el arte final, y cómo regenerar.
- Tests: 4 EditMode (`ArteLowpolyTests`: ningún objeto del INIA sin modelo, prefabs de la planta, la colocación de cada muestra con los modelos sin cubos y con los agarrables agarrándose) y `Sample_ModelPrefabsMatchGuionModelsAndUseUrpLit` exige un prefab con `Ajuste` por cada `modelo` (377 / 109).

### Añadido — UX del visor del 31 de octubre (2026-10-31)
- Lo que dijo el dueño en el Quest 3, las decisiones, sus fuentes y cómo probarlas en el casco: [`Documentation~/decisiones-ux-visor.md`](Documentation~/decisiones-ux-visor.md). Fuente de base: el informe `investigacion/reports/2026-10-31-ux-visor-y-assets-3d.md` de Coresearch.
- **Giro y agarre.** `SnapTurnGrabGuard` (raíz del rig): sin giro mientras la mano derecha sostiene algo, sin giro al soltar hasta que el stick vuelve al centro, y umbral de 0,75. `HandBusyLocomotionBlock` (en cada mando): la mano que sostiene no saca el arco de teletransporte. Sin media vuelta (`enableTurnAround = false`). `XriRigBuilder` los agrega (`HasSnapTurnGuard`, `HasHandBusyBlocks`) y el prefab del rig se regeneró en batch.
- **`RigHeadingAligner`.** Ignora el `trackingOriginUpdated` que llega sin foco o en los 2 s tras recuperarlo (`FocusGuardSeconds`, `IgnoredOriginUpdates`, `NotifyFocusChanged`, `NotifyTrackingOriginUpdated`, `Recenter`).
- **Anclas orientadas.** Las zonas `teleport` son `TeleportationAnchor` (`TargetUpAndForward`, hijo `Llegada`) con `TeleportGuideAnchor`: anillo, huellas y flecha en el suelo, que pulsan en los pasos para los que el sitio es el mejor. Campo opcional `zonas[].mirarHacia` en la colocación (esquema, documento y validador). Sin valor, mira a lo que usa el primer paso que nombra la zona o al ancla del coach. El suelo libre sigue teletransportable.
- **Guía por inactividad.** `StepGuidance` (`Runtime/Core`; «Preparar escena» lo pone en `[Simulation]`): a los 8 s sin avance (configurable) el objetivo pulsa con emisión y sale una línea con flecha en el suelo hacia el objetivo o el ancla recomendada. El coach repite la instrucción a `max(N, hintDelay) + N` s. Botón «¿Qué hago?» en el HUD (`WhatToDoButton`), botón Menú del mando izquierdo y tecla H. Ayuda de mandos con el control del paso (`StepControlsHint`, `ControlHints`).
- Tests: 5 EditMode (`UxVisorEditTests`) y 6 PlayMode (`UxVisorPlayTests`); `ColocacionImporterTests`, `MenuXriGeneratorTests` y `RigVisorPlayTests` (el stick atrás ya no gira) puestos al día (378 / 115).

### Cambiado — integración del contrato 0.3, lotes 1, 2, 3 y 6, en `feature/visor` (2026-10-31)
- Una sola ruta para los efectos de estado: el `StepSystem` aplica `alIniciar`, `alError`, `avanzar` y ahora también `alCompletar` (antes de `StepCompleted`), y en un salto rehace el estado con los pasos anteriores (días, `alIniciar`, `alElegir` de la opción correcta y `alCompletar`, saltando los que su `si` saltaba); `SimulationStateHost` deja de escuchar `StepCompleted` y `JumpedToStep` y queda como dueño de la tabla y de `state_changed` (el `StepSystem` solo lo manda para su tabla propia o la de `UseState`).
- Una sola declaración de `estado` (`GuionDocument.StateVarEntry`), una sola validación de la declaración (`GuionStateRules`) y un solo estado inicial (`StateAuthoring.BuildDefinitions` + `dia`); `StateChangedEvent` en un solo fichero. Un guion o una colocación 0.1/0.2 que usa algo de la 0.3 recibe un solo aviso de `esquema` (antes, uno por lote; el de `bloqueos` salía en la ruta `bloqueos`). `GuionExpander` quita `IsTimeAdvance` al desenrollar.
- Tests: 1 PlayMode (`EstadoEfectosUnaVezPlayTests`); `ZonasBloqueosTests` mira el aviso de esquema unificado (373 / 109).

### Añadido — contrato 0.3, lote 6: una zona por soltado, `medir` y `bloqueos` (2026-10-31)
- **El doble juicio de §3, visto en PlayMode antes del arreglo:** con dos zonas `soltar` solapadas que aceptan el objeto, un soltado daba un `DroppedAnywhere` por zona («cubierta, capas»). Ahora `DropZone` lo juzga una sola vez, en una zona: de las que lo contienen, la más pequeña (volumen del collider) que lo acepta; si ninguna, la más pequeña. Solo se resalta la zona que va a juzgar; `ReturnToOrigin` decide con esa misma zona. Rige para toda colocación (corrección para la muestra; Fallas de Brocas, fijado en `#v0.5.0`, no lo recibe).
- `zonas[].medir` (colocación 0.3): `"contacto"` (por defecto, como antes) o `"centro"` (el centro de los límites del objeto dentro del volumen). Esquema, `ColocacionDocument`, `ColocacionValidator` (otro valor, error; en `teleport` o en un fichero 0.1/0.2, aviso) y `ColocacionImporter` (`DropZone.measure`).
- `bloqueos` (guion 0.3, §2.8): `GuionDocument.Locks`, esquema, regla propia en `GuionValidator` (zona u objeto, `hasta`/`desde` paso o grupo, objeto existente; aviso si ningún paso hasta `hasta` declara la clave) y referencia cruzada de la zona con la colocación; `GuionImporter` los deja en `SimulationSequence.locks` (`StepLock`). `LockEnforcer` (`Runtime/Interactions`, nuevo) los aplica: la zona bloqueada rechaza todo soltado (no llega a la condición, el objeto vuelve) y el objeto bloqueado no se agarra ni se activa (`GrabbableItem` cancela la selección de XRI); con `clave` declarada en el paso en curso, `StepSystem.ReportError`. «Preparar escena» añade `LockEnforcer` a `[Simulation]` solo si el guion trae bloqueos (idempotente; lo quita si deja de traerlos).
- Tests: 11 EditMode (`ZonasBloqueosTests`, `ScenePreparerBloqueosTests`) y 8 PlayMode (`ZonasBloqueosPlayTests`) (320 / 99).

### Añadido — contrato 0.3, lote 3: grupos y bloques que se desenrollan al importar (2026-10-31)
- `Editor/Authoring/GuionExpander.cs` (nuevo, puro): los pasos `tipo: "grupo"` (con `pasos` en línea o `bloque` de los `bloques` de primer nivel, `repetir`, `contador`, `porIteracion`) pasan a la lista plana del 0.2, vuelta por vuelta, con ids `<grupo>.<k>.<paso>` (`<grupo>.<paso>` si `repetir` es 1; anidados, `COMP-08.2.puno.decidir`). El primer paso de cada vuelta recibe en `alIniciar` el contador y el objeto de `porIteracion` de esa vuelta, por debajo del suyo; `{contador}` en los ids de frase se sustituye al desenrollar; el `si` del grupo se suma al de cada paso; `tarea` en el grupo cuenta solo su último paso; un `desde` de `secciones` que nombra un grupo pasa a su primer paso; cada contador queda declarado en `estado`. Trabaja sobre el JSON, así que las claves de los lotes 1 y 2 (`si`, efectos, `estado`) viajan intactas (`GuionDocument` guarda las que no declara en `Extra`).
- `GuionValidator` valida el guion desenrollado y cita el id desenrollado y el grupo: grupo sin pasos, `pasos` y `bloque` a la vez, bloque que falta o recursivo, `repetir` fuera de 1–20 (aviso por encima de 10), `porIteracion` de otro largo, más de dos niveles, ids desenrollados repetidos o de más de 100 caracteres; un 0.1/0.2 con grupos recibe un aviso (D8). `GuionImporter` desenrolla en su primera línea: re-preparar con menos vueltas borra los pasos y condiciones sobrantes y repetir la importación no cambia nada. `ScenePreparer` ve también los pasos desenrollados. `ImportReport.Expanded` lista cada id con su grupo y su vuelta. `Schema/guion.schema.json`: `grupo`, `pasos`, `bloque`, `repetir`, `contador`, `porIteracion` y `bloques`.
- Tests: 15 EditMode (6 `GuionExpanderTests`, 7 `GuionGruposValidatorTests`, 2 `GuionGruposImporterTests`) con un guion de prueba de tres vueltas como las capas de COMP-04, y 1 PlayMode (`GuionGruposPlayTests`: la secuencia desenrollada se recorre entera y su sección cae en el primer paso del grupo) (324 / 92). La muestra del INIA no cambia (lote 7).

### Añadido — contrato 0.3, lote 2: guardas, efectos, `{variable}` y tiempo simulado (2026-10-31)
- `xrlabs.guion/0.3` (esquema y validador; 0.1 y 0.2 siguen igual y un 0.1/0.2 que usa algo de esto recibe un aviso): `estado` de texto y numérico (`inicial`, `min`/`max`, `registrar`), `si` en cualquier paso (valor, lista, `mayor`/`menor`), `alIniciar` y `alError` (texto, número o `{ "sumar": n }`, recortado al rango), el paso `avanzar` (`dias` obligatorio, `etiqueta` soloTexto, `fundido` 0–5, sin `condicion`; `dia` lo declara el importador) e ids de frase con `{variable}` (de texto; el validador exige cada frase expandida). Reglas en `Editor/Authoring/GuionStateRules.cs`, que comparten validador e importador.
- `StepDefinition`: `guard`, `onStartEffects`, `onErrorEffects`, `advanceDays`, `advanceLabel`, `advanceFadeSeconds` (vacíos = como antes, D8). La `SimulationSequence` lleva el estado inicial (`initialState`, del lote 1, rehecho en cada importación).
- `StepSystem`: un paso cuya guarda no se cumple al llegar se salta (no suena, no cuenta, descuenta su tarea: `SessionStats.SkipTask`); `alIniciar` antes de la introducción; `alError` tras la corrección; `{variable}` sustituida en intro, instrucción, éxito, errores y reacciones; el éxito espera a que termine una reacción; `avanzar` funde a negro, suma los días y aplica `alIniciar` con la pantalla en negro, enseña la etiqueta y sigue; los saltos de capítulo rehacen el estado. Usa la `SimulationState` del lote 1 (la del `SimulationStateHost` o una propia).
- Cortinilla: `TimeAdvanceCurtain` (`Runtime/Simulations/UI`) y `SubtitleHudBuilder.EnsureCurtain`, que «Preparar escena» pone en el `[HUD]` solo si la secuencia tiene un `avanzar`.
- Telemetría: `step_skipped` (`motivo: "si"`), `state_changed` (`variable`, `antes`, `valor`, solo con `registrar`) y `time_advanced` (`dias`, `dia`) por `POST /activity-log` con `entity: "Step"`; `action` es texto libre en `CreateActivityEventDto`, así que van con su nombre.
- Tests: 23 EditMode (`GuionEstadoTests`: validador, reglas, importador y cortinilla) y 6 PlayMode (`StepSystemEstadoTests`: guarda que salta, efecto que cambia el estado, `{variable}`, `alError`, `avanzar` con la cortinilla y cortada a mitad) (340 / 97, con los 8 de `SimulationStateTests` del lote 1).

### Añadido — contrato 0.3, lote 1: la pila aparece sobre la zona elegida en COMP-01 (2026-10-31)
- `SimulationState` (`Runtime/Core`, C# pura): variables de texto y numéricas, `Apply`, `Evaluate`, `Replay` para los saltos y el evento `Changed`. `SimulationStateHost` la guarda en escena con el estado inicial de `SimulationSequence.initialState`, aplica `alCompletar` al completar un paso y repite los efectos en un salto; manda `state_changed` (texto libre en `action` del activity log) para las variables con `registrar`.
- Guion `xrlabs.guion/0.3`: `estado`, `alCompletar`, `alElegir` (`ChoiceOption.onChoose`, que `ChoiceByTargetCondition` aplica al tocar). Colocación `xrlabs.colocacion/0.3`: `visibleSi` (`StateVisibility`) y `conjuntos` con `posicionSegun` (`Conjunto_<id>` + `StateLayout`). Esquemas, documentos, validadores cruzados (§2.1, §2.10) e importadores idempotentes; «Preparar escena» añade `SimulationStateHost` solo si el guion usa estado.
- Muestra del INIA: `estado.lugar` (de `ninguno` a `d`), la opción D de COMP-01 lleva `alElegir`, y el conjunto `compostera` (pila, `marca-centro`, tubo, palo, los objetos de COMP-03 a 07, zonas `centro`/`costado`/`capas`/`cubierta`/`frente-pila` y el ancla `pila`) está oculto hasta acertar y aparece sobre D conservando su disposición (D33). `arte-compostaje.md` §3/§6 y el `LEEME` dejan de decir que la pila está fija a 3,4 m de D.
- Tests: 15 EditMode (`SimulationStateTests`, `Estado03Tests`) y 2 PlayMode (`StateLayoutPlayTests`: COMP-01 con D muestra el conjunto sobre D y A/B/C no lo mueven; el salto atrás lo oculta y el cambio sale por telemetría) (324 / 93).

### Añadido — giro por pasos con el stick derecho (2026-10-26, quinto recorrido en el Quest 3)
- «¿Por qué tengo que dar una vuelta yo?»: `XriRigBuilder` agrega al rig un `SnapTurnProvider` de XRI (45° a los lados, media vuelta atrás, bajo el mismo `LocomotionMediator` que el teletransporte) que lee solo el stick derecho (`XRI Right Locomotion/Snap Turn`); el izquierdo sigue apuntando el arco. `XRLabsRig.prefab` regenerado (`IsUpToDate` exige `HasSnapTurn`); la ayuda de mandos del HUD dice «Stick derecho a los lados: girar». Diseño en `Documentation~/menu-xri.md` §10. Tests: 3 EditMode y 1 PlayMode (288 / 81).

### Añadido — `experiencia.visibilidadPorPaso`: la escena muestra solo lo que usa el paso en curso (2026-10-26)
- Clave opcional del guion (por defecto `false`; sin ella todo igual, D8) y `StepVisibilityController` (`Runtime/Interactions`): lo que ningún paso usa se ve siempre; lo que sí, del primer al último paso que lo usa (renderers y colliders, salvo agarrado); la etiqueta y el recuadro de una zona solo en los pasos que lo usan de verdad. «Preparar escena» e «Importar colocación» lo ponen en `[Colocacion]` (`StepVisibilityPlanner`). `autoria.md` §12.
- Tests: 14 EditMode y 8 PlayMode (299 / 88). Encendida en la experiencia 12 («Compostaje en planta»); la del INIA sigue sin ella.

### Añadido — la experiencia 12 replica el simulador web de compostaje paso a paso (2026-10-25, noche)
- `Samples~/ExperienciaCompostajePlanta/guion.json` (0.2): los 50 pasos del web (`Documentation~/replica-web-compostaje.md`) en nueve secciones y 54 pasos (la mezcla 3:2 en dos y las cuatro capas en cuatro, porque 0.2 no cuenta por fuente dentro de un paso), 25 tareas, 57 objetos y 150 frases (125 dichas, 25 rótulos); 14 `llevar`, 10 `tocar`, 8 `mantener`, 6 `narracion`, 5 `elegir`, 5 `manual`, 3 `apuntar`, 3 `frotar`. Los cinco pasos que 0.2 no expresa (mirar alrededor y las tarjetas de partícula, EM·1, bitácora y calidad: `PLANTA-04`, `12`, `16`, `26`, `43`) son `manual` con una frase que lee la tarjeta; el texto es el de la sim o el del web, con el original en la `nota`, y las 12 frases sin equivalente en el web van marcadas «Añadida por la réplica». Errores, pistas y decisiones (once carteles) como en el web; lo que se pierde está en el `LEEME.md`.
- `colocacion.json`: el inicio entre el cobertizo y la losa mirando a la losa, siete anclas del coach, los 57 objetos en la disposición del artista (convención del `entorno.json` ya instanciado: `x = 17,21 − x_artista`, `z = z_artista − 7`), seis recuadros de teletransporte y doce zonas de soltar. Nueve objetos usan un FBX del artista (pala, dos horquetas, carretilla, trituradora, tres termómetros, tanque); los otros 48 son marcadores con nombre de modelo.
- Voces: 125 clips del proveedor provisional del sistema (`say`, Paulina), uno por frase dicha con el id de la frase, en MP3 mono de 48 kbps (3,9 MB; en WAV pasarían de 27 MB). Se borran los 9 WAV del guion de cuatro pasos anterior.
- `MockExperienceCatalog`: la muestra del INIA (`ProductSceneName`, 11) va primera; después la 12 y luego la cero.
- Tests: 12 EditMode (11 en `ExperienciaCompostajePlantaTests`: validador sin avisos, los 50 pasos en orden, los cinco manuales, mezcla y capas, riego, reloj, decisiones, frases literales, una voz por frase dicha, preparar asigna clips, peso, disposición y agarrables; 1 en `ExperienceSceneMapTests`: el orden del menú) y `EntornoPlantaTests` comprueba que cada modelo del artista lo usa algún objeto (283 / 79).

### Corregido — orientación inicial y teletransporte entendible (2026-10-25, cuarto recorrido en el Quest 3, 23:50)
- «Todas las experiencias me aparecen detrás mío»: `RigHeadingAligner` (`Runtime/MenuXRI/`), en la raíz del prefab del rig (lo agrega `XriRigBuilder`; corre en el Menu XRI y en cada experiencia). Dos cuadros después del primero con la cabeza seguida, gira el `XROrigin` alrededor de la cámara hasta que el rumbo de la cámara es el de la raíz del rig (el `inicio` con su `giro`) y deja la cámara sobre el punto del inicio; lo repite con el recentrado del sistema (`XRInputSubsystem.trackingOriginUpdated`), conservando entonces el sitio de la persona. En pantalla el rig está apagado y nada cambia.
- «No sabía cómo teletransportarme»: el `Suelo` que arma `EntornoBuilder` (las dos muestras) lleva una `TeleportationArea` como la de los recuadros (solo la capa `Teleport`, al soltar, collider sólido) y baja 1 cm (`EntornoBuilder.SueloDrop`): se puede ir a cualquier punto del suelo y las zonas de soltar y los recuadros, por encima, mandan. Los `NearFarInteractor` del rig dejan de ver la capa `Teleport` (tenían todas).
- Ayuda de mandos fija en el `[HUD]` (`SubtitleHudBuilder.ControlsHelpName`, encima del subtítulo, en todas las builds): «Stick adelante y soltar: moverte · Gatillo lateral: agarrar · Gatillo: pulsar · B: completar paso · Y: saltar frase».
- Tests: 1 PlayMode (`RigHeadingAlignerPlayTests`) y 2 EditMode (`ScenePreparerTests`: la ayuda; `EntornoCompostajeTests`: el suelo teletransportable); los de colliders de `EntornoCompostajeTests` y `EntornoPlantaTests` miran el suelo aparte (273 / 80).

### Voces — proveedor provisional del sistema y la muestra de compostaje con voz (2026-10-25)
- Proveedor **«Sistema (macOS, provisional)»** (`VoiceProviderKind.MacSay`, `Editor/Voice/MacSayProvider.cs`): el `say` de macOS escribe cada frase en WAV de 16 bits a 22 050 Hz, local y sin clave. Es un relleno hasta que el dueño guarde la clave de ElevenLabs en las preferencias del Editor; D5 no cambia. El inspector de `VoiceSettings` y el de la `LineLibrary` lo avisan; `VoiceSettings.RequiresApiKey` y `VoiceApiKeys.HasOrNotNeeded` dejan hornear sin clave solo con este proveedor. Voz por defecto: Paulina (español de México); campo `systemVoice` por idioma.
- La muestra de compostaje trae sus voces: `Samples~/ExperienciaCompostaje/Voces/es/`, 53 WAV (una por frase dicha; las 7 `soloTexto` no), 324 s, 14 MB en el repositorio. `SamplePreparer` llama a `SampleVoices.Link`, que las copia a `<experiencia>/Voces/es/` del anfitrión, las importa como mono Vorbis 0,5 y las asigna a las variantes sin clip: la escena preparada y el APK del visor (`build_visor.sh -prepareSamples`) ya no son mudos.
- Tests: 3 EditMode en `MuestraVocesTests` (el proveedor del sistema no pide clave ni ID de voz; la muestra trae un WAV de más de medio segundo por frase dicha; al prepararla cada frase dicha recibe su clip) (256 / 72).

### Corregido — telemetría y menú tras el segundo recorrido en el Quest 3 (2026-10-25, tarde)
- El activity log de los pasos lleva el paso: `step_error`, `step_warning`, `hint_shown` y `exploration_summary` mandan `entityId` = el id del paso del guion (`COMP-02`); la metadata sigue con `stepId` y la clave del error (`key`). El mock imprime la metadata. Antes el logcat decía `(entidad Step )`.
- El puntaje descuenta errores: «Preparar escena» pone en el `ScoringSystem` la regla del coach, `TasksErrorsHints` (precisión = tareas / (tareas + errores) × 100, menos 2 por pista), y la corrige en las escenas ya preparadas; `TimeBased` solo si el guion reparte `puntos` o `penalizacion`. Con `TimeBased`, una experiencia guiada cerraba con 100 aunque hubiera errores. El backend y el mock guardan el puntaje que manda el cliente: la regla es del cliente hasta que el backend fije otra (`telemetria-extremo-a-extremo.md`). `SimulationManager.Steps` expone el `StepSystem`.
- El cierre de sesión manda `errorCount` con los errores de los pasos (antes, siempre 0); el mock lo imprime.
- El texto de carga del menú, «⟳ Cargando cursos...», salía con un cuadrado: ni ⟳ ni ↻ están en LiberationSans (ni en el atlas ni en el `.ttf` del fallback dinámico). Queda «Cargando cursos...» en el Menu XRI y en el prefab del menú.
- Tests: 2 EditMode (`ScenePreparerTests`: la regla; `MenuFontGlyphsTests`: todo texto del Menu XRI tiene glifo en su fuente o en un fallback) y 1 PlayMode (`SessionTelemetryMockTests`: tres errores y una pista, `entityId` del paso y puntaje por debajo de 100); los dos de COMP-01 afirman además el `entityId`, el puntaje y `errorCount` (253 / 72).

### Corregido — COMP-02 contaba soltados, no materiales distintos (2026-10-25, segundo recorrido en el Quest 3)
- `DropCondition` cuenta objetos distintos (un conjunto por instancia), no soltados: volver a soltar un material que ya estaba en el acopio no suma ni da error, y si el guion nombra los objetos y pide tantos como ids distintos tiene la lista (COMP-02: cuatro materiales, `cantidad` 4), «cumplida» exige cada id de la lista; con una cantidad menor (paja, ichu o manta) basta ese número de objetos distintos, y cada soltado de una pila (`CarriedItem`) sigue contando. Sacar un objeto del acopio no se rastrea (la condición no ve el soltado fuera de toda zona): uno ya contado sigue contado. Tests: 4 PlayMode (2 en `AcopioDropPlayTests`, 2 en `InteractionTests`) y el de `Count` de `InteractionTests` pasa a dos objetos distintos (251 / 78).

### Corregido — cinco «fuera-acopio» seguidos en COMP-02 y frotar agachado hasta el suelo (2026-10-25, segundo recorrido en el Quest 3)
- Causa, con el registro del casco (`visor-quest3-2026-10-25_160337`): nueve soltados en COMP-02 (el aviso de XRI «Cannot throw a kinematic Rigidbody» marca cada uno), cinco con «fuera-acopio» en el mismo cuadro y cuatro sin error; el cuarto cierra el paso. Ningún soltado cayó fuera de toda zona y soltar fuera nunca es error, así que no fue el teletransporte, ni la huella, ni la física (los agarrables son cinemáticos y sin gravedad): fueron soltados dentro de una zona juzgados no aceptados. Con el acopio como única zona a mano, es un objeto ajeno a COMP-02 en el acopio (los residuos picados de COMP-04 están a 0,1 m de su borde y son lo más cercano al teletransporte frente al acopio), y la clave por defecto decía «Eso va al área de acopio, no ahí» con el objeto dentro.
- `DropCondition.Judge`: un objeto que no es del paso soltado en una zona del paso se ignora aunque haya `defaultErrorKey` (claveFuera); `ReturnToOrigin` lo devuelve igual porque la zona no lo acepta. Un material del paso en otra zona sigue siendo el error.
- Tolerancia e imán en el acopio (`colocacion.json`, solo la zona): huella de 1,6 × 1,6 a 2,4 × 2,4 (0,4 m más por lado) e `imantar: true`. `SnapZone.keepHorizontalOffset`: en una zona imantada de un metro o más por lado (un área; el importador lo enciende), el objeto baja al suelo donde se soltó, recortado a la huella y derecho, en vez de apilarse en el centro; el centro de la pila (0,4 m) sigue imantando exacto.
- `ColocacionImporter`: el trigger de una `superficie` cubre al menos de 0,2 a 1,0 m sobre la base del objeto (`RaiseScrubVolume`); el montón de COMP-03 ya no pide agacharse hasta el suelo.
- Tests: 3 PlayMode en `AcopioDropPlayTests` (objeto ajeno dentro del acopio, soltar fuera de toda zona y en otra zona, tolerancia con imán de área) y aserciones nuevas en `ExperienciaCompostajeTests` (acopio 2,4 × 2,4 imantado como área, montón de 0,2 a 1,0 m) (251 / 74).

### Añadido — entorno de la muestra de compostaje con el arte del equipo (2026-10-25)
- `Samples~/ExperienciaCompostaje/Entorno/` (7 FBX de la planta de concreto y 2 texturas, 4,9 MB; la del concreto bajada de 2K a 1K) y `EntornoBuilder`: «Preparar escena» pone la raíz `Entorno` (suelo de tierra de 24 × 22 m, losa, muros, columnas, techo de calamina, tanque y contenedor como telón a la derecha de la pila, a x glTF > 8,4, y un sol cálido sin sombras); convención en `autoria.md` §4.1. Un test EditMode (252).

### Arte — la muestra de compostaje usa los primeros modelos del equipo (2026-10-25)
- `palo` y `agua` dejan de ser cubos: `Samples~/ExperienciaCompostaje/Modelos/` trae `Palo.prefab` (el cuartón del artista a 0,05 × 2,0 m) y `BaldeAgua.prefab` (su tanque de agua a Ø 0,30 × 0,43 m), con materiales URP Lit propios; los otros 20 objetos siguen como marcador porque no hay modelo que se les parezca (`arte-compostaje.md` §7). «Preparar las muestras» copia esa carpeta a `Assets/Experiencias/<experiencia>/Modelos/` antes de la colocación (`SamplePreparer.CopyModels`). Un test EditMode comprueba nombres, `.meta`, ausencia de collider y URP Lit (252).

### Corregido — el HUD se leía lejos y chico en el Quest 3 (2026-10-25, segunda tanda en el casco)
- «La interfaz está muy lejos de mi vista, no veo bien»: con 16–24 px el cuerpo del subtítulo medía 1–1,4 cm a 1,6 m (medio grado). Ahora `HudPlacement.DefaultDistance` es 1,3 m y los textos del HUD miden del doble para arriba (cuerpo 36–50 px, quién 36, botón 44, panel de desarrollo 20–30); el panel de subtítulos, el botón Comenzar y el panel de desarrollo crecen para que quepan. «Preparar escena» pasa a los nuevos tamaños y distancia un HUD que traiga los del 17 o los del mediodía del 25 (`SubtitleHudBuilder`).

### URP para el Quest (2026-10-25, corrección 7 de la auditoría del visor)
- `Host~/Assets/Settings/URP-Asset.asset`: HDR apagado, MSAA 4×, sombras de la luz principal apagadas (las adicionales ya lo estaban); `URP-Renderer.asset`: Intermediate Texture en «Auto». Un solo URP Asset para todas las plataformas (razón en `platform-support.md`).
- `VisorUrpCheck` (`Editor/Visor`): la build del visor (`VisorBuilds.Build` y `VisorPreBuild`) se detiene, con el motivo y el asset, si el URP vuelve a tener HDR, MSAA menor de 4×, sombras o la textura intermedia en «Always». Tres tests EditMode (245); `XRLabs.Visor.Editor` referencia ahora `Unity.RenderPipelines.Universal.Runtime`.
- Los FPS en el visor con este URP siguen sin medirse.

### Corregido — la telemetría llega al cliente del API desde la escena preparada (2026-10-25)
- «Preparar escena» pone la raíz `[ApiTelemetry]` con el `ApiTelemetryBridge` (solo, no en `[Session]` ni en `[Platform]`: el bridge hace `DontDestroyOnLoad` de su objeto y destruye entero el duplicado del segundo intento). Sin él, `SessionManager` cerraba el intento «localmente» y no llegaban ni el inicio, ni los errores de los pasos, ni el cierre (`telemetria-extremo-a-extremo.md`, riesgo 1). Idempotente; un bridge puesto a mano en otro objeto raíz se respeta.
- `ApiTelemetryBridge` decide el transporte: con `useMockData` encendido o sin `ApiClient` (escena abierta en el Editor sin pasar por el `Menu`) todo va a `MockApiClient`, sin red y sin excepciones; con el mock apagado, al API real como siempre. Antes, en mock, la sesión se abría por fuera del bridge y el activity log salía por la red hacia el `baseUrl`; sin `ApiClient`, `NullReferenceException`. Una sesión mock no escribe ni reenvía la cola en disco. `SessionManager` abre y cierra siempre por el bridge.
- `MockApiClient`: `LogActivity` (`POST /activity-log`) y el evento `TelemetryReceived` con cada llamada de telemetría que recibe (método, ruta y cuerpo).
- Tests: 2 EditMode en `ScenePreparerTests` y 2 PlayMode en `SessionTelemetryMockTests` (COMP-01 con un error contra el mock; nunca contra un API) (URP + telemetría: 247 / 68).

### Corregido (2026-10-17, tras el primer recorrido de la muestra en el Mac)
- «Preparar escena» ahora pone `[HUD]`: canvas de pantalla con el `SubtitlePanel` del paquete, Intro salta la frase (`Editor/Authoring/SubtitleHudBuilder.cs`). Sin voces horneadas y sin panel, la escena preparada no mostraba nada de lo que el coach decía. Dos tests más en `ScenePreparerTests` (EditMode 197).
- El mismo `[HUD]` trae el botón **Comenzar** de los pasos `manual` (`ManualStepButton`, nuevo en `Runtime/Simulations/UI`; `ManualKeyStepCondition.Complete()`) y un `EventSystem`: el storyboard dice «pulsa Comenzar» y en modo plano solo existía la barra espaciadora. El botón aparece cuando el paso ya escucha y se oculta con su `CanvasGroup` (la primera versión apagaba su objeto y no aparecía nunca en Play). El subtítulo se autoajusta para no salirse del cuadro. Tres tests EditMode (200) y uno PlayMode con el StepSystem real (59).

- La escena preparada sin modelos se entiende sola: los marcadores llevan su nombre del guion flotando (`FaceCamera`, nuevo en `Runtime/Core`), las zonas `soltar` llevan un recuadro en el suelo y su nombre, y un `llevar` sin `activos` resalta también sus zonas. Lo pidió el recorrido del dueño («no sé qué hacer en este paso»). Tres tests EditMode (203).

### Añadido y corregido — tarde del 2026-10-18 (preparando el día 1 en el visor)
- Las librerías importadas de un guion hornean sus voces en `<experiencia>/Voces/<es|en>/`, junto al resto de la experiencia; las demás siguen en `VoiceSettings.outputRoot`. La build del visor solo permite la voz incompleta si falta alguna voz, con la cuenta en el registro. Test en `VoiceBakerTests` (EditMode 227).
- `Tools~/medir_visor.sh quest3|galaxyxr`: instala el APK con el `adb` de Unity, abre la app, guarda el logcat (completo y filtrado) en `Host~/Logs/` y mide los cuadros por segundo 30 s (`VrApi FPS=`, SurfaceFlinger, gfxinfo) con un resumen; autoprueba de los lectores en `Tools~/check.sh`.
- En modo mock, el menú del curso ofrece también las experiencias del `ExperienceSceneMap` del anfitrión (`MockExperienceCatalog` en `Runtime/UI`, `MockApiClient.ExtraExperiencesProvider` y `BuildGroupExperiences`): PIN del mock → curso → «Experiencia compostaje» carga la muestra, también en el visor. Sin mapa, el menú de siempre. Tres tests en `ExperienceSceneMapTests` (EditMode 230).
- Muestra de compostaje, COMP-07: soltar la cubierta sobre la pila daba acierto y error a la vez (la zona `cubierta` contiene a `capas` y `centro`, cada zona emite su soltado y `claveFuera` contaba los no aceptados como error). Ahora el error `descubierta` es una regla del acopio. Test `Comp07_DropOnTheOverlap_CountsWithoutError_AndTheAcopioIsTheError` (EditMode 231).
- `HologramCoachTests.SetVoice_ErrorTintsOrangeAndBack` espera por condición: con la máquina cargada, un cuadro de más de 0,5 s dejaba la voz vieja y el test caía.

### Corregido tras la primera prueba en el Quest 3 (2026-10-25)
- «Preparar escena» pone en el `[HUD]` un **panel de desarrollo** (`DevStepPanel`, solo en Development Build y en el Editor): paso en curso, siguiente y fase; botones Saltar frase, Completar paso, Anterior y Siguiente; en el mando, **B** completa el paso y **Y** salta la frase. Textos del HUD más pequeños para el visor (subtítulo 16–24, Comenzar 28, canvas de 1,1 m); los HUD ya preparados con los tamaños viejos se adaptan al volver a preparar.
- Etiquetas de los marcadores a 1,0 (zonas 0,8), en dos líneas de 1,4 m y más altas: antes se veían «grandes y pegadas».
- Los `hotspot` importados ya no se disparan al pasar el rayo (`triggerOnTouch` apagado): en el visor exigen seleccionar (botón lateral), en pantalla el clic sigue igual.
- `SnapZone` imanta solo al soltar, solo lo aceptado y moviendo el objeto entero (antes imantaba cualquier collider que entrara y movía solo el marcador hijo).
- Muestra: la zona de acopio sube a 1,6 m (un saco soltado de pie quedaba fuera) y la frase de cierre ya dice «ocho pantallas».
- Tests: 6 EditMode y 6 PlayMode nuevos (237 / 66).
- El menú del mock ofrece primero las experiencias del anfitrión, la más nueva arriba (Compostaje antes que la cero), y la demostración solo si el mapa no tiene su id; la experiencia cero lleva la nota «(solo pantalla: elige con teclado)»: en el visor su paso p3 elige con teclas y el dueño se quedó atascado ahí. Cinco tests EditMode (242).
- Colocación de la muestra rehecha con la disposición del simulador web como referencia (D32; `referencias-web-compostaje.md`): el coach se para al lado de la tarea y no a la espalda, los recuadros de teletransporte salen de las zonas de soltar (soltar junto a los pies ya no cuenta como error), el acopio queda a 3 m de la pila, todo lo de COMP-03 a 07 delante de la persona y las zonas A–D a 3 m entre sí, de cara al inicio. Solo cambian posiciones, giros y tamaños; ids, `acepta` y `alto` iguales.
- «Preparar escena» y su test tratan como libre el GUID del `ApiSettings` del Menu cuando la base de assets lo mapea a una ruta que ya no existe (quedaba inconcluso un test del sello tras cada build del visor).
- **Frotar con la mano en el visor** (COMP-03 no avanzaba nunca: los mandos del rig no tenían collider y la `ScrubSurface` solo mide lo que se mueve dentro de su trigger). Cada `<Lado>_NearFarInteractor` del rig XRI lleva un hijo `HandTrigger`: esfera trigger de 5 cm con `Rigidbody` cinemático sin gravedad, en la capa `Ignore Raycast`; la superficie la cuenta como mano (`ScrubSurface.IsValidMover`, ahora público). `XRLabsRig.prefab` regenerado en batch con el constructor (`XriRigBuilder.RebuildFromCommandLine`, menú `Tools/XRLabs/Regenerar rig XRI`); un rig viejo ya no pasa por «al día» y el Menu XRI lo rehace. El ratón en pantalla no cambia (`DriverScrub`).
- **Seguro del cambio de escena Menu ↔ experiencia** (auditoría del visor, punto 8): `RigSceneGuard` (nuevo, `Runtime/MenuXRI`) en la raíz del rig vuelve a encender las acciones, a registrar la UI de los `NearFarInteractor` en el EventSystem que queda y a enlazar al gestor del rig los interactuables huérfanos cuando otra escena se descarga después de que el rig arranque; interactores y grupos del rig van enlazados a su propio `XRInteractionManager`. Medido en el Editor: en una carga Single la escena vieja se apaga antes del `Awake` de la nueva, así que con `SceneTransitionManager` hay un solo EventSystem, las acciones quedan encendidas y el guard no tiene nada que reponer. Dos rigs vivos a la vez no están soportados (XRI busca el `XROrigin` con un buscador global).
- Tests: 3 EditMode (`XriRigPrefabTests`) y 3 PlayMode (`RigVisorPlayTests`: frotar con cada mano del rig real, Menu → experiencia → Menu con cargas Single, y el guard tras una descarga tardía) nuevos (245 / 69).

### Añadido — semana 2, día 2: COMP-03, 04, 06 y 07 de la muestra de compostaje (2026-10-18)
- «Preparar escena» pone `[Debug]` con el panel de depuración de siempre (`SimDebugHUD` + `SimulationDebugger`: F1 dónde estoy y qué sigue, F2 completar el paso, F4 saltar, F7 registro), pedido por el dueño para adelantar sin esperar las frases. Test en `ScenePreparerTests` (EditMode 226).
- `Samples~/ExperienciaCompostaje/` pasa de cuatro pantallas a ocho (COMP-00 a COMP-07): picar y mezclar (`frotar`), la pila por capas en un ciclo (cuatro `llevar` con reglas de orden), la prueba del puño (`mantener` + `elegir`) y cubrir la pila (`llevar` con `claveFuera`). 13 pasos, 60 frases, 22 objetos, 8 zonas. Adaptaciones y entradas del contrato 0.3 en `a5-experiencia-compostaje.md` §8. Tests: orden de los trece pasos, condiciones de la semana 2, veinte frases literales (EditMode 225).

### Añadido — el lote del visor (2026-10-17, rama `feature/visor`; `Documentation~/platform-support.md`)
- «Preparar escena» pone `[Platform]` con `PlatformBootstrapper`: el rig XRI del paquete (D23) apagado en edición como `xrRigRoot` y la `Main Camera` plana como `flatRigRoot`; el coach sigue a `Camera.main`. La escena preparada sirve en pantalla y en el visor sin tocarla.
- `HudPlacement` (`Runtime/Platform`): el `[HUD]` pasa al mundo cuando hay dispositivo (1,6 m delante de la cámara, sigue la cabeza); el canvas lleva `TrackedDeviceGraphicRaycaster` y el EventSystem `XRUIInputModule`.
- Capa OpenXR del anfitrión (D27): `com.unity.xr.management` 4.7.0, `com.unity.xr.openxr` 1.18.0, `com.unity.xr.androidxr-openxr` 1.4.1; el paquete declara management y openxr.
- `Editor/Visor` (`XRLabs.Visor.Editor`): `VisorBuildPlan` (escenas, características de OpenXR por nombre, SDK y salida por visor), `VisorOpenXr` (loader y características), `VisorBuilds` (`Tools/XRLabs/Visor/…`, batch con `Tools~/build_visor.sh`; build de investigación: Development Build con la voz incompleta permitida y las muestras preparadas), `VisorPreBuild`. `SamplePreparer` (`Tools/XRLabs/Preparar las muestras del paquete`). Tests EditMode: 2 + 1 + 4 (224); PlayMode: `HudPlacementTests` (60).
- Primeras builds en la estación (2026-10-17, sin visor conectado): `Builds/Quest3/xrlabs-host-quest3.apk` (API 32, Meta Quest Support y perfiles Touch, categoría VR de Oculus) y `Builds/GalaxyXR/xrlabs-host-galaxyxr.apk` (API 34, Android XR Support, Hand Interaction, `android.software.xr.api.openxr`), 54 MB cada uno, con el Menu XRI y las dos muestras. Los cuatro «Shader error» de cada build son los shaders URP del holograma en un anfitrión del pipeline integrado (el coach magenta): resuelto con D31, URP 17.3.0 en `Host~` (`Assets/Settings/URP-Asset.asset`).

### Añadido — el `Menu` sin el SDK de Meta y la teleportación (lotes X1 y X2, 2026-10-10; fusionados en `feature/visor` el 2026-10-17; D23 pendiente de ratificar)
- **El `Menu` sin el SDK de Meta (lote X1, D23 provisional; `Documentation~/menu-xri.md`).** `Runtime/MenuXRI/Menu.unity`, una segunda escena con el mismo nombre que `Tools/XRLabs/Generar Menu XRI` genera desde `Runtime/Menu/Menu.unity`: sin el rig ni la interacción de Meta, con el rig XRI del paquete (`Runtime/MenuXRI/XRLabsRig.prefab`: `XROrigin`, cámara con `TrackedPoseDriver`, dos `NearFarInteractor`, acciones propias), `XRUIInputModule` en el EventSystem, `TrackedDeviceGraphicRaycaster` en los canvas y `PlatformBootstrapper` con rig plano para el Editor. `Menu.unity` y los prefabs de los paneles no cambian; un consumidor pone una sola de las dos escenas en Build Settings y «Preparar escena» elige según tenga el SDK de Meta. Tests EditMode en `Tests/Editor/MenuXRI` (8) y en `ScenePreparerTests` (2).
- **Teleportación (lote X2; `Documentation~/menu-xri.md` §9).** El rig trae `TeleportationProvider` con `LocomotionMediator`, y por mano un rayo de teleportación (`XRRayInteractor` en proyectil, capa `Teleport`, bit 31) en un `XRInteractionGroup` detrás del `NearFarInteractor`, encendido solo durante `Teleport Mode` por el `TeleportModeActivator` nuevo (`Runtime/MenuXRI`, assembly `XRLabs.MenuXRI`). Las zonas `teleport` de la colocación son losas sólidas con `TeleportationArea`; las zonas `soltar` siguen siendo triggers con su recuadro y su nombre. Tests EditMode: +5.

### Añadido (lote A5, 2026-10-17)
- Muestra `Samples~/ExperienciaCompostaje/`: las pantallas COMP-00, 01, 02 y 05 del storyboard del manual INIA 2025 escritas en el contrato 0.2 (`manual`, `elegir` por objeto, `llevar` ×2 con zonas `soltar`), con 28 frases en español, 13 objetos y la colocación provisional. Diseño y huecos del contrato en `Documentation~/a5-experiencia-compostaje.md`. Seis tests EditMode (`ExperienciaCompostajeTests`).

Destino: 0.7.0 (lo estampa el dueño con `python3 Tools~/stamp_version.py 0.7.0` antes de etiquetar). Diseño del lote:
`Documentation~/ids-de-texto.md`.

### Added — Contrato 0.2: el guion expone las interacciones que el runtime ya tenía (lotes A3 y A4; D24, pendiente de ratificar)
Diseño: `Documentation~/contrato-0.2.md`. Nada de 0.1 cambia de significado; los validadores aceptan 0.1 y 0.2 (D8).

- Tipos de paso `llevar` (`DropCondition`: objetos, zonas, cantidad, reglas de error por objeto y zona, clave para otra zona),
  `frotar` (`ScrubCondition`), `mantener` (`HoldCondition`) y `apuntar` (`AimCondition`, con herramienta y objetivos equivocados).
  Estaban escritos y probados desde v0.6.0 y funcionaban en modo plano; 0.1 los dejó fuera por creer que necesitaban el visor.
- `elegir` por objeto: `condicion.opciones[]` (hotspot, resultado correcta/error/aviso, clave) genera la condición nueva
  `ChoiceByTargetCondition` (`Runtime/Interactions/Conditions`), porque `KeyChoiceStepCondition` es por teclado y en un visor no hay.
- Tipos de objeto `agarrable` (`GrabbableItem` + `ReturnToOrigin`), `fuente` (`SourcePile`), `superficie` (`ScrubSurface`),
  `boton` (`HoldButton`) y `herramienta` (`AimTool` + `ReturnToOrigin`), con los campos opcionales `herramienta`, `recorrido`,
  `segundos`, `herramientas`; el importador de colocación crea y quita los componentes al cambiar de tipo.
- Zonas `soltar` en la colocación (`DropZone` o, con `imantar`, `SnapZone`; `acepta`, `alto`), con referencia cruzada desde los
  pasos `llevar`. Esquemas `xrlabs.guion/0.2` y `xrlabs.colocacion/0.2`.
- «Preparar escena» añade `[Coach]`: el holograma (`HologramCoach.prefab`), `CoachDirector` enlazado al `StepSystem`, a la
  presencia y a la cámara, y `StepTargetHighlighter`; el coach nace a 2 m delante de la cámara (lote A4).
- Tests: EditMode 151 → 189 (`GuionValidatorTests` +15, `GuionImporterTests` +6, `ColocacionValidatorTests` +4,
  `ColocacionImporterTests` +11, `ScenePreparerTests` +2); PlayMode 55 → 58 (`ChoiceByTargetConditionTests`).

### Changed — Networking con ids de texto (contrato XR del backend nuevo; D10, pendiente de ratificar)
Rompe el código de un consumidor que use estos ids como `int` (ni compostajevr ni Fallas de Brocas lo hacen); las
escenas y los assets de los consumidores no se tocan (D8).

- Ids `int` → `string`: `XrUserData.OrgId/RoleId` y `AuthenticatedUser.OrgId/RoleId` (eran `int?`), `UserData.Id`,
  `RoleData.Id`, `OrganizationData.Id`, `GroupData.Id`, `CourseData.Id`, `SpecialtyData.Id`, `DepartmentData.Id`,
  `ExperienceData.Id`, `GroupExperienceData.GroupId/ExperienceId`, `SessionStartRequest.GroupId`,
  `SessionStartResponse.ExperienceId`, `ScoreEvent.GroupId/ExperienceId` y `ActivityEvent.OrgId/EntityId`.
- Firmas con ids de texto: `DataService.FetchGroupExperiences(string groupId, …)` y `CheckAddressableVersion(string)`,
  `ApiTelemetryBridge.StartSession(string experienceId, string groupId, …)` y sus propiedades `ExperienceId`/`GroupId`,
  `MockApiClient.GetGroupExperiences(string, …)` y `StartSession(string, string, …)`, y
  `ExperienceSceneMap.GetSceneName(string)`.
- `AddressableInfo` en camelCase (`bundleUrl`, `version`, `sizeMb`, `catalogUrl`), como responde el backend.
- `DataService` lee `GET /courses/{id}` en `CourseData` y `GET /group-experiences` en `GroupExperienceData` (tenían los
  mismos nombres JSON que sus copias privadas, que desaparecen) y compone las rutas con `Uri.EscapeDataString`.
- `ApiTelemetryBridge.StartSession` sin `experienceId` no llama al API: devuelve `false` con un aviso.
- Modo mock: ids de texto con forma de cuid (constantes `MockApiClient.Demo*Id`) y estados en MAYÚSCULAS, como el
  backend; la experiencia sigue siendo `"10"` para que los `ExperienceSceneMap` existentes la resuelvan.

### Added
- `ExperienceSceneMap.Entry.experienceKey` (opcional): la escena se busca por la clave de texto y, si ninguna
  coincide, por el `experienceId` heredado convertido a texto; un asset de v0.5.1 resuelve igual sin tocarlo.
- `ApiStatus`: las constantes de estado y `ApiStatus.Is`, que compara sin distinguir mayúsculas.
- `ExperienceData.Attempts` y `GroupExperienceData.Attempts` leen `attempts` y, si falta, la grafía `attemps` que
  también envía el backend.
- Tests EditMode en `Tests/Editor/Networking` (18): respuestas reales del backend capturadas el 2026-10-09
  (`Tests/Editor/Fixtures/xr`), los cuerpos que el backend aceptó, `ExperienceSceneMap` (clave, `int` heredado con un
  asset de v0.5.1, precedencia y desconocido) y los estados; y en `Tests/Editor/Menu` (2), el módulo de entrada del Menu.
- `XRLabs.UI` referencia `Unity.InputSystem` (el paquete ya dependía de `com.unity.inputsystem`).
- `SessionManager.navigateOnEnd` (serializada, encendida por defecto): apagada, `EndSession` cierra la sesión en el
  backend y no carga ninguna escena, para experiencias con su propio cierre (el informe final de compostajevr);
  `SessionManager.SessionEnded` y el evento `OnSessionEnded(float)` avisan del cierre. Diseño:
  `Documentation~/sesion-api-en-consumidor.md`. Tests EditMode en `Tests/Editor/Menu` (3).
- **Autoría desde ficheros (lote A1, D19–D22; diseño en `Documentation~/autoria.md`).** La experiencia se describe en dos
  ficheros, `guion.json` (`xrlabs.guion/0.1`: pasos, condiciones, frases por idioma, objetos, secciones; sin nada de Unity)
  y `colocacion.json` (`xrlabs.colocacion/0.1`: inicio, anclas del coach, objetos y zonas en los ejes del GLB), con sus
  JSON Schema en `Schema/`. La ventana `Tools/XRLabs/Autoría` (`Editor/Authoring`, assembly `XRLabs.Authoring.Editor`)
  valida e importa de forma idempotente: `StepDefinition`, `StepCondition`, `SimulationSequence` y `LineLibrary` por
  ruta estable en `Assets/Experiencias/<id>/` (conserva `clip` y `bakeHash` al reimportar), la entrada del
  `ExperienceSceneMap`, los tags que piden los pasos `girar`, y en la escena abierta los objetos `Inicio`, `Ancla_<id>`,
  `Objeto_<id>` (con `TouchableHotspot` si es hotspot, y el prefab de `Modelos/` o un marcador) y `Zona_<id>`.
  Conversión glTF → Unity provisional en `GltfToUnity` hasta el fixture de los modeladores; lector mínimo de GLB (`GlbJson`).
  Muestra: `Samples~/ExperienciaCero/`. Tests EditMode en `Tests/Editor/Authoring` (66).
- `TouchableHotspotCondition` (`Runtime/Interactions/Conditions`): la condición que escucha a un `TouchableHotspot` por su
  `interactionId`, y que un paso `tocar` pueda completarse igual con el rayo del visor y con el clic del driver plano
  (hasta ahora solo `HotspotTouchCondition`, que depende del trigger XR de `HotspotMarker`). Menú
  `XR Simulation/Conditions/Touchable Hotspot`. Tests PlayMode en `Tests/Runtime` (2).
- **«Preparar escena» y voces de un clic (lote A2; `Documentation~/autoria.md` §10).** En `Tools/XRLabs/Autoría`, «Preparar
  escena» crea o abre la escena del guion en `Assets/Experiencias/<id>/Escenas/`, deja `[Simulation]` con los siete
  sistemas, la secuencia y la biblioteca asignadas, `[Session]` (`navigateOnEnd` según la clave nueva y opcional
  `experiencia.cierrePropio`), `[Colocacion]`, la cámara plana con `FlatInteractionDriver`, el `ApiSettings` del `Menu`
  con mock si falta, y la escena en Build Settings detrás de `Menu`; todo idempotente (`ScenePreparer`). «Generar voces
  que faltan (N)» hornea desde la ventana con el proveedor configurado, y sin clave lo dice en claro sin tocar la red
  (`VoiceBakeRunner`, sobre `Editor/Voice`, D5). Tests EditMode en `Tests/Editor/Authoring` (23).
- **La cola de eventos en disco y el motivo del cierre (lote N3; `Documentation~/sesion-api-en-consumidor.md`).**
  `PendingEventStore` guarda los `ScoreEvent` pendientes en `persistentDataPath/Telemetry/pending/` cuando un envío
  falla, al pausar y al salir, y `ApiTelemetryBridge` los reenvía al abrir la siguiente sesión (opción serializada
  `persistPendingEvents`, encendida; apagada = comportamiento anterior). `SessionCompleteRequest.EndReason` (`endReason`,
  solo se envía cuando no es null) y `SessionManager.EndSession(float, string endReason = null)`. Tests EditMode en
  `Tests/Editor/Networking` (6). `POST /score-events/batch` sigue fuera: el cuerpo del backend no está a la vista en la estación.

### Fixed
- `POST /xr-auth/validate-pin` ya no falla al deserializar con el backend nuevo (`orgId` y `roleId` llegan como cuid).
- Las comparaciones de estado no distinguen mayúsculas: `DataService` (membresías y grupos activos, experiencias
  completadas) y `ExperienceCardView`, que mostraba «Pendiente» para un `COMPLETED` del backend.
- La escena `Menu` en un proyecto sin el SDK de Meta: su EventSystem se quedaba sin ningún módulo de entrada y el PIN
  no se podía teclear ni con el ratón. `UIFlowController` agrega uno (`InputSystemUIInputModule`, o
  `StandaloneInputModule` si el proyecto solo usa el Input Manager viejo) cuando no hay ninguno activo: ratón y teclado
  en el Editor y en pantalla plana. Con el SDK de Meta no cambia nada; el visor sin él sigue necesitando un rig XR.

## [0.6.0] — 2026-10-08

### Added — Coach: frases, errores con reintento y presencia
Todo es aditivo: un StepDefinition sin frases del coach se comporta igual que en v0.5.

- **Frases por ID e idioma**: `LineLibrary` (texto ES/EN, texto hablado para TTS, clip, hash de horneado,
  diccionario de pronunciación), `LineRef` con selector en el inspector, `LanguageService` (cambio en caliente).
- **Voz**: `VOManager.Say/SayAsync/Skip` — una sola voz a la vez, duración estimada si falta el clip
  (el subtítulo siempre aparece), eventos `LineStarted/LineEnded`, `Amplitude` y `GetSpectrum` para el avatar.
- **Errores y avisos**: `StepCondition.ReportError/ReportWarning/Rearm`, `StepSystem.ReportError/ReportWarning`
  para validación desde la escena. Error → corrección bloqueante (`errorLines` / `defaultErrorLine`) y se
  repite el paso; aviso → frase no bloqueante una vez por paso.
- **Pista dinámica**: `StepCondition.CurrentHintLine` (gana sobre `hintLine`); `LineLibrary.InvalidateCache()`.
- **Progreso**: `ReportInfo` (condición y StepSystem) + evento `StepInfo`; `StepDefinition.repeatInstructionAfterError`.
- **StepDefinition**: `introLines` (bloqueantes), `instructionLine` (no bloqueante), `hintLine`, `successLine`,
  `countsAsTask` + `taskLabel`, `coachAnchorId`, `pointAtTargetId`, `activeTargetIds`.
- **StepSystem**: fases `Intro/Active/Correcting/Confirming`, eventos `StepFailed`, `StepWarned`, `TaskCompleted`,
  `JumpedToStep`, `PhaseChanged`; `JumpToStep/JumpToSection` públicos; `Stats` (`SessionStats`).
- **Puntaje** `ScoringRule.TasksErrorsHints`: precisión − 2 × ayudas, nota A/B/C/D. `TimeBased` sigue por defecto.
- `HintSystem.Paused` y `HintShown`; `FeedbackSystem` real (SFX, vibración vía `IHapticsProvider`, partículas).
- `StepEventBindings` (efectos de escena por paso) y `StepEndStates` (saltar capítulos).
- `SceneTargetRegistry` + `SceneTarget`; los `InteractableBase` se registran solos por `InteractionId`.
- `SubtitlePanel` (máquina de escribir, modo error, saltar) y `StepChecklistBinder`.
- `XRHapticsProvider` (XRI).
- Nuevo assembly **XRLabs.Coach**: `CoachPresence` (abstracta), `CoachAnchor`, `CoachDirector` (anclas por paso,
  modo seguir, señalar), `CoachPlacement` (suelo, espacio libre, línea de vista, NavMesh opcional).
- `StepSignalEvent` en telemetría local y API.
- **`HologramCoach`** (`Runtime/Coach/Hologram`): coach v1 como proyector holográfico — base con lente, cono de luz,
  disco con retrato (escaneo, parpadeo, borde reactivo a la voz), anillo, onda circular de 128 puntos desde
  `VOManager.GetSpectrum`, placa con nombre (TMP), modo error (turquesa → naranja), rayo punteado `PointAt`,
  `Appear/Disappear`. Shaders URP `XRLabs/HoloCone`, `HoloDisc`, `HoloDots`, `HoloGlow` (Single Pass Instanced + GPU instancing).
- `Tools → XRLabs → Create Hologram Coach Prefab` y prefab `HologramCoach.prefab`; `Setup Coach Demo` ahora coloca el
  holograma, un `CoachDirector`, un `CoachAnchor` (`demo.anchor`) y un objeto señalado (`demo.target`).
- `XRLabs.Coach` ahora referencia `Unity.TextMeshPro`; `XRLabs.Editor` referencia `XRLabs.Coach`.
- Tests PlayMode: `HologramCoachTests` y `CoachDirectorTests` (modo seguir y ancla).
- `Tools → XRLabs → Setup Coach Demo` y tests PlayMode (`Tests/Runtime`, agregar `"testables": ["com.xrlabs.core"]`).
- **Voz horneada en el editor** (`Editor/Voice`, assembly editor-only `XRLabs.Coach.Editor`; no toca el runtime ni agrega
  claves o red a los builds): asset `VoiceSettings` (proveedor ElevenLabs/Fish Audio, modelo, voz por idioma, ajustes,
  semilla, carpeta de salida, concurrencia), claves de API solo en `EditorPrefs` o variables de entorno, `ITtsProvider`
  con `ElevenLabsProvider` y `FishAudioProvider` (errores 401/402/429/503 con mensaje claro, reintento con espera
  exponencial), `VoiceBaker` (hash SHA-256, salta lo que no cambió, importa el clip como mono/Vorbis, asigna clip y
  `bakeHash`, limpia huérfanos con confirmación, concurrencia limitada, cancelable, resumen), inspector de `LineLibrary`
  con "Generar faltantes", "Regenerar todo", estado por frase/idioma, generar/regenerar y ▶ escuchar, y
  `VoiceBuildValidator` que falla el build si hay voz sin generar. Guía: "Generar la voz" en `Documentation~/coach.md`.
- Tests EditMode (`Tests/Editor`) del horneado y de los proveedores, sin red.

### Added — Interacciones de acción (v0.6)
Principio: el interactuable informa, la condición juzga, el StepDefinition decide qué se dice.

- `InteractableRegistry` (id → `InteractableBase`); `InteractableBase` suma `Deactivated`, `IsActivated` y `DriverDeactivate()`.
- `DropZone` (trigger, `Dropped`, resaltado) y `ReturnToOrigin` (vuelve animado si se suelta fuera de zona).
  `SnapZone` ahora hereda de `DropZone` y mantiene su comportamiento.
- `SourcePile` + `CarriedItem` (carry con `SourceId`), `AimTool` (segundos por objetivo), `ScrubSurface`
  (recorrido normalizado 0–1) y `HoldButton` (valor 0–1 al mantener).
- Condiciones: `DropCondition` (reglas de error ordenadas, primera que coincide gana), `AimCondition`,
  `ScrubCondition`, `HoldCondition`. Todas conservan el progreso parcial en `Rearm`.
- `FlatInteractionDriver`: arrastrar `GrabbableItem`/herramientas sobre un plano, soltar en `DropZone`,
  mantener `HoldButton`/`AimTool`, frotar `ScrubSurface`; `HandlePointer` público para pruebas.
- `StepTargetHighlighter`: anillo pulsante bajo los `activeTargetIds` del paso, crece 15 % con la pista.
- Playground con un ejemplar de cada componente nuevo; tests PlayMode de zonas, condiciones, retorno, pila,
  frotar, mantener, apuntar, modo plano e integración con el StepSystem.

### Fixed
- `HintSystem` ya no lanza NullReferenceException si no hay `FeedbackSystem` en escena.

## [0.5.0] — 2026-07-07

### Added — Layout tablet: dock de UI + viewport 3D
- `FlatScreenLayout`: reparte la pantalla en dock de UI (izquierda, fracción configurable)
  y viewport 3D (derecha, vía Camera.rect). Tres slots verticales (Top/Middle/Bottom).
- `CanvasPlatformAdapter` rediseñado: modos DockTop/DockMiddle/DockBottom (re-parenta el
  panel VR escalado al slot — conserva layout interno y show/hide), ScreenSpaceFull y
  KeepWorldSpace (labels 3D).
- `FlatInteractionDriver`: los clicks sobre el dock ya no raycastean al 3D (guard de viewport).

## [0.4.0] — 2026-07-07

### Added — Fundación multi-dispositivo (modo plano)
- `PlatformDetector` (define XRLABS_FLAT o detección runtime de device XR) y
  `PlatformBootstrapper` (activa el rig XR o flat por escena).
- `OrbitCameraController`: cámara flat que orbita el punto de interés
  (drag derecho/1 dedo) y hace zoom (scroll/pinch).
- `FlatInteractionDriver`: mouse/touch → eventos de InteractableBase
  (tap=touch/activate, drag=rotar RotatableItem). La simulación no distingue VR de flat.
- `CanvasPlatformAdapter`: WorldSpace → ScreenSpaceCamera en flat.
- InteractableBase expone API Driver* para fuentes no-XRI; TouchableHotspot.Touch()
  y RotatableItem.ApplyExternalRotation() públicos.

## [0.3.0] — 2026-07-07

### Added
- `ExperienceSceneMap` (SO): el mapeo experienceId → escena ya no está hardcodeado en
  `ExperienceListController` — cada proyecto crea el suyo en Resources
  (menú XR Platform → Experience Scene Map). Desbloquea experiencias nuevas.
- Prefabs de UI de evaluación genérica en `Runtime/Simulations/Prefabs/`
  (EvaluationUIRoot, EvaluationFinalResultsPanel, CaseProgressPanel) + sprites.

## [0.2.0] — 2026-07-07

### Added
- **Escena Menu.unity dentro del paquete** (`Runtime/Menu/`): el flujo login por PIN →
  menú → lista de experiencias es transversal a todas las experiencias. Incluye entorno 3D,
  prefabs de paneles Futuristic y lighting. Agregar a Build Settings como escena 0.
- Requisito documentado: el proyecto consumidor provee su `ApiSettings.asset`
  (config por despliegue) — el paquete es read-only.

## [0.1.0] — 2026-07-07

Primera extracción del framework desde `platform-unity` (Sim 1: Fallas en Brocas).

### Added
- StepSystem lineal con StepDefinition/StepCondition (ScriptableObjects), scoring, VO, hints.
- Pipeline de telemetría: TelemetryHub + eventos tipados (QuizAnswerEvent con distractor
  elegido y tiempo de respuesta, HintShownEvent, ExplorationEvent, InteractionEvent),
  canal local (JSON/CSV + crash recovery) y canal API (contrato verificado contra OpenAPI).
- Networking: ApiClient, AuthManager (PIN XR), DataService, mock completo.
- Interacciones: contrato `InteractableBase` agnóstico del SDK + 4 interactables XRI +
  Interaction Playground (Tools → XRLabs).
- UI base: login/menú/experiencias, SessionManager, transiciones de escena sin DOTween.
- 8 assembly definitions con grafo de dependencias forzado por compilador.
- `XRLabs.Platform` con Meta XR SDK opcional (versionDefines).

### Known gaps
- Los paneles de evaluación traen estética hardcodeada (migrarán a Samples~ en 0.2).
- Modo flat (PC/tablet) y Android XR: planificados para 0.2/0.3.
