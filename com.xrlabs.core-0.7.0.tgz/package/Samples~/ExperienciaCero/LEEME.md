# Experiencia cero

Los dos ficheros de la experiencia de prueba del lote A1 (`Documentation~/autoria.md`, sección 7): `guion.json` (cinco pasos, trece frases en `es` y `en`, tres objetos, tres secciones) y `colocacion.json` (inicio, dos anclas, tres objetos, dos zonas de teletransporte) sobre una sala que los modeladores entregarán como `SalaCero.glb` y `SalaCero.fbx` desde el mismo `.blend` (D21).

Son el fixture de los tests del importador (`Tests/Editor/Authoring/`) y lo que el dueño recorre en el Editor: `Tools/XRLabs/Autoría`, importar guion, importar colocación sobre la escena `ExperienciaCero`, asignar la secuencia al `StepSystem`, Play desde `Menu` con el PIN del mock.

Los esquemas que los validan están en `Schema/`. Un editor de texto que entienda JSON Schema (VS Code con `"$schema"` apuntando al fichero) autocompleta las claves.
