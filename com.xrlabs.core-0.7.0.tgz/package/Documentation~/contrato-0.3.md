# Contrato 0.3: estado, tiempo y repetición en el guion

Fecha: 2026-10-18 (Mac), cerrado el 2026-10-25. **Propuesta cerrada para decidir, sin implementar.** Cada sección de 2.1 a 2.10 y la 3 termina en un «Cierre»: campos con tipo y valor por defecto, qué se ve en pantalla y en el visor, qué valida el importador y qué sale por telemetría. Lo que el dueño tiene que decidir está en §9; los cambios de código, en §5 y §6. Complementa `contrato-0.2.md` y `autoria.md`, que siguen valiendo para todo lo que aquí no se cambia. Entradas: `a5-experiencia-compostaje.md` §4 y §8.

## 1. Para qué

Con 0.2 la muestra llega a COMP-07 haciendo trampa en tres sitios: COMP-04 hace un ciclo de cinco, COMP-06 tiene siempre la pila bien regada y COMP-07 no mira el tubo. Las pantallas 08 a 13 del storyboard (`experiencias-web/pruebas/storyboard-compostaje-inia-2025.md`) no se pueden escribir: piden que pase el tiempo, que la pila tenga un estado que cambia y se pregunta, y repetir pasos.

| Pantalla (página del manual) | Lo que pide, en sus notas para desarrollo | Qué le falta a 0.2 |
|---|---|---|
| COMP-08 Temperatura y fases (50–53, 60) | «Bucle semanal con avance de tiempo»; cuatro lecturas y un evento por encima de 70 °C | tiempo, estado, repetición, paso condicional |
| COMP-09 Volteo (61) | «Se repite cada 15 días»; destapar, voltear, prueba del puño, cubrir | repetición, reutilizar COMP-06, «Continuar» que valida |
| COMP-06 Humedad (60) | «Se presentan primero dos casos incorrectos»; «Pantalla reutilizable» | estado que decide la respuesta correcta |
| COMP-10 Madurez (62) | dos muestras, inmadura y madura | estado visible |
| COMP-12 Ensacar (aporte de Coresearch) | «Los intentos fuera de orden disparan su corrección» | bloqueo de objetos |
| COMP-13 Aplicar (63–64) | «Zona válida en anillo bajo la copa», una dosis por planta | geometría mínima, conteo por zona |
| COMP-04 Capas (56–58) | «Ciclo 1 de 5», altura de la pila | repetición con contador, indicadores |
| COMP-02, 03, 05, 07 (55, 56, 58, 59) | función de cada material al colocarlo; «La pila queda bloqueada»; «La cubierta queda bloqueada»; «Validar que el tubo quede descubierto» | reacciones, bloqueos, geometría |
| COMP-00 (48–49) | «Los tres indicadores quedan visibles durante todo el simulador» | indicadores |

Criterio: **nada de lógica general en el guion**. Ni bucles «mientras», ni expresiones. La repetición se desenrolla al importar y el estado es una tabla de valores que los pasos escriben y leen con reglas fijas: el runtime sigue siendo una lista de pasos y el validador lo comprueba todo antes de importar.

## 2. Lo que 0.3 añade al guion

`esquema`: `xrlabs.guion/0.3`. Todas las claves son opcionales (D8).

### 2.1 Estado de la escena

```json
"estado": {
  "humedad":     { "valores": ["bien", "mojada", "seca"], "inicial": "bien" },
  "temperatura": { "inicial": 12 },
  "dia":         { "inicial": 0 }
}
```

Clave de primer nivel. Cada variable es de **texto** (`valores`, lista cerrada) o **numérica** (`inicial` numérico). Los pasos, de cualquier tipo, la escriben con:

| Clave | Cuándo se aplica | Forma |
|---|---|---|
| `alIniciar` | al empezar el paso, antes de la introducción | `{ "humedad": "seca", "temperatura": 62, "dia": { "sumar": 7 } }` |
| `alCompletar` | al cumplirse la condición, antes de la frase de éxito | igual |
| `alError` | tras la corrección de un error, por clave | `{ "sin-volteo": { "olor": "fuerte" } }` |

Y lo leen con `si`, que **salta el paso** si no se cumple al llegar a él: `{ "temperatura": { "mayor": 70 } }`, `{ "semana": [2, 4, 6] }` (cualquiera), `{ "humedad": "mojada" }`; varias variables, todas a la vez. Un paso saltado no suena, no cuenta y descuenta su tarea del total.

Errores: variable sin declarar, valor fuera de `valores`, `sumar`/`mayor`/`menor` en una de texto. Aviso: variable que nadie lee.

**Cierre 2.1**

| Campo | Tipo | Por defecto | Regla |
|---|---|---|---|
| `estado.<var>.valores` | lista de texto, 2 o más, sin repetidos | — | la hace de texto |
| `estado.<var>.inicial` | texto de `valores`, o número | texto: el primero de `valores`; numérica: **obligatorio** | |
| `estado.<var>.min` / `max` | número | sin límite | solo numéricas; `sumar` recorta al rango (temperatura 0–80) |
| `estado.<var>.registrar` | booleano | `false` | manda `state_changed` (abajo) |
| efecto | texto, número o `{ "sumar": n }` | — | `sumar` solo en numéricas |
| `si` | var → valor, lista (cualquiera), `{ "mayor": n }`, `{ "menor": n }` o los dos (entre, exclusivo) | sin `si`: siempre | varias variables: todas |

- Nombres: minúsculas, letras, cifras y guion, como los ids de paso. `dia` y los `contador` de §2.4 los declara el importador; declararlos a mano con otro tipo es error.
- Orden dentro de un paso: `si` (al llegar) → `alIniciar` → introducción → escucha → condición → `alCompletar` → éxito. `alError`: después de la frase de corrección, antes de repetir.
- **Pantalla y visor:** el estado no se ve por sí mismo; se ve por `indicadores` (§2.9) y por `visibleSi` / `posicionSegun` (§2.10). Igual en plano y en el visor.
- **Importador:** el estado inicial va en la `SimulationSequence`; cada `StepDefinition` lleva sus efectos y su guarda ya resueltos (sin texto que interpretar en ejecución).
- **Telemetría** (`POST /activity-log`, `entity: "Step"`, `entityId` = id del paso): `step_skipped` (metadata `motivo: "si"`) por cada paso saltado; `state_changed` (metadata `variable`, `antes`, `valor`) solo para variables con `registrar`; `complete_experience` suma `metadata.estado` con los valores finales (base del informe final).

```json
"estado": { "lugar": { "valores": ["ninguno", "a", "b", "c", "d"], "registrar": true },
            "temperatura": { "inicial": 12, "min": 0, "max": 80 } },
"pasos": [ { "id": "COMP-08.alerta", "tipo": "narracion", "si": { "temperatura": { "mayor": 70 } } } ]
```

### 2.2 Frases que dependen del estado

Un id de frase de un paso puede llevar `{variable}`: `"exito": "COMP-04.ciclo.{ciclo}"`, `"COMP-08.fase.{fase}"`. El runtime lo sustituye antes de decirla; el validador expande cada valor posible (los `valores`, o 1…`repetir` de un contador, §2.4) y exige cada frase. Una numérica que no es contador no vale. Son las **frases por iteración**: la voz está horneada, así que el número va en el id, no en el texto.

En las frases `soloTexto` del HUD, `{variable}` dentro del **texto** muestra su valor: `"ui.ciclo": { "es": "Ciclo {ciclo} de 5", "soloTexto": true }`.

**Cierre 2.2.** Vale en `intro`, `instruccion`, `pista`, `exito` y los valores de `errores`. Números en el texto: enteros sin decimales; si no, uno, con coma (`57,5`). **Pantalla y visor:** el subtítulo y la voz son los de la frase ya sustituida. **Importador:** expande y exige cada id (`COMP-04.ciclo.1` … `.5`); error si falta una, si la variable no existe o si es numérica sin ser contador. **Telemetría:** sin cambios; `hint_shown` lleva el id ya sustituido.

### 2.3 Tiempo simulado: `avanzar`

```json
{ "id": "semana", "tipo": "avanzar", "dias": 7, "etiqueta": "ui.semana",
  "intro": ["COMP-08.instructor"], "alIniciar": { "temperatura": 58 } }
```

`NonInteractive`, sin `condicion`. Al empezar suma `dias` (entero ≥ 1, obligatorio) a `dia` (se declara sola), aplica `alIniciar`, funde a negro 1,5 s con `etiqueta` («Semana {semana}») y dice la introducción.

**Cierre 2.3**

| Campo | Tipo | Por defecto | Regla |
|---|---|---|---|
| `dias` | entero ≥ 1 | — (obligatorio) | suma a `dia` |
| `etiqueta` | id de frase `soloTexto` | sin texto | admite `{variable}` |
| `fundido` | segundos, 0–5 | 1,5 | 0: sin fundido |
| `alIniciar` | efectos (§2.1) | — | se aplica **con la pantalla en negro**: lo que cambia `visibleSi` / `posicionSegun` no se ve saltar |

- **No hay reloj que mueva el estado:** cada semana escribe sus lecturas (temperatura, humedad, olor) con `alIniciar` o con `porIteracion` del grupo (§2.4). El calendario es dato, no simulación.
- **Pantalla:** cortinilla negra a pantalla completa con la etiqueta al centro. **Visor:** el mismo fundido del teletransporte (si el lote `[HUD]` no lo trae, un quad negro pegado a la cámara) y la etiqueta en el HUD; la persona no se mueve.
- No suma tarea ni puntaje. **Importador:** error si falta `dias`, si es menor que 1 o si el paso trae `condicion`. **Telemetría:** `time_advanced` (metadata `dias`, `dia`).

```json
{ "id": "semana", "tipo": "avanzar", "dias": 7, "etiqueta": "ui.semana", "alIniciar": { "temperatura": 58 } }
```

### 2.4 Grupos: repetición y pasos reutilizables

```json
"bloques": { "prueba-puno": [
  { "id": "puno", "tipo": "mantener", "condicion": { "objeto": "punado" } },
  { "id": "decidir", "tipo": "elegir", "condicion": { "segun": "humedad" } },
  { "id": "secar", "tipo": "llevar", "si": { "humedad": "mojada" }, "alCompletar": { "humedad": "bien" } } ] },
"pasos": [
  { "id": "COMP-04", "tipo": "grupo", "repetir": 5, "contador": "ciclo", "pasos": [
    { "id": "vegetal", "tipo": "llevar" },
    { "id": "riego", "tipo": "llevar", "exito": "COMP-04.ciclo.{ciclo}", "alCompletar": { "altura": { "sumar": 0.3 } } } ] },
  { "id": "COMP-06", "tipo": "grupo", "bloque": "prueba-puno", "repetir": 3,
    "porIteracion": [ { "humedad": "mojada" }, { "humedad": "seca" }, { "humedad": "bien" } ] } ]
```

(Condiciones abreviadas.)

| Clave | Regla |
|---|---|
| `tipo: "grupo"` | Lleva `pasos` (en línea) **o** `bloque` (nombre en `bloques`), nunca los dos (error). |
| `repetir` | Entero ≥ 1, por defecto 1. |
| `contador` | Variable numérica que vale 1…`repetir` (se declara sola). Al empezar cada vuelta se escribe en el estado. |
| `porIteracion` | Lista de `repetir` objetos de estado; la vuelta *k* aplica el *k*-ésimo al empezar, después del contador y antes del `alIniciar` del primer paso. |
| `si` | Se copia a cada paso del grupo; si un paso del grupo escribe la variable que lo guarda, aviso. |
| `bloques` | Primer nivel: nombre → lista de pasos (o grupos). Un bloque que se usa a sí mismo, aun indirectamente, es error. |

**El importador desenrolla.** Cada grupo se reemplaza por sus pasos, vuelta por vuelta, con ids `<grupo>.<k>.<paso>` (`<grupo>.<paso>` si `repetir` es 1): `COMP-04.3.riego`, `COMP-08.2.puno.decidir`. El runtime recibe una lista plana, como hoy. Un `desde` de `secciones` puede nombrar un grupo (su primer paso). Pasar `repetir` de 5 a 4 borra los assets de la quinta vuelta (`autoria.md` §3.6). Las frases no se copian. El validador trabaja sobre el guion desenrollado y cita el id desenrollado y el del grupo.

**Cierre 2.4.** `repetir` entre 1 y 20 (aviso por encima de 10). Un grupo puede contener grupos, hasta dos niveles (COMP-09 dentro de COMP-08); los `si` se suman (todas). `porIteracion`, si está, tiene exactamente `repetir` elementos (error si no). Un id desenrollado no pasa de **100 caracteres** (el límite de `entityId` en el backend): error. `tarea` y `etiquetaTarea` se aplican a cada paso desenrollado; para contar el grupo como **una** tarea, `tarea` va en el grupo y solo cuenta su último paso. **Pantalla y visor:** el grupo no tiene interfaz propia; la vuelta se ve con un indicador del contador (§2.9). **Telemetría:** cada evento lleva el id desenrollado (`COMP-08.2.puno.decidir`); `metadata.grupo` y `metadata.vuelta` se añaden cuando el paso viene de un grupo.

### 2.5 `elegir` según el estado

```json
"condicion": {
  "segun": "humedad",
  "opciones": [
    { "objeto": "humedad-bien",  "valor": "bien" },
    { "objeto": "humedad-sobra", "valor": "mojada" },
    { "objeto": "humedad-falta", "valor": "seca" }
  ],
  "errorPorEstado": { "mojada": "mojada", "seca": "seca", "bien": "esta-bien" }
}
```

Con `segun`, las opciones llevan `valor` en vez de `resultado`. Al armarse el paso, la correcta es la de `valor` igual al estado; tocar otra reporta `errorPorEstado[estado]`, porque la corrección del storyboard habla de lo que se ve («el agua corre entre los dedos»), no de la opción tocada. Errores: `segun` no es de texto; algún valor de la variable sin opción (habría un estado sin respuesta correcta); clave sin frase en `errores`; mezclar `valor` y `resultado`.

**Cierre 2.5.** Una opción, con `segun` o sin él, puede llevar **`alElegir`** (efectos, §2.1), que se aplica al tocarla, antes de la corrección o del éxito. Es lo que deja escrita la zona que la persona eligió en COMP-01 (§2.10). `errorPorEstado` es obligatorio con `segun` y cubre todos los valores. **Pantalla y visor:** como `elegir` de 0.2 (rayo o clic sobre el hotspot). **Telemetría:** `step_error` con `key` = la clave por estado y `metadata.opcion` = el objeto tocado (así se distingue cuál tocó sin una frase por opción).

```json
{ "objeto": "zona-d", "resultado": "correcta", "alElegir": { "lugar": "d" } }
```

### 2.6 `llevar`: reacciones, faltantes y zonas distintas

```json
"condicion": {
  "objetos": ["estiercol", "rastrojos", "agua", "cal-ceniza"], "zonas": ["acopio"], "cantidad": 4,
  "reacciones": { "estiercol": "COMP-02.porque.estiercol", "agua": "COMP-02.porque.agua" },
  "faltantes":  { "estiercol": "sin-estiercol", "cal-ceniza": "sin-cal" },
  "distintas": false
}
```

- `reacciones`: objeto → id de frase, dicha sin bloquear ni contar (`ReportInfo`; el importador la pone en `errorLines` con la clave `reaccion.<objeto>`) al aceptarse su soltado. Si ese soltado cierra el paso, el éxito espera a que termine (hoy `Say` la cortaría).
- `faltantes`: objeto → clave de `errores`. «Continuar» (§2.7) reporta la del **primer** objeto de `objetos` aún sin colocar.
- `distintas`: `true` cuenta un soltado solo si su zona aún no tenía uno («una dosis por planta», COMP-13).

**Hecho en el lote 5 (2026-10-31).** La reacción suena solo la primera vez que se cuenta el objeto (volver a soltar uno que ya cuenta no reacciona). Con `distintas`, el soltado rechazado no es error ni se dice: no cuenta y el objeto vuelve a su sitio (`ReturnToOrigin.ReturnNow`).

**Cierre 2.6.** Por defecto: `reacciones` y `faltantes` vacíos, `distintas: false` (como 0.2). Errores: objeto que no está en `objetos`; clave de `faltantes` sin frase en `errores`. Aviso: `distintas: true` con menos zonas que `cantidad` (no se puede completar). **Pantalla y visor:** la reacción es un subtítulo con voz; en el visor, además, el pulso háptico de acierto que ya existe. **Telemetría:** la reacción no se envía (no es error ni ayuda); el faltante sale como `step_error` con su clave.

### 2.7 «Continuar» que dice qué falta

```json
"continuar": { "etiqueta": "ui.continuar", "claveIncompleto": "descubierta" }
```

Para pasos `Interaction`. El HUD muestra un botón con `etiqueta` mientras el paso escucha (como «Comenzar»). Pulsado con la condición cumplida, completa el paso; si no, reporta un **error**: la clave de `faltantes` si la hay, si no `claveIncompleto`, y sigue el camino de siempre (corrección, cuenta, se repite, `alError`). También sirve para «esperar otra semana» sin medir (COMP-08) o adelantar el tiempo sin voltear (COMP-09). El paso **sigue cerrándose solo** al cumplirse la condición (duda D-1, §7).

**Hecho en el lote 5 (2026-10-31).** «Continuar» incompleto cuenta **un** error con la clave del primer objeto sin colocar (la de `step_error`), y la corrección dice después, seguidas, las frases de `faltantes` de los demás que faltan, en el orden de `objetos`: la persona oye la lista entera sin voz sintetizada en ejecución (las voces están horneadas, así que no hay `{faltantes}` dentro de un texto: la lista son las frases de cada objeto). En pantalla, Intro es «Continuar» solo con el coach callado: con una frase sonando, Intro la salta como antes (`SubtitleHudBuilder.SkipKey`). En un paso `manual`, `TryConfirm` lo completa (lo usa el mismo botón).

**Cierre 2.7.** `etiqueta` por defecto `ui.continuar` (la frase tiene que existir). Sin `faltantes` en la condición, `claveIncompleto` es obligatoria (error). Solo en pasos `llevar`, `elegir`, `frotar`, `mantener`, `apuntar` (error en `manual`, `narracion`, `tiempo`, `avanzar`). **Pantalla:** botón en el panel del HUD y la tecla Intro. **Visor:** el mismo botón del HUD, pulsable con el rayo, como «Comenzar» (`ManualStepButton` generalizado). **Telemetría:** el error por «Continuar» es un `step_error` normal; si lo completa, `metadata.porContinuar: true` en el siguiente evento del paso.

### 2.8 Bloqueos

```json
"bloqueos": [
  { "zona": "capas",          "hasta": "COMP-03",        "clave": "rastrojo-entero" },
  { "zona": "cubierta",       "hasta": "COMP-05",        "clave": "sin-respiradero" },
  { "objeto": "boton-verde",  "hasta": "COMP-12.saco",   "clave": "sin-saco" }
]
```

Primer nivel. Hasta completarse el paso `hasta`, la zona rechaza todo soltado (el objeto vuelve) y el objeto no responde (el agarrable vuelve al soltarlo; el hotspot o botón no se activa). Si el paso en curso tiene `clave` en `errores`, se reporta; si no, no se dice ni cuenta, como pide el storyboard para lo soltado fuera de lugar. El soltado bloqueado no llega a la condición del paso. Errores: `hasta` o `zona` inexistentes. Aviso: ningún paso hasta `hasta` declara la clave.

**Hecho en el lote 6 (2026-10-31).** El objeto bloqueado **no se agarra**: `InteractableBase` no emite el agarre ni la activación, y `GrabbableItem` cancela la selección de XRI (`CancelInteractableSelection`); el intento es lo que reporta la `clave`. Si ya estaba en la mano cuando empezó a regir (`desde`), al soltarlo vuelve (`ReturnToOrigin`) y el soltado no llega a la condición. Lo aplica `LockEnforcer` (en `[Simulation]`) con los bloqueos que el importador deja en `SimulationSequence.locks`; rige desde que empieza `desde` hasta que se **completa** `hasta` (no hasta que empieza el siguiente), y un salto atrás vuelve a bloquear.

**Cierre 2.8.** Cada bloqueo lleva `zona` **u** `objeto` (los dos o ninguno: error), `hasta` (paso o grupo; un grupo vale por su último paso desenrollado) y, opcionales, `desde` (por defecto, el inicio) y `clave`. **Pantalla y visor:** el objeto vuelve a su sitio con `ReturnToOrigin`; en el visor, sin háptico de acierto. **Telemetría:** con `clave`, `step_error`; sin ella, nada (el storyboard no lo cuenta).

### 2.9 Indicadores

```json
"indicadores": [
  { "id": "humedad", "estado": "humedad", "etiqueta": "ui.ind.humedad",
    "textos": { "bien": "ui.humedad.bien", "mojada": "ui.humedad.mojada", "seca": "ui.humedad.seca" } },
  { "id": "temperatura", "estado": "temperatura", "etiqueta": "ui.ind.temperatura", "unidad": "°C" },
  { "id": "ciclo", "estado": "ciclo", "etiqueta": "ui.ciclo", "desde": "COMP-04", "hasta": "COMP-04" }
]
```

Primer nivel. Un panel fijo del HUD muestra por indicador `etiqueta` (`soloTexto`, admite `{variable}`) y el valor: por `textos` si es de texto, con `unidad` si es numérico. `desde`/`hasta` (paso o grupo) acotan cuándo se ve; sin ellos, siempre.

**Cierre 2.9**

| Campo | Tipo | Por defecto | Regla |
|---|---|---|---|
| `id` | texto | — | único |
| `estado` | variable de §2.1 | — | obligatorio |
| `etiqueta` | id `soloTexto` | — | obligatorio |
| `textos` | valor → id `soloTexto` | — | obligatorio y completo si la variable es de texto |
| `unidad` / `decimales` | texto / entero | sin unidad / 0 | solo numéricas |
| `desde` / `hasta` | paso o grupo | todo el recorrido | |
| `enInforme` | booleano | `false` | el panel final muestra su valor final |

- **Pantalla:** panel fijo arriba a la derecha, hasta cuatro indicadores (aviso con más); al cambiar, el valor destella 0,6 s, sin sonido. **Visor:** el mismo panel dentro del HUD que sigue la mirada (lo que fije el lote `[HUD]`), a la izquierda del subtítulo.
- Los «medidores» del simulador web (temperatura y humedad) son dos indicadores; su «informe final» es `enInforme` más `metadata.estado` de `complete_experience` (§2.1).
- **Telemetría:** ninguna propia (la lleva el estado).

### 2.10 Objetos que dependen del estado: `visibleSi` y `posicionSegun` (en `colocacion.json`)

Pedido del 2026-10-25: la pila tiene que **aparecer sobre la zona que la persona eligió en COMP-01**. Hoy está a 3,4 m de D (`arte-compostaje.md` §6; segundo recorrido en `auditoria-visor-2026-10-18.md`) porque 0.2 no puede moverla ni ocultarla. Dos claves en la colocación y un contenedor:

```json
"conjuntos": [ {
  "id": "compostera", "origen": [5.0, 0, -2.2],
  "miembros": { "objetos": ["pila", "marca-centro", "tubo", "palo"],
                "zonas": ["centro", "costado", "capas", "cubierta", "frente-pila"],
                "anclas": ["pila"] },
  "visibleSi": { "lugar": ["a", "b", "c", "d"] },
  "posicionSegun": { "estado": "lugar",
                     "lugares": { "a": "zona-a", "b": "zona-b", "c": "zona-c", "d": "zona-d" } }
} ]
```

| Clave | Dónde | Tipo | Por defecto | Qué hace |
|---|---|---|---|---|
| `visibleSi` | `objetos[]`, `zonas[]`, `conjuntos[]` | forma de `si` (§2.1) | siempre visible | oculta el objeto (inactivo) o desactiva la zona (no acepta ni se resalta); en un conjunto, vale para todos sus miembros, sumado al de cada uno |
| `conjuntos[].origen` | | `[x, y, z]` | — | punto del conjunto que se lleva al lugar |
| `conjuntos[].miembros` | | ids de `objetos`, `zonas`, `anclas` | — | se mueven juntos, sin cambiar su disposición entre sí |
| `posicionSegun.estado` | | variable de texto | — | |
| `posicionSegun.lugares` | | valor → id de objeto (toma su `pos`) o `{ "pos": [...], "giro": g }` | valor sin lugar: el conjunto queda donde está escrito | |
| `posicionSegun.girar` | | booleano | `false` | `true` también toma el `giro` del lugar |
| `posicionSegun.desplazar` | | `[x, y, z]` | `[0, 0, 0]` | para dejarlo al lado del marcador, no encima |

- **Cuándo se mueve:** al cambiar la variable, en el mismo fotograma. Sin animación: se escribe para que ocurra oculto (la pila no se ve hasta que `lugar` vale algo) o en el negro de `avanzar`. Un salto atrás vuelve el estado al inicial: el conjunto vuelve a `origen` y se oculta.
- **COMP-01 en la muestra:** `estado.lugar` con inicial `ninguno`; la opción D lleva `alElegir: { "lugar": "d" }` (o el paso, `alCompletar`, si solo D avanza). La pila, sus zonas `centro`/`costado`/`capas`/`cubierta`, el tubo, el palo, `frente-pila` y el ancla `pila` aparecen sobre D al acertar. A, B y C quedan escritas en `lugares` para cuando una experiencia acepte más de una ubicación.
- **Pantalla y visor:** igual en los dos. En el visor, el `TeleportationArea` de `frente-pila` y el ancla se mueven con el conjunto (son hijos); un agarrable que ya está en la mano no se recoloca.
- **Importador** (`ColocacionImporter`): crea un vacío `Conjunto_<id>` en `origen` y cuelga de él a los miembros conservando su posición; le pone `StateLayout`; a lo que tiene `visibleSi`, `StateVisibility`.
- **Validador** (cruzado con el guion): miembro inexistente o en dos conjuntos; variable inexistente o numérica; valor de `lugares` fuera de `valores`; objeto destino inexistente: errores. Aviso: la variable cambia después de que un paso ya usó un miembro (se movería a medio usar).
- **Telemetría:** ninguna propia; el lugar sale por `state_changed` si `lugar` tiene `registrar`.

## 3. `colocacion.json`: la validación geométrica mínima

Una sola clave nueva y una regla.

**La regla (runtime):** un soltado se juzga **una sola vez, en una zona**: de las que contienen al objeto, la más pequeña que lo acepta; si ninguna lo acepta, la más pequeña. Hoy cada zona que lo contiene emite su `DroppedAnywhere` (`DropZone.OnItemReleased`) y la condición juzga varias veces. En la muestra `cubierta` contiene a `capas` y `centro`: soltar la manta en COMP-07 probablemente da a la vez el acierto y el error de `claveFuera` (`capas` no la acepta). **Visto en PlayMode el 2026-10-31** (lote 6, antes del arreglo): dos zonas `soltar` solapadas, `cubierta` (2 m) y `capas` (1 m) dentro, las dos aceptan la manta; soltarla dentro de `capas` dio dos juicios, «cubierta, capas» (`ZonasBloqueosPlayTests.ZonasSolapadas_UnSoltado_LoJuzgaUnaSolaZona_LaMasPequenaQueLoAcepta`, que entonces fallaba con «Expected: 1 But was: 2»). Arreglado en el lote 6: cada zona que contiene al objeto recibe el soltado, pero solo la que juzga emite `Dropped`/`DroppedAnywhere`, una vez por soltado (`DropZone.ResolveJudge`; el tamaño es el volumen del collider). Lo decidido antes de que `SnapZone` mueva el objeto es lo que vale para `ReturnToOrigin`.

**La clave:** `zonas[].medir`: `"contacto"` (por defecto, como hoy: algún collider del objeto toca el volumen) o `"centro"` (el centro de los límites del objeto está dentro).

Así se escribe «el tubo descubierto»: dentro de `cubierta`, una zona `boca-tubo` de 0,4 × 0,4 m, del suelo a la punta del tubo (`autoria.md` §10.1), `medir: "centro"`, que acepta las tres cubiertas; y en COMP-07 la regla 0.2 `{ "zona": "boca-tubo", "clave": "tubo-tapado" }`. Con el centro de la cubierta sobre el tubo juzga `boca-tubo` (error); en otro punto de la pila, `cubierta` (acierto), que la imanta en la pose que deja el tubo libre. **Valida la intención** (dónde la soltó), no la malla final: eso pediría colliders con hueco en el arte. El anillo de COMP-13 es igual: `tronco` dentro de `anillo-copa`.

`xrlabs.colocacion/0.3` solo si usa `medir`, `visibleSi` o `conjuntos` (§2.10); una colocación 0.2 vale con un guion 0.3. El validador suma las referencias cruzadas de `bloqueos[].zona` y de los pasos desenrollados.

**Cierre 3.** `medir`: `"contacto"` (por defecto) o `"centro"`; otro valor, error. La regla de una zona por soltado es de runtime y no tiene clave: rige para toda colocación 0.3 y, para la muestra, también en 0.2 (es una corrección). **Pantalla y visor:** solo se resalta la zona que va a juzgar el soltado; las demás que contienen al objeto, no. **Telemetría:** un soltado da como mucho un `step_error`, con `metadata.zona` = la zona que juzgó. Ejemplo mínimo:

```json
{ "id": "boca-tubo", "tipo": "soltar", "pos": [5.0, 0, -2.2], "tamano": [0.4, 0.4], "alto": 1.8,
  "acepta": ["paja", "ichu", "manta"], "medir": "centro" }
```

## 4. Compatibilidad (D8)

- Los validadores aceptan 0.1, 0.2 y 0.3; un fichero 0.1 o 0.2 que usa algo de 0.3 recibe un **aviso**, como en 0.2. Nada de 0.1 ni 0.2 cambia de significado; la experiencia cero y la muestra importan igual y sus tests no cambian.
- **Importador:** sin claves 0.3 genera los mismos assets. Los campos nuevos de `StepDefinition` quedan vacíos, y vacío es «como antes». Los grupos solo existen en el fichero.
- **Preparar escena** añade `SimulationState`, `LockEnforcer` y el panel de indicadores solo si el guion los usa; idempotente como hoy.
- **Runtime:** cada cambio de `StepSystem` lo guarda un campo vacío por defecto. La regla de una zona por soltado sí cambia algo existente con zonas solapadas; Fallas de Brocas, fijado en `#v0.5.0` (D9), no lo recibe; para la muestra es una corrección.
- **Saltos** (F4, capítulos): adelante, se aplican en orden los efectos de los pasos saltados; atrás, el estado vuelve al inicial y se repiten hasta el destino. Son datos: no hace falta `StepEndStates`.

## 5. Qué cambia en el importador y el runtime

Tamaño: S, medio día o menos; M, un día; L, más de un día. Los tests van en `Tests/Editor` (EditMode) y `Tests/Runtime` (PlayMode), al estilo de `ExperienciaCompostajeTests` y `StepSystemCoachTests`.

| Fichero | Nuevo | Qué cambia | Tamaño | Tests |
|---|---|---|---|---|
| `Schema/guion.schema.json` | | `xrlabs.guion/0.3`: `estado`, efectos, `si`, `avanzar`, `grupo`, `bloques`, `segun`, `alElegir`, `continuar`, `bloqueos`, `indicadores` | S | con el validador |
| `Schema/colocacion.schema.json` | | `xrlabs.colocacion/0.3`: `medir`, `visibleSi`, `conjuntos` | S | con el validador |
| `Editor/Authoring/GuionDocument.cs` | | clases de las claves nuevas | S | — |
| `Editor/Authoring/GuionExpander.cs` | sí | desenrolla grupos y bloques, ids `<grupo>.<k>.<paso>`, contador y `porIteracion` | M | ~6 |
| `Editor/Authoring/GuionValidator.cs` | | reglas de los cierres 2.1–2.9, sobre el guion desenrollado | L | ~25 |
| `Editor/Authoring/GuionImporter.cs` | | efectos y guarda en `StepDefinition`, `{variable}` expandido, estado inicial, bloqueos e indicadores en la `SimulationSequence`, borrar las vueltas sobrantes | M | ~8 |
| `Editor/Authoring/ColocacionDocument.cs` | | `medir`, `visibleSi`, `conjuntos` | S | — |
| `Editor/Authoring/ColocacionValidator.cs` | | reglas de §2.10 y §3, cruzadas con `estado` del guion | S | ~6 |
| `Editor/Authoring/ColocacionImporter.cs` | | `Conjunto_<id>`, `StateLayout`, `StateVisibility`, `medir` en `DropZone` | M | ~4 |
| `Editor/Authoring/ScenePreparer.cs` | | añade `SimulationState`, `LockEnforcer` y el panel de indicadores solo si se usan (idempotente) | S | ~2 |
| `Editor/Authoring/SubtitleHudBuilder.cs` | | panel de indicadores, botón «Continuar», cortinilla de `avanzar` | M | ~2 |
| `Editor/Authoring/ImportReport.cs` | | lista ids desenrollados y su grupo | S | — |
| `Runtime/Core/SimulationState.cs` | sí | tabla, `Apply`, `Evaluate`, `Replay`, evento `Changed`; C# puro | S | ~8 |
| `Runtime/Core/StepDefinition.cs` | | efectos, guarda, `dias`, `etiqueta`, «Continuar» | S | — |
| `Runtime/Core/StepSystem.cs` | | guarda y salto, efectos, `{variable}`, `avanzar`, `TryConfirm()`, éxito tras la reacción | M | ~5 |
| `Runtime/Core/StepCondition.cs` | | `TryConfirm(out clave)` virtual (por defecto, no confirma) | S | con `StepSystem` |
| `Runtime/Core/ManualKeyStepCondition.cs` | | Intro como «Continuar» en plano | S | ~1 |
| `Runtime/Core/SimulationSequence.cs` | | estado inicial, bloqueos, indicadores | S | — |
| `Runtime/Core/ScoringSystem.cs`, `SessionStats.cs` | | un paso saltado descuenta su tarea | S | ~2 |
| `Runtime/Core/StateVisibility.cs`, `StateLayout.cs` | sí | `visibleSi` y `posicionSegun` | S | ~4 |
| `Runtime/Core/Telemetry/TelemetryEvents.cs` y el canal del API | | `step_skipped`, `state_changed`, `time_advanced`, `metadata.estado` del cierre | S | ~3 |
| `Runtime/Interactions/Conditions/DropCondition.cs` | | `reacciones`, `faltantes`, `distintas`, `TryConfirm` | S | ~4 |
| `Runtime/Interactions/Conditions/ChoiceByTargetCondition.cs` | | `segun`, `errorPorEstado`, `alElegir` | S | ~3 |
| `Runtime/Interactions/DropZone.cs` | | una zona por soltado, `medir`, `Locked` | M | ~4 |
| `Runtime/Interactions/LockEnforcer.cs` | sí | aplica `bloqueos` | S | ~3 |
| `Runtime/Interactions/ReturnToOrigin.cs` | | devolver lo soltado en zona bloqueada | S | con `LockEnforcer` |
| `Runtime/Simulations/UI/ManualStepButton.cs` | | generalizado a «Continuar» | S | ~2 |
| `Runtime/Simulations/UI/IndicatorPanel.cs` | sí | panel de indicadores | S | ~2 |
| `Runtime/Simulations/UI/EvaluationFinalResultsPanel.cs` | | indicadores `enInforme` | S | ~1 |

No cambian: `ElapsedTimeStepCondition`, `KeyChoiceStepCondition`, `HoldCondition`, `ScrubCondition`, `AimCondition`, `TouchableHotspotCondition`. Unos 70 tests nuevos (50 EditMode, 20 PlayMode). La experiencia cero y Fallas de Brocas (fijado en `#v0.5.0`, D9) no se tocan.

## 6. Lotes de implementación (sello verde al cerrar cada uno)

| Lote | Qué | Ficheros principales | Días | Desbloquea |
|---|---|---|---|---|
| 1 | **Hecho el 2026-10-31** (rama `wt/lote1`). **La pila sobre la zona elegida:** `estado` de texto, `alCompletar`, `alElegir`, `visibleSi`, `conjuntos` + `posicionSegun` | `SimulationState`, `StateVisibility`, `StateLayout`, `Colocacion*`, `ChoiceByTargetCondition`, esquemas | 1,5 | el pedido de hoy, visible en el Quest 3 |
| 2 | **Hecho el 2026-10-31** (rama `wt/lote2`). **Guardas y tiempo:** numéricas, `si`, `alIniciar`, `alError`, `avanzar`, `{variable}`, telemetría nueva | `StepSystem`, `StepDefinition`, `Guion*`, `SubtitleHudBuilder`, `TelemetryEvents` | 2 | 06, 08, 09, 10 |
| 3 | **Hecho el 2026-10-31** (rama `wt/lote3`). **Grupos:** `grupo`, `bloques`, `porIteracion`, contador | `GuionExpander`, `GuionValidator`, `GuionImporter` | 1,5 | 04 con cinco ciclos, 06 con tres casos, bucles de 08 y 09 |
| 4 | **Hecho el 2026-10-31** (rama `wt/lote4`). **Preguntar y ver el estado:** `segun`, `errorPorEstado`, indicadores, `enInforme` | `ChoiceByTargetCondition`, `IndicatorPanel`, `EvaluationFinalResultsPanel` | 1,5 | 06 completo, fase de 08, 00 con indicadores |
| 5 | **Hecho el 2026-10-31** (rama `wt/lote5`). **«Continuar» y `llevar`:** `continuar`, `faltantes`, `reacciones`, `distintas` | `StepCondition`, `DropCondition`, `ManualStepButton` | 1 | 02 completo, 07–09 con «sin hacer», hortalizas de 13 |
| 6 | **Zonas y bloqueos** (antes, ver en Play el doble juicio de §3): una zona por soltado, `medir`, `bloqueos`. **Hecho el 2026-10-31** (rama `wt/lote6`): doble juicio confirmado en PlayMode y corregido; 11 EditMode y 8 PlayMode. La muestra no cambia: `boca-tubo` con `medir: "centro"` entra con la muestra en 0.3 (lote 7) | `DropZone`, `LockEnforcer`, `ReturnToOrigin` | 1,5 | 03, 05, 07 (tubo), 12, 13 (tronco) |
| 7 | **Hecho el 2026-10-31** (rama `wt/lote7`). **La muestra de COMP-08 a 13** en 0.3 (y 02, 04, 06 y 07 reescritas), tests de fidelidad | `Samples~/ExperienciaCompostaje`, `ExperienciaCompostajeTests` | 2 | el storyboard entero |
| 8 | **Reserva:** voces, recorrido del dueño en pantalla y en el visor | — | 1 | |

Total: **12 días**. El lote 1 va primero porque resuelve lo que se vio hoy en el visor y no depende de los demás; el 6 puede adelantarse si el doble juicio se confirma en Play.

**Lote 1, cómo quedó (2026-10-31).** `SimulationState` (C# pura: tabla, `Apply`, `Evaluate`, `Replay`, `Changed`) vive en escena en `SimulationStateHost`, que «Preparar escena» añade a `[Simulation]` solo si el guion declara `estado` y que lee el estado inicial de `SimulationSequence.initialState`. En la rama del lote 1 (la integración lo cambió: ver abajo), mientras el lote 2 no llevara los efectos al `StepSystem`, el host aplicaba `alCompletar` al `StepCompleted` (sale antes de la frase de éxito) y, en un salto, repite los efectos de los pasos anteriores (de un `elegir`, el `alElegir` de la opción correcta, guardado en `SimulationSequence.stepStateEffects`); el lote 2 puede mover eso al `StepSystem` y dejar el host como dueño de la tabla. `ChoiceByTargetCondition` aplica `ChoiceOption.onChoose` al tocar. `StateVisibility` y `StateLayout` se evalúan en `Awake` (orden −300) y a cada `Changed`, aunque su objeto esté inactivo: lo que empieza oculto no llega a despertar en su sitio escrito. El validador del guion acepta 0.3 y comprueba declaraciones y efectos; el de la colocación, `visibleSi`, miembros, `posicionSegun` y el aviso de mover a medio usar. El aviso «variable que nadie lee» queda para el lote 2, que es el que añade `si`. **Telemetría:** `action` del activity log es texto libre (`CreateActivityLogDto.action` es `@IsString()` en `platform-api`), así que el cambio sale como `state_changed` (metadata `variable`, `antes`, `valor`; `entityId` = el paso en curso) y no como `step_warning` con `metadata.tipo`; el evento está en su propio fichero (`StateChangedEvent.cs`) para no chocar con el lote 2. En la muestra, el conjunto `compostera` lleva además los objetos de COMP-03 a 07 (montón, picados, puñado, las tres opciones de humedad y las tres cubiertas) y `marca-centro`, para que su disposición respecto a la pila (D33) se conserve. Fuera de este lote: `StepVisibilityPlanner` (`visibilidadPorPaso`) solo mira los hijos directos de `[Colocacion]` y no ve los miembros de un conjunto (la muestra del INIA no lo usa).

**Lote 2, hecho el 2026-10-31** (rama `wt/lote2`, sobre la `SimulationState` del lote 1): las reglas viven en `Editor/Authoring/GuionStateRules.cs`; el validador y el importador las llaman desde regiones marcadas «0.3 lote 2». `action` del activity log resultó texto libre (`CreateActivityEventDto`: `IsString`, `MaxLength(100)`), así que `step_skipped`, `state_changed` y `time_advanced` van con su nombre (§9, lo abierto queda cerrado). Quedan para otros lotes: `metadata.estado` en `complete_experience` (lo emite `SessionManager`, fuera del reparto), el aviso de «variable que nadie lee» (necesita `visibleSi` e `indicadores`, lotes 1 y 4), los contadores en `{variable}` (lote 3) y, en el visor, el fundido del teletransporte en vez de la cortinilla del HUD.

**Lote 3, hecho (2026-10-31).** `Editor/Authoring/GuionExpander.cs` desenrolla al importar: cada vuelta copia los pasos del grupo (en línea o de su bloque) con ids `<grupo>.<k>.<paso>`; el primer paso de la vuelta recibe en `alIniciar`, por debajo del suyo, el contador y el *k*-ésimo de `porIteracion` (los aplica el runtime del lote 2); `{contador}` en los ids de frase se sustituye ya al desenrollar; el `si` del grupo se suma al de cada paso; `tarea` en el grupo marca solo su último paso; un `desde` que nombra un grupo pasa a su primer paso; cada contador se declara en `estado` (`inicial` 0). `GuionValidator` valida el guion desenrollado (errores de estructura con el grupo y la ruta: sin pasos, `pasos` y `bloque` a la vez, bloque que falta o que se usa a sí mismo, `repetir` fuera de 1–20, `porIteracion` de otro largo, tres niveles, ids desenrollados repetidos o de más de 100 caracteres; aviso por encima de 10 vueltas y si un 0.1/0.2 usa grupos). `GuionImporter` desenrolla en su primera línea, así que re-preparar con menos vueltas borra sus pasos y condiciones (idempotente); `ImportReport.Expanded` lista «id ← grupo G, vuelta k». La muestra del INIA no se reescribe con grupos: es el lote 7.

**Lote 5, hecho (2026-10-31, rama `wt/lote5` sobre la integración 1, 2, 3 y 6).** `StepCondition.TryConfirm(out clave)` (virtual, no confirma) y `MissingKeys()`; `StepSystem.TryConfirm()` cierra el paso con la condición cumplida o reporta el error de lo que falta (§2.7, nota «Hecho en el lote 5»); `ManualStepButton` es «Continuar» en los pasos con `continuar` (texto de `etiqueta`) y «Comenzar» en los manuales; Intro en pantalla. `DropCondition`: `reactionItemIds`, `missingKeys`, `distinctZones`. Esquema, `GuionDocument`, `GuionValidator` e `GuionImporter` en regiones «0.3 lote 5». «Preparar escena» no cambia: el botón ya estaba en todo `[HUD]`. Tests: 9 EditMode y 4 PlayMode (sello 382 / 113). Pendiente: `metadata.porContinuar` (el `StepSystem` deja `CompletedByContinue`, pero el cierre del paso no sale hoy por el canal del API: `StepCompletedEvent` es solo local), y la muestra con `continuar` en COMP-02, 07–09 y 13 (lote 7).

**Integración de los lotes 1, 2, 3 y 6 (2026-10-31, `feature/visor`).** Una sola ruta para los efectos, para que cada uno se aplique una vez: el `StepSystem` aplica `alIniciar`, `alError`, `avanzar` y `alCompletar` (este, antes de `StepCompleted` y de la frase de éxito) y, en un salto, rehace el estado desde el inicial con los pasos anteriores al destino cuya guarda se cumplía (días de `avanzar`, `alIniciar`, el `alElegir` de la opción correcta de un `elegir` y `alCompletar`; `alError` no se repite); `ChoiceByTargetCondition` aplica el `alElegir` al tocar; el `SimulationStateHost` solo guarda la tabla y manda `state_changed` (el `StepSystem` lo manda solo para una tabla propia o la de `UseState`, así que no sale dos veces). La declaración de `estado` se valida una vez (`GuionStateRules`, que conoce `dia`) y el estado inicial sale de `StateAuthoring.BuildDefinitions` más `dia`; un guion o una colocación 0.1/0.2 que usa algo de la 0.3 (grupos, estado, efectos, guardas, `avanzar`, `bloqueos`, `visibleSi`, conjuntos, `medir`) recibe un solo aviso de esquema con todo lo que usa. `GuionExpander` quita también `IsTimeAdvance` al desenrollar. Test: `EstadoEfectosUnaVezPlayTests` (COMP-01 con D deja `lugar=d` y suma su `alCompletar` una vez; el salto a COMP-05 lo conserva). Sello 373 / 109. Pendiente: `metadata.estado` en `complete_experience`, el aviso de «variable que nadie lee», `StepVisibilityPlanner` no ve los miembros de un conjunto, y los lotes 4, 5, 7 y 8.


**Lote 4, hecho el 2026-10-31** (rama `wt/lote4`, sobre la integración de los lotes 1, 2, 3 y 6). `ChoiceByTargetCondition` con `segun` decide la correcta por el valor de la variable **al tocar, antes del `alElegir`** de la opción tocada (lo mismo que «al armarse el paso» mientras nada cambie el estado dentro del paso; leerlo al tocar evita depender de si `Initialize` corre antes o después del `alIniciar`) y reporta `errorPorEstado[estado]`; la opción tocada viaja aparte por `IStepSignalDetails` hasta `StepSignalEvent.Option` y `metadata.opcion` (en todo `elegir` por objeto, no solo con `segun`), sin cambiar `StepSignal` ni `StepCondition` (lote 5). En un salto se repite el `alElegir` de la opción del valor de ese momento (`StepStateEffects.chooseBy`). Los indicadores van a `SimulationSequence.indicators` con `desde`/`hasta` de grupo ya resueltos a paso; `IndicatorPanel` los pinta en un panel del `[HUD]` que «Preparar escena» pone solo si hay indicadores (y quita si dejan de estar). **Pantalla y visor comparten el canvas**: el panel va arriba a la derecha en los dos (en el visor el canvas entero es el HUD de 1,1 m a 1,3 m); «a la izquierda del subtítulo» no cabe sin achicar el texto por debajo de lo legible, así que queda para el lote del visor si se quiere. `EvaluationFinalResultsPanel` muestra los de `enInforme` y `SessionManager` manda `metadata.estado` en `complete_experience` (cerrado el pendiente del lote 2). Tests: 26 EditMode y 5 PlayMode (399 / 114). Pendiente: el aviso de «variable que nadie lee» (ya hay `visibleSi`, `si` e `indicadores` para calcularlo), la etiqueta de un indicador con `{variable}` no se valida contra `estado` (se sustituye en runtime), y los lotes 5, 7 y 8.

**Lote 7, hecho el 2026-10-31** (rama `wt/lote7`, sobre `feature/visor` con los lotes 1 a 6). La muestra del INIA entera: 136 pasos al desenrollar, de COMP-00 a COMP-13 (`a5-experiencia-compostaje.md` §9, que pasa de boceto a hecho). COMP-02 con `reacciones`, `faltantes` y `continuar` (decisión a: se cierra solo); COMP-03 y COMP-05 con `bloqueos` de zona; COMP-04 en un grupo de cinco ciclos (`porIteracion` de `altura`); COMP-06 con el bloque `prueba-puno` en tres casos, `segun` y `errorPorEstado` (decisión c); COMP-07 con `boca-tubo` (`medir: centro`) y `continuar`; COMP-08 en seis semanas con el calendario de Coresearch en `porIteracion` y en `nota`/`descripcion` (decisión b) y COMP-09 dentro, en las semanas 2, 4 y 6. Los pasos de la prueba del puño van copiados en el bloque `volteo`: COMP-08 > COMP-09 > `prueba-puno` serían tres niveles de grupo (§2.4 admite dos). COMP-10 a 13 con los tipos de 0.2 más `segun`, `bloqueos` de objeto, `medir` y `distintas`. Lo que el storyboard no tiene (la cosecha como acción, el gráfico de fases, la profundidad de 15 cm, el suelo seco, «voltea solo una parte», «retira el saco sin coserlo») queda fuera, como dice §7. Un arreglo de runtime (región «0.3 lote 7» de `StepSystem`): un `avanzar` completado en pleno fundido sin nadie escuchando `TimeAdvanced` no sumaba los días ni su `alIniciar`. Tests: 5 EditMode y 2 PlayMode (413 / 120).

## 7. Fuera, a propósito

- Bucles «hasta que» en tiempo de ejecución: la salida de 08 y 09 es un número fijo de vueltas (el modo guiado es determinista).
- Expresiones, aritmética salvo `sumar`, condiciones «o», estado que cambie con el reloj real.
- Gráfico de fases, barras de progreso, balanza animada, ficha de madurez y casillas de COMP-01 y 02 (interfaz y arte).
- Espesor de capa (04) y profundidad de 15 cm (13): no hay medida en la escena. «Terminar antes del quinto ciclo» no tiene gesto.
- Geometría de malla, punto de control del día 0, informe final más allá de `enInforme` y `metadata.estado`, sonidos por zona, inglés, importador del storyboard.

Las dudas D-1 a D-3 (punto 7 de `decisiones-pendientes.md`) quedan con recomendación en §9.

## 8. Pantalla → claves 0.3 que necesita

| Pantalla | Claves 0.3 |
|---|---|
| COMP-00 | `estado`, `indicadores` |
| COMP-01 | `estado` (`lugar`), `alElegir`; en la colocación, `conjuntos` + `visibleSi` + `posicionSegun` (§2.10) |
| COMP-02 | `reacciones`, `faltantes`, `continuar` |
| COMP-03 | `bloqueos` |
| COMP-04 | `grupo` + `repetir` + `contador`, `{ciclo}`, `alCompletar` (`sumar`), `indicadores`, `visibleSi` |
| COMP-05 | `bloqueos` |
| COMP-06 | `bloques`, `grupo` + `porIteracion`, `elegir.segun`, `si`, `alCompletar` |
| COMP-07 | `medir` + una zona por soltado, `continuar`, `alCompletar`, `visibleSi` |
| COMP-08 | `grupo` + `porIteracion`, `avanzar`, `elegir.segun`, `{fase}`, `si`, `continuar`, `bloques`, `indicadores` |
| COMP-09 | `avanzar`, `si`, `continuar` + `alError`, `bloques`, `alCompletar`, `visibleSi` |
| COMP-10 | `estado`, `visibleSi`, `alIniciar` (dos `elegir` de 0.2) |
| COMP-11 | ninguna (`frotar` y `elegir` de 0.2) |
| COMP-12 | `bloqueos` de objeto, `indicadores` (balanza), `alCompletar` |
| COMP-13 | `medir` + una zona por soltado, `distintas`, `continuar` |

## 9. Decisiones que pide este contrato

> **Decidido el 2026-10-26 (D35):** todo tal como se recomienda abajo; el dueño delegó la decisión («tú decide todo eso»). Lo abierto que no es del dueño sigue abierto.

| Duda (punto 7 de `decisiones-pendientes.md`) | Recomendación | Coste |
|---|---|---|
| (a) ¿COMP-02 exige pulsar «Continuar» o se cierra solo con los cuatro materiales? | **Se cierra solo**; «Continuar» queda para preguntar qué falta (§2.7) | cero: es el comportamiento por defecto |
| (b) Calendario de COMP-08 y 09 (semanas, cuándo pasa de 70 °C), que el manual no da | **Lo fija Coresearch**, marcado en `nota` y en `porIteracion` (propuesta en `a5-experiencia-compostaje.md` §9) | media hora de redacción; revisable por el INIA sin tocar código |
| (c) COMP-06: ¿una corrección por estado de humedad o una por opción tocada? | **Por estado** (`errorPorEstado`, §2.5); la opción tocada queda en `metadata.opcion` | 3 frases con voz en vez de 9 |

Además, para cerrar 0.3:

- **Confirmar fuera de esta versión** el espesor de capa (04), los 15 cm (13) y «terminar antes del quinto ciclo» (§7). Coste: cero.
- **Nombres nuevos:** `posicionSegun`, `conjuntos`, `alElegir`, `enInforme` (§2.10, §2.5, §2.9), en el estilo de `visibleSi` y `alCompletar`. Coste: cero si se aceptan ahora; cambiarlos después cuesta una migración de la muestra.
- **Abierto, no del dueño:** comprobar que `action` del activity log acepta texto libre (`CreateActivityEventDto`); si es una lista cerrada, `step_skipped`, `state_changed` y `time_advanced` van como `step_warning` con `metadata.tipo`. Ver en Play el doble juicio de §3 antes del lote 6: **visto el 2026-10-31**, había doble juicio (§3); corregido en el lote 6.
