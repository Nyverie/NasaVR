# Autoría: el guion y la colocación como ficheros, y el importador que los convierte en una experiencia

Diseño del lote A1 (2026-10-10, estación Windows). Lo arrancó el dueño: «lo que más me gustaría experimentar ahora es la facilidad del framework para construir la experiencia», con el criterio «que alguien no programador pueda hacerlo», y aceptó los dos ficheros («me gusta lo de los 2 ficheros») y Blender como herramienta de los modeladores. Decisiones D19 a D22 en `decisiones.md`. Esta página manda sobre el código del lote; si el código la contradice, se corrige uno de los dos y se anota aquí.

## 1. Qué se quiere medir y qué no

Se quiere saber si una persona que no programa puede construir una experiencia completa con el framework sin abrir el Inspector de Unity, y dónde se traba. Para eso, la experiencia deja de construirse a mano en el Editor (hoy, `tutorial-primera-experiencia.md`: 45 a 60 minutos para cuatro pasos, con tags, assets y campos del Inspector) y pasa a describirse en dos ficheros que el framework importa.

No se mide todavía: el visor (no hay ninguno conectado en la estación), la voz real (el horneado ya existe, D5; aquí solo se deja la biblioteca de frases lista para hornear) ni la web de edición (vendrá después y editará estos mismos ficheros).

## 2. Los dos ficheros

| Fichero | Quién lo escribe | Quién lo lee | Qué contiene |
|---|---|---|---|
| `guion.json` | La persona (hoy a mano o desde una hoja; después la web). Unity **nunca** lo edita. | El importador de Unity; después, la web y el reproductor web. | La experiencia como datos: pasos, condiciones, frases del coach por idioma, objetos a los que se refiere, secciones, puntaje. Nada de Unity: ni GUID, ni rutas de assets, ni posiciones. |
| `colocacion.json` | La web sobre el GLB del entorno, o Unity (más adelante, con una exportación). | El importador de Unity (y el reproductor web). | Dónde va cada cosa en el espacio: punto de inicio, anclas del coach, objetos, zonas. Los objetos son los del guion (mismos ids); las anclas y las zonas se declaran aquí, con ids propios y únicos, y el guion solo nombra las anclas (`ancla`). Coordenadas en los ejes del GLB. |

Separados porque cambian a ritmos distintos y por manos distintas: el guion lo revisa un docente; la colocación la ajusta quien coloca. Y porque el guion sin coordenadas sirve igual en pantalla, en el visor y en la web.

Los dos llevan un campo `esquema` con nombre y versión (`xrlabs.guion/0.1`, `xrlabs.colocacion/0.1`). Los esquemas JSON Schema viven en `Schema/` dentro del paquete (D20) hasta que exista el repo `experience-schema` que propone la estrategia; la web los leerá de allí.

## 3. El guion (`xrlabs.guion/0.1`)

El esquema completo está en `Schema/guion.schema.json`; esto es la lectura humana. Las claves van en español porque las lee la persona que escribe; el código C# que las mapea sigue en inglés.

```json
{
  "esquema": "xrlabs.guion/0.1",
  "experiencia": {
    "id": "experiencia-cero",
    "titulo": "Experiencia cero: separar residuos",
    "escena": "ExperienciaCero",
    "clave": "",
    "idHeredado": 10,
    "modo": "guiado",
    "idiomas": ["es", "en"]
  },
  "coach": { "nombre": "Coach" },
  "lineas": {
    "intro.bienvenida": { "es": "Hola. Hoy vamos a separar residuos.", "en": "Hi. Today we sort waste.", "nota": "cálida, corta" },
    "p2.instr": { "es": "Toca la pila de restos.", "dicho": { "es": "Toca la pila de restos" } },
    "p2.pista": { "es": "La pila es el montón marrón. Tócala." },
    "p2.exito": { "es": "Bien. Hay cáscaras, hojas y una bolsa." },
    "ui.tarea.tocar": { "es": "Tocar la pila", "soloTexto": true }
  },
  "objetos": [
    { "id": "pila", "nombre": "Pila de restos", "tipo": "hotspot", "modelo": "Pila" },
    { "id": "pieza", "nombre": "Pieza para girar", "tipo": "objeto", "modelo": "Pieza", "etiqueta": "Pieza" }
  ],
  "secciones": [ { "id": "inicio", "titulo": "Inicio", "desde": "p1" } ],
  "pasos": [
    { "id": "p1", "titulo": "Bienvenida", "tipo": "narracion", "intro": ["intro.bienvenida"] },
    { "id": "p2", "titulo": "Tocar la pila", "tipo": "tocar", "condicion": { "objeto": "pila" },
      "instruccion": "p2.instr", "pista": "p2.pista", "exito": "p2.exito", "retrasoPista": 10,
      "tarea": true, "etiquetaTarea": "ui.tarea.tocar", "ancla": "pila", "senalar": "pila", "activos": ["pila"] }
  ]
}
```

### 3.1 `experiencia`

| Clave | Obligatoria | Qué es | A dónde va en Unity |
|---|---|---|---|
| `id` | sí | Identificador estable, en minúsculas, letras, números y guiones. Nombra la carpeta `Assets/Experiencias/<id>/` y la `LineLibrary`. | Carpeta y nombres de assets |
| `titulo` | sí | Lo que ve la persona | `SimulationSequence.sequenceName` |
| `descripcion` | no | Para quien lee el guion | `SimulationSequence.description` |
| `escena` | sí | Nombre de la escena Unity (la crea quien coloca; debe estar en Build Settings) | `ExperienceSceneMap.Entry.sceneName` |
| `clave` | no | Id de texto de la experiencia en el backend (cuid). Vacía en mock. | `ExperienceSceneMap.Entry.experienceKey` |
| `idHeredado` | no | Id numérico de v0.5.1 (el mock usa `10`) | `ExperienceSceneMap.Entry.experienceId` |
| `modo` | sí | `guiado` o `evaluacion` | `SimulationSequence.mode` (`SimulationMode.Guided` / `Evaluation`) |
| `idiomas` | no | Idiomas de las frases; por defecto `["es"]`. Solo `es` y `en` (los de `CoachLanguage`). | Variantes de cada `VoiceLine` |

`coach.nombre` (opcional, «Coach») va a `LineLibrary.speakerName`.

### 3.2 `lineas`

Un diccionario id → frase. Cada frase tiene un texto por idioma (`es`, `en`), y opcionalmente `nota` (para quien escribe; no se muestra), `soloTexto` (etiquetas y títulos que no se dicen; el horneador las salta) y `dicho` (texto para el TTS cuando difiere del subtítulo, por idioma). Va a `LineLibrary.lines`: `VoiceLine.id`, `note`, `textOnly`, `variants[].text`, `variants[].spokenText`. El clip y el `bakeHash` los pone el horneador después y el importador los conserva (3.6).

Convención de ids: `<paso>.<papel>` (`p2.instr`, `p2.pista`, `p2.exito`, `p2.err.<clave>`) y `ui.<cosa>` para lo que solo se muestra. La parte `<paso>.<papel>` es convención; lo que el validador y el esquema sí exigen es que cada id use solo letras, números, punto, guion y guion bajo (patrón `^[a-zA-Z0-9][a-zA-Z0-9._-]*$`), sea único y exista cuando se referencia. Cada frase trae al menos un texto (`es` o `en`); si falta el de un idioma declarado en `experiencia.idiomas`, es aviso (3.7), no error.

### 3.3 `objetos`

Lo que la experiencia nombra: cosas que se tocan, se señalan o se giran. Cada uno tiene `id`, `nombre` (para la persona), `tipo` (`objeto` u `hotspot`), `modelo` (nombre del prefab que entregan los modeladores, opcional) y `etiqueta` opcional (el `tag` de Unity que usan algunas condiciones; si falta y una condición lo necesita, el importador usa el `id`). Las zonas no son objetos del guion: se declaran en la colocación (4), porque son espacio, no contenido.

El guion no dice dónde están: eso es la colocación. En Unity, el importador de colocación crea cada objeto con un `SceneTarget` cuyo `targetId` es el `id`, y los `hotspot` además con un `TouchableHotspot` cuyo `interactionId` es el `id`, que es lo que la condición `tocar` escucha (3.4).

**0.2 (`contrato-0.2.md` §4):** cinco tipos de objeto más (`agarrable`, `fuente`, `superficie`, `boton`, `herramienta`), con sus campos opcionales (`herramienta`, `recorrido`, `segundos`, `herramientas`), para las interacciones que el runtime ya tiene.

### 3.4 `pasos`

Lista ordenada. Claves comunes a todos:

| Clave | Obligatoria | A dónde va |
|---|---|---|
| `id` | sí, única | `StepDefinition.stepId`; nombre del asset `Pasos/<id>.asset` |
| `titulo` | no | `StepDefinition.titleText` |
| `descripcion` | no | `StepDefinition.description` |
| `tipo` | sí | Decide `StepDefinition.stepType` y la `StepCondition` (tabla siguiente) |
| `intro` | no | Lista de ids de frase → `introLines` |
| `instruccion`, `pista`, `exito` | no | `instructionLine`, `hintLine`, `successLine` |
| `retrasoPista` | no (10) | `hintDelay` |
| `errores` | no | Diccionario clave → id de frase → `errorLines` |
| `errorPorDefecto` | no | `defaultErrorLine` |
| `repetirInstruccionTrasError` | no (false) | `repeatInstructionAfterError` |
| `tarea`, `etiquetaTarea` | no | `countsAsTask`, `taskLabel` (id de frase o texto plano, como hoy) |
| `ancla`, `senalar`, `activos` | no | `coachAnchorId`, `pointAtTargetId`, `activeTargetIds` (ids de objetos del guion; `ancla` es un id de ancla de la colocación) |
| `tiempoMaximo`, `puntos`, `penalizacion` | no (60, 0, 0) | `maxAllowedTime`, `scoreOnSuccess`, `penaltyOnError` (solo cuentan con la regla `TimeBased`, que «Preparar escena» deja si algún paso los trae) |
| `esperaCierreManual` | no (false) | `waitForManualCompletion` |
| `condicion` | según `tipo` | La `StepCondition` del paso, `Condiciones/<id>.asset` |

Tipos de paso en 0.1 y la condición que generan. Son los que se pueden recorrer en el Editor en modo plano con ratón y teclado, que es el criterio de «funcional» de esta etapa. Soltar, sostener, apuntar y frotar tampoco necesitan el visor: `FlatInteractionDriver` ya los recorre con el ratón y sus condiciones existen (F3 de v0.6.0). Entran en 0.2 como `llevar`, `frotar`, `mantener` y `apuntar`, y `elegir` gana una forma por objeto (`opciones`); el diseño, las claves y las reglas están en [`contrato-0.2.md`](contrato-0.2.md) §6, y lo que entra o no en `contrato-0.2.md` §1 y §2.

| `tipo` | `stepType` | `StepCondition` | `condicion` |
|---|---|---|---|
| `narracion` | `NonInteractive` | ninguna | no lleva |
| `tocar` | `Interaction` | `TouchableHotspotCondition` (`interactionId` = `objeto`), **nueva en este lote** (3.4.1) | `{ "objeto": "<id de objeto tipo hotspot>" }` |
| `elegir` | `Interaction` | `KeyChoiceStepCondition` (`correctKey`, `errorKey`/`errorKeyId`, `warningKey`/`warningKeyId`) | `{ "correcta": "1", "error": { "tecla": "2", "clave": "mal" }, "aviso": { "tecla": "3", "clave": "cuidado" } }`; las claves deben existir en `errores` del paso |
| `manual` | `Interaction` | `ManualKeyStepCondition` (`completeKey`) | `{ "tecla": "espacio" }` (por defecto espacio) |
| `tiempo` | `Interaction` | `ElapsedTimeStepCondition` (`secondsToComplete`) | `{ "segundos": 3 }` |
| `girar` | `Interaction` | `RotationTrackingCondition` (`targetTag`, `requiredAngleDegrees`) | `{ "objeto": "<id>", "grados": 360 }`; `targetTag` = `etiqueta` del objeto o su `id` |

Teclas admitidas en `elegir` y `manual`: `"1"` a `"9"`, `"espacio"`, `"enter"`, letras `"a"` a `"z"`. El mapeo a `KeyCode` es una función pura con test. `KeyChoiceStepCondition` nació como condición de demo (su menú dice «(demo)»); aquí se usa a propósito como la forma de elegir en modo plano, y en 0.2 `elegir` tendrá además una condición de elección por interfaz o por objeto en el visor, sin cambiar el guion.

#### 3.4.1 `TouchableHotspotCondition`, el puente que faltaba

Hoy el único camino para `tocar` era `HotspotTouchCondition`, que consulta el `HotspotRegistry` que llenan los `HotspotMarker`; y los `HotspotMarker` solo se disparan por el trigger de un interactor XR. En modo plano, el `FlatInteractionDriver` solo raycastea `InteractableBase` y, al pulsar un `TouchableHotspot`, llama a `Touch()`, que dispara `Activated`; nadie escuchaba eso desde una condición (`TouchableHotspot.cs` lo anuncia como pendiente, «F7»). Así que un paso `tocar` no se podía completar con el ratón, que es el criterio de funcional de esta etapa.

La pieza nueva, en `Runtime/Interactions/Conditions/TouchableHotspotCondition.cs` (assembly `XRLabs.Interactions`, que ya referencia XRI y `XRLabs.Core`): una `StepCondition` con `[SerializeField] string interactionId`. `Initialize` busca los `TouchableHotspot` de la escena cuyo `InteractionId` coincide (por el `InteractableRegistry` si ofrece búsqueda por id; si no, `FindObjectsByType`), les llama `ResetHotspot()` para que `oneShot` no bloquee un paso repetido, y se suscribe a `Activated`; `IsCompleted` devuelve verdadero tras la primera activación; `Cleanup` se desuscribe. Si al iniciar no hay ninguno, lo reintenta con el mismo throttle que `RotationTrackingCondition` (0,5 s), porque el objeto puede instanciarse después. Funciona igual en el visor (hover-touch o select del XRI) y en pantalla (clic del driver plano), y no toca `HotspotMarker` ni `HotspotTouchCondition`, que siguen para Fallas de Brocas (D8). Menú: `XR Simulation/Conditions/Touchable Hotspot`. Dos tests PlayMode en `Tests/Runtime` (`Touch` del id esperado completa; `Touch` de otro id no), que suben `PLAYMODE_TESTS` de 53 a 55.

### 3.5 `secciones`

Lista de `{ "id", "titulo", "desde" }` donde `desde` es el id del primer paso de la sección. Va a `SimulationSequence.sections` (`sectionName` = `titulo`, `startStepIndex` = índice de ese paso). Opcional.

### 3.6 Qué genera el importador del guion, y cómo vuelve a importar

Carpeta `Assets/Experiencias/<id>/` (el importador la crea):

```
Pasos/<pasoId>.asset            StepDefinition, uno por paso, en el orden del guion
Condiciones/<pasoId>.asset      StepCondition del tipo que pide el paso (no la hay en narracion)
Secuencias/<id>.asset           SimulationSequence con los pasos en orden y las secciones
Frases/<id>.asset               LineLibrary con todas las lineas
```

y la entrada en `Assets/Resources/ExperienceSceneMap.asset` (lo crea si no existe) con `clave`, `idHeredado` y `escena`.

Reglas de la reimportación, que es lo que hace que el fichero sea la fuente de verdad:

- **El asset de cada paso, condición y secuencia se busca por su ruta** (`Pasos/<pasoId>.asset`). Si existe, se actualiza en el mismo objeto: el GUID no cambia y nada que lo referencie se rompe. Si no existe, se crea. Si un paso desaparece del guion, su asset y su condición **se borran** y el informe lo dice.
- **Las frases se funden por id.** Texto, `dicho`, `nota` y `soloTexto` se sobrescriben desde el guion; `clip` y `bakeHash` de cada variante se conservan (el horneador decide, por el hash, si el clip sigue valiendo). Una frase que ya no está en el guion se quita de la biblioteca y el informe la lista; su fichero de audio, si existía, no se toca.
- **Un `StepDefinition` cuyo `tipo` cambia** conserva el asset y cambia la condición: la vieja se borra, la nueva se crea en la misma ruta.
- **Fuera de `Assets/Experiencias/<id>/` el importador del guion solo toca dos cosas:** el `ExperienceSceneMap` de `Resources`, y los **tags** que piden los pasos `girar` (la `etiqueta` del objeto o su `id`): si el tag no existe en el proyecto, lo añade con `InternalEditorUtility.AddTag` y lo informa, porque `RotationTrackingCondition` busca por tag y en un proyecto nuevo (`Host~` incluido) la lista de tags está vacía. Es la misma acción que haría la persona en Project Settings; se registra como provisional hasta que el dueño la ratifique. El importador no abre escenas ni toca `Build Settings`.
- Todo el trabajo va dentro de un `AssetDatabase.StartAssetEditing()`/`StopAssetEditing()` y termina con `SaveAssets`.

El importador devuelve un `ImportReport`: listas de creados, actualizados, borrados y avisos, con una línea por asset. La ventana lo muestra; los tests lo leen.

### 3.7 Validación, antes de tocar nada

`GuionValidator.Validate(GuionDocument) → List<ValidationIssue>` (pura, sin Unity). Errores, que impiden importar: `esquema` distinto de `xrlabs.guion/0.1`; `experiencia.id` vacío o con caracteres fuera de `[a-z0-9-]`; ids de paso duplicados; id de frase referenciado que no existe en `lineas`; id de objeto referenciado (`condicion.objeto`, `senalar`, `activos`) que no existe en `objetos`; `tipo` desconocido; `condicion` ausente en un tipo que la pide, o `objeto` de `tocar` que no es un `hotspot`; clave de `elegir` sin frase en `errores`; tecla no admitida; `desde` de una sección que no es un paso. Avisos, que dejan importar: frase sin texto en algún idioma declarado; frase definida y nunca referenciada; paso `Interaction` sin `instruccion`; `modelo` vacío en un objeto.

## 4. La colocación (`xrlabs.colocacion/0.1`)

```json
{
  "esquema": "xrlabs.colocacion/0.1",
  "experiencia": "experiencia-cero",
  "entorno": { "glb": "SalaCero.glb", "unidades": "m", "ejes": "gltf" },
  "inicio": { "pos": [0, 0, 0], "giro": 0 },
  "anclas": [ { "id": "pila", "pos": [1.2, 0, 1.8], "giro": 200, "mirarUsuario": true } ],
  "objetos": [ { "id": "pila", "pos": [1.0, 0, 2.5], "giro": 0, "escala": 1 } ],
  "zonas": [ { "id": "frente-pila", "tipo": "teleport", "pos": [1.0, 0, 1.2], "tamano": [1.0, 1.0], "giro": 0 } ]
}
```

- `experiencia` tiene que ser el `id` del guion. Los `id` de `objetos` tienen que existir en `objetos` del guion; los de `anclas` se declaran aquí, únicos, y son los que los pasos nombran en `ancla`; los de `zonas` se declaran aquí, únicos. `entorno.glb` y `entorno.fbx` documentan qué entregaron los modeladores (del mismo `.blend`, D21): el importador no los lee ni los importa en 0.1; están para la web y para quien coloca.
- `pos` es `[x, y, z]` en metros y en los **ejes del GLB** (glTF: Y arriba, mano derecha, +Z hacia el espectador). `giro` es la rotación alrededor de Y en grados, en el mismo sistema. `tamano` de una zona es `[ancho, largo]` en el suelo; su altura es fija, 0,1 m (una losa).
- **Conversión a Unity (D21):** Unity es Y arriba y mano izquierda, así que `x_unity = -x`, `y_unity = y`, `z_unity = z`, y `giro_unity = -giro`. Es una función pura con test, y la **comprobación real la da el fixture de los modeladores** (sección 6): hasta que el cubo del fixture caiga en el mismo sitio en la web y en Unity, esta regla es provisional y se corrige en un solo lugar.

### 4.1 Qué genera el importador de colocación

Trabaja sobre un `Transform` raíz que le pasa quien lo llama (la ventana usa, en la escena abierta, un objeto `[Colocacion]` que crea si falta; los tests pasan uno propio). Debajo, por id y de forma idempotente (busca el hijo por nombre; si existe lo actualiza, si no lo crea; lo que ya no está en el fichero se borra y se informa):

| Del fichero | Objeto en la escena | Componentes |
|---|---|---|
| `inicio` | `Inicio` | `SceneTarget` (`targetId` = `inicio`). El rig XRI del lote siguiente lo usará como punto de aparición. |
| `anclas[]` | `Ancla_<id>` | `CoachAnchor` (`anchorId` = id, `faceUser` = `mirarUsuario`) |
| `objetos[]` | `Objeto_<id>` | `SceneTarget` (`targetId` = id). Si `modelo` nombra un prefab que existe en `Assets/Experiencias/<id>/Modelos/<modelo>.prefab` (o en cualquier `Resources`), se instancia como hijo; si no, un hijo `Placeholder`: un cubo de 0,3 m **con `BoxCollider`**, para que se vea dónde va y para que el rayo lo encuentre. Si el guion lo declara `hotspot`, el objeto lleva además `TouchableHotspot` (`interactionId` = id; `XRSimpleInteractable` llega solo por `RequireComponent`) y necesita un collider en su jerarquía: el del placeholder, o el del prefab si lo trae (si el prefab no trae ninguno, se agrega un `BoxCollider` ajustado a sus renderers y se informa). Si el objeto tiene `etiqueta` (o un paso `girar` lo usa), se le pone ese `tag`, que el importador del guion ya habrá creado (3.6); si no existe, aviso. |
| `zonas[]` | `Zona_<id>` | `SceneTarget` (`targetId` = id) y un `BoxCollider` **sólido** de `tamano` × 0,1 m de alto (un suelo, no un muro: X2, 2026-10-10) con `TeleportationArea` de XRI en la capa `Teleport`, que el rig de `Runtime/MenuXRI` usa para teleportar. |

Todos los campos privados (`anchorId`, `faceUser`, `targetId`, `interactionId`) se escriben con `SerializedObject`, como lo haría el Inspector, para no tocar el runtime (D8). El importador marca la escena abierta como modificada (`EditorSceneManager.MarkSceneDirty`) y no la guarda; la ventana la guarda al terminar «Importar colocación», para que la persona no tenga que acordarse.

**El entorno de una muestra (2026-10-25).** Si la muestra trae `Samples~/<muestra>/Entorno/` (`Modelos/*.fbx` y `Texturas/*.png` del arte del equipo, sin `.meta` ni `.mat`), «Preparar escena» (`EntornoBuilder`, una línea en `ScenePreparer.Prepare`) lo copia a `<assetsRoot>/<id>/Entorno/Arte/`, arma `<assetsRoot>/<id>/Entorno/Entorno.prefab` con materiales URP Lit propios (`Entorno/Materiales/`) y lo instancia una vez como raíz suelta `Entorno`, fuera de `[Colocacion]`, como el terreno.
Las piezas se colocan en código, en ejes glTF de la colocación, centradas por su caja y con la base a 0 (los FBX del artista no estaban en el origen); el prefab se rehace en cada preparación y no lleva colliders ni sombras en tiempo real.
Regla: el entorno no pisa las zonas, los recuadros de teletransporte ni las huellas de las zonas A–D (lo comprueba `EntornoCompostajeTests`); cuando llegue `CampoCompostaje.fbx`, el suelo del prefab se retira y la planta queda como telón.

### 4.2 Validación

`ColocacionValidator.Validate(ColocacionDocument, GuionDocument)`: `esquema`; `experiencia` igual al `id` del guion; ids de `objetos` existentes en el guion; ids de `zonas` y `anclas` únicos; `pos` de tres números; `tamano` de dos positivos; `anclas` que los pasos referencian y no existen → error; objetos del guion sin colocación → aviso.

## 5. La ventana `Tools/XRLabs/Autoría`

Lo único de Unity que ve la persona. Tres partes:

1. **Guion:** campo de ruta al `guion.json` (botón para elegir), botón **Validar** (lista de errores y avisos) y botón **Importar guion** (deshabilitado con errores). Debajo, el informe de la última importación.
2. **Colocación:** ruta al `colocacion.json`, **Validar** e **Importar colocación** (deshabilitado si no hay escena abierta o el guion no se ha importado). Informe.
3. **Voces:** una línea con «faltan N voces en `<idioma>`» calculada sobre la `LineLibrary` de la experiencia (variantes sin clip y no `soloTexto`) y un botón **Abrir biblioteca de frases** que selecciona el asset, donde ya está el horneador (D5). El botón de un solo clic para hornear queda para el lote A2.

La ventana no tiene lógica propia: llama a los validadores e importadores. Sin tests de interfaz; los tests cubren lo que hay debajo.

## 6. El fixture de coordenadas para los modeladores (Blender)

Para fijar la conversión de 4 de una vez y no por ensayo. Pedido a los modeladores, a entregar en `Tests/Editor/Authoring/Fixtures/FixtureCoordenadas/` (dentro de `Tests/`, que Unity sí importa, para que el test pueda leer el FBX como asset; con sus `.meta`):

- Un `.blend` con una sala de 4 × 4 m (piso y cuatro paredes de 2,5 m, origen en el centro del piso) y un cubo de 0,5 m de lado, con su origen en la base, en la posición Blender `(1.0, 2.0, 0.0)`, es decir 1 m a la derecha y 2 m hacia el fondo, apoyado en el piso, y girado 30° alrededor de Z. Nombres de objeto: `Sala`, `CuboMarca`. Unidades métricas, escala 1.
- Exportado dos veces desde ese mismo fichero, sin mover nada: `FixtureCoordenadas.glb` (glTF 2.0, `+Y arriba` activado, que es el valor por defecto del exportador) y `FixtureCoordenadas.fbx` (ajustes por defecto de Blender para Unity: `-Z adelante, Y arriba`, escala 1, «Apply Unit»).
- Una captura del viewport desde arriba con los ejes visibles.

Con eso, el test `FixtureCoordenadas_ElCuboCaeEnElMismoSitio` carga el FBX como asset (`AssetDatabase.LoadAssetAtPath<GameObject>`), lee la posición y el giro del hijo `CuboMarca`, y los compara con la conversión de 4 aplicada a `translation` y `rotation` del nodo `CuboMarca` del GLB. El GLB se lee sin ningún paquete glTF: es un fichero binario con una cabecera de 12 bytes y un primer trozo JSON (longitud y tipo `JSON` en 8 bytes más), que se parsea con Newtonsoft; `nodes[].translation` y `nodes[].rotation` están ahí (un lector mínimo, `GlbJson.ReadNodes(path)`, con su test sobre un GLB de dos nodos escrito a mano en el test). Si no coinciden, cambia la función de conversión, no el fixture. Hasta que llegue el fixture, el test se marca `[Explicit]` y la regla de 4 es provisional.

## 7. La experiencia cero

`Samples~/ExperienciaCero/guion.json` y `colocacion.json`: cinco pasos sobre separar residuos (bienvenida narrada, tocar la pila, elegir el contenedor con las teclas 1 y 2 y una línea de error que explica, esperar tres segundos mientras el coach cierra la idea, y despedida), tres objetos (`pila`, `organico`, `inorganico`), dos anclas y dos zonas de teleportación. Todas las frases en `es` y `en`. Es el fixture de los tests del importador y lo que el dueño recorre en el Editor.

Recorrido esperado en el Editor, en modo plano y con login mock. En A1 la persona **todavía** hace tres cosas a mano que D19 quiere quitar, y son las fricciones medidas que A2 resuelve con un botón «Preparar escena»: crear la escena `ExperienciaCero` con el `[Simulation]` del tutorial (parte 2), añadirla a Build Settings (D9), y asignar la secuencia al `StepSystem`. Lo demás ya no pasa por el Inspector: abrir la ventana, importar guion, importar colocación (la ventana guarda la escena), Play desde `Menu`. El registro de fricciones de ese recorrido es el resultado del experimento.

## 8. Lo que queda fuera, a propósito

- La web de edición y de colocación: edita estos ficheros; llega cuando el importador genere escena (orden del dueño: contrato primero).
- Los tipos de paso `llevar`, `frotar`, `mantener` y `apuntar` ya no quedan fuera: no necesitan el visor y entran en 0.2 (`contrato-0.2.md`). Sigue fuera la evaluación por casos, y con ella todo lo que `contrato-0.2.md` §2 deja fuera (ciclos, variables, medidor de progreso, condición compuesta).
- El botón de hornear voces de un clic y «Preparar escena»: lote A2.
- Importar el GLB en Unity: los modeladores entregan también el FBX (D21); un paquete glTF en el framework es decisión del dueño.
- El esquema de la hoja de cálculo: la web lo hará innecesario; mientras, el guion se escribe en JSON con el esquema como ayuda del editor de texto.

## 9. Reparto del trabajo (D16)

- **Sesión principal:** esta página, los esquemas, la experiencia cero, las decisiones, los `.meta` de carpetas y asmdef, la integración, el sello y la documentación de estado.
- **Agente A (`xrlabs-core`):** `Editor/Authoring/GuionDocument.cs`, `GuionValidator.cs`, `GuionImporter.cs`, `KeyNames.cs`, `AuthoringWindow.cs` y `Tests/Editor/Authoring/GuionValidatorTests.cs`, `GuionImporterTests.cs`; más la condición nueva `Runtime/Interactions/Conditions/TouchableHotspotCondition.cs` con sus dos tests PlayMode en `Tests/Runtime/TouchableHotspotConditionTests.cs`.
- **Agente B (`xrlabs-core`):** `Editor/Authoring/ColocacionDocument.cs`, `ColocacionValidator.cs`, `ColocacionImporter.cs`, `GltfToUnity.cs`, `GlbJson.cs` y `Tests/Editor/Authoring/ColocacionImporterTests.cs`, `GltfToUnityTests.cs`, `GlbJsonTests.cs`, `FixtureCoordenadasTests.cs` (`[Explicit]` hasta que llegue el fixture).
- **Lector (`xrlabs-core-lector`):** revisa esta página contra el código antes de que arranquen A y B.

Contrato entre A y B, para que la ventana (A) llame a B sin esperarlo:

```csharp
namespace XRLabs.Authoring.Editor
{
    public sealed class ImportReport { List<string> Created, Updated, Deleted, Warnings; bool HasErrors; string Summary(); }
    public sealed class ValidationIssue { bool IsError; string Path; string Message; }
    public static class GuionDocument  { static GuionDocument Load(string path); static GuionDocument Parse(string json); }
    public static class GuionValidator { static List<ValidationIssue> Validate(GuionDocument doc); }
    public static class GuionImporter  { static ImportReport Import(GuionDocument doc, string assetsRoot = "Assets/Experiencias"); }
    public static class ColocacionDocument  { static ColocacionDocument Load(string path); static ColocacionDocument Parse(string json); }
    public static class ColocacionValidator { static List<ValidationIssue> Validate(ColocacionDocument doc, GuionDocument guion); }
    public static class ColocacionImporter  { static ImportReport Import(ColocacionDocument doc, GuionDocument guion, Transform root, string assetsRoot = "Assets/Experiencias"); }
    public static class GltfToUnity { static Vector3 Position(float x, float y, float z); static Quaternion Yaw(float degrees); }
    public static class GlbJson { static IReadOnlyList<GlbNode> ReadNodes(string path); }   // GlbNode: Name, Translation (float[3] o null), Rotation (float[4] o null)
}
```

Y una regla sobre borrar: cuando un paso desaparece del guion, su `StepDefinition` y su condición se borran. Las escenas de los consumidores referencian la `SimulationSequence`, no los pasos, así que no se rompe nada que siga el tutorial; si un consumidor referenciara un paso suelto desde una escena, es su decisión y el informe de importación lo avisa listando lo borrado.

(`GuionDocument` y `ColocacionDocument` son clases de datos con esos métodos estáticos de carga; el pseudocódigo solo fija nombres y firmas.)

## 10. Lote A2: «Preparar escena» y voces de un clic (2026-10-10, estación Windows)

Lo arrancó el dueño al irse: «sigue avanzando con el desarrollo todo lo que puedas, con los siguientes módulos». Quita las tres fricciones que §7 dejó a mano y pone el horneado de voz a un clic desde la ventana. Mismo método que A1.

### 10.1 «Preparar escena»

`ScenePreparer.Prepare(GuionDocument guion, string assetsRoot = "Assets/Experiencias") → ImportReport`, en `Editor/Authoring/ScenePreparer.cs`. Precondición: el guion ya importado (existen `Secuencias/<id>.asset` y `Frases/<id>.asset`); si no, error en el informe y no toca nada. Idempotente: cada objeto y componente se busca antes de crearse, y las referencias se reescriben siempre.

1. **La escena**, en `<assetsRoot>/<id>/Escenas/<experiencia.escena>.unity`. Si no existe: `EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single)` y guardar en esa ruta (antes, `SaveCurrentModifiedScenesIfUserWantsTo`, para no perder lo que la persona tuviera abierto). Si existe, se abre (`OpenScene`, Single).
2. **`[Simulation]`** con `SimulationManager` (`simulationMode` según `experiencia.modo`; `stepSystem`, `scoringSystem`, `telemetryClient` apuntando a los del mismo objeto), `StepSystem` (`sequence` = la secuencia importada), `ScoringSystem` (desde el 2026-10-25, regla `TasksErrorsHints`, la del coach; `TimeBased` si algún paso trae `puntos` o `penalizacion`), `TelemetryClient`, `VOManager` (`lineLibraries` = `[la biblioteca importada]`; su `AudioSource`: `playOnAwake` apagado, `spatialBlend` 0), `HintSystem`, `FeedbackSystem`. Como en `Editor/CoreSimulationDemoSetupEditor.cs`, pero sin el HUD de demo. Campos privados con `SerializedObject`.
3. **`[Session]`** con `SessionManager`: `mainMenuScene` = `Menu`, `nextScene` vacío, `navigateOnEnd` = no `experiencia.cierrePropio` (clave nueva, opcional, por defecto `false`; se añade a `Schema/guion.schema.json` y a `GuionDocument.ExperienceInfo` como `OwnEnding`; D8: vacía, comportamiento de siempre).
4. **`[Colocacion]`** vacío, para que «Importar colocación» tenga raíz y no dependa del orden.
5. **Modo plano en el Editor:** la `Main Camera` de la escena nueva a 1,6 m de alto en el `inicio` (si hay colocación importada, en `Inicio`; si no, en el origen), y lo que `Runtime/Platform` ofrezca para el modo plano sin rig XR (leer `Documentation~/platform-support.md` y `FlatInteractionDriver`): se agrega lo mínimo para que el clic del ratón llegue a los `TouchableHotspot`. Si eso exige el rig XRI (lote aparte), se deja la cámara sola y se informa.
6. **`Assets/Config/ApiSettings.asset`** (el `ApiSettings` de `Runtime/Networking`) con `useMockData` encendido, si no existe; si existe no se toca. Es lo que el `Menu` necesita para el login mock.
7. **Build Settings:** la escena `Menu` del paquete (`Packages/com.xrlabs.core/Runtime/Menu/Menu.unity`) en el índice 0 si no está ninguna `Menu`; la escena de la experiencia después, si no está. Nunca se quita ni se reordena lo que ya hay.
8. Guardar la escena y `SaveAssets`. Informe con cada cosa creada o actualizada.

**Desde el lote A4 (2026-10-10) también pone al coach:** una raíz `[Coach]` con el holograma del paquete (instancia de `HologramCoach.prefab`), el `CoachDirector` enlazado al `StepSystem`, a la presencia y a la cámara, y el `StepTargetHighlighter`. Es idempotente como el resto; el detalle está en `contrato-0.2.md` §8.

**Regla de las zonas `soltar` (2026-10-18):** en modo plano el objeto se arrastra en un plano horizontal a la altura a la que estaba, así que una zona que no empiece en el suelo (por ejemplo el centro de una pila de 1,5 m) es inalcanzable en pantalla; toda zona `soltar` para objetos que están en el suelo empieza en `y = 0` y sube con `alto` hasta donde el modelo lo pida. En el visor, con la mano, la columna también vale.

**Lo que el recorrido del 2026-10-17 añadió a la colocación («no sé qué hacer en este paso»):** sin modelo, cada marcador lleva una etiqueta (`Etiqueta`: TextMeshPro 3D con el `nombre` del guion, `FaceCamera` para que mire a la persona) y se quita cuando llega el modelo; cada zona `soltar` lleva un recuadro en el suelo (`Suelo`: Quad del tamaño de la zona, sin collider) y su etiqueta con el id legible (`ColocacionImporter.Humanize`); los teleport no se dibujan. En el guion, un `llevar` sin `activos` resalta los objetos **y las zonas** de su condición (las zonas son `SceneTarget`), y la muestra de compostaje añade `acopio` y `centro` a los activos de COMP-02 y COMP-05 para que el anillo marque también el destino (el validador acepta en `activos` las zonas de la condición de un `llevar`).

**Desde el 2026-10-25 también pone `[ApiTelemetry]`:** un objeto raíz con el `ApiTelemetryBridge` solo, lo que `SessionManager` necesita para abrir la sesión, mandar los errores y avisos de los pasos y cerrarla en el cliente del API (`telemetria-extremo-a-extremo.md`, «Actualización del 2026-10-25»). En su propia raíz y no en `[Session]` ni en `[Platform]`: el bridge hace `DontDestroyOnLoad` de su objeto (solo vale en una raíz) y, en el segundo intento, destruye su objeto entero. Nada que enlazar: `ApiClient`, `AuthManager` y `AppState` vienen del `Menu`. Sin `ApiClient` (escena abierta sin el `Menu`) o con `useMockData`, el bridge manda todo a `MockApiClient`, sin red. Si la escena ya tiene un bridge (también puesto a mano en otro objeto raíz) no se agrega otro; si está dentro de otro objeto, el informe avisa. Tests `ApiTelemetry_IsARootWithTheBridgeAlone_OutsideSessionAndPlatform_AndIsSaved`, `PreparingTwice_LeavesASingleBridge_AndRespectsOneAddedByHand` y PlayMode `SessionTelemetryMockTests`.

**Desde el 2026-10-18 también pone `[Debug]`:** `SimulationDebugger` y `SimDebugHUD` de `Runtime/Debug` (los de `Tools/XR Simulation/Setup Sim Debugger Scene`), enlazados al `StepSystem`, al `SimulationManager` y al `ScoringSystem`: F1 panel con el paso en curso y el siguiente, F2 completar, F4 saltar, F7 registro. IMGUI: solo en pantalla.

**Desde el 2026-10-17 también pone el HUD:** una raíz `[HUD]` con un canvas de pantalla y el `SubtitlePanel` del paquete (`Runtime/Simulations/UI`), con el grupo, los dos textos y el acento enlazados, e Intro para saltar la frase (Espacio es «Comenzar» en los pasos `manual`). Lo destapó el primer recorrido de la muestra de compostaje en el Mac: sin voces horneadas el coach habla con duración estimada y, sin panel, no se veía ni se oía nada. Construcción en `Editor/Authoring/SubtitleHudBuilder.cs` (la misma que la demo del coach, sin la checklist); si `[HUD]` ya trae un `SubtitlePanel` no se reconstruye (desde el 2026-10-25 solo pasa a los tamaños del visor si conserva los de antes; test `RePreparing_AHudWithTheOldScreenSizes_MovesItToTheHeadsetSizes_AndRespectsCustomOnes`). El mismo `[HUD]` trae el botón **Comenzar** de los pasos `manual` (`Runtime/Simulations/UI/ManualStepButton.cs`: visible cuando el paso ya escucha (fase `Active`, no durante la introducción) y su condición es `ManualKeyStepCondition`; el clic la completa con `Complete()`, la tecla sigue valiendo; se oculta con su `CanvasGroup`, nunca apagando el objeto; siempre reenlazado al `StepSystem`; test PlayMode `ManualStepButtonPlayTests`) y un `EventSystem` con el módulo del Input System, porque el segundo recorrido oyó «pulsa Comenzar» y no había nada que pulsar. Desde el 2026-10-25 (primera corrida en un Quest 3) el canvas trae también el **panel de desarrollo** (`Runtime/Simulations/UI/DevStepPanel.cs`, uGUI, arriba a la izquierda, solo en el Editor y en builds de desarrollo; fuera de ellas se oculta con su `CanvasGroup` y no escucha nada): «Paso n de m · id · título [fase]», el paso siguiente y cuatro botones que el rayo del mando pulsa (◄ Anterior, Saltar frase, Completar paso, Siguiente ►), el equivalente en el visor del `SimDebugHUD`, que es IMGUI y allí no existe. Atajos de mando: **B** (secundario derecho) completa el paso e **Y** (secundario izquierdo) salta la frase; `SubtitleHudBuilder.EnsureDevPanel` lo crea una vez y en cada preparación solo lo reenlaza al `StepSystem` (tests `Hud_HasTheDevPanel_WiredToTheStepSystem_WithFourButtons` y `DevStepPanelPlayTests`).

Ventana: botón **Preparar escena** en la sección del guion, habilitado tras una importación sin errores. Tras prepararla, «Importar colocación» usa el `[Colocacion]` de esa escena.

Tests EditMode (`Tests/Editor/Authoring/ScenePreparerTests.cs`): importa el guion de la muestra en una carpeta temporal y prepara la escena: existe el `.unity` en la ruta; `[Simulation]` trae los siete componentes con la secuencia y la biblioteca asignadas (leer con `SerializedObject`); `[Session]` con `Menu` y `navigateOnEnd` según `cierrePropio` (dos casos); `[Colocacion]` existe; `ApiSettings` creado con mock si faltaba y no sobrescrito si existía; Build Settings tiene `Menu` en 0 y la escena después, y se restauran en `TearDown` (guardar `EditorBuildSettings.scenes` antes); preparar dos veces no duplica objetos ni componentes. Un guion no importado da error y no crea la escena. La escena temporal se cierra y borra en `TearDown`.

### 10.2 «Generar voces que faltan»

`VoiceBakeRunner` en `Editor/Authoring/VoiceBakeRunner.cs`, sobre el horneador existente (`Editor/Voice`, D5): `static BakePlan PlanMissing(LineLibrary library, VoiceSettings settings)` y `static bool TryStart(LineLibrary library, VoiceSettings settings, ITtsProvider provider, out string message)`. Reglas: si no hay `VoiceSettings` en `VoiceSettings.DefaultAssetPath`, se crea con los valores por defecto (como «Crear VoiceSettings» de `LineLibraryEditor`); si no hay clave del proveedor (`VoiceApiKeys.Has`), devuelve `false` con un mensaje en claro que dice dónde se pone (el inspector de `VoiceSettings`, botón «Ajustes», o la variable de entorno), **sin tocar la red**; con clave, lanza la sesión de horneado de las variantes sin clip y no `soloTexto` (`VoiceBakeSession`, como `LineLibraryEditor.RunBake`) y devuelve `true`. El proveedor real lo elige `settings.provider`; el parámetro `provider` existe para que los tests pasen `FakeTtsProvider`.

Ventana: la sección «Voces» muestra «faltan N voces en es, M en en» y el botón **Generar voces que faltan (N)**, deshabilitado mientras hay una sesión corriendo; debajo, el mensaje (sin clave, en curso, terminado con cuántos clips).

Tests EditMode (`Tests/Editor/Authoring/VoiceBakeRunnerTests.cs`, con `FakeTtsProvider` y `outputRoot` en una carpeta temporal): el plan de la biblioteca importada cuenta las variantes sin clip menos las `soloTexto`; sin clave, `TryStart` devuelve `false`, el mensaje nombra el proveedor y el proveedor falso no recibe llamadas; con el proveedor falso, hornear deja clips y `bakeHash` en las variantes y el plan siguiente queda en cero. La asmdef de autoría pasa a referenciar `XRLabs.Coach.Editor`.

**Dónde quedan las voces (2026-10-18):** una librería importada de un guion vive en `<experiencia>/Frases/`, y sus clips van a `<experiencia>/Voces/<es|en>/<id>.mp3` (en el anfitrión, `Assets/Experiencias/experiencia-compostaje/Voces/es/`), junto al resto de la experiencia: la carpeta se copia entera y lleva su voz. Cualquier otra librería sigue en `<raíz de salida>/<librería>/<es|en>` (`VoiceSettings.outputRoot`, por defecto `Assets/Voice`). Los clips ya horneados en la raíz siguen valiendo (la variante guarda la referencia); al volver a hornear una frase, el clip nuevo cae en `Voces/` y el viejo queda huérfano en la raíz. `VoiceBaker.GetClipFolder`; test `ImportedLibrary_BakesIntoTheExperienceVoicesFolder_NotTheOutputRoot`. Y la build del visor (`VisorBuilds.Build`) solo permite la voz incompleta cuando de verdad falta alguna voz en las escenas de la build, y lo dice en el registro con la cuenta; con las voces horneadas no la toca.

### 10.3 El fixture

Si `Tests/Editor/Authoring/Fixtures/FixtureCoordenadas/` ya tiene el FBX y el GLB, se quita la guarda `XRLABS_FIXTURE_COORDENADAS` y se corrige `GltfToUnity` si el cubo no coincide. Si no (2026-10-10: no ha llegado), se deja como está.

### 10.4 Lo que el código de A2 añadió o cambió respecto a este diseño (2026-10-10, al integrar)

- La asmdef de autoría referencia además `XRLabs.Networking` (`ApiSettings`) y `XRLabs.Platform` (`FlatInteractionDriver`).
- Modo plano sin rig: `FlatInteractionDriver` solo necesita una `Camera`, así que la `Main Camera` lleva el driver y un `OrbitCameraController` (clic derecho para mirar); sin `PlatformBootstrapper`, `FlatScreenLayout` ni `EventSystem`. La cámara plana queda también en un build de visor hasta el lote del rig XRI.
- `ApiSettings`: la escena `Menu` del paquete referencia el asset por el GUID `35d5b021ba32f794481c31931cd4198b`; para que el login mock funcione sin tocar la escena, el preparador escribe el `.asset` y su `.meta` con ese GUID si está libre (y cae a `CreateAsset` con aviso si no). Comprobado por el sello en `Host~`.
- Build Settings: insertar `Menu` en 0 desplaza índices pero conserva el orden relativo; si ya hay un `Menu` fuera del 0, solo avisa.
- `Prepare` acepta un tercer parámetro opcional, la ruta del `ApiSettings`, para que los tests no toquen `Assets/Config` del anfitrión; y vuelve a cargar la secuencia y la biblioteca por ruta después de crear la escena, porque los assets recién importados se reimportan al guardarla y la instancia cargada antes queda destruida (fallo visto en el sello, corregido en la integración).
- Ventana: botón «Ajustes de voz», barra de progreso con «Cancelar» y repintado mientras hornea; si `TryStart` falla, selecciona `VoiceSettings`. `VoiceBakeRunner.TryStart` tiene una sobrecarga con `hasApiKey` inyectable para los tests; con `provider` dado, la tanda la corre el propio ejecutor con `VoiceBaker` (la `VoiceBakeSession` no admite un proveedor ajeno).
- `Tools~/check.sh` exporta `PYTHONUTF8=1`: en Windows, el lector de resultados moría al imprimir «✗» y las tildes.

## 11. `Entorno/entorno.json`: la disposición del arte de una muestra (2026-10-25, réplica del web)

Si `Samples~/<muestra>/Entorno/` trae un `entorno.json` (`xrlabs.entorno/0.1`, clase `EntornoDisposicion`), `EntornoBuilder` arma el entorno **desde ese fichero** en vez del telón fijo de la muestra del INIA (que sigue igual sin él, D8). Es lo único que cambia de una muestra a otra; los FBX y las texturas van en la misma carpeta (`Modelos/*.fbx`, `Texturas/*`) y se copian a `Assets/Experiencias/<id>/Entorno/Arte/` (sin los `.meta` del artista, sin `entorno.json`).

| Clave | Qué es |
|---|---|
| `raiz.pos` | Desplazamiento (m, ejes de Unity) de la raíz del prefab del artista a la escena. El entorno queda como `Entorno/Planta`, y la colocación (en glTF: `x_unity = −x`) cuenta desde ahí. |
| `suelo` | Plano (`centro`, `tamano` [ancho, largo], `color`, `suavidad`) bajo la planta; sin collider. |
| `materiales` | Nombre → material URP Lit: `base` (textura de color), `normal` (se importa como mapa de normales), `metalSuavidad` (metálico en R y suavidad en A, en lineal; con él `_Smoothness` queda en 1) o `color` plano, `suavidad` y `dobleCara` (true = se dibuja por las dos caras, para una plancha que se mira desde abajo). Rutas relativas a `Entorno/`. |
| `piezas` | Lo estático: `nombre`, `grupo` (opcional: un hijo de `Planta` que los agrupa), `fbx` (sin extensión), `material`, `pos`, `rot` (cuaternión [x, y, z, w]) y `escala` opcional de la **raíz del FBX**, tal cual los dejó el artista; sin `escala`, la que trae el FBX (100 en estos, con −90° en X en la raíz). Sombras apagadas. |
| `colliders` | Cajas sólidas (`nombre`, `centro`, `tamano`) solo donde se pisa; nada de los FBX. |
| `modelos` | Un prefab envoltorio por `modelo` del guion en `Assets/Experiencias/<id>/Modelos/<modelo>.prefab` (donde lo busca la colocación): raíz con el nombre, hijo `Ajuste` (escala opcional) y dentro el FBX con la posición a cero —el origen del objeto es el origen del nodo del artista—. Sin collider: el importador de la colocación lo pone al que se agarra. |
| `omitidos` | FBX que se copian y no se dibujan, con su `motivo`. |

`EntornoDisposicion.Problems(carpeta)` es la comprobación pura (FBX o textura que falta, material sin declarar, vector de longitud equivocada, nombre repetido en su grupo, FBX de la carpeta que nadie usa ni omite); `BuildPrefab` falla con ese texto si hay problemas, y `Prepare` lo deja como aviso del informe. La muestra que lo usa es `Samples~/ExperienciaCompostajePlanta` (`LEEME.md`); sus posiciones salen de `Environment.prefab` y `cobertiso.prefab` de compostajevr, leídos del YAML como datos, sin tocar el repo del artista.

**Título del menú:** `ExperienceSceneMap.Entry.title` (opcional; vacío = el nombre de la escena legible, como antes) lo rellena «Importar guion» con `experiencia.titulo`, y el menú mock lo usa (`MockExperienceCatalog.TitleOf`).

## 12. `experiencia.visibilidadPorPaso`: mostrar solo lo que usa el paso en curso (2026-10-26)

Nació del recorrido del dueño en el Quest 3 con la experiencia 12 (2026-10-26): «¿por qué hay tantos cubos? Y letras, no se entienden las letras, y con tanta información es difícil desplazarse». La colocación trae 48 marcadores con etiqueta flotante y 12 zonas con su recuadro y su nombre, todos a la vista desde el primer paso.

**La clave.** `experiencia.visibilidadPorPaso` (booleano, opcional, por defecto `false`; mismo estilo que `cierrePropio`, §10.1). Está en `Schema/guion.schema.json` y en `GuionDocument.ExperienceInfo.VisibilityByStep`. No cambia la versión del contrato (como `cierrePropio`, es una clave opcional más) y vacía o `false` deja la escena exactamente como antes (D8): no se añade ningún componente y, si había uno de una preparación anterior, se quita.

**La regla**, que se recalcula entera con el índice del paso (por eso saltar con el panel de depuración, adelante o atrás, deja lo mismo que llegar jugando):

1. Un objeto o zona que **ningún paso usa** (decorado, la planta, herramientas sin función) se ve siempre. Si es un marcador sin modelo, su etiqueta nunca.
2. Uno que **sí se usa** se ve desde el primer paso que lo usa hasta el último, ambos inclusive, y fuera de ese tramo se apagan sus renderers y sus colliders (el rayo y el clic no lo encuentran). Antes del primer paso de la sesión, todo lo que tiene tramo está oculto. Mientras está **agarrado** no se oculta: se oculta al soltarlo.
3. La **etiqueta** flotante de un marcador y el **recuadro con nombre** de una zona solo se ven en los pasos que lo usan de verdad, no en todo el tramo.

«Un paso usa un id» cuando aparece en su condición (`objeto`, `objetos`, `zonas`, `opciones[].objeto`, `herramienta`, `reglas[].objeto/zona`, `equivocados[].objeto`), en `activos` o en `senalar`. Además, una `superficie` usada arrastra las `herramientas` con que se frota (sin ellas el paso no se podría hacer). La herramienta que carga una `fuente` no cuenta: es una plantilla que la pila instancia.

**Dos decisiones de implementación.** Se apagan renderers y colliders, no el GameObject: el objeto sigue registrado (`SceneTarget`, `InteractableRegistry`) y las condiciones, el anillo y el coach lo encuentran sin esperar a un `Start` pendiente. Y una zona **no apaga su trigger**: solo cambia su dibujo (recuadro y nombre), porque apagar el collider con objetos dentro dejaría a medias la cuenta de `DropZone`; lo que acepta está oculto fuera de su tramo. Una zona que ningún paso usa no dibuja nada (la regla 3 manda sobre la 1). Las zonas de teleport no tienen dibujo y no se tocan.

**Dónde vive.** `Runtime/Interactions/StepVisibilityController.cs` (en `XRLabs.Interactions` porque lee `InteractableBase.IsSelected`; nada de XR en `XRLabs.Core`, F2) escucha `StepSystem.StepStarted`. Lleva una `Entry` por objeto y zona: `id`, `target` (`Objeto_<id>` o `Zona_<id>`), `isZone`, `firstStepId`, `lastStepId` y `labelStepIds`. Los pasos van por id y se resuelven a índice contra la secuencia al encenderse: un id que la secuencia ya no tiene deja el objeto a la vista. El cálculo está en `Editor/Authoring/StepVisibilityPlanner.cs` (`Compute` es puro) y lo llaman `ColocacionImporter.Import`, al terminar, y `ScenePreparer` al preparar `[Colocacion]`, en cualquier orden y sin duplicar. Escribe el componente en la raíz `[Colocacion]` y enlaza el `StepSystem` de la escena.

**Puente a `visibleSi` (contrato 0.3, §2.10).** Esto es el primer escalón: la visibilidad se decide por el paso, desde el guion, para toda la experiencia. `visibleSi` la decide por el **estado** (`lugar`, `humedad`, `dia`) y por objeto o zona de la colocación, sumándose a esta regla. El componente seguirá siendo quien muestra y oculta; lo que cambia es de dónde sale la condición. Un guion con `visibilidadPorPaso` no necesita cambios para convivir con `visibleSi`.

Tests: EditMode `StepVisibilityPlannerTests` (12: los tramos de un guion de fixture, lo que escribe el importador, sin la opción nada, idempotencia, la regla pura) y dos en `ScenePreparerTests`; PlayMode `StepVisibilityPlayTests` (8: avanzar, etiqueta solo en su paso, zona, objeto agarrado, saltos adelante y atrás, encendido tardío, id desconocido, apagar el componente).

## 13. Contrato 0.3: estado, `visibleSi`, conjuntos, guardas, efectos y `avanzar` (lotes 1 y 2; 2026-10-31)

La forma completa está en `contrato-0.3.md` §2; aquí, lo que necesita quien escribe el guion y la colocación.

### 13.1 Estado, `visibleSi` y conjuntos (lote 1)

Lo que añade el lote 1 de `contrato-0.3.md` (§2.1, §2.5, §2.10), con todas las claves opcionales (D8):

- **Guion (`xrlabs.guion/0.3`):** `estado` de primer nivel (variables de texto con `valores` o numéricas con `inicial`), `alCompletar` en un paso y `alElegir` en una opción de `elegir`. El importador deja el estado inicial en `SimulationSequence.initialState`, los efectos ya resueltos en `stepStateEffects` y el `alElegir` de cada opción en `ChoiceOption.onChoose`.
- **Colocación (`xrlabs.colocacion/0.3`):** `visibleSi` en objetos y zonas (pone `StateVisibility` en `Objeto_<id>` o `Zona_<id>`) y `conjuntos`: un vacío `Conjunto_<id>` en `origen` del que cuelgan sus miembros (objetos, zonas y anclas) con su pose de mundo, con `StateLayout` (`posicionSegun`) y, si lo pide, `StateVisibility`. Reimportar devuelve los miembros a la raíz, los importa por nombre como siempre y los vuelve a colgar: es idempotente. Un fichero 0.1 o 0.2 que use estas claves recibe un aviso.
- **Raíces de la escena:** «Preparar escena» añade `SimulationStateHost` a `[Simulation]` solo si el guion declara `estado` (y lo quita si deja de declararlo). Los conjuntos cuelgan de `[Colocacion]`, como el resto de lo colocado.
- **Estilo:** lo que se mueve por estado se escribe para que ocurra oculto (el conjunto no se ve hasta que la variable vale algo), sin animación.

### 13.2 Guardas, efectos y `avanzar` (lote 2)

- `esquema: "xrlabs.guion/0.3"` y `estado` de primer nivel: `{ "humedad": { "valores": ["bien", "mojada", "seca"] }, "temperatura": { "inicial": 12, "min": 0, "max": 80, "registrar": true } }`. Nombres en minúsculas, cifras y guion. `dia` no se declara: la añade el importador si hay un `avanzar`.
- En cualquier paso: `si` (se salta si no se cumple al llegar; un saltado no suena, no cuenta y descuenta su tarea), `alIniciar` (antes de la introducción) y `alError` (por clave de `errores`, tras la corrección). Un efecto es un texto de `valores`, un número o `{ "sumar": n }`.
- `{ "id": "semana", "tipo": "avanzar", "dias": 7, "etiqueta": "ui.semana", "fundido": 1.5 }`: suma los días, aplica `alIniciar` con la pantalla en negro y enseña la etiqueta (`soloTexto`; su texto admite `{variable}`, p. ej. «Día {dia}»). No lleva `condicion` ni suma tarea. «Preparar escena» pone la cortinilla en el `[HUD]` solo si hay un `avanzar`.
- Un id de frase puede llevar `{variable}` de texto (`"intro": ["COMP-08.fase.{fase}"]`): el validador exige una frase por cada valor y el coach dice la del valor actual.
- El validador dice qué cambiar ante una variable sin declarar, un valor fuera de `valores`, `sumar`/`mayor`/`menor` en una de texto, un `avanzar` sin `dias` o con `condicion`, o una frase expandida que falta. Las reglas están en `GuionStateRules`.

### 13.3 Cuándo se aplica cada efecto (integración de los lotes, 2026-10-31)

- `alIniciar` al empezar el paso (en un `avanzar`, con la pantalla en negro), `alElegir` al tocar la opción, `alError` tras la corrección y `alCompletar` al cumplirse la condición, antes de la frase de éxito. Cada uno, una vez.
- En un salto (capítulos, panel de desarrollo) el estado vuelve al inicial y se repiten, en orden, los efectos de los pasos anteriores al destino cuya `si` se cumplía: días, `alIniciar`, el `alElegir` de la opción **correcta** y `alCompletar`. `alError` no se repite.
- Un guion o una colocación que declara 0.1 o 0.2 y usa algo de la 0.3 recibe un solo aviso de `esquema` con la lista de lo que usa.

### 13.4 `elegir` según el estado e indicadores (lote 4)

- **`elegir` con `segun`:** `"condicion": { "segun": "humedad", "opciones": [ { "objeto": "humedad-bien", "valor": "bien" }, … ], "errorPorEstado": { "mojada": "mojada", "seca": "seca", "bien": "esta-bien" } }`. Las opciones llevan `valor` (nunca `resultado`); hace falta una opción por cada valor de la variable y una clave de `errorPorEstado` por cada valor, con su frase en `errores`. Tocar la opción equivocada dice la corrección del **estado** («el agua corre entre los dedos»), no la de la opción; el objeto tocado queda en la telemetría (`metadata.opcion`). `alElegir` vale igual que sin `segun`.
- **`indicadores`** (primer nivel): `{ "id": "temperatura", "estado": "temperatura", "etiqueta": "ui.ind.temperatura", "unidad": "°C", "decimales": 0, "enInforme": true }`; en una de texto, `textos` con una frase por valor y sin `unidad`. `etiqueta` y `textos` son frases `soloTexto` (la etiqueta admite `{variable}`). `desde`/`hasta` (paso o grupo) acotan cuándo se ve; sin ellos, todo el recorrido. Hasta cuatro: con más, aviso.
- **En escena:** «Preparar escena» añade el panel `Indicadores` al `[HUD]` (arriba a la derecha, en pantalla y en el visor) solo si el guion los declara, y lo quita si dejan de estar. El valor que cambia destella 0,6 s, sin sonido. Los de `enInforme` salen en el panel final con su valor final, y el cierre de la sesión (`complete_experience`) lleva `metadata.estado` con todas las variables.

### 13.5 «Continuar» y `llevar` con reacciones, faltantes y zonas distintas (lote 5, 2026-10-31)

```json
{ "id": "COMP-02", "tipo": "llevar",
  "errores": { "sin-estiercol": "COMP-02.falta.estiercol", "sin-cal": "COMP-02.falta.cal" },
  "condicion": {
    "objetos": ["estiercol", "rastrojos", "agua", "cal-ceniza"], "zonas": ["acopio"], "cantidad": 4,
    "reacciones": { "estiercol": "COMP-02.porque.estiercol" },
    "faltantes":  { "estiercol": "sin-estiercol", "cal-ceniza": "sin-cal" },
    "distintas": false },
  "continuar": { "etiqueta": "ui.continuar" } }
```

- `continuar` (pasos `llevar`, `elegir`, `frotar`, `mantener` y `apuntar`): el HUD enseña el botón con la frase de `etiqueta` (por defecto `ui.continuar`, que tiene que existir; conviene `soloTexto`) mientras el paso escucha. En pantalla vale también Intro, con el coach callado; en el visor, el rayo sobre el botón. Con la condición cumplida cierra el paso; si no, es un error: el coach dice la frase de `faltantes` de cada objeto que falta, en el orden de `objetos`, y el paso se repite como tras cualquier error. Sin `faltantes`, `claveIncompleto` (una clave de `errores`) es obligatoria. El paso se sigue cerrando solo al cumplirse la condición.
- `reacciones`: objeto → id de frase que se dice al aceptarse su soltado (la primera vez), sin bloquear ni contar. Si ese soltado cierra el paso, la frase de éxito espera a que termine.
- `distintas: true`: un soltado cuenta solo si su zona aún no tenía uno («una dosis por planta»); el rechazado vuelve a su sitio sin decir nada. Con menos zonas que `cantidad`, el validador avisa de que no se puede completar.
- Los objetos de `reacciones` y `faltantes` tienen que estar en `objetos`; cada clave de `faltantes`, en `errores` del paso.
