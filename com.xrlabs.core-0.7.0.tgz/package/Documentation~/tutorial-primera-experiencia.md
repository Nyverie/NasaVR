# Tutorial completo — Tu primera experiencia, paso a paso

> Construiremos una mini-simulación de 4 pasos: bienvenida narrada → tocar un punto de
> inspección → rotar una pieza 360° → cierre. Al final corre desde el menú con login,
> puntúa y telemetriza. Tiempo estimado: 45-60 min. No asume conocimiento previo del framework.

Prerequisito: proyecto creado desde el template y verificado (login mock funciona).
Ver `getting-started.md` sección 1-2 si aún no lo hiciste.

---

## Parte 1 — Estructura de carpetas de tu experiencia

En `Assets/` crea esta estructura (Project window → click derecho → Create → Folder):

```
Assets/
└── MiExperiencia/
    ├── Audio/VO/          ← clips de voz
    ├── Modelos/           ← FBX/prefabs de las piezas
    ├── Escenas/
    ├── Steps/             ← StepDefinition .assets
    ├── Conditions/        ← StepCondition .assets
    └── Secuencias/        ← SimulationSequence .assets
```

### Importar recursos

- **Audio VO**: arrastra los .mp3/.wav a `Audio/VO/`. En el Inspector de cada clip:
  `Load Type = Compressed In Memory`, `Compression = Vorbis`, calidad ~70% (son voces).
- **Modelos 3D**: arrastra el FBX a `Modelos/`. Crea un prefab: arrastra el FBX a la
  escena, ajusta escala/materiales, y arrastra el GameObject de vuelta a `Modelos/`
  (elige "Original Prefab"). **Importante**: el prefab necesita un **Collider** (añade
  MeshCollider o un BoxCollider aproximado) para que las interacciones lo detecten.

---

## Parte 2 — La escena y sus managers

1. `File → New Scene` (Basic URP) → guardar como `Escenas/MiExperiencia.unity`.
2. Agregar la escena a **Build Settings** (File → Build Settings → Add Open Scenes).
3. Agrega un **XR Origin**: `GameObject → XR → XR Origin (VR)`. Bórrale la Main Camera
   vieja de la escena si quedó duplicada.
4. Crea un GameObject vacío llamado `[Simulation]` y agrégale estos componentes
   (Add Component, buscar por nombre):

| Componente | Configuración |
|---|---|
| **SimulationManager** | `Simulation Mode = Guided` (o Evaluation si puntúa). Arrastra a sus 3 campos los componentes de este mismo GO: Step System, Scoring System, Telemetry Client |
| **StepSystem** | `Sequence` = (lo asignamos en la Parte 4) · `Auto Advance Grace Seconds = 3` |
| **ScoringSystem** | `Initial Score = 100`, `Max Score = 100` (defaults OK para modo guiado) |
| **TelemetryClient** | Defaults OK para desarrollo (escribe JSON/CSV locales). `Device Platform = Meta Quest 3` |
| **VOManager** | Se auto-agrega un AudioSource (RequireComponent). En el AudioSource: `Play On Awake = off`, `Spatial Blend = 0` (voz 2D) |
| **HintSystem** | Sin campos — solo agregarlo |
| **FeedbackSystem** | Sin campos — solo agregarlo |

> ⚠️ `SimulationManager.Start()` arranca la simulación sola al cargar la escena.
> Si la escena no tiene Sequence asignada verás un error claro en consola.

5. Crea otro GameObject vacío `[Session]` con el componente **SessionManager**
   (`XRLabs.UI`): `Main Menu Scene = Menu` · `Next Scene` vacío (o el nombre de tu
   segunda escena si encadenas guiado → evaluación). Este componente inicia la sesión
   en el API al cargar y navega de vuelta al menú al terminar.

---

## Parte 3 — Interactables en escena

### El punto de inspección (paso 2 del tutorial)

1. Arrastra tu prefab del modelo a la escena, posiciónalo sobre una mesa/soporte a
   ~1.2 m de altura frente al XR Origin.
2. Crea una esfera pequeña como hija del modelo (`GameObject → 3D Object → Sphere`,
   scale ~0.05) sobre la zona a inspeccionar. Nómbrala `Hotspot_Zona1`.
3. Agrégale el componente **TouchableHotspot**: se auto-agrega un XRSimpleInteractable.
   En el inspector: `Interaction Id = zona1` · `Trigger On Touch = ✔` · `One Shot = ✔`.
4. Su SphereCollider debe tener `Is Trigger = ✔`.

### La pieza rotable (paso 3)

1. Duplica el modelo (o usa el mismo) y agrégale **RotatableItem**: se auto-agrega
   XRGrabInteractable ya configurado para girar en su sitio (no se lleva a la mano).
   `Interaction Id = pieza_rotable` · `Rotation Sensitivity = 1.5`.
2. Necesita Rigidbody (el XRGrabInteractable lo agrega): márcale `Is Kinematic = ✔`
   y `Use Gravity = off` para que no se caiga.

---

## Parte 4 — Conditions, Steps y Secuencia

### 4.1 Las conditions (Create → click derecho en `Conditions/`)

| Asset | Menú | Configuración |
|---|---|---|
| `Cond_TocarZona1` | `XR Simulation → Conditions → Hotspot Touch` | `Hotspot Id = zona1` |
| `Cond_Rotar360` | `XR Simulation → Conditions → Rotation Tracking` | `Target Tag = DrillBit` · `Required Angle Degrees = 360` |

> La rotation condition busca por **tag**: crea el tag `DrillBit` (o el que uses en
> `Target Tag`) en Project Settings → Tags y asígnaselo al GameObject de la pieza rotable.
> (El hotspot no necesita tag: se registra por su Interaction Id en el HotspotRegistry...
> **ojo**: `HotspotTouchCondition` consulta el `HotspotRegistry` — para el flujo con
> `TouchableHotspot` del contrato nuevo, usa en su lugar una condition propia de 10 líneas,
> ver 4.4.)

### 4.2 Los StepDefinitions (Create → `XR Simulation → Step Definition`, en `Steps/`)

**`Step_01_Bienvenida`**
- `Step Type = NonInteractive` · `Step Id = intro_bienvenida`
- `Vo Sequence`: arrastra el/los clips de bienvenida (se reproducen en orden)
- Al terminar el VO avanza solo (+ los 3 s de gracia del StepSystem)

**`Step_02_TocarZona`**
- `Step Type = Interaction` · `Step Id = inspeccion_zona1`
- `Vo Sequence`: clip con la instrucción ("toca la zona señalada…")
- `Hint VO`: clip de ayuda · `Hint Delay = 10` (si en 10 s no actúa, suena — y se telemetriza)
- `Completion Condition` = `Cond_TocarZona1`
- `Max Allowed Time = 60` · `Score On Success = 0` (guiado no puntúa)

**`Step_03_Rotar`**
- `Step Type = Interaction` · `Step Id = exploracion_rotar`
- `Completion Condition` = `Cond_Rotar360` · resto igual al anterior

**`Step_04_Cierre`**
- `Step Type = NonInteractive` · `Step Id = cierre` · VO de despedida

Campos opcionales que verás y puedes ignorar por ahora: `Panel Type` (paneles flotantes
de imagen), `Model Display/Model Prefab` (presentación cinematográfica del modelo por
paso), `Sfx On Enter/Complete`.

### 4.3 La secuencia

Create → `XR Simulation → Simulation Sequence` en `Secuencias/` → `Seq_MiExperiencia`:
- `Sequence Name = Mi Experiencia` · `Mode = Guided`
- `Steps`: arrastra los 4 StepDefinitions **en orden**
- Asigna este asset al campo `Sequence` del **StepSystem** en la escena.

### 4.4 (Referencia) Una condition propia en 10 líneas

Si tu paso necesita algo que no existe, crea la condition así (en tu carpeta de scripts):

```csharp
using UnityEngine;
using XRLabs.Core;
using XRLabs.Interactions;

[CreateAssetMenu(menuName = "MiExperiencia/Conditions/Hotspot Contrato")]
public class TouchableHotspotCondition : StepCondition
{
    [SerializeField] private string interactionId;
    private bool _done;

    public override void Initialize()
    {
        _done = false;
        foreach (var h in Object.FindObjectsByType<TouchableHotspot>(FindObjectsSortMode.None))
            if (h.InteractionId == interactionId)
                h.Activated += _ => _done = true;
    }

    public override bool IsCompleted() => _done;
    public override void Cleanup() { }
}
```

---

## Parte 5 — Conectarla al menú

1. **Registrar la escena**: abre `Assets/Resources/ExperienceSceneMap.asset` → Entries →
   `+` → `Experience Key` = el id de texto que el backend le dio a tu experiencia (un cuid; en mock,
   deja la clave vacía y usa `Experience Id = 10`) · `Scene Name = MiExperiencia`.
2. Verifica que tanto `Menu` (del paquete, índice 0) como tu escena están en Build Settings.
3. `Assets/Config/ApiSettings.asset`: `Use Mock Data = ✔` para probar sin backend.

## Parte 6 — Probar

**En Editor sin headset**: instala el XR Device Simulator (Package Manager → XR
Interaction Toolkit → Samples → Import) y arrastra su prefab a la escena (o actívalo
en Project Settings → XR Interaction Toolkit → Use XR Device Simulator in scenes).

1. Play desde la escena **Menu** → PIN `123456` → tu curso → tu experiencia → carga tu escena.
2. Checklist de consola:
   - `[Step] ◎ Condición escuchando…` al entrar a cada paso Interaction
   - `[FFR]` al inicio (en device)
   - `[ApiTelemetry] Sesión iniciada…` y al final `Sesión completada`
   - Sin warnings de `No hay ExperienceSceneMap` ni `Sequence`
3. El archivo local de telemetría queda en `persistentDataPath/Telemetry/<sessionId>/`
   (en macOS: `~/Library/Application Support/<company>/<product>/`).

**En Quest**: Build Profile "Meta Quest" → Build & Run. Espera ≥72 FPS con los settings
del template.

## Parte 7 — ¿Y la evaluación con quiz?

Cuando tu experiencia necesite la Parte 2 (casos + 3 preguntas + nota):

1. Crea los `CaseData` (Create → `XR Simulation → Evaluation → Case Data`): número de caso,
   nombre de la falla, `Model Prefab` del caso, y las 3 `QuestionData` inline (pregunta,
   4 opciones, índice correcto, feedback).
2. Arrastra a la escena el prefab **EvaluationUIRoot** del paquete
   (`Packages/com.xrlabs.core/Runtime/Simulations/Prefabs/`) — trae el quiz panel cableado.
3. Agrega un GO con **CaseEvaluationController**: asigna su `Quiz Panel` (del prefab)
   y `Session Manager`.
4. La secuencia de evaluación usa steps con ids convencionales
   (`eval_case1_inspect/quiz/summary`… `eval_results`) y `QuizCompletedCondition` en los
   pasos de quiz. El orquestador que mapea stepIds→casos es código de TU experiencia —
   usa `EvaluationSessionController` de la Sim 1 (repo platform-unity,
   `Assets/_Project/Scripts/FallasBrocas/Controllers/`) como referencia para copiar/adaptar.
5. `SimulationManager.Simulation Mode = Evaluation` y los steps de quiz con
   `Score On Success = 10`.

## Troubleshooting

| Síntoma | Causa probable |
|---|---|
| "No hay escena configurada para experienceId=X" | Falta la entrada en ExperienceSceneMap o el nombre no coincide con Build Settings |
| El paso Interaction nunca avanza | La condition no encuentra su target: revisa tag/Interaction Id y que el collider no sea hijo desactivado |
| No suena el VO | AudioSource del VOManager con Play On Awake, o el clip no está asignado en `Vo Sequence` |
| El hotspot dispara al pasar el rayo, no al tocar | En XRI el hover del ray también es hover: usa `Trigger On Touch = off` (requiere select) o interaction layers para limitar al poke |
| "Falta el paquete UniTask" | El manifest perdió el scoped registry — ver README del template |
| La pieza rotable se cae o se va volando | Rigidbody sin `Is Kinematic` |
| En flat no pasa nada al hacer click | Falta `FlatScreenLayout`/driver en el rig flat, o el click cae fuera del viewport 3D |
