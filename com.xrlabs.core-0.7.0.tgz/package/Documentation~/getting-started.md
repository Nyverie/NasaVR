# Getting Started — Crear una experiencia nueva

## Requisitos

- Unity 6000.3+ (probado en 6000.3.5f2)
- Acceso Read al repo `xrlabs-studio/platform-framework` (ssh key o PAT en tu máquina)
- Quest 3 en modo developer para builds

## 1. Configurar el proyecto

En `Packages/manifest.json`:

```json
{
  "scopedRegistries": [
    { "name": "package.openupm.com", "url": "https://package.openupm.com", "scopes": ["com.cysharp"] }
  ],
  "dependencies": {
    "com.xrlabs.core": "https://github.com/xrlabs-studio/platform-framework.git#v0.2.0",
    "com.cysharp.unitask": "2.3.3",
    "com.meta.xr.sdk.core": "85.0.0",
    ...
  }
}
```

- **UniTask es obligatorio** (el paquete no puede declararlo; un check de Editor avisa si falta).
- **Meta XR SDK es opcional** pero necesario para el foveated rendering en Quest.
- Importar **TMP Essentials** (Window → TextMeshPro → Import TMP Essential Resources).

### Settings críticos de rendimiento (Quest 3)

En el URP asset móvil: `Render Scale = 1.0`, `MSAA = 2x`. En OpenXR (Android): habilitar
Meta XR Foveation Feature + Subsampled Layout. Agregar `FoveatedRenderingBootstrap`
(XRLabs.Platform) a un GameObject de la escena inicial. Validado: 35-50 FPS → ≥75 FPS.

## 2. Escena de menú (transversal)

1. Arrastrar `Packages/com.xrlabs.core/Runtime/Menu/Menu.unity` a Build Settings, índice 0.
2. Crear tu `ApiSettings.asset` (menú `XR Platform/API Settings`) con baseUrl y flags,
   y asignarlo al componente `ApiClient` de la escena Menu (el paquete no puede traer
   config editable — es read-only).
3. Registrar tu escena de experiencia en un `ExperienceSceneMap` llamado así dentro de una carpeta
   `Resources` (menú `XR Platform/Experience Scene Map`): `Experience Key` = el id de texto (cuid) que el backend
   le dio a tu experiencia, y `Scene Name`. Desde 0.7.0 los ids son de texto; el campo numérico `Experience Id`
   queda para los mapas de v0.5 y para el modo mock, cuya experiencia de demostración es la `10`.

## 3. Construir la simulación

1. Crear la escena de la experiencia y agregarla a Build Settings.
2. En escena: GameObject con `SimulationManager` + `StepSystem` + `ScoringSystem` +
   `TelemetryClient` + `VOManager` + `HintSystem` (ver `SimDebugSceneSetupEditor` como referencia).
3. Crear los pasos como assets `StepDefinition` (menú `XR Simulation/Step Definition`)
   y ordenarlos en una `SimulationSequence`. Ver [step-system.md](step-system.md).
4. Agregar interactables — ver [interactions.md](interactions.md).
5. Agregar un `SessionManager` (XRLabs.UI): inicia la sesión API, acumula respuestas
   y navega de vuelta al menú al terminar. La telemetría fluye sola — ver [telemetry.md](telemetry.md).

## 4. Probar

- **Sin headset**: XR Device Simulator (sample de XRI) + el Interaction Playground
  (`Tools → XRLabs → Setup Interaction Playground`).
- **Modo mock**: `ApiSettings.useMockData = true` — login con PIN `123456`, datos simulados.
- **Contra API real**: `useMockData = false`; el PIN se genera desde el panel web.
