# Step System — Flujo de una simulación

## Conceptos

- **`SimulationSequence`** (SO): lista ordenada de pasos de una parte de la experiencia.
- **`StepDefinition`** (SO): un paso. Define VO, panel visual, modelo 3D, timing, scoring
  y su condición de completado.
- **`StepCondition`** (SO abstracto): "qué debe pasar para avanzar". El StepSystem la
  sondea cada frame mientras el paso está activo (`Initialize()` al entrar,
  `IsCompleted()` por frame, `Cleanup()` al salir).
- **`SimulationManager`**: orquesta modos (Guided/Evaluation), expone eventos
  `OnSimulationStarted/OnStepStarted/OnStepCompleted/OnSimulationEnded`.

## Tipos de paso

| StepType | Avanza cuando |
|---|---|
| `NonInteractive` | Termina la secuencia de VO (narración/transición) |
| `Interaction` | Su `completionCondition.IsCompleted()` devuelve true |

En pasos `Interaction`, si el usuario no actúa en `hintDelay` segundos, suena el `hintVO`
(y se telemetriza un `HintShownEvent` automáticamente).

## Campos clave de StepDefinition

- `stepId` — identificador estable. La convención de evaluación exige el número de caso:
  `eval_case1_inspect`, `eval_case1_quiz`, `eval_case1_summary`, `eval_intro`, `eval_results`.
- `modelDisplay` / `modelPrefab` / `spinSpeed` — presentación del modelo 3D del paso
  (None/Show/ShowAndSpin). Genérico: broca, barra, motor, lo que sea.
- `panelType` + `displayImage` / `iconCount` — panel flotante (Image, IconSequence,
  PartLabel, Checklist).
- `scoreOnSuccess` / `penaltyOnError` / `maxAllowedTime` — scoring (0 en modo guiado).

## Crear una StepCondition nueva

```csharp
[CreateAssetMenu(menuName = "XR Simulation/Conditions/Mi Condicion")]
public class MiCondicion : StepCondition
{
    public override void Initialize() { /* resolver referencias, resetear estado */ }
    public override bool IsCompleted() { /* consultar estado; barato, corre por frame */ }
    public override void Cleanup() { /* soltar referencias; buen lugar para emitir telemetría */ }
}
```

Reglas aprendidas del código existente:
- **No hagas `FindWithTag` por frame**: resuelve el target en `Initialize()` y, si puede no
  existir aún, reintenta con throttle (ver `RotationTrackingCondition.targetRetryIntervalSeconds`).
- Para localizar objetos usa el patrón de registro (`HotspotRegistry`) o escucha eventos de
  `InteractableBase` — no busques tipos del SDK XR.
- `TelemetryContext.CurrentStepId` te da el paso actual si necesitas etiquetar eventos.

## Condiciones incluidas

`ElapsedTimeStepCondition`, `ManualKeyStepCondition` (Core);
`RotationTrackingCondition` (girar N grados), `TimedExplorationCondition` (N segundos o
rotación), `HotspotTouchCondition`, `AllHotspotsTouchedCondition`, `QuizCompletedCondition`
(Simulations).

## Evaluación por casos

El quiz no encaja en StepConditions: `CaseEvaluationController` orquesta las 3 preguntas
de cada `CaseData` (SO con `QuestionData[3]`: tipo de falla → causa → recomendación,
4 opciones, `correctOptionIndex`). El StepSystem usa `QuizCompletedCondition` para
sincronizarse. `EvaluationSessionController` (en el proyecto de la experiencia) mapea
stepIds ↔ casos y muestra los paneles.
