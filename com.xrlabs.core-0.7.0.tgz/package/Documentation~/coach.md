# Coach — frases, errores y presencia (v0.6)

El coach es la voz y la presencia que guía al usuario. Es 100 % guionizado: el guion son
datos (`SimulationSequence` + `StepDefinition`) y las frases viven en una `LineLibrary`.

## Reglas de diseño

1. Una sola voz a la vez: una frase nueva corta a la anterior.
2. Instrucciones **no bloquean** (`instructionLine`); explicaciones, correcciones y confirmaciones **sí**.
3. El subtítulo siempre aparece, haya o no audio (sin clip, la frase dura una estimación).
4. Toda frase se puede saltar (`VOManager.Skip`).
5. El interactuable informa, la condición juzga, el StepDefinition decide qué se dice.
6. El error dice qué estuvo mal y por qué, y repite el paso. Soltar fuera de zona no es error.
7. Los avisos suenan una vez por paso.
8. Los datos variables (%, °C) no se dicen: se muestran en medidores.
9. Números con letras en el texto hablado y diccionario de pronunciación para siglas.
10. Cada paso deja el mundo en un estado reproducible (`StepEndStates`) para saltar capítulos.

## Montaje mínimo

En un GO de escena: `SimulationManager`, `StepSystem`, `ScoringSystem` (regla `TasksErrorsHints`; «Preparar escena» la pone desde el 2026-10-25),
`HintSystem`, `VOManager` (+ `AudioSource`, asignar `lineLibraries`), `FeedbackSystem`.
UI: `SubtitlePanel` y `ChecklistPanel` + `StepChecklistBinder`. Atajo: **Tools → XRLabs → Setup Coach Demo**.

## Frases (`LineLibrary`)

- Cada frase tiene un **ID estable** (`escena.paso.tipo`, ej: `s4.cubrir.instr`) y una variante por idioma.
- `spokenText` es opcional: lo que recibe el TTS cuando difiere del subtítulo.
- El idioma activo es `LanguageService.Current` y se cambia en caliente con `LanguageService.Set`.

## Un paso con el coach

| Campo | Para qué |
|---|---|
| `introLines` | Explicaciones al iniciar, bloqueantes. En pasos Interaction la condición se arma al terminarlas |
| `instructionLine` | Qué hacer. No bloquea; si no hay `hintLine`, se repite como pista |
| `hintLine` + `hintDelay` | Pista por inactividad (suma una ayuda) |
| `errorLines` / `defaultErrorLine` | Frase por clave que reporta la condición (errores y avisos) |
| `successLine` | Confirmación tras acertar, bloqueante. Conviene que explique el porqué |
| `countsAsTask` + `taskLabel` | Suma al checklist y al puntaje. `taskLabel` puede ser un ID de frase |
| `coachAnchorId` | Ancla donde se para el coach. Vacío = modo seguir |
| `pointAtTargetId` | Objeto al que señala el coach (`InteractionId` o `SceneTarget`) |

## Errores y avisos desde una condición

```csharp
public override bool IsCompleted()
{
    if (_dropped == null) return false;
    if (_dropped.InteractionId == "estiercol" && _layers == 0) { ReportError("empieza_con_vegetal"); _dropped = null; return false; }
    if (_humidity > 0.6f) ReportWarning("demasiada_agua");
    return _layers >= 4;
}
```

`ReportError` → `StepFailed`, +1 error, se dice la frase de `errorLines["empieza_con_vegetal"]`
(bloqueante, en modo error) y luego `Rearm()`. Sobrescribir `Rearm()` si se debe conservar
progreso parcial. Desde un componente de escena: `stepSystem.ReportError("clave")`.

`ReportInfo("capa_2")` dice la frase de `errorLines["capa_2"]` sin bloquear y sin contar (progreso:
"Capa dos de cuatro"); se puede repetir. `repeatInstructionAfterError` vuelve a decir la instrucción
tras una corrección (útil en preguntas cortas). Sobrescribir `CurrentHintLine` en la condición da una pista
que depende del estado ("ahora toca vegetal"); gana sobre `hintLine`.

Las condiciones listas para usar (`DropCondition`, `AimCondition`, `ScrubCondition`, `HoldCondition`)
y los componentes que las alimentan están en `interactions.md` (sección *Interacciones de acción*).
`StepTargetHighlighter` dibuja el anillo bajo los `activeTargetIds` del paso.

## Puntaje

`precisión = tareas / (tareas + errores) × 100`, `puntaje = precisión − 2 × ayudas` (0–100),
nota A ≥ 90 · B ≥ 75 · C ≥ 60 · D. Estadísticas por sección en `StepSystem.Stats`.

## Presencia (assembly XRLabs.Coach)

- `CoachPresence`: clase base del cuerpo visible (holograma v1, avatar 3D a futuro).
- `CoachAnchor`: estaciones por ID.
- `CoachDirector`: lleva el coach al ancla del paso; sin ancla, lo reubica a un lado de la mirada
  del usuario cuando este se aleja (`followDistance`) o lo pierde de vista (`outOfViewSeconds`).
  Nunca se mueve durante una corrección. Desliza en distancias cortas y reaparece en las largas.
- `CoachPlacement`: valida suelo, espacio libre, línea de vista y (opcional) NavMesh.
  Configurar `floorMask` y `obstacleMask` para excluir la capa del rig y del propio coach.

## Generar la voz (editor)

La voz **no se genera en runtime**: se hornea en el editor y los clips viajan en el build (el simulador
funciona sin red y el build no lleva ninguna clave). Todo el código vive en `Editor/Voice` (assembly
`XRLabs.Coach.Editor`, solo editor).

### Configuración (una vez por proyecto)

1. `Tools → XRLabs → Voice Settings` crea/selecciona el asset `VoiceSettings` (`Assets/Voice/VoiceSettings.asset`).
2. Elegir proveedor (**ElevenLabs** o **Fish Audio**; **«Sistema (macOS, provisional)»** es un relleno local sin clave, ver abajo), modelo y una **voz por idioma** (Español / English; los IDs
   de voz son distintos por proveedor). Ajustes: estabilidad/similitud/estilo y semilla (ElevenLabs),
   temperatura/velocidad (Fish). Carpeta de salida (por defecto `Assets/Voice`) y concurrencia (por defecto 2). Las librerías importadas de un guion (`<experiencia>/Frases/`) no usan esa carpeta: hornean en `<experiencia>/Voces/<es|en>/` (`autoria.md` §10.2).
3. Pegar la **clave de API** en el mismo inspector (campo de contraseña → *Guardar*). Se guarda solo en `EditorPrefs`
   de tu usuario (sin cifrar, no entra al repositorio ni al build). Alternativa: variables de entorno
   `ELEVENLABS_API_KEY` / `FISH_AUDIO_API_KEY` (EditorPrefs tiene prioridad). La clave nunca se escribe en el asset ni en el log.

### Flujo de quien escribe el guion

Seleccionar la `LineLibrary`; arriba del inspector está el panel **Voz (TTS)**:

| Control | Qué hace |
|---|---|
| **Generar faltantes** | Solo las variantes sin audio o con texto cambiado. Es el botón de uso diario |
| **Regenerar todo** | Rehace todo (p. ej. al cambiar de voz). Pide confirmación mostrando los caracteres que va a gastar |
| **Generar / Regenerar** (por frase e idioma) | Solo esa variante |
| **▶** | Escucha el clip en el editor, sin Play |
| Barra de progreso + **Cancelar** | La tanda es asíncrona y no bloquea el editor; cancelar conserva lo ya generado |
| **Borrar clips huérfanos (N)** | Aparece si hay clips cuyo ID de frase ya no existe; pide confirmación antes de borrar |

Estados por variante: `Sin audio` · `Al día` · `Texto cambiado` · `Error` (con el mensaje del proveedor) · `Sin texto`
(no necesita voz). Los campos de texto, `spokenText` y el diccionario de pronunciación se editan en el inspector
normal, debajo del panel.

### Cómo decide qué regenerar

Cada clip guarda `bakeHash = SHA-256(proveedor | voz | modelo | ajustes | semilla | idioma | textoHablado)`, donde
`textoHablado` es `LineLibrary.GetSpokenText` (`spokenText` o el texto con el diccionario de pronunciación aplicado).
Si el hash coincide y el clip existe, **no se llama a la API** (cada llamada cuesta y cambia la entonación).
Cambiar proveedor, voz, modelo o ajustes deja todo en `Texto cambiado`. (La semilla solo entra al hash en ElevenLabs,
y `previous_text/next_text`, que mejoran la entonación, no entran: editar una frase no regenera las vecinas.)

Los clips se escriben en `<salida>/<librería>/<es|en>/<id>.mp3` (IDs saneados para nombre de archivo) y se importan
como mono, Vorbis, *Compressed In Memory*, calidad 0,5, carga en segundo plano. **Subir los clips al repositorio**:
el resto del equipo y la máquina de builds no necesitan clave ni conexión. Errores 429/503 se reintentan con espera
exponencial; 401/402 o falta de clave abortan la tanda con un mensaje claro.

### Proveedor provisional del sistema (macOS, 2026-10-25)

Mientras el dueño no guarde la clave de ElevenLabs en las preferencias del Editor (D5 no cambia: la clave nunca va a un
asset ni a git), el coach puede hablar con una voz local: en `VoiceSettings`, proveedor **«Sistema (macOS,
provisional)»** (`VoiceProviderKind.MacSay`, `Editor/Voice/MacSayProvider.cs`). Es un **relleno**: el inspector de
`VoiceSettings` y el de la `LineLibrary` lo avisan en amarillo, y la voz del producto sigue siendo la de ElevenLabs.

- Solo en el Editor de macOS; sin red y sin clave (`VoiceSettings.RequiresApiKey` da false, así que «Generar voces que
  faltan» no pide clave). Cada frase sale de `say -v <voz> -o <tmp>.wav --file-format=WAVE --data-format=LEI16@22050`
  (el texto va por fichero); no hace falta `afconvert`, porque `say` escribe WAV directo y no acepta little-endian en AIFF.
- La voz es el campo `systemVoice` de cada idioma; vacío, **Paulina** (español de México, `say -v '?' | grep es_MX`) y
  Samantha en inglés. Entra al hash como cualquier voz: `macos-say | Paulina | say | rate=22050 | - | es | texto`.
- **La muestra de compostaje trae sus voces**: `Samples~/ExperienciaCompostaje/Voces/es/<id>.wav`, una por cada frase dicha
  del guion (53 de 60; las 7 `soloTexto` no se dicen), con el nombre de fichero de `VoiceBaker.BuildFileStems`. Al preparar
  las muestras (`Tools/XRLabs/Preparar las muestras del paquete` o `Tools~/build_visor.sh -prepareSamples`),
  `SampleVoices.Link` las copia a `Assets/Experiencias/experiencia-compostaje/Voces/es/` del anfitrión (donde las deja el
  horneador), las importa como mono Vorbis 0,5 y las asigna a las variantes que no tienen clip. Un clip que ya estaba
  (horneado con ElevenLabs en el anfitrión) no se toca. El `bakeHash` queda vacío: sin `VoiceSettings` cuentan como al día;
  con `VoiceSettings` de ElevenLabs salen «Texto cambiado» y «Generar faltantes» las rehace con la voz buena.
- Cuando llegue la clave: proveedor ElevenLabs en `VoiceSettings`, la clave en el inspector, «Generar voces que faltan» en
  la ventana de autoría, y sustituir los WAV de `Samples~/ExperienciaCompostaje/Voces/es/` por los nuevos clips (o borrar la
  carpeta si las voces pasan a viajar de otro modo).

### Validación antes del build

`VoiceBuildValidator` (`IPreprocessBuildWithReport`) **falla el build** si alguna frase con texto está en `Sin audio`,
`Texto cambiado` o `Error`. Alcance: las `LineLibrary` referenciadas por las escenas activas de Build Settings
(dependencias transitivas) más las que estén en carpetas `Resources`; si no hay escenas activas, todas las de `Assets/`.
Opt-out: `allowIncompleteVoiceInDevBuilds` en `VoiceSettings` (solo Development Build; avisa en vez de fallar).
Revisión manual: `Tools → XRLabs → Validar voz del coach`.

### Tests

`Tests/Editor` (EditMode, `FakeTtsProvider`: nunca llama a las APIs reales). Ejecutarlos con el Test Runner → EditMode
(`"testables": ["com.xrlabs.core"]`).

## HologramCoach (presencia v1)

Proyector holográfico que replica a la instructora de la versión web; no necesita rig ni animación.
Es un `CoachPresence`, así que el `CoachDirector` lo mueve, lo gira y lo hace señalar sin cambios.

- **Partes**: base metálica con lente emisivo, cono de luz aditivo con líneas que suben (su brillo se
  multiplica por `1 + amplitud`), disco de 0,48 m con el retrato, anillo, onda circular de 128 puntos y placa con nombre.
- **Disco**: retrato + líneas de escaneo + parpadeo leve + borde que brilla con la voz. Gira en Y hacia el usuario
  (`LookAt`), flota ±4 cm y su centro está a 1,7 m (`discHeight`; la web usa 1,98 m).
- **Voz**: `SetVoice(amplitud, esError)`. El anillo escala `1 + amp × 0,06`; la onda sale del espectro de
  `VOManager.GetSpectrum` (opacidad 0,9 hablando / 0,35 en silencio). En error el acento pasa de turquesa a naranja.
- **Retrato y nombre**: campos `portraitTexture` / `portraitSprite`; si están vacíos usa `LineLibrary.speakerPortrait`
  y `speakerName` (vía `VOManager`). Sin retrato dibuja una silueta de reemplazo. `SetPortrait(...)` lo cambia en runtime.
- **Señalar**: `PointAt(transform)` enciende un rayo punteado animado desde el borde del disco hasta el objeto
  (`null` lo apaga). El director lo usa con `StepDefinition.pointAtTargetId`.
- **Aparecer/desaparecer**: `Disappear()` / `Appear()` (~0,3 s, tiempo sin escala) se usan al reubicarse lejos.

### Uso

1. **Tools → XRLabs → Create Hologram Coach Prefab** regenera `Runtime/Coach/Hologram/HologramCoach.prefab`
   (con mallas y materiales). El prefab ya viene incluido en el paquete.
2. Arrastrar el prefab a la escena, y en un GO agregar `CoachDirector` con `stepSystem`, `presence` (el prefab) y
   `head` (cámara del rig). Poner `CoachAnchor` donde el coach deba pararse y usar su ID en `coachAnchorId`.
3. Para la demo completa: **Tools → XRLabs → Setup Coach Demo** (coloca el holograma a 2 m, un ancla `demo.anchor`
   y un cubo `demo.target` que el paso 2 señala).

Requiere URP y TextMeshPro (importar *TMP Essentials*). Los shaders (`XRLabs/HoloCone`, `HoloDisc`, `HoloDots`,
`HoloGlow`) soportan Single Pass Instanced y GPU instancing; se incluyen en el build porque los materiales del prefab los referencian.

### Presupuesto Quest

Sin luces en tiempo real ni sombras, ~8 renderers (todos transparentes, sin escritura de profundidad),
`MaterialPropertyBlock` para los parámetros por frame y cero asignaciones de memoria por frame (hay un test que lo verifica).
Para usar otro tamaño, escalar el prefab y ajustar `discRadius`.

## Tests

En el proyecto consumidor: `"testables": ["com.xrlabs.core"]` en `Packages/manifest.json` y
correr los tests PlayMode (`Tests/Runtime`).
