# Contrato 0.2: el guion expone las interacciones que el runtime ya tiene

Fecha: 2026-10-10 (estación Windows). Lotes A3 (contrato), A4 (coach en escena). Decisión D24. Complementa `autoria.md` (0.1), que sigue valiendo para todo lo que aquí no se cambia.

## 1. Por qué

`autoria.md` §3.4 dejó fuera soltar, sostener, apuntar y frotar porque «necesitan el visor». No es cierto: `Runtime/Platform/FlatInteractionDriver.cs` arrastra un `GrabbableItem` y lo suelta en una `DropZone`, carga una herramienta desde una `SourcePile`, mantiene un `HoldButton`, apunta con un `AimTool` y frota una `ScrubSurface` con el ratón, y `Tests/Runtime/InteractionStepTests.cs` lo prueba. Las condiciones `DropCondition`, `ScrubCondition`, `HoldCondition` y `AimCondition` (lote F3 de v0.6.0) existen con tests y se escribieron para el compostaje. El storyboard base del equipo (manual INIA 2025, 14 pantallas) necesita exactamente eso: con 0.1, once pantallas caerían en `manual`, el coach hablaría sin saber si la persona acertó.

Lo que falta no es runtime: es que el guion y la colocación puedan nombrar esas piezas y que los importadores las creen. Más una condición pequeña, elegir por objeto, porque `KeyChoiceStepCondition` es por teclado y en un Quest no hay teclado.

## 2. Alcance

**Entra (A3):** cuatro tipos de paso nuevos (`llevar`, `frotar`, `mantener`, `apuntar`); `elegir` por objeto (`opciones`) con una condición nueva `ChoiceByTargetCondition`; cinco tipos de objeto nuevos (`agarrable`, `fuente`, `superficie`, `boton`, `herramienta`); zonas de colocación de tipo `soltar`; esquemas 0.2; validadores; importadores; tests. **Entra (A4):** «Preparar escena» pone al coach (holograma, director, resaltado de objetivos). **No entra:** secuencias con ciclos, tiempo simulado, variables, bucles, subrutinas, medidor visual de progreso, condición compuesta, botón «Continuar» que reporta lo que falta, el importador del storyboard (va después, con la plantilla estricta). Nada de eso lo necesita la versión 1 del compostaje: COMP-04 y COMP-08 se desenrollan en pasos fijos.

## 3. Compatibilidad (D8)

- `esquema`: `xrlabs.guion/0.2` y `xrlabs.colocacion/0.2`. Los validadores aceptan **0.1 y 0.2**; un fichero 0.1 que use algo de 0.2 recibe un **aviso** («usa 0.2 en `esquema`»), no un error. Todo lo de 0.1 sigue significando lo mismo. La experiencia cero no cambia.
- Nada de lo nuevo toca `StepSystem`, `StepDefinition`, `SimulationSequence` ni las condiciones existentes salvo lo que se lista en §9 (cambios de runtime, mínimos y opcionales en la serialización).
- Fallas de Brocas no se ve afectado: solo se añaden tipos y una condición.

## 4. Objetos (`guion.objetos[]`)

| `tipo` | Componente que crea `ColocacionImporter` sobre `Objeto_<id>` | Campos opcionales del objeto en el guion |
|---|---|---|
| `objeto` | `SceneTarget` (como hoy) | |
| `hotspot` | `TouchableHotspot` (como hoy) | |
| `agarrable` | `GrabbableItem` (`interactionId` = id) + `ReturnToOrigin` (`returnWhenZoneRejects` = true, `returnAfterAcceptedDrop` = false) + collider si el modelo no trae | |
| `fuente` | `SourcePile` (`interactionId` = id, `sourceId` = id); la herramienta que carga es la de `toolPrefab` por defecto (cubo) | `herramienta`: id de un objeto `herramienta` cuyo modelo se usa como `toolPrefab` (si el prefab existe; si no, el de por defecto y aviso) |
| `superficie` | `ScrubSurface` (`interactionId` = id, `requiredDistance`, `toolIds`, `allowHands`) + collider | `recorrido` (m, por defecto 1), `herramientas` (ids de objetos `herramienta` o `fuente`; vacío = `allowHands` true y `requireToolSelected` false) |
| `boton` | `HoldButton` (`interactionId` = id, `holdSeconds`, `holdMode` = `SelectOrActivate`, `releaseBehaviour` = `Keep`) + collider | `segundos` (por defecto 3) |
| `herramienta` | `AimTool` (`interactionId` = id, `requireActivate` = true) + `ReturnToOrigin` + collider. **Excepción (2026-10-26):** si solo existe para dar su modelo a una o más `fuente` (campo `herramienta` de la fuente) y ningún paso, superficie ni zona la usa, se coloca de decorado: su modelo, sin collider ni interactuable (`ColocacionImporter.IsModelOnlyTool`); en el visor se agarra la fuente, no esa herramienta | |

Reglas: `herramientas` y `herramienta` deben referenciar objetos existentes del tipo indicado (error). Los campos opcionales solo valen para su tipo (aviso si sobran). `ReturnToOrigin.SetOrigin()` lo llama el propio componente al arrancar (verificar en el código; si no, el importador no hace nada especial: la posición de la colocación es el origen). Los ids de los componentes se escriben siempre por `SerializedObject` (`SetString`, `SetBool`, `SetFloat`, y una nueva `SetStringList`), como hoy.

Si un objeto cambia de tipo entre importaciones, el importador quita el componente que ya no corresponde (como hace `RemoveHotspot`) y lo anota.

## 5. Zonas (`colocacion.zonas[]`)

| `tipo` | Qué crea `ColocacionImporter` sobre `Zona_<id>` | Campos |
|---|---|---|
| `teleport` | como hoy | `tamano` [ancho, largo] |
| `soltar` | `DropZone` (`zoneId` = id, `acceptedIds` = `acepta`) + `BoxCollider` **trigger** de `tamano` × `alto`, centro a `alto/2`; con `imantar: true`, `SnapZone` en vez de `DropZone`, con `snapPoint` = el propio transform | `tamano` [ancho, largo], `alto` (m, por defecto 0,5), `acepta` (ids de objetos del guion de tipo `agarrable`, `fuente` o `herramienta`; obligatorio, al menos uno), `imantar` (bool, por defecto false) |

El agente que implemente debe leer `DropZone.Evaluate` para confirmar cómo decide «dentro» (bounds del collider, trigger, u otra cosa) y crear el collider de la forma que esa lógica espera. Si `DropZone` requiere `Rigidbody` o kinematic en el ítem, se anota y se añade al `agarrable`.

Validación de colocación (recibe el guion, como hoy): `acepta` con ids que no existen o de tipo no agarrable (error); `alto` ≤ 0 (error); y la **referencia cruzada** de los pasos: todo id en `pasos[].condicion.zonas` o en `reglas[].zona` de un paso `llevar` debe ser una zona `soltar` de la colocación (error en la colocación, igual que hoy con `pasos[].ancla`).

## 6. Pasos nuevos (`guion.pasos[]`)

Todos son `stepType` = `Interaction` y llevan las mismas claves que cualquier paso (`instruccion`, `pista`, `exito`, `errores`, `tarea`…). Las claves de `reglas[].clave`, `claveFuera` y `equivocados[].clave` tienen que existir en `errores` del paso (misma regla que `CheckSignal` hoy).

### 6.1 `llevar` → `DropCondition`

```json
"condicion": {
  "objetos": ["estiercol", "rastrojo", "agua", "cal"],
  "zonas": ["acopio"],
  "cantidad": 4,
  "reglas": [
    { "objeto": "estiercol", "zona": "agua", "clave": "estiercol-en-agua" },
    { "zona": "pila", "clave": "antes-de-tiempo", "tipo": "aviso" }
  ],
  "claveFuera": "otra-zona"
}
```

| Clave | Va a | Regla |
|---|---|---|
| `objetos` | `acceptedItemIds` | obligatorio, ≥ 1; ids de objetos `agarrable`, `fuente` o `herramienta` |
| `zonas` | `acceptedZoneIds` | obligatorio, ≥ 1; se comprueba contra la colocación (§5) |
| `cantidad` | `requiredCount` | opcional, por defecto 1, entero ≥ 1 |
| `reglas[]` | `rules[]` (`DropRule`: `itemId`, `zoneId`, `errorKey`, `kind`) | opcional; `objeto` y `zona` opcionales (vacío = cualquiera, como `DropRule` hoy; verificar en `DropCondition.Judge`); `clave` obligatoria; `tipo` `error` (por defecto) o `aviso` → `StepSignalKind` |
| `claveFuera` | `defaultErrorKey` | opcional: soltar en una zona que no es ninguna de las aceptadas |

`keepProgressOnRearm` queda en true (su valor por defecto). El importador escribe las listas por `SerializedProperty` (`arraySize` + elementos), con un helper nuevo `SetStringList(target, field, values)` y otro para la lista de reglas (`SetDropRules`); ambos con test.

### 6.2 `frotar` → `ScrubCondition`

`"condicion": { "objeto": "broza", "umbral": 1.0 }`. `objeto` obligatorio, de tipo `superficie` → `surfaceId`; `umbral` opcional (0,05 a 1, por defecto 1) → `threshold`; `resetOnStart` queda true.

### 6.3 `mantener` → `HoldCondition`

`"condicion": { "objeto": "reloj", "umbral": 1.0 }`. `objeto` obligatorio, de tipo `boton` → `buttonId`; `umbral` como en frotar → `threshold`.

### 6.4 `apuntar` → `AimCondition`

```json
"condicion": {
  "objeto": "pila", "herramienta": "manguera", "segundos": 3,
  "equivocados": [ { "objeto": "suelo", "clave": "agua-al-suelo", "tipo": "error", "gracia": 1 } ]
}
```

`objeto` obligatorio (cualquier objeto del guion) → `targetId`; `herramienta` obligatoria, de tipo `herramienta` → `toolId`; `segundos` opcional (> 0, por defecto 3) → `secondsRequired`; `equivocados[]` opcional → `wrongTargets[]` (`AimWrongTarget`: `targetId`, `errorKey`, `kind`, `graceSeconds`), `gracia` por defecto 1.

### 6.5 `elegir` por objeto → `ChoiceByTargetCondition` (nueva)

```json
"condicion": {
  "opciones": [
    { "objeto": "zona-a", "resultado": "error", "clave": "elige-a" },
    { "objeto": "zona-b", "resultado": "error", "clave": "elige-b" },
    { "objeto": "zona-c", "resultado": "aviso", "clave": "elige-c" },
    { "objeto": "zona-d", "resultado": "correcta" }
  ]
}
```

- Si `condicion` trae `opciones`, el paso genera `ChoiceByTargetCondition`; si trae `correcta` (tecla), `KeyChoiceStepCondition` como hoy. Las dos a la vez: error de validación («elige teclas u objetos»). Ninguna: error.
- `opciones[]`: ≥ 2 entradas; `objeto` existente y de tipo `hotspot`; exactamente... **al menos una** `correcta`; `error` y `aviso` exigen `clave` en `errores`; `correcta` no lleva clave (aviso si la trae).
- `ConditionTypeFor` pasa a recibir el `StepEntry` (o el `ConditionEntry`) para decidir entre las dos clases; `DeleteStaleConditions` sigue derivando de ahí, así que un paso que cambia de teclas a objetos reemplaza el asset.

**La condición** (`Runtime/Interactions/Conditions/ChoiceByTargetCondition.cs`, assembly `XRLabs.Interactions`, menú `XR Simulation/Conditions/Choice By Target`), calcada de `TouchableHotspotCondition`:

- `[Serializable] class ChoiceOption { string targetId; ChoiceOutcome outcome; string signalKey; }`, `enum ChoiceOutcome { Correct, Error, Warning }`; `[SerializeField] List<ChoiceOption> options`.
- `Initialize`: por cada opción, `InteractableRegistry.GetAll(targetId)`, filtra `TouchableHotspot`, `ResetHotspot()`, suscribe `Activated`. Reintento cada 0,5 s desde `IsCompleted` si alguna opción no encontró hotspot (mismo patrón).
- `Activated` de una opción `Correct` → completa. `Error` → `ReportError(signalKey)` y `ResetHotspot()` del tocado (para poder volver a elegir). `Warning` → `ReportWarning(signalKey)` y reset. Tras completar, ignora el resto.
- `Cleanup` desuscribe. Tests PlayMode en `Tests/Runtime/ChoiceByTargetConditionTests.cs`, con `InteractionTestUtil` como `TouchableHotspotConditionTests`: tocar la correcta completa; tocar una errónea reporta la clave (comprobar la señal con el mecanismo que usen los tests existentes de `StepCondition`, p. ej. `TryConsumeSignal`) y no completa; después de un error, la correcta sigue completando.

## 7. Cambios en ficheros (A3)

| Fichero | Cambio |
|---|---|
| `Editor/Authoring/GuionDocument.cs` | `ObjectEntry`: `Herramienta`, `Recorrido`, `Segundos`, `Herramientas`; `IsGrabbable` (agarrable, fuente, herramienta). `ConditionEntry`: `Objects`, `Zones`, `Count`, `Rules[]` (`DropRuleEntry`: `objeto`, `zona`, `clave`, `tipo`), `OutsideKey` (`claveFuera`), `Threshold` (`umbral`), `Tool` (`herramienta`), `WrongTargets[]` (`equivocados`: `objeto`, `clave`, `tipo`, `gracia`), `Options[]` (`opciones`: `objeto`, `resultado`, `clave`). Comentarios en español, identificadores en inglés. |
| `Editor/Authoring/GuionValidator.cs` | `StepKinds` + 4; `ObjectKinds` nuevo; `SupportedSchemas` {0.1, 0.2} con el aviso de §3; un `case` por tipo nuevo y la rama `opciones` en `elegir`; validación de campos de objeto por tipo; el mensaje del `default` enumera los diez tipos. |
| `Editor/Authoring/GuionImporter.cs` | `case` por tipo nuevo en `WriteCondition`; `ConditionTypeFor(StepEntry)`; helpers `SetStringList`, `SetInt`, `SetEnum`, `SetDropRules`, `SetWrongTargets`, `SetOptions`. |
| `Schema/guion.schema.json` | `objetos[].tipo` enum + campos opcionales; `pasos[].tipo` enum; un `if/then` por tipo nuevo; `elegir` con `oneOf` teclas u `opciones`; `esquema` const → enum 0.1/0.2 (o `pattern`). |
| `Editor/Authoring/ColocacionDocument.cs` | `ZoneEntry`: `Height` (`alto`), `Accepts` (`acepta`), `Snap` (`imantar`). |
| `Editor/Authoring/ColocacionValidator.cs` | zona `soltar` (§5) y la referencia cruzada de `llevar`. |
| `Editor/Authoring/ColocacionImporter.cs` | componentes por tipo de objeto (§4) y zona `soltar` (§5); quitar componentes al cambiar de tipo. |
| `Schema/colocacion.schema.json` | `zonas[].tipo` enum {teleport, soltar}; `alto`, `acepta`, `imantar` con `if/then`. |
| `Runtime/Interactions/Conditions/ChoiceByTargetCondition.cs` (+ `.meta`) | §6.5. |
| Tests | `GuionValidatorTests` (+1 por tipo nuevo válido, +1 por error característico de cada tipo, +2 `elegir` opciones, +1 esquema 0.1 con aviso: ~12), `GuionImporterTests` (+1 por tipo: condición creada con sus campos; +1 cambio teclas→opciones reemplaza el asset: ~6), `ColocacionValidatorTests` (+3), `ColocacionImporterTests` (+1 por tipo de objeto, +2 zona soltar/imantar: ~7), `ChoiceByTargetConditionTests` PlayMode (+3). |
| `Tools~/seal_stages.sh` | `EDITMODE_TESTS`, `PLAYMODE_TESTS` (los pone la sesión principal con las cifras que informen los agentes). |
| `Documentation~/autoria.md` | §3.3, §3.4, §4, §8 remiten a este fichero; corregir la frase de «necesitan el visor». `CHANGELOG.md` `[Unreleased]`; `decisiones.md` D24; `plan.md`; `relevo.md`; `index.md`. |

Los tests de EditMode van en el namespace `XRLabs.Coach.Editor.Tests.Authoring` (el sello cuenta esa suite). Cada fichero nuevo fuera de carpetas `~` lleva su `.meta`.

## 8. Lote A4: el coach en la escena preparada

`ScenePreparer.Prepare` añade una raíz `[Coach]`:

- Instancia `Runtime/Coach/Hologram/HologramCoach.prefab` como hijo (por `PrefabUtility.InstantiatePrefab`, para que siga enlazado al prefab), nombre `Coach`. Si el prefab no está (paquete sin esa carpeta), aviso y nada más.
- `CoachDirector` en `[Coach]`: `stepSystem` = el `StepSystem` de `[Simulation]`; `presence` = el `CoachPresence` del holograma (`HologramCoach` deriva de `CoachPresence`; verificar); `head` = el transform de `Main Camera`. Lo demás con sus valores por defecto.
- `StepTargetHighlighter` (`Runtime/Core`) en `[Simulation]` o en `[Coach]`, enlazado al `StepSystem`, según cómo lo usen las escenas y tests existentes (`Tests/Runtime/StepSystemCoachTests.cs`, `HologramCoachTests.cs`, `Documentation~/interactions.md` o el doc del coach). El agente lee cómo se cablea hoy en el `Menu` o en los tests y lo replica; si el holograma necesita el `LineLibrary`/`CoachVoice`, lo enlaza igual que `[Simulation]`.
- Idempotente: volver a preparar no duplica (`GetOrAdd` por nombre, como el resto). El informe lo lista. Tests en `ScenePreparerTests` (+2: crea el coach con director y referencias; preparar dos veces no duplica).

## 9. Cambios de runtime permitidos en A3

Solo `ChoiceByTargetCondition` (nueva). Si el agente de colocación descubre que `GrabbableItem`, `DropZone` o `SourcePile` necesitan algo que el importador no puede dar sin tocarlos (por ejemplo un `Rigidbody` por `RequireComponent`), lo anota en su informe y el importador lo añade desde fuera; no se modifican esas clases en este lote.

## 10. Prueba de aceptación del lote

1. Sello verde en el clon: `CHECK: OK`, EditMode y PlayMode con las cifras nuevas, logs limpios.
2. La experiencia cero (0.1) importa igual que antes (sus tests no cambian).
3. Un guion 0.2 de prueba en `Tests/Editor/Authoring/Fixtures/` (o inline en los tests) con un paso de cada tipo nuevo y un `elegir` por objeto, con su colocación con una zona `soltar`, valida sin errores e importa creando las condiciones y los componentes correctos.
4. Siguiente lote (A5, fuera de este): las pantallas COMP-00, 01, 02 y 05 del storyboard del INIA escritas a mano en 0.2 como `Samples~/ExperienciaCompostaje/`, recorribles en modo plano con el coach que habla, señala, corrige y repite. Es la medición real de este contrato.
