# Interacciones — Contrato y extensión

## El contrato: InteractableBase

Todo objeto interactivo hereda de `XRLabs.Interactions.InteractableBase`:

- Eventos C#: `Hovered`, `Unhovered`, `SelectedEvent`, `ReleasedEvent`, `Activated`, `Deactivated` (v0.6)
- `InteractionId` (string estable, configurable en Inspector; default = nombre del GO)
- `IsSelected`, `IsActivated` (v0.6: entre `Activated` y `Deactivated`; solo significativo en
  interactuables con gatillo, no en un `TouchableHotspot` de un solo disparo)
- API `Driver*` (`DriverSelect`, `DriverRelease`, `DriverActivate`, `DriverDeactivate`…) para drivers no-XR y tests
- **Telemetría automática**: cada evento emite un `InteractionEvent` al TelemetryHub

**Regla de oro**: los consumidores (StepConditions, controllers, UI) escuchan
`InteractableBase` y NUNCA tipos de XRI. Esto permite que el modo plano (mouse/touch)
dispare los mismos eventos con otro driver sin tocar la lógica de simulación.

## Interactables incluidos

| Componente | Comportamiento | XRI subyacente |
|---|---|---|
| `GrabbableItem` | Agarrar/soltar; `SetGrabEnabled(bool)` | XRGrabInteractable |
| `RotatableItem` | Gira en su sitio al agarrar (turntable); `TotalRotationDegrees` acumulado | XRGrabInteractable (sin tracking) |
| `TouchableHotspot` | Se activa al tocar (poke) o select; one-shot con `ResetHotspot()` | XRSimpleInteractable |
| `SnapZone` | Encaja el objeto entrante en `snapPoint` (trigger); telemetriza "snap". Desde v0.6 es una `DropZone` | — |
| `DropZone` | Zona de soltado: emite `Dropped(item, zone)` al soltar un objeto dentro (v0.6) | — (trigger) |
| `SourcePile` | Pila de material: al agarrarla pone una herramienta cargada en la mano (v0.6) | XRSimpleInteractable |
| `AimTool` | Apuntar con gatillo: acumula segundos por objetivo (v0.6) | XRGrabInteractable |
| `ScrubSurface` | Frotar: acumula recorrido dentro de su trigger, progreso 0–1 (v0.6) | — (trigger) |
| `HoldButton` | Mantener para avanzar un valor 0–1 en N segundos (v0.6) | XRSimpleInteractable |

Los `RequireComponent` agregan las piezas XRI automáticamente al añadir el componente.

## Interacciones de acción (v0.6)

Principio: **el interactuable informa, la condición juzga, el `StepDefinition` decide qué se dice.**
Los componentes solo emiten eventos; las condiciones (ScriptableObjects, no pueden referenciar
objetos de escena) los encuentran por **id de texto** al `Initialize()` y reportan
`ReportError(clave)` / `ReportWarning(clave)` ante acciones incorrectas. Soltar fuera de cualquier
zona **no es un error**: el objeto vuelve a su sitio.

### InteractableRegistry
`InteractableRegistry.TryGet<T>(id, out item)` busca por `InteractionId` (se registra solo en `Start`).
Si varios objetos comparten id, devuelve el más reciente. `ResolveTargetId(collider)` da el id de
lo que golpea un rayo (interactuable, `SceneTarget` o `DropZone`).

### DropZone y ReturnToOrigin
- `DropZone`: collider **trigger** + `zoneId` (vacío = nombre del GO) + `acceptedIds` opcional (vacío = todo).
  Evento `Dropped(item, zone)` cuando un objeto se **suelta** dentro (también el estático
  `DropZone.DroppedAnywhere`, que usan las condiciones). `Dropped` se emite aun para objetos no
  aceptados, para que la condición pueda reportar el error. Mientras un objeto **agarrado y
  aceptable** está dentro, la zona se resalta (`highlightRenderer` + `highlightColor`, o
  `onHighlightChanged` para efectos propios).
- `SnapZone` hereda de `DropZone`: imanta al soltar (solo lo aceptado, mueve el objeto entero) (como siempre) y además emite `Dropped`.
- `ReturnToOrigin` (en el mismo GO del interactuable): recuerda la pose inicial y, al soltar, vuelve
  animado (`returnSeconds`, 0.4 s) si quedó **fuera de toda zona** o dentro de una zona que **no lo
  acepta** (`returnWhenZoneRejects`). Con `returnAfterAcceptedDrop` también vuelve tras un soltado
  aceptado (herramienta que se devuelve a la mesa). `ReturnNow()` y `SetOrigin()` para control manual.

### SourcePile (carry)
Agarrar la pila pone una herramienta cargada (`CarriedItem`, con `SourceId`) en la mano; la pila no
se mueve. Al soltarla sobre una `DropZone`, esta emite `Dropped` con esa herramienta y
`CarriedItem.SourceId` dice de qué pila viene (estiércol, hojas, agua…). La herramienta es un
`toolPrefab`, un `sceneProxy` de escena (se oculta al soltar) o una esfera por defecto. Los ids
(`acceptedIds` de zona, `DropCondition`, `ScrubSurface.toolIds`) se comparan con el `InteractionId`
o con el `SourceId`.

### AimTool
Hereda de `GrabbableItem`. Mientras está agarrada **y activada** (gatillo; `requireActivate` para
cambiarlo) lanza un rayo desde `tip` (por defecto su propio forward) y acumula segundos por id de
objetivo: eventos `AimProgress(id, segundosTotales)` y `AimTargetChanged(id)`, `GetSeconds(id)`.
Un trigger sin id se ignora; un sólido sin id tapa lo de atrás.

### ScrubSurface
Collider trigger. Acumula el recorrido de una herramienta **agarrada** o de la mano/control
(`allowHands`) que se mueve dentro. `requiredDistance` metros = progreso 1; métrica `Distance3D` o
`Lateral` (|Δx| + 0.5·|Δy| locales). Eventos `ProgressChanged(0–1)` y `Completed`; `ResetProgress()`.

### HoldButton
Mantener (`Select`, `Activate` o cualquiera) sube `Value` de 0 a 1 en `holdSeconds`. Al soltar:
`Keep` (conserva), `Reset` o `Decay`. Eventos `ValueChanged(v)` y `Completed`; `ResetValue()`.

### Condiciones (`Runtime/Interactions/Conditions`, menú *XR Simulation/Conditions*)

| Condición | Se cumple cuando | Errores | `Rearm` |
|---|---|---|---|
| `DropCondition` | `requiredCount` soltados válidos | lista ordenada de reglas `{itemId?, zoneId?, errorKey, kind}`; **la primera que coincide gana**; sin regla y no aceptado = se ignora (o `defaultErrorKey`) | conserva el conteo (`keepProgressOnRearm`) |
| `AimCondition` | `secondsRequired` apuntando a `targetId` durante el paso (`toolId` opcional) | `wrongTargets` con margen de gracia | conserva los segundos |
| `ScrubCondition` | la `ScrubSurface` `surfaceId` llega a `threshold` | — | conserva el progreso |
| `HoldCondition` | el `HoldButton` `buttonId` llega a `threshold` (recuerda que ya llegó aunque decaiga) | — | conserva el valor |

Orden de juicio de `DropCondition` por cada soltado: 1) reglas en orden (Error → `ReportError`, no
cuenta; Aviso → `ReportWarning` y cuenta si era aceptable); 2) sin regla, aceptado → cuenta;
3) sin regla y no aceptado → ignorado o error con `defaultErrorKey`. Las reglas van **antes** de
"aceptado" para poder expresar pares incorrectos (estiércol en la zona de agua).
`ScrubCondition` y `HoldCondition` ponen el objeto en 0 al iniciar el paso (`resetOnStart`).

Ejemplo (paso "pon estiércol en la pila"): `DropCondition` con `acceptedItemIds=[estiercol]`,
`acceptedZoneIds=[pila]`, regla `{zoneId: agua, errorKey: estiercol_en_agua}` y en el `StepDefinition`
`errorLines["estiercol_en_agua"]` con la corrección hablada.

### Modo plano (`FlatInteractionDriver`)
Mismos eventos con mouse/touch, además de tap y rotación:
- arrastrar un `GrabbableItem` lo mueve sobre un plano horizontal a su altura; al soltar sobre una
  `DropZone` se emite el mismo `Dropped` (el release espera un paso de física para que la zona vea
  el último movimiento). Un tap corto sigue siendo tap (`DriverActivate`);
- presionar una `SourcePile` carga la herramienta y la arrastra desde el primer pixel;
- mantener sobre un `HoldButton` = select + activate; sobre una `AimTool` = select + activate y
  apunta con el rayo del puntero (`SetExternalRay`);
- arrastrar sobre una `ScrubSurface` frota con el recorrido del puntero.
`HandlePointer(...)` es público para simular el puntero en pruebas.

### StepTargetHighlighter
Componente de escena (Core, junto al `StepSystem`): al iniciar un paso muestra un anillo que pulsa bajo
cada `activeTargetIds` (los busca en `SceneTargetRegistry`; si aún no existen los espera) y lo
oculta al completar el paso. Con `HintSystem.HintShown` los anillos crecen 15 %. Anillo procedural
(`LineRenderer`, material `Sprites/Default` salvo que se asigne `ringMaterial`).

## Crear una interacción nueva (~15 min)

1. Script que herede de `InteractableBase`.
2. Traducir los eventos de tu fuente (XRI u otra) a los `Raise*()` protegidos:

```csharp
[RequireComponent(typeof(XRSimpleInteractable))]
public class PressableButton : InteractableBase
{
    private XRSimpleInteractable _interactable;

    private void Awake() => _interactable = GetComponent<XRSimpleInteractable>();

    private void OnEnable()
    {
        _interactable.selectEntered.AddListener(_ => RaiseActivated());
    }

    private void OnDisable() => _interactable.selectEntered.RemoveAllListeners();
}
```

3. Probarla en el playground (abajo). La telemetría y el contrato vienen gratis.

## Interaction Playground

Escena nueva → **Tools → XRLabs → Setup Interaction Playground**: genera mesa con un
ejemplar de cada interactable (y una segunda mesa con `DropZone`, `SourcePile`, `AimTool`,
`ScrubSurface` y `HoldButton`, v0.6) + `PlaygroundEventLog` (panel 3D que lista eventos y soltados en vivo).

Para probar sin headset: agregar XR Origin (GameObject → XR) y el **XR Device Simulator**
(Package Manager → XR Interaction Toolkit → Samples). WASD mueve, botón derecho mira,
G agarra.

## Legacy

`GrabInteractable` está `[Obsolete]` (era solo logging) — usar `GrabbableItem`.
`HotspotMarker`/`HotspotRegistry` (Simulations) siguen vigentes para las escenas actuales;
la fusión con `TouchableHotspot` está planificada junto con el re-cableado de escenas.
