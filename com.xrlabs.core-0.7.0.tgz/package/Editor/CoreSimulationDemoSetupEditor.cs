using XRLabs.Core;
using SimMode = XRLabs.Core.SimulationMode;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace XRLabs.Editor
{
    public static class CoreSimulationDemoSetupEditor
    {
        private const string RootName       = "SimulationRoot";
        private const string DemoAssetFolder = "Assets/_Project/Demo";

        [MenuItem("Tools/XR Simulation/Setup Core Demo (Editor)")]
        public static void SetupCoreDemo()
        {
            EnsureSceneLoaded();

            GameObject root = GameObject.Find(RootName);
            if (root == null)
                root = new GameObject(RootName);

            var simulationManager = GetOrAdd<SimulationManager>(root);
            var stepSystem        = GetOrAdd<StepSystem>(root);
            var scoringSystem     = GetOrAdd<ScoringSystem>(root);
            var hintSystem        = GetOrAdd<HintSystem>(root);
            _ = GetOrAdd<VOManager>(root);
            var feedbackSystem    = GetOrAdd<FeedbackSystem>(root);
            var telemetryClient   = GetOrAdd<TelemetryClient>(root);
            var demoHud           = GetOrAdd<CoreSimulationDemoHUD>(root);

            _ = hintSystem;
            _ = feedbackSystem;
            _ = demoHud;

            if (root.GetComponent<AudioSource>() == null)
                root.AddComponent<AudioSource>();

            AssignSimulationManagerReferences(simulationManager, stepSystem, scoringSystem, telemetryClient);
            AssignDemoSequence(stepSystem);

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Selection.activeObject = root;
            EditorUtility.SetDirty(root);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());

            Debug.Log("Core demo setup complete. Press Play → Space / Wait 2s / Enter to complete all steps.");
        }

        private static void EnsureSceneLoaded()
        {
            if (!SceneManager.GetActiveScene().IsValid())
                EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        }

        private static T GetOrAdd<T>(GameObject target) where T : Component
        {
            T component = target.GetComponent<T>();
            if (component == null)
                component = target.AddComponent<T>();
            return component;
        }

        private static void AssignSimulationManagerReferences(
            SimulationManager simulationManager,
            StepSystem stepSystem,
            ScoringSystem scoringSystem,
            TelemetryClient telemetryClient)
        {
            var so = new SerializedObject(simulationManager);
            so.FindProperty("stepSystem").objectReferenceValue      = stepSystem;
            so.FindProperty("scoringSystem").objectReferenceValue   = scoringSystem;
            so.FindProperty("telemetryClient").objectReferenceValue = telemetryClient;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void AssignDemoSequence(StepSystem stepSystem)
        {
            EnsureFolder(DemoAssetFolder);
            EnsureFolder(DemoAssetFolder + "/Conditions");
            EnsureFolder(DemoAssetFolder + "/Steps");
            EnsureFolder(DemoAssetFolder + "/Sequences");

            var condSpace = CreateOrLoadManualKeyCondition(
                DemoAssetFolder + "/Conditions/Condition_Space.asset", KeyCode.Space);
            var condTime  = CreateOrLoadElapsedCondition(
                DemoAssetFolder + "/Conditions/Condition_2Seconds.asset", 2f);
            var condEnter = CreateOrLoadManualKeyCondition(
                DemoAssetFolder + "/Conditions/Condition_Enter.asset", KeyCode.Return);

            var step1 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_01_Inspect.asset",
                "step-01-inspect",
                "Presiona Space para confirmar inspeccion inicial.",
                condSpace, 8f, 20f, 10, 5);

            var step2 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_02_Observe.asset",
                "step-02-observe",
                "Espera el tiempo de observacion para simular analisis.",
                condTime, 6f, 15f, 10, 5);

            var step3 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_03_Confirm.asset",
                "step-03-confirm",
                "Presiona Enter para confirmar diagnostico.",
                condEnter, 8f, 20f, 10, 5);

            var sequence = CreateOrLoadDemoSequence(
                DemoAssetFolder + "/Sequences/DemoSequence.asset",
                step1, step2, step3);

            var so = new SerializedObject(stepSystem);
            so.FindProperty("sequence").objectReferenceValue = sequence;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static SimulationSequence CreateOrLoadDemoSequence(
            string path, StepDefinition s1, StepDefinition s2, StepDefinition s3)
        {
            var asset = AssetDatabase.LoadAssetAtPath<SimulationSequence>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<SimulationSequence>();
                AssetDatabase.CreateAsset(asset, path);
            }

            asset.sequenceName = "Demo Sequence";
            asset.description  = "Secuencia demo para testear el StepSystem en editor.";
            asset.mode         = SimMode.Guided;

            var so = new SerializedObject(asset);
            var arr = so.FindProperty("steps");
            arr.arraySize = 3;
            arr.GetArrayElementAtIndex(0).objectReferenceValue = s1;
            arr.GetArrayElementAtIndex(1).objectReferenceValue = s2;
            arr.GetArrayElementAtIndex(2).objectReferenceValue = s3;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static ManualKeyStepCondition CreateOrLoadManualKeyCondition(string path, KeyCode keyCode)
        {
            var asset = AssetDatabase.LoadAssetAtPath<ManualKeyStepCondition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<ManualKeyStepCondition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            var so = new SerializedObject(asset);
            so.FindProperty("completeKey").intValue = (int)keyCode;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static ElapsedTimeStepCondition CreateOrLoadElapsedCondition(string path, float seconds)
        {
            var asset = AssetDatabase.LoadAssetAtPath<ElapsedTimeStepCondition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<ElapsedTimeStepCondition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            var so = new SerializedObject(asset);
            so.FindProperty("secondsToComplete").floatValue = seconds;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static StepDefinition CreateOrLoadStep(
            string path,
            string stepId,
            string description,
            StepCondition completionCondition,
            float hintDelay,
            float maxAllowedTime,
            int scoreOnSuccess,
            int penaltyOnError)
        {
            var asset = AssetDatabase.LoadAssetAtPath<StepDefinition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<StepDefinition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            asset.stepType            = StepType.Interaction;
            asset.stepId              = stepId;
            asset.description         = description;
            asset.completionCondition = completionCondition;
            asset.hintDelay           = hintDelay;
            asset.maxAllowedTime      = maxAllowedTime;
            asset.scoreOnSuccess      = scoreOnSuccess;
            asset.penaltyOnError      = penaltyOnError;

            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static void EnsureFolder(string folderPath)
        {
            if (AssetDatabase.IsValidFolder(folderPath)) return;

            string[] parts = folderPath.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
