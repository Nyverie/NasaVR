using XRLabs.Core;
using SimMode = XRLabs.Core.SimulationMode;
using XRLabs.DebugTools;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

namespace XRLabs.Editor
{
    /// <summary>
    /// Menú: Tools/XR Simulation/Setup Sim Debugger Scene
    /// Crea (o actualiza) la escena activa con todos los componentes necesarios para
    /// correr el sistema de simulación completo sin headset Meta.
    /// </summary>
    public static class SimDebugSceneSetupEditor
    {
        private const string SimRootName    = "SimulationRoot";
        private const string DemoAssetFolder = "Assets/_Project/Demo";

        [MenuItem("Tools/XR Simulation/Setup Sim Debugger Scene")]
        public static void SetupSimDebuggerScene()
        {
            EnsureSceneLoaded();

            EnsureMainCamera();
            EnsureEventSystem();

            GameObject root = GetOrCreateRoot(SimRootName);

            // ── Core systems ─────────────────────────────────────────────────────
            var simulationManager = GetOrAdd<SimulationManager>(root);
            var stepSystem        = GetOrAdd<StepSystem>(root);
            var scoringSystem     = GetOrAdd<ScoringSystem>(root);
            var hintSystem        = GetOrAdd<HintSystem>(root);
            _ = GetOrAdd<VOManager>(root);
            _ = GetOrAdd<FeedbackSystem>(root);
            var telemetryClient   = GetOrAdd<TelemetryClient>(root);

            _ = hintSystem;

            // AudioSource requerido por VOManager
            if (root.GetComponent<AudioSource>() == null)
                root.AddComponent<AudioSource>();

            // ── Debug systems ────────────────────────────────────────────────────
            var debugger = GetOrAdd<SimulationDebugger>(root);
            _ = GetOrAdd<SimDebugHUD>(root);

            // ── Wiring ───────────────────────────────────────────────────────────
            WireSimulationManager(simulationManager, stepSystem, scoringSystem, telemetryClient);
            WireSimulationDebugger(debugger, stepSystem, simulationManager);
            AssignDemoSequence(stepSystem);

            // ── Finalizar ────────────────────────────────────────────────────────
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Selection.activeObject = root;
            EditorUtility.SetDirty(root);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());

            UnityEngine.Debug.Log(
                "[SimDebugSetup] Escena configurada. " +
                "Presiona Play → F1 para el HUD → F2 para avanzar pasos.");
        }

        // ── Helpers de escena ────────────────────────────────────────────────────

        private static void EnsureSceneLoaded()
        {
            if (!SceneManager.GetActiveScene().IsValid())
                EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        }

        private static void EnsureMainCamera()
        {
            if (Camera.main != null) return;
            var camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            var cam = camObj.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.Skybox;
            camObj.AddComponent<AudioListener>();
            EditorUtility.SetDirty(camObj);
        }

        private static void EnsureEventSystem()
        {
            if (Object.FindAnyObjectByType<EventSystem>() != null) return;
            var esObj = new GameObject("EventSystem");
            esObj.AddComponent<EventSystem>();
            esObj.AddComponent<StandaloneInputModule>();
            EditorUtility.SetDirty(esObj);
        }

        private static GameObject GetOrCreateRoot(string name)
        {
            var existing = GameObject.Find(name);
            return existing != null ? existing : new GameObject(name);
        }

        private static T GetOrAdd<T>(GameObject target) where T : Component
        {
            var c = target.GetComponent<T>();
            if (c == null) c = target.AddComponent<T>();
            return c;
        }

        // ── Wiring ───────────────────────────────────────────────────────────────

        private static void WireSimulationManager(
            SimulationManager sm,
            StepSystem ss,
            ScoringSystem sc,
            TelemetryClient tc)
        {
            var so = new SerializedObject(sm);
            so.FindProperty("stepSystem").objectReferenceValue      = ss;
            so.FindProperty("scoringSystem").objectReferenceValue   = sc;
            so.FindProperty("telemetryClient").objectReferenceValue = tc;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void WireSimulationDebugger(
            SimulationDebugger dbg,
            StepSystem ss,
            SimulationManager sm)
        {
            var so = new SerializedObject(dbg);
            so.FindProperty("stepSystem").objectReferenceValue        = ss;
            so.FindProperty("simulationManager").objectReferenceValue = sm;
            // hotspotRegistry y caseEvaluationController quedan null (opcionales)
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // ── Demo sequence ────────────────────────────────────────────────────────

        private static void AssignDemoSequence(StepSystem stepSystem)
        {
            EnsureFolder(DemoAssetFolder);
            EnsureFolder(DemoAssetFolder + "/Conditions");
            EnsureFolder(DemoAssetFolder + "/Steps");
            EnsureFolder(DemoAssetFolder + "/Sequences");

            var condSpace = CreateOrLoadManualKeyCondition(
                DemoAssetFolder + "/Conditions/Condition_Space.asset", KeyCode.Space);
            var condTime  = CreateOrLoadElapsedCondition(
                DemoAssetFolder + "/Conditions/Condition_2Seconds.asset", 2f);
            var condEnter = CreateOrLoadManualKeyCondition(
                DemoAssetFolder + "/Conditions/Condition_Enter.asset", KeyCode.Return);

            var step1 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_01_Inspect.asset",
                "step-01-inspect",
                "Presiona Space para confirmar inspección inicial.",
                condSpace, 8f, 20f, 10, 5);

            var step2 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_02_Observe.asset",
                "step-02-observe",
                "Espera el tiempo de observación (o F2 para forzar).",
                condTime, 6f, 15f, 10, 5);

            var step3 = CreateOrLoadStep(
                DemoAssetFolder + "/Steps/Step_03_Confirm.asset",
                "step-03-confirm",
                "Presiona Enter para confirmar diagnóstico.",
                condEnter, 8f, 20f, 10, 5);

            var sequence = CreateOrLoadDemoSequence(
                DemoAssetFolder + "/Sequences/DemoSequence.asset",
                step1, step2, step3);

            var so = new SerializedObject(stepSystem);
            so.FindProperty("sequence").objectReferenceValue = sequence;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static SimulationSequence CreateOrLoadDemoSequence(
            string path, StepDefinition s1, StepDefinition s2, StepDefinition s3)
        {
            var asset = AssetDatabase.LoadAssetAtPath<SimulationSequence>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<SimulationSequence>();
                AssetDatabase.CreateAsset(asset, path);
            }

            asset.sequenceName = "Demo Sequence";
            asset.description  = "Secuencia demo para testear el StepSystem en editor.";
            asset.mode         = SimMode.Guided;

            var so = new SerializedObject(asset);
            var arr = so.FindProperty("steps");
            arr.arraySize = 3;
            arr.GetArrayElementAtIndex(0).objectReferenceValue = s1;
            arr.GetArrayElementAtIndex(1).objectReferenceValue = s2;
            arr.GetArrayElementAtIndex(2).objectReferenceValue = s3;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static ManualKeyStepCondition CreateOrLoadManualKeyCondition(string path, KeyCode key)
        {
            var asset = AssetDatabase.LoadAssetAtPath<ManualKeyStepCondition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<ManualKeyStepCondition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            var so = new SerializedObject(asset);
            so.FindProperty("completeKey").intValue = (int)key;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static ElapsedTimeStepCondition CreateOrLoadElapsedCondition(string path, float seconds)
        {
            var asset = AssetDatabase.LoadAssetAtPath<ElapsedTimeStepCondition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<ElapsedTimeStepCondition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            var so = new SerializedObject(asset);
            so.FindProperty("secondsToComplete").floatValue = seconds;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static StepDefinition CreateOrLoadStep(
            string path,
            string stepId,
            string description,
            StepCondition condition,
            float hintDelay,
            float maxAllowedTime,
            int scoreOnSuccess,
            int penaltyOnError)
        {
            var asset = AssetDatabase.LoadAssetAtPath<StepDefinition>(path);
            if (asset == null)
            {
                asset = ScriptableObject.CreateInstance<StepDefinition>();
                AssetDatabase.CreateAsset(asset, path);
            }

            asset.stepType            = StepType.Interaction;
            asset.stepId              = stepId;
            asset.description         = description;
            asset.completionCondition = condition;
            asset.hintDelay           = hintDelay;
            asset.maxAllowedTime      = maxAllowedTime;
            asset.scoreOnSuccess      = scoreOnSuccess;
            asset.penaltyOnError      = penaltyOnError;

            EditorUtility.SetDirty(asset);
            return asset;
        }

        private static void EnsureFolder(string folderPath)
        {
            if (AssetDatabase.IsValidFolder(folderPath)) return;
            string[] parts = folderPath.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
