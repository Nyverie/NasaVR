using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;

namespace XRLabs.Visor.Editor
{
    /// <summary>
    /// Compila el anfitrión para un visor (lote del visor, 2026-10-17): Android, IL2CPP, ARM64, Vulkan, el SDK mínimo
    /// del visor, el Menu XRI en el índice 0 y las experiencias preparadas detrás, con OpenXR configurado por
    /// <see cref="VisorOpenXr"/>. Menú <c>Tools/XRLabs/Visor</c> y, en batch, <see cref="BuildFromCommandLine"/>
    /// (<c>-visorTarget Quest3|GalaxyXR</c>). El APK cae en <c>Builds/&lt;visor&gt;/</c> del proyecto anfitrión.
    /// </summary>
    public static class VisorBuilds
    {
        [MenuItem("Tools/XRLabs/Visor/Compilar Quest 3")]
        public static void BuildQuest3Menu() => Build(VisorTarget.Quest3);

        [MenuItem("Tools/XRLabs/Visor/Compilar Galaxy XR")]
        public static void BuildGalaxyXrMenu() => Build(VisorTarget.GalaxyXR);

        [MenuItem("Tools/XRLabs/Visor/Solo configurar OpenXR para Quest 3")]
        public static void ConfigureQuest3Menu() { VisorOpenXr.Remember(VisorTarget.Quest3); VisorOpenXr.Configure(VisorTarget.Quest3); }

        [MenuItem("Tools/XRLabs/Visor/Solo configurar OpenXR para Galaxy XR")]
        public static void ConfigureGalaxyXrMenu() { VisorOpenXr.Remember(VisorTarget.GalaxyXR); VisorOpenXr.Configure(VisorTarget.GalaxyXR); }

        /// <summary>Para Unity en batch: <c>-executeMethod XRLabs.Visor.Editor.VisorBuilds.BuildFromCommandLine -visorTarget Quest3</c>.</summary>
        public static void BuildFromCommandLine()
        {
            var args = Environment.GetCommandLineArgs();
            int i = Array.IndexOf(args, "-visorTarget");
            if (i < 0 || i + 1 >= args.Length || !Enum.TryParse(args[i + 1], true, out VisorTarget target))
            {
                Debug.LogError("[Visor] Falta -visorTarget Quest3|GalaxyXR");
                EditorApplication.Exit(2);
                return;
            }
            bool prepareSamples = Array.IndexOf(args, "-prepareSamples") >= 0;
            bool ok = Build(target, prepareSamples);
            EditorApplication.Exit(ok ? 0 : 1);
        }

        /// <summary>
        /// Compila para el visor. Con <paramref name="prepareSamples"/>, antes prepara las muestras del paquete en el anfitrión
        /// (sus escenas entran en Build Settings). La build es **de investigación**: Development Build; si a alguna escena le
        /// faltan voces, se permite la voz incompleta (VoiceSettings.allowIncompleteVoiceInDevBuilds) y lo dice el registro; con
        /// las voces horneadas no hace falta. Una build de producto se detiene sin voz, como siempre (VoiceBuildValidator).
        /// </summary>
        public static bool Build(VisorTarget target, bool prepareSamples = false)
        {
            // Primero lo barato: si el URP no está listo para el Quest, no se gasta el cambio de plataforma ni la preparación.
            if (!VisorUrpCheck.Validate(out var urpProblem)) { Debug.LogError(urpProblem); return false; }

            if (prepareSamples)
            {
                bool prepared = XRLabs.Authoring.Editor.SamplePreparer.PrepareAll(out var samplesSummary);
                Debug.Log(samplesSummary);
                if (!prepared) { Debug.LogError("[Visor] Las muestras no se prepararon; no se compila."); return false; }
            }

            VisorOpenXr.Remember(target);
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
            {
                Debug.Log("[Visor] Cambiando la plataforma activa a Android");
                if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
                {
                    Debug.LogError("[Visor] No se pudo cambiar a Android (¿módulo Android instalado?)");
                    return false;
                }
            }

            ApplyPlayerSettings(target);
            VisorOpenXr.Configure(target);

            var scenes = VisorBuildPlan.ScenePaths(EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path));
            var output = VisorBuildPlan.OutputPath(target);
            Directory.CreateDirectory(Path.GetDirectoryName(output) ?? "Builds");

            var voice = XRLabs.Authoring.Editor.VoiceBakeRunner.GetOrCreateSettings();
            int missingVoices = XRLabs.Coach.Editor.VoiceBuildValidator.CountProblemsForBuild(voice);
            if (missingVoices == 0)
            {
                Debug.Log("[Visor] Voces completas en las escenas de la build: no hace falta permitir la voz incompleta.");
            }
            else
            {
                if (voice != null && !voice.allowIncompleteVoiceInDevBuilds)
                {
                    voice.allowIncompleteVoiceInDevBuilds = true;
                    EditorUtility.SetDirty(voice);
                    AssetDatabase.SaveAssets();
                }
                Debug.Log($"[Visor] Build de investigación: Development Build con la voz incompleta permitida ({missingVoices} variantes sin voz al día; «Generar voces que faltan» en Tools/XRLabs/Autoría).");
            }

            var options = new BuildPlayerOptions
            {
                scenes = scenes.ToArray(),
                locationPathName = output,
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                options = BuildOptions.Development
            };
            Debug.Log($"[Visor] Compilando {target}: {scenes.Count} escenas ({string.Join(", ", scenes)}) → {output}");
            var report = BuildPipeline.BuildPlayer(options);
            var summary = report.summary;
            bool ok = summary.result == BuildResult.Succeeded;
            Debug.Log($"[Visor] {(ok ? "OK" : "ERROR")}: {summary.result}, {summary.totalErrors} errores, {summary.totalWarnings} avisos, " +
                      $"{summary.totalSize / (1024 * 1024)} MB, {summary.totalTime.TotalMinutes:0.0} min → {summary.outputPath}");
            Debug.Log(ok ? "VISOR: OK" : "VISOR: ERROR");
            return ok;
        }

        private static void ApplyPlayerSettings(VisorTarget target)
        {
            var android = NamedBuildTarget.Android;
            PlayerSettings.SetApplicationIdentifier(android, VisorBuildPlan.ApplicationIdentifier);
            PlayerSettings.SetScriptingBackend(android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = (AndroidSdkVersions)VisorBuildPlan.MinSdk(target);
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.Vulkan });
            PlayerSettings.colorSpace = ColorSpace.Linear;
            if (string.IsNullOrEmpty(PlayerSettings.productName)) PlayerSettings.productName = "XRLabs Host";
            PlayerSettings.companyName = "XRLabs";
        }
    }

    /// <summary>
    /// Antes de cualquier build Android (también una lanzada desde Build Settings a mano), aplica el OpenXR del último
    /// visor elegido en <c>Tools/XRLabs/Visor</c>; el XR Plug-in Management no se fija por Build Profile, así que esto es
    /// lo que hace de «perfil». Sin visor recordado no toca nada y lo dice; con él, además detiene la build si el URP no es el
    /// del Quest (<see cref="VisorUrpCheck"/>).
    /// </summary>
    public sealed class VisorPreBuild : IPreprocessBuildWithReport
    {
        public int callbackOrder => -100;

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android) return;
            if (!VisorOpenXr.TryGetRemembered(out var target))
            {
                Debug.LogWarning("[Visor] Build Android sin visor elegido: OpenXR queda como esté. Elige uno en Tools/XRLabs/Visor.");
                return;
            }
            VisorOpenXr.Configure(target);
            // Con visor elegido, el URP también tiene que ser el del visor: una build a mano desde Build Settings no se salta el chequeo.
            if (!VisorUrpCheck.Validate(out var urpProblem)) throw new BuildFailedException(urpProblem);
        }
    }
}
