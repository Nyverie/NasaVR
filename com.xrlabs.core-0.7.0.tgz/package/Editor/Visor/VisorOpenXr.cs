using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

namespace XRLabs.Visor.Editor
{
    /// <summary>
    /// Deja el XR Plug-in Management y OpenXR de Android como los pide el visor elegido (lote del visor, 2026-10-17):
    /// loader OpenXR asignado e iniciado al arrancar, y encendido solo el conjunto de características del visor (Meta
    /// Quest para el Quest 3; Android XR para el Galaxy XR), con lo que cada conjunto trae por defecto (soporte del
    /// dispositivo y perfiles de interacción). Lo llama VisorBuilds antes de compilar y VisorPreBuild en cualquier build
    /// Android si hay un visor recordado en EditorPrefs.
    /// </summary>
    public static class VisorOpenXr
    {
        public const string PrefsKey = "xrlabs.visor.target";
        private const string OpenXrLoaderType = "UnityEngine.XR.OpenXR.OpenXRLoader";
        public const string SettingsAssetPath = "Assets/XR/XRGeneralSettingsPerBuildTarget.asset";

        public static bool TryGetRemembered(out VisorTarget target)
        {
            var stored = EditorPrefs.GetString(PrefsKey, string.Empty);
            return System.Enum.TryParse(stored, out target) && !string.IsNullOrEmpty(stored);
        }

        public static void Remember(VisorTarget target) => EditorPrefs.SetString(PrefsKey, target.ToString());

        /// <summary>Aplica la configuración y devuelve un resumen legible (lo que quedó encendido).</summary>
        public static string Configure(VisorTarget target)
        {
            var notes = new List<string>();
            EnsureOpenXrLoader(BuildTargetGroup.Android, notes);
            EnableFeatureSet(BuildTargetGroup.Android, target, notes);
            AssetDatabase.SaveAssets();
            var summary = $"[Visor] OpenXR para {target}: " + string.Join("; ", notes);
            Debug.Log(summary);
            return summary;
        }

        private static void EnsureOpenXrLoader(BuildTargetGroup group, List<string> notes)
        {
            // Lo que hace la ventana de XR Plug-in Management, con la API pública: el asset de ajustes por plataforma
            // registrado como objeto de configuración, y dentro de él los ajustes y el gestor de la plataforma.
            if (!EditorBuildSettings.TryGetConfigObject(XRGeneralSettings.k_SettingsKey, out XRGeneralSettingsPerBuildTarget perTarget) || perTarget == null)
            {
                perTarget = AssetDatabase.LoadAssetAtPath<XRGeneralSettingsPerBuildTarget>(SettingsAssetPath);
                if (perTarget == null)
                {
                    if (!AssetDatabase.IsValidFolder("Assets/XR")) AssetDatabase.CreateFolder("Assets", "XR");
                    perTarget = ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();
                    AssetDatabase.CreateAsset(perTarget, SettingsAssetPath);
                }
                EditorBuildSettings.AddConfigObject(XRGeneralSettings.k_SettingsKey, perTarget, true);
                notes.Add("XRGeneralSettings creados en " + SettingsAssetPath);
            }
            var settings = perTarget.SettingsForBuildTarget(group);
            if (settings == null)
            {
                settings = ScriptableObject.CreateInstance<XRGeneralSettings>();
                settings.name = group + " Settings";
                var created = ScriptableObject.CreateInstance<XRManagerSettings>();
                created.name = group + " Providers";
                AssetDatabase.AddObjectToAsset(settings, perTarget);
                AssetDatabase.AddObjectToAsset(created, perTarget);
                settings.Manager = created;
                perTarget.SetSettingsForBuildTarget(group, settings);
                notes.Add("ajustes de " + group + " creados");
            }
            if (settings.Manager == null)
            {
                var created = ScriptableObject.CreateInstance<XRManagerSettings>();
                created.name = group + " Providers";
                AssetDatabase.AddObjectToAsset(created, perTarget);
                settings.Manager = created;
                notes.Add("gestor de " + group + " creado");
            }
            settings.InitManagerOnStart = true;
            var manager = settings.Manager;
            bool hasLoader = manager.activeLoaders.Any(l => l != null && l.GetType().FullName == OpenXrLoaderType);
            if (!hasLoader)
            {
                if (XRPackageMetadataStore.AssignLoader(manager, OpenXrLoaderType, group)) notes.Add("loader OpenXR asignado");
                else notes.Add("NO se pudo asignar el loader OpenXR");
            }
            else notes.Add("loader OpenXR ya estaba");
            EditorUtility.SetDirty(settings);
            EditorUtility.SetDirty(perTarget);
        }

        // Primero los conjuntos (si el paquete registra uno para el visor), y siempre las características una a una por su
        // nombre (2026-10-17: en batch solo apareció el conjunto 'android'; el soporte de Meta Quest es una característica
        // del propio paquete OpenXR sin conjunto). Lo del otro fabricante se apaga para no mezclar runtimes.
        private static void EnableFeatureSet(BuildTargetGroup group, VisorTarget target, List<string> notes)
        {
            FeatureHelpers.RefreshFeatures(group);

            var sets = OpenXRFeatureSetManager.FeatureSetsForBuildTarget(group);
            if (sets == null) sets = new List<OpenXRFeatureSetManager.FeatureSet>();
            var wantedSets = sets.Where(s => VisorBuildPlan.FeatureSetMatches(s.featureSetId, target)).ToList();
            foreach (var set in sets)
            {
                bool on = wantedSets.Contains(set);
                if (set.isEnabled != on)
                {
                    set.isEnabled = on;
                    notes.Add((on ? "enciende el conjunto " : "apaga el conjunto ") + set.name);
                }
            }
            if (wantedSets.Count() > 0) OpenXRFeatureSetManager.SetFeaturesFromEnabledFeatureSets(group);
            else notes.Add("sin conjunto propio para " + target + " (hay: " + string.Join(", ", sets.Select(s => s.featureSetId)) + ")");

            var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(group);
            if (settings == null) { notes.Add("NO hay OpenXRSettings para " + group); return; }

            var features = settings.GetFeatures<OpenXRFeature>().Where(f => f != null).ToList();
            int wanted = 0;
            foreach (var feature in features)
            {
                string ui = FeatureUiName(feature);
                if (VisorBuildPlan.FeatureWanted(ui, target))
                {
                    wanted++;
                    if (!feature.enabled) { feature.enabled = true; notes.Add("enciende " + ui); }
                }
                else if (VisorBuildPlan.FeatureForeign(ui, target) && feature.enabled)
                {
                    feature.enabled = false;
                    notes.Add("apaga " + ui);
                }
            }
            if (wanted == 0)
                notes.Add($"NO hay ninguna característica de OpenXR para {target} entre: {string.Join(", ", features.Select(FeatureUiName))}; falta el paquete");

            // XR al día 2026-10-31 (H4): la latencia que prioriza la entrada, si el visor la pide.
            var latency = VisorBuildPlan.PrioritizeInputPolling(target)
                ? OpenXRSettings.LatencyOptimization.PrioritizeInputPolling
                : OpenXRSettings.LatencyOptimization.PrioritizeRendering;
            if (settings.latencyOptimization != latency)
            {
                settings.latencyOptimization = latency;
                notes.Add("latencia: " + latency);
            }

            var enabled = features.Where(f => f.enabled).Select(FeatureUiName).ToList();
            notes.Add("características encendidas: " + string.Join(", ", enabled));
            foreach (var feature in features) EditorUtility.SetDirty(feature);
            EditorUtility.SetDirty(settings);
        }

        // El nombre de la UI viene del atributo; si falta, el del asset (que suele ser el mismo) o el del tipo.
        private static string FeatureUiName(OpenXRFeature feature)
        {
            var attribute = (OpenXRFeatureAttribute)System.Attribute.GetCustomAttribute(feature.GetType(), typeof(OpenXRFeatureAttribute));
            if (attribute != null && !string.IsNullOrEmpty(attribute.UiName)) return attribute.UiName;
            return string.IsNullOrEmpty(feature.name) ? feature.GetType().Name : feature.name;
        }
    }
}
