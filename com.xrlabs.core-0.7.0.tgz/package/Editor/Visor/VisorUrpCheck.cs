using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace XRLabs.Visor.Editor
{
    /// <summary>Lo que importa del URP para el visor: lo que dicen el URP Asset y su Universal Renderer.</summary>
    public readonly struct VisorUrpSettings
    {
        public readonly string Origin;
        public readonly bool Hdr;
        public readonly int Msaa;
        public readonly bool MainLightShadows;
        public readonly bool AdditionalLightShadows;
        public readonly bool IntermediateTextureAlways;

        public VisorUrpSettings(string origin, bool hdr, int msaa, bool mainLightShadows, bool additionalLightShadows, bool intermediateTextureAlways)
        {
            Origin = origin;
            Hdr = hdr;
            Msaa = msaa;
            MainLightShadows = mainLightShadows;
            AdditionalLightShadows = additionalLightShadows;
            IntermediateTextureAlways = intermediateTextureAlways;
        }
    }

    /// <summary>
    /// El URP que el Quest necesita, comprobado antes de compilar para el visor (corrección 7 de la auditoría del visor,
    /// 2026-10-25): HDR apagado, MSAA 4× o más, sin sombras de la luz principal ni de las adicionales y la textura
    /// intermedia en «Auto». Con la configuración por defecto de URP (HDR, sin MSAA, sombras, textura intermedia siempre)
    /// el Quest paga una copia completa por cuadro hacia la swapchain XR, una pasada de sombras que la escena no usa y bordes
    /// que parpadean; la build compila igual, así que la regresión no se vería hasta medir en el casco. Por eso
    /// <see cref="VisorBuilds"/> y <see cref="VisorPreBuild"/> **detienen la build** en vez de avisar. La parte pura
    /// (<see cref="Problems"/>, <see cref="Failure"/>) se prueba sin assets; <see cref="ReadProject"/> lee los URP Assets que
    /// usa el proyecto (el de Graphics y los de todos los niveles de Quality: el sistema no deja leer por plataforma qué
    /// niveles excluye Android, y el anfitrión usa uno solo, D31).
    /// </summary>
    public static class VisorUrpCheck
    {
        public const int MinMsaa = 4;

        /// <summary>Lo que no cumple un URP, una línea por incumplimiento; vacío si está listo para el Quest.</summary>
        public static List<string> Problems(VisorUrpSettings s)
        {
            var problems = new List<string>();
            if (s.Hdr) problems.Add("HDR encendido (debe estar apagado: con la textura intermedia obliga a una copia extra por cuadro hacia la swapchain XR)");
            if (s.Msaa < MinMsaa) problems.Add($"MSAA {s.Msaa}× (mínimo {MinMsaa}×: sin él los bordes de los cubos y las etiquetas parpadean)");
            if (s.MainLightShadows) problems.Add("sombras de la luz principal encendidas (deben estar apagadas: una pasada de mapa de sombras por cuadro)");
            if (s.AdditionalLightShadows) problems.Add("sombras de las luces adicionales encendidas (deben estar apagadas)");
            if (s.IntermediateTextureAlways) problems.Add("Intermediate Texture en «Always» (debe ser «Auto»: fuerza una textura intermedia que el Quest no perdona)");
            return problems;
        }

        /// <summary>El mensaje de un build detenido: cada incumplimiento con su origen y dónde se arregla.</summary>
        public static string Failure(IReadOnlyList<string> problems)
        {
            var text = new StringBuilder("[Visor] El URP del anfitrión no está listo para el Quest (corrección 7 de la auditoría del visor); no se compila:");
            foreach (var p in problems) text.Append("\n  - ").Append(p);
            text.Append("\n  Se arregla en Host~/Assets/Settings (URP-Asset.asset y URP-Renderer.asset); los valores y por qué están en Documentation~/platform-support.md, «URP para el Quest».");
            return text.ToString();
        }

        /// <summary>
        /// Los URP Assets del proyecto (Graphics y todos los niveles de Quality, sin repetir), cada uno con cada Universal
        /// Renderer de su lista. Un asset que no es URP no cuenta. Sin ninguno, la lista sale vacía.
        /// </summary>
        public static List<VisorUrpSettings> ReadProject()
        {
            var result = new List<VisorUrpSettings>();
            var seen = new HashSet<UniversalRenderPipelineAsset>();
            void Add(RenderPipelineAsset candidate)
            {
                if (candidate is UniversalRenderPipelineAsset urp && seen.Add(urp)) Read(urp, result);
            }
            Add(GraphicsSettings.defaultRenderPipeline);
            for (int i = 0; i < QualitySettings.names.Length; i++) Add(QualitySettings.GetRenderPipelineAssetAt(i));
            return result;
        }

        private static void Read(UniversalRenderPipelineAsset asset, List<VisorUrpSettings> into)
        {
            var path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) path = asset.name;
            bool any = false;
            foreach (var data in asset.rendererDataList)
            {
                if (data is not UniversalRendererData renderer) continue;
                any = true;
                into.Add(new VisorUrpSettings($"{path} + {AssetDatabase.GetAssetPath(renderer)}", asset.supportsHDR, asset.msaaSampleCount,
                    asset.supportsMainLightShadows, asset.supportsAdditionalLightShadows, renderer.intermediateTextureMode == IntermediateTextureMode.Always));
            }
            // Un URP Asset sin Universal Renderer (otro tipo de renderer) no tiene textura intermedia que forzar.
            if (!any)
                into.Add(new VisorUrpSettings(path, asset.supportsHDR, asset.msaaSampleCount,
                    asset.supportsMainLightShadows, asset.supportsAdditionalLightShadows, false));
        }

        /// <summary>Los incumplimientos del proyecto, cada uno con el asset de donde sale. Vacío = listo para el Quest.</summary>
        public static List<string> ProjectProblems()
        {
            var all = new List<string>();
            var settings = ReadProject();
            if (settings.Count == 0) all.Add("el proyecto no usa URP: ni Graphics ni ningún nivel de Quality tiene un URP Asset (D31)");
            foreach (var s in settings)
                foreach (var p in Problems(s)) all.Add($"{s.Origin}: {p}");
            return all;
        }

        /// <summary>El chequeo previo a la build: true si está todo bien; si no, deja el motivo en <paramref name="message"/>.</summary>
        public static bool Validate(out string message)
        {
            var problems = ProjectProblems();
            message = problems.Count == 0 ? string.Empty : Failure(problems);
            return problems.Count == 0;
        }
    }
}
