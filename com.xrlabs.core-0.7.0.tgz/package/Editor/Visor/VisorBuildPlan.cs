using System;
using System.Collections.Generic;
using System.Linq;

namespace XRLabs.Visor.Editor
{
    /// <summary>Las dos cabeceras del lote del visor (2026-10-17). Cada una es una build Android con su OpenXR.</summary>
    public enum VisorTarget
    {
        Quest3,
        GalaxyXR
    }

    /// <summary>
    /// La parte pura del «perfil de build» de cada visor, separada para probarla sin compilar nada: qué escenas van y en
    /// qué orden (D9: el Menu en el índice 0; en el visor es el Menu XRI, D23, y nunca el Menu de Meta), qué conjunto de
    /// características de OpenXR se enciende, el SDK mínimo de Android y dónde cae el APK. Los Build Profiles de Unity 6
    /// no fijan el XR Plug-in Management por perfil: por eso esto vive en código y VisorOpenXr lo aplica antes de compilar.
    /// </summary>
    public static class VisorBuildPlan
    {
        public const string ApplicationIdentifier = "lat.xrlabs.host";
        public const string MenuXriScenePath = "Packages/com.xrlabs.core/Runtime/MenuXRI/Menu.unity";
        public const string MenuMetaScenePath = "Packages/com.xrlabs.core/Runtime/Menu/Menu.unity";

        /// <summary>El id del conjunto de características de OpenXR que enciende cada visor (se compara sin mayúsculas, por contenido).</summary>
        public static string FeatureSetKeyword(VisorTarget target) => target == VisorTarget.GalaxyXR ? "androidxr" : "meta";

        public static bool FeatureSetMatches(string featureSetId, VisorTarget target) =>
            !string.IsNullOrEmpty(featureSetId) &&
            featureSetId.IndexOf(FeatureSetKeyword(target), StringComparison.OrdinalIgnoreCase) >= 0;

        // XR al día 2026-10-31 (informe «OpenXR, Android XR y XRI al día», hallazgos H2, H3 y H4):
        //  - H2: el Galaxy XR ya no apaga el Oculus Touch Controller Profile. Google: «Android XR supports the Oculus Touch
        //    Controller Profile for 6DoF controllers» (developer.android.com/develop/xr/unity, 2026-10-28); sin él el mando
        //    del Galaxy XR solo llegaba por el Khronos Simple, sin palanca (teletransporte y giro) ni grip (agarre). La
        //    palabra foránea deja de ser «oculus» a secas y pasa a «meta quest» y «oculus quest» (el soporte de Meta).
        //  - H3: manos en los dos visores: Hand Tracking Subsystem (XR Hands) y Hand Interaction Profile (XR_EXT_hand_
        //    interaction); en el Quest, además, Meta Hand Tracking Aim (lo pide la Hands Interaction Demo de XRI 3.7). En el
        //    Galaxy XR el Aim de Meta es foráneo: es una extensión de Meta.
        //  - H4: Foveated Rendering en los dos (la API de SRP ya está elegida en el asset) y la latencia «Prioritize Input
        //    Polling» (la valida el soporte de Meta Quest; es un ajuste genérico de OpenXR, así que va en los dos).
        //  - El Microsoft Hand Interaction Profile es de HoloLens y su nombre contiene «hand interaction profile»: no cuenta
        //    como deseado y se apaga en los dos.

        /// <summary>
        /// Las características de OpenXR que cada visor enciende, por su nombre en la UI (sin mayúsculas, por contenido):
        /// el soporte del dispositivo, sus perfiles de mandos, las manos y la foveación. Lo que coincide con el otro visor
        /// se apaga; lo demás no se toca.
        /// </summary>
        public static string[] FeatureKeywords(VisorTarget target) => target == VisorTarget.GalaxyXR
            ? new[]
            {
                "android xr support", "android xr controller", "android xr: display", "android xr: performance",
                "oculus touch controller", "khronos simple controller",
                "hand interaction profile", "hand tracking subsystem", "foveated rendering"
            }
            : new[]
            {
                "meta quest support", "oculus touch controller", "meta quest touch pro", "meta quest touch plus",
                "hand interaction profile", "hand tracking subsystem", "meta hand tracking aim", "foveated rendering"
            };

        /// <summary>Las palabras que delatan una característica del otro fabricante o de otro casco (se apaga para no mezclar runtimes).</summary>
        public static string[] ForeignKeywords(VisorTarget target) => target == VisorTarget.GalaxyXR
            ? new[] { "meta quest", "oculus quest", "meta hand tracking aim", MicrosoftHandInteraction }
            : new[] { "android xr", "oculus quest", MicrosoftHandInteraction };

        // El perfil de manos de HoloLens: contiene «hand interaction profile» y nunca es el que queremos.
        private const string MicrosoftHandInteraction = "microsoft hand interaction";

        public static bool FeatureWanted(string uiName, VisorTarget target) =>
            Matches(uiName, FeatureKeywords(target)) && !Matches(uiName, new[] { MicrosoftHandInteraction });
        public static bool FeatureForeign(string uiName, VisorTarget target) => Matches(uiName, ForeignKeywords(target));

        /// <summary>
        /// La optimización de latencia de OpenXR: «Prioritize Input Polling» (xrWaitFrame antes de leer la entrada) en los
        /// dos visores (H4, 2026-10-31). La validación del soporte de Meta Quest la recomienda.
        /// </summary>
        public static bool PrioritizeInputPolling(VisorTarget target) => true;

        private static bool Matches(string uiName, string[] keywords)
        {
            if (string.IsNullOrEmpty(uiName)) return false;
            var lower = uiName.ToLowerInvariant();
            foreach (var k in keywords) if (lower.Contains(k)) return true;
            return false;
        }

        /// <summary>Quest 3 exige API 32; Android XR, API 34.</summary>
        public static int MinSdk(VisorTarget target) => target == VisorTarget.GalaxyXR ? 34 : 32;

        public static string OutputPath(VisorTarget target) =>
            $"Builds/{target}/xrlabs-host-{target.ToString().ToLowerInvariant()}.apk";

        /// <summary>
        /// Las escenas de la build a partir de las habilitadas en Build Settings: el Menu XRI primero (se agrega si falta),
        /// el Menu de Meta nunca, y el resto en su orden. Vacías o repetidas se descartan.
        /// </summary>
        public static List<string> ScenePaths(IEnumerable<string> enabledScenePaths)
        {
            var result = new List<string> { MenuXriScenePath };
            foreach (var path in enabledScenePaths ?? Enumerable.Empty<string>())
            {
                if (string.IsNullOrEmpty(path)) continue;
                var normalized = path.Replace('\\', '/');
                if (normalized == MenuXriScenePath || normalized == MenuMetaScenePath) continue;
                if (!result.Contains(normalized)) result.Add(normalized);
            }
            return result;
        }
    }
}
