#if !XRLABS_UNITASK_PRESENT
using UnityEditor;
using UnityEngine;

namespace XRLabs.Editor
{
    /// <summary>
    /// UPM no permite declarar dependencias de scoped registries, así que UniTask
    /// es un prerequisito manual. Este check avisa con instrucciones si falta.
    /// XRLABS_UNITASK_PRESENT lo define el asmdef vía versionDefines cuando
    /// com.cysharp.unitask está instalado.
    /// </summary>
    [InitializeOnLoad]
    internal static class UniTaskDependencyCheck
    {
        static UniTaskDependencyCheck()
        {
            Debug.LogError(
                "[XRLabs] Falta el paquete UniTask (com.cysharp.unitask) — XRLabs.Networking no compilará.\n" +
                "Agregar a Packages/manifest.json:\n" +
                "  scopedRegistries: [{ \"name\": \"package.openupm.com\", \"url\": \"https://package.openupm.com\", \"scopes\": [\"com.cysharp\"] }]\n" +
                "  dependencies: { \"com.cysharp.unitask\": \"2.3.3\" }");
        }
    }
}
#endif
