using UnityEditor;
using UnityEngine;
using XRLabs.Core;
using XRLabs.Interactions;

namespace XRLabs.Editor
{
    /// <summary>
    /// Genera el contenido del Interaction Playground en la escena abierta:
    /// mesa con un ejemplar de cada interactable + panel de log de eventos.
    /// Uso: crear una escena nueva → Tools/XRLabs/Setup Interaction Playground →
    /// agregar un XR Origin (XR > XR Origin (VR)) y el XR Device Simulator
    /// (sample de XRI) para probar sin headset.
    /// </summary>
    public static class InteractionPlaygroundSetupEditor
    {
        [MenuItem("Tools/XRLabs/Setup Interaction Playground")]
        public static void SetupPlayground()
        {
            var root = new GameObject("[InteractionPlayground]");

            // Piso y mesa
            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";
            floor.transform.SetParent(root.transform);

            var table = GameObject.CreatePrimitive(PrimitiveType.Cube);
            table.name = "Table";
            table.transform.SetParent(root.transform);
            table.transform.localPosition = new Vector3(0f, 0.5f, 0.6f);
            table.transform.localScale = new Vector3(1.6f, 1f, 0.7f);

            // 1) Grabbable — esfera agarrable
            var grabbable = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            grabbable.name = "Example_GrabbableItem";
            grabbable.transform.SetParent(root.transform);
            grabbable.transform.localPosition = new Vector3(-0.5f, 1.15f, 0.6f);
            grabbable.transform.localScale = Vector3.one * 0.15f;
            grabbable.AddComponent<Rigidbody>();
            grabbable.AddComponent<GrabbableItem>(); // RequireComponent agrega XRGrabInteractable
            grabbable.AddComponent<ReturnToOrigin>(); // v0.6: vuelve a su sitio si se suelta fuera de una zona

            // 2) Rotatable — cilindro que gira en su lugar
            var rotatable = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            rotatable.name = "Example_RotatableItem";
            rotatable.transform.SetParent(root.transform);
            rotatable.transform.localPosition = new Vector3(0f, 1.25f, 0.6f);
            rotatable.transform.localScale = new Vector3(0.15f, 0.12f, 0.15f);
            var rotatableRb = rotatable.AddComponent<Rigidbody>();
            rotatableRb.isKinematic = true;
            rotatable.AddComponent<RotatableItem>();

            // 3) TouchableHotspot — esfera pequeña que se activa al tocar
            var hotspot = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            hotspot.name = "Example_TouchableHotspot";
            hotspot.transform.SetParent(root.transform);
            hotspot.transform.localPosition = new Vector3(0.5f, 1.1f, 0.6f);
            hotspot.transform.localScale = Vector3.one * 0.08f;
            hotspot.GetComponent<Renderer>().sharedMaterial.color = new Color(1f, 0.6f, 0.1f);
            hotspot.AddComponent<TouchableHotspot>(); // RequireComponent agrega XRSimpleInteractable

            // 4) SnapZone — área de encaje
            var snapZone = new GameObject("Example_SnapZone");
            snapZone.transform.SetParent(root.transform);
            snapZone.transform.localPosition = new Vector3(0.5f, 1.02f, 0.35f);
            var trigger = snapZone.AddComponent<BoxCollider>();
            trigger.isTrigger = true;
            trigger.size = new Vector3(0.2f, 0.1f, 0.2f);
            var zone = snapZone.AddComponent<SnapZone>();
            var snapPoint = new GameObject("SnapPoint");
            snapPoint.transform.SetParent(snapZone.transform, false);
            zone.snapPoint = snapPoint.transform;

            AddV06Examples(root.transform);

            // Panel de log de eventos
            var logGO = new GameObject("EventLog");
            logGO.transform.SetParent(root.transform);
            logGO.transform.localPosition = new Vector3(0f, 2.3f, 1.9f);
            logGO.transform.localScale = Vector3.one * 0.05f;
            var textMesh = logGO.AddComponent<TextMesh>();
            textMesh.fontSize = 48;
            textMesh.anchor = TextAnchor.UpperCenter;
            textMesh.alignment = TextAlignment.Left;
            logGO.AddComponent<PlaygroundEventLog>();

            Selection.activeGameObject = root;
            Debug.Log("[Playground] Contenido creado. Falta: agregar XR Origin (menú GameObject > XR) " +
                      "y el XR Device Simulator (Window > Package Manager > XRI > Samples) para probar sin headset.");
        }

        /// <summary>v0.6: segunda mesa con DropZone, SourcePile, AimTool, ScrubSurface y HoldButton.</summary>
        private static void AddV06Examples(Transform root)
        {
            var table = GameObject.CreatePrimitive(PrimitiveType.Cube);
            table.name = "Table_Actions";
            table.transform.SetParent(root);
            table.transform.localPosition = new Vector3(0f, 0.5f, 1.6f);
            table.transform.localScale = new Vector3(2.4f, 1f, 0.8f);

            // 5) DropZone — zona de soltado resaltable (se pinta mientras se sostiene algo aceptable)
            var zoneVisual = GameObject.CreatePrimitive(PrimitiveType.Cube);
            zoneVisual.name = "Example_DropZone";
            zoneVisual.transform.SetParent(root);
            zoneVisual.transform.localPosition = new Vector3(-0.8f, 1.02f, 1.6f);
            zoneVisual.transform.localScale = new Vector3(0.4f, 0.04f, 0.4f);
            var zoneBox = zoneVisual.GetComponent<BoxCollider>();
            zoneBox.isTrigger = true;
            zoneBox.size = new Vector3(1f, 6f, 1f); // volumen alto: suelta "encima"
            var dropZone = zoneVisual.AddComponent<DropZone>();
            var serializedZone = new SerializedObject(dropZone);
            serializedZone.FindProperty("zoneId").stringValue = "playground_zone";
            serializedZone.FindProperty("highlightRenderer").objectReferenceValue = zoneVisual.GetComponent<Renderer>();
            serializedZone.ApplyModifiedPropertiesWithoutUndo();

            // 6) SourcePile — al agarrarla pone una herramienta cargada en la mano
            var pile = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pile.name = "Example_SourcePile";
            pile.transform.SetParent(root);
            pile.transform.localPosition = new Vector3(-0.35f, 1.1f, 1.6f);
            pile.transform.localScale = new Vector3(0.18f, 0.1f, 0.18f);
            pile.GetComponent<Renderer>().sharedMaterial.color = new Color(0.45f, 0.3f, 0.15f);
            pile.AddComponent<SourcePile>(); // RequireComponent agrega XRSimpleInteractable

            // 7) AimTool + objetivo — apuntar y mantener el gatillo acumula segundos
            var aimTarget = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            aimTarget.name = "Example_AimTarget";
            aimTarget.transform.SetParent(root);
            aimTarget.transform.localPosition = new Vector3(0.9f, 1.4f, 2.0f);
            aimTarget.transform.localScale = Vector3.one * 0.25f;
            aimTarget.AddComponent<SceneTarget>();

            var aimTool = GameObject.CreatePrimitive(PrimitiveType.Cube);
            aimTool.name = "Example_AimTool";
            aimTool.transform.SetParent(root);
            aimTool.transform.localPosition = new Vector3(0.1f, 1.1f, 1.6f);
            aimTool.transform.localScale = new Vector3(0.05f, 0.05f, 0.25f);
            aimTool.AddComponent<Rigidbody>();
            aimTool.AddComponent<AimTool>(); // sale por su forward (+Z); agregar XRGrabInteractable lo hace GrabbableItem

            // 8) ScrubSurface — frotar con una herramienta agarrada o con la mano
            var scrub = GameObject.CreatePrimitive(PrimitiveType.Cube);
            scrub.name = "Example_ScrubSurface";
            scrub.transform.SetParent(root);
            scrub.transform.localPosition = new Vector3(0.55f, 1.015f, 1.6f);
            scrub.transform.localScale = new Vector3(0.35f, 0.03f, 0.35f);
            scrub.GetComponent<Renderer>().sharedMaterial.color = new Color(0.6f, 0.75f, 0.9f);
            var scrubBox = scrub.GetComponent<BoxCollider>();
            scrubBox.isTrigger = true;
            scrubBox.size = new Vector3(1f, 8f, 1f);
            scrub.AddComponent<ScrubSurface>();

            // 9) HoldButton — mantener para avanzar un valor 0–1
            var hold = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            hold.name = "Example_HoldButton";
            hold.transform.SetParent(root);
            hold.transform.localPosition = new Vector3(1.0f, 1.04f, 1.6f);
            hold.transform.localScale = new Vector3(0.12f, 0.04f, 0.12f);
            hold.GetComponent<Renderer>().sharedMaterial.color = new Color(0.9f, 0.3f, 0.3f);
            hold.AddComponent<HoldButton>(); // RequireComponent agrega XRSimpleInteractable
        }
    }
}
