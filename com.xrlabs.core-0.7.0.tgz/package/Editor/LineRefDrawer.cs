using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Editor
{
    /// <summary>
    /// Inspector de LineRef: campo de texto con el ID + menú con los IDs de todas las
    /// LineLibrary del proyecto, y una vista previa del texto en español. Si el ID no
    /// existe en ninguna librería, el campo se marca en rojo.
    /// </summary>
    [CustomPropertyDrawer(typeof(LineRef))]
    public class LineRefDrawer : PropertyDrawer
    {
        private const float ButtonWidth = 22f;

        private static List<LineLibrary> _libraries;
        private static double _librariesLoadedAt = -1;

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            var idProp = property.FindPropertyRelative("id");
            bool hasPreview = !string.IsNullOrEmpty(idProp.stringValue);
            return EditorGUIUtility.singleLineHeight * (hasPreview ? 2f : 1f) + (hasPreview ? 2f : 0f);
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var idProp = property.FindPropertyRelative("id");
            EditorGUI.BeginProperty(position, label, property);

            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            var fieldRect = EditorGUI.PrefixLabel(line, label);
            var textRect = new Rect(fieldRect.x, fieldRect.y, fieldRect.width - ButtonWidth - 2f, fieldRect.height);
            var buttonRect = new Rect(textRect.xMax + 2f, fieldRect.y, ButtonWidth, fieldRect.height);

            string id = idProp.stringValue;
            bool known = string.IsNullOrEmpty(id) || FindLine(id, out _);

            var previousColor = GUI.color;
            if (!known) GUI.color = new Color(1f, 0.55f, 0.55f);
            int indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;
            string edited = EditorGUI.DelayedTextField(textRect, id);
            EditorGUI.indentLevel = indent;
            GUI.color = previousColor;
            if (edited != id) idProp.stringValue = edited;

            if (GUI.Button(buttonRect, "▾", EditorStyles.miniButton))
                ShowMenu(idProp);

            if (!string.IsNullOrEmpty(idProp.stringValue))
            {
                var previewRect = new Rect(fieldRect.x, line.yMax + 2f, fieldRect.width, EditorGUIUtility.singleLineHeight);
                string preview = FindLine(idProp.stringValue, out var found)
                    ? FirstText(found)
                    : "⚠ ID no encontrado en ninguna LineLibrary";
                EditorGUI.LabelField(previewRect, preview, EditorStyles.miniLabel);
            }

            EditorGUI.EndProperty();
        }

        private static void ShowMenu(SerializedProperty idProp)
        {
            var menu = new GenericMenu();
            menu.AddItem(new GUIContent("(ninguna)"), string.IsNullOrEmpty(idProp.stringValue), () =>
            {
                idProp.stringValue = string.Empty;
                idProp.serializedObject.ApplyModifiedProperties();
            });

            foreach (var library in Libraries(forceReload: true))
            {
                foreach (var line in library.lines)
                {
                    if (line == null || string.IsNullOrEmpty(line.id)) continue;
                    string lineId = line.id;
                    // "/" en el menú crea submenús: s4.cubrir.instr → s4/cubrir/instr
                    string path = $"{library.name}/{lineId.Replace('.', '/')}";
                    menu.AddItem(new GUIContent(path), idProp.stringValue == lineId, () =>
                    {
                        idProp.stringValue = lineId;
                        idProp.serializedObject.ApplyModifiedProperties();
                    });
                }
            }

            menu.ShowAsContext();
        }

        private static bool FindLine(string id, out VoiceLine line)
        {
            foreach (var library in Libraries(forceReload: false))
            {
                line = library.Find(id);
                if (line != null) return true;
            }
            line = null;
            return false;
        }

        private static string FirstText(VoiceLine line)
        {
            var es = line.GetVariant(CoachLanguage.Spanish);
            if (es != null && !string.IsNullOrEmpty(es.text)) return es.text;
            foreach (var v in line.variants)
                if (v != null && !string.IsNullOrEmpty(v.text)) return v.text;
            return "(sin texto)";
        }

        private static List<LineLibrary> Libraries(bool forceReload)
        {
            // Recargar como mucho cada 2 s: el drawer se pinta muchas veces por segundo.
            if (_libraries == null || forceReload || EditorApplication.timeSinceStartup - _librariesLoadedAt > 2.0)
            {
                _libraries = new List<LineLibrary>();
                foreach (string guid in AssetDatabase.FindAssets("t:LineLibrary"))
                {
                    var lib = AssetDatabase.LoadAssetAtPath<LineLibrary>(AssetDatabase.GUIDToAssetPath(guid));
                    if (lib != null) _libraries.Add(lib);
                }
                _librariesLoadedAt = EditorApplication.timeSinceStartup;
            }
            return _libraries;
        }
    }
}
