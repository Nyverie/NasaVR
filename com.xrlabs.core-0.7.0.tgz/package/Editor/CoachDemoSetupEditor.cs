using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using XRLabs.Coach;
using XRLabs.Core;
using XRLabs.Simulations;

namespace XRLabs.Editor
{
    /// <summary>
    /// Genera una escena de demo del flujo del coach (v0.6) en la escena activa:
    /// sistemas, LineLibrary ES/EN sin audio (usa duración estimada), tres pasos y la UI de
    /// subtítulos + checklist. En Play: 1 = acierto, 2 = error, 3 = aviso, Espacio = saltar frase.
    /// </summary>
    public static class CoachDemoSetupEditor
    {
        private const string RootName = "CoachDemoRoot";
        private const string Folder = "Assets/XRLabsCoachDemo";
        private const string AnchorId = "demo.anchor";
        private const string TargetId = "demo.target";

        [MenuItem("Tools/XRLabs/Setup Coach Demo")]
        public static void Setup()
        {
            if (!SceneManager.GetActiveScene().IsValid())
                EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

            EnsureFolder(Folder);

            var library = CreateLibrary();
            var sequence = CreateSequence();

            var root = GameObject.Find(RootName);
            if (root == null) root = new GameObject(RootName);
            var audio = GetOrAdd<AudioSource>(root);
            audio.playOnAwake = false;

            var manager = GetOrAdd<SimulationManager>(root);
            var steps = GetOrAdd<StepSystem>(root);
            var scoring = GetOrAdd<ScoringSystem>(root);
            GetOrAdd<HintSystem>(root);
            var vo = GetOrAdd<VOManager>(root);
            GetOrAdd<FeedbackSystem>(root);
            var telemetry = GetOrAdd<TelemetryClient>(root);

            Set(manager, "stepSystem", steps);
            Set(manager, "scoringSystem", scoring);
            Set(manager, "telemetryClient", telemetry);
            Set(steps, "sequence", sequence);
            SetEnum(scoring, "rule", (int)ScoringRule.TasksErrorsHints);

            var so = new SerializedObject(vo);
            var libs = so.FindProperty("lineLibraries");
            libs.arraySize = 1;
            libs.GetArrayElementAtIndex(0).objectReferenceValue = library;
            so.ApplyModifiedPropertiesWithoutUndo();

            BuildUi(root.transform, steps);
            BuildCoachPresence(root, steps);

            EditorUtility.SetDirty(root);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            AssetDatabase.SaveAssets();
            Selection.activeObject = root;

            Debug.Log("[CoachDemo] Listo. Play → 1 acierta, 2 error, 3 aviso, Espacio salta la frase.");
        }

        // ── Presencia del coach (holograma) ───────────────────────────────────

        /// <summary>
        /// Si existe el prefab HologramCoach (Tools → XRLabs → Create Hologram Coach Prefab) lo coloca 2 m delante
        /// de la cámara, con un CoachDirector, un ancla ("demo.anchor", la usa el paso 2) y un objeto que señalar.
        /// </summary>
        private static void BuildCoachPresence(GameObject root, StepSystem steps)
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(HologramCoachPrefabEditor.PrefabPath);
            if (prefab == null)
            {
                Debug.Log("[CoachDemo] Sin prefab HologramCoach: la demo corre sin presencia 3D. " +
                          "Generarlo con Tools → XRLabs → Create Hologram Coach Prefab y repetir.");
                return;
            }

            var camera = Camera.main;
            if (camera == null)
            {
                var cameraGo = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener)) { tag = "MainCamera" };
                cameraGo.transform.position = new Vector3(0f, 1.6f, 0f);
                camera = cameraGo.GetComponent<Camera>();
            }

            Vector3 forward = Vector3.ProjectOnPlane(camera.transform.forward, Vector3.up);
            forward = forward.sqrMagnitude < 1e-4f ? Vector3.forward : forward.normalized;
            Vector3 right = Vector3.Cross(Vector3.up, forward);
            Vector3 ground = new Vector3(camera.transform.position.x, 0f, camera.transform.position.z);

            // Suelo para que el coach pueda reubicarse (CoachPlacement necesita un collider).
            if (GameObject.Find(FloorName) == null)
            {
                var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
                floor.name = FloorName;
                floor.transform.position = ground;
                floor.transform.localScale = Vector3.one * 3f;
            }

            var coachGo = GameObject.Find(CoachName);
            if (coachGo == null)
                coachGo = (GameObject)PrefabUtility.InstantiatePrefab(prefab, SceneManager.GetActiveScene());
            coachGo.name = CoachName;
            coachGo.transform.SetPositionAndRotation(ground + forward * 2f, Quaternion.LookRotation(-forward, Vector3.up));

            // Ancla del paso 2: a la derecha y un poco más lejos, para que se note el desplazamiento.
            var anchorGo = GameObject.Find(AnchorName);
            if (anchorGo == null) anchorGo = new GameObject(AnchorName);
            anchorGo.transform.SetPositionAndRotation(ground + forward * 2.6f + right * 1.4f, Quaternion.LookRotation(-forward, Vector3.up));
            var anchor = GetOrAdd<CoachAnchor>(anchorGo);
            SetString(anchor, "anchorId", AnchorId);

            // Objeto que el coach señala en el paso 2.
            var targetGo = GameObject.Find(TargetName);
            if (targetGo == null)
            {
                targetGo = GameObject.CreatePrimitive(PrimitiveType.Cube);
                targetGo.name = TargetName;
                Object.DestroyImmediate(targetGo.GetComponent<Collider>());
            }
            targetGo.transform.position = ground + forward * 2.2f - right * 1.1f + Vector3.up * 0.9f;
            targetGo.transform.localScale = Vector3.one * 0.25f;
            var target = GetOrAdd<SceneTarget>(targetGo);
            SetString(target, "targetId", TargetId);

            var director = GetOrAdd<CoachDirector>(root);
            Set(director, "stepSystem", steps);
            Set(director, "presence", coachGo.GetComponent<HologramCoach>());
            Set(director, "head", camera.transform);

            EditorUtility.SetDirty(coachGo);
        }

        private const string FloorName = "CoachDemoFloor";
        private const string CoachName = "CoachDemoHologram";
        private const string AnchorName = "CoachDemoAnchor";
        private const string TargetName = "CoachDemoTarget";

        // ── Assets ────────────────────────────────────────────────────────────

        private static LineLibrary CreateLibrary()
        {
            string path = $"{Folder}/CoachDemoLines.asset";
            var library = AssetDatabase.LoadAssetAtPath<LineLibrary>(path);
            if (library == null)
            {
                library = ScriptableObject.CreateInstance<LineLibrary>();
                AssetDatabase.CreateAsset(library, path);
            }

            library.speakerName = "Ing. Rosa Quispe";
            library.lines = new List<VoiceLine>
            {
                Line("demo.welcome",
                    "Hola, soy tu instructora. Vamos a probar cómo te guío.",
                    "Hi, I'm your instructor. Let's try how I guide you."),
                Line("demo.choose.intro",
                    "En cada paso te explico primero y luego te pido una acción.",
                    "In each step I explain first and then ask you for an action."),
                Line("demo.choose.instr",
                    "Presiona uno para acertar, dos para equivocarte o tres para recibir un aviso.",
                    "Press one to get it right, two to make a mistake or three to get a warning."),
                Line("demo.choose.hint",
                    "Recuerda: la tecla uno completa el paso.",
                    "Remember: key one completes the step."),
                Line("demo.choose.err",
                    "Esa no era. Cuando te equivocas te explico por qué y repetimos el mismo paso.",
                    "That wasn't it. When you make a mistake I explain why and we repeat the same step."),
                Line("demo.choose.warn",
                    "Cuidado: esto es un aviso. No cuenta como error y solo lo digo una vez.",
                    "Careful: this is a warning. It doesn't count as an error and I only say it once."),
                Line("demo.choose.ok",
                    "Bien. Al acertar se marca la tarea en el checklist.",
                    "Good. When you get it right the task is checked off."),
                Line("demo.choose.task", "Elegir la opción correcta", "Choose the right option"),
                Line("demo.end",
                    "Eso es todo. El puntaje considera tareas, errores y ayudas.",
                    "That's all. The score considers tasks, errors and hints.")
            };

            EditorUtility.SetDirty(library);
            return library;
        }

        private static SimulationSequence CreateSequence()
        {
            var condition = LoadOrCreate<KeyChoiceStepCondition>($"{Folder}/Condition_KeyChoice.asset");

            var welcome = LoadOrCreate<StepDefinition>($"{Folder}/Step_01_Welcome.asset");
            welcome.stepId = "demo.welcome";
            welcome.stepType = StepType.NonInteractive;
            welcome.introLines = new List<LineRef> { new("demo.welcome") };

            var choose = LoadOrCreate<StepDefinition>($"{Folder}/Step_02_Choose.asset");
            choose.stepId = "demo.choose";
            choose.stepType = StepType.Interaction;
            choose.completionCondition = condition;
            choose.introLines = new List<LineRef> { new("demo.choose.intro") };
            choose.instructionLine = new LineRef("demo.choose.instr");
            choose.hintLine = new LineRef("demo.choose.hint");
            choose.hintDelay = 11f;
            choose.successLine = new LineRef("demo.choose.ok");
            choose.errorLines = new List<StepErrorLine>
            {
                new() { key = "wrong_choice", line = new LineRef("demo.choose.err") },
                new() { key = "careful", line = new LineRef("demo.choose.warn") }
            };
            choose.coachAnchorId = AnchorId;
            choose.pointAtTargetId = TargetId;
            choose.countsAsTask = true;
            choose.taskLabel = "demo.choose.task";

            var end = LoadOrCreate<StepDefinition>($"{Folder}/Step_03_End.asset");
            end.stepId = "demo.end";
            end.stepType = StepType.NonInteractive;
            end.introLines = new List<LineRef> { new("demo.end") };

            var sequence = LoadOrCreate<SimulationSequence>($"{Folder}/CoachDemoSequence.asset");
            sequence.sequenceName = "Coach Demo";
            sequence.steps = new List<StepDefinition> { welcome, choose, end };
            sequence.sections = new List<StepSection> { new() { sectionName = "Demo", startStepIndex = 0 } };

            foreach (var asset in new Object[] { condition, welcome, choose, end, sequence })
                EditorUtility.SetDirty(asset);

            return sequence;
        }

        // ── UI ────────────────────────────────────────────────────────────────

        private static void BuildUi(Transform parent, StepSystem steps)
        {
            var existing = parent.Find("CoachDemoCanvas");
            if (existing != null) Object.DestroyImmediate(existing.gameObject);

            var canvasGo = new GameObject("CoachDemoCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.transform.SetParent(parent, false);
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);

            // Subtítulo (abajo)
            var panel = Box("Subtitle", canvasGo.transform, new Vector2(0.2f, 0.04f), new Vector2(0.8f, 0.22f), new Color(0.05f, 0.1f, 0.12f, 0.85f));
            var accent = Box("Accent", panel.transform, new Vector2(0f, 0f), new Vector2(0.008f, 1f), new Color(0.16f, 0.76f, 0.78f, 1f));
            var speaker = Text("Speaker", panel.transform, new Vector2(0.03f, 0.68f), new Vector2(0.97f, 0.95f), 28, FontStyles.Bold);
            var body = Text("Body", panel.transform, new Vector2(0.03f, 0.08f), new Vector2(0.97f, 0.7f), 32, FontStyles.Normal);
            var group = panel.AddComponent<CanvasGroup>();
            var subtitle = panel.AddComponent<SubtitlePanel>();
            Set(subtitle, "canvasGroup", group);
            Set(subtitle, "bodyText", body);
            Set(subtitle, "speakerText", speaker);
            Set(subtitle, "accentGraphic", accent.GetComponent<Image>());
            SetEnum(subtitle, "skipKey", (int)KeyCode.Space);

            // Checklist (derecha)
            var list = Box("Checklist", canvasGo.transform, new Vector2(0.78f, 0.6f), new Vector2(0.98f, 0.9f), new Color(0.05f, 0.1f, 0.12f, 0.75f));
            var checklist = list.AddComponent<ChecklistPanel>();
            var items = new SerializedObject(checklist).FindProperty("items");
            items.arraySize = 3;
            for (int i = 0; i < 3; i++)
            {
                float top = 0.95f - i * 0.3f;
                var row = new GameObject($"Item{i}", typeof(RectTransform));
                row.transform.SetParent(list.transform, false);
                Anchor(row.GetComponent<RectTransform>(), new Vector2(0.05f, top - 0.25f), new Vector2(0.95f, top));
                var label = Text("Label", row.transform, new Vector2(0.15f, 0f), new Vector2(1f, 1f), 24, FontStyles.Normal);
                var icon = Box("Icon", row.transform, new Vector2(0f, 0.25f), new Vector2(0.1f, 0.75f), Color.white);

                var element = items.GetArrayElementAtIndex(i);
                element.FindPropertyRelative("label").objectReferenceValue = label;
                element.FindPropertyRelative("checkIcon").objectReferenceValue = icon.GetComponent<Image>();
                element.FindPropertyRelative("pendingColor").colorValue = Color.white;
                element.FindPropertyRelative("completedColor").colorValue = new Color(0.3f, 0.9f, 0.5f);
            }
            items.serializedObject.ApplyModifiedPropertiesWithoutUndo();

            var binder = list.AddComponent<StepChecklistBinder>();
            Set(binder, "stepSystem", steps);
            Set(binder, "checklist", checklist);
        }

        private static GameObject Box(string name, Transform parent, Vector2 min, Vector2 max, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            Anchor(go.GetComponent<RectTransform>(), min, max);
            go.GetComponent<Image>().color = color;
            return go;
        }

        private static TextMeshProUGUI Text(string name, Transform parent, Vector2 min, Vector2 max, float size, FontStyles style)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            Anchor(go.GetComponent<RectTransform>(), min, max);
            var text = go.GetComponent<TextMeshProUGUI>();
            text.fontSize = size;
            text.fontStyle = style;
            text.textWrappingMode = TextWrappingModes.Normal;
            text.text = string.Empty;
            return text;
        }

        private static void Anchor(RectTransform rect, Vector2 min, Vector2 max)
        {
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        private static VoiceLine Line(string id, string es, string en) => new()
        {
            id = id,
            variants = new List<VoiceLineVariant>
            {
                new() { language = CoachLanguage.Spanish, text = es },
                new() { language = CoachLanguage.English, text = en }
            }
        };

        private static T LoadOrCreate<T>(string path) where T : ScriptableObject
        {
            var asset = AssetDatabase.LoadAssetAtPath<T>(path);
            if (asset != null) return asset;
            asset = ScriptableObject.CreateInstance<T>();
            AssetDatabase.CreateAsset(asset, path);
            return asset;
        }

        private static T GetOrAdd<T>(GameObject go) where T : Component
        {
            // Sin "??": en el editor GetComponent devuelve un null falso que "??" no detecta.
            var component = go.GetComponent<T>();
            return component != null ? component : go.AddComponent<T>();
        }

        private static void Set(Object target, string field, Object value)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(field);
            if (prop == null)
            {
                Debug.LogWarning($"[CoachDemo] {target.GetType().Name}.{field} no existe");
                return;
            }
            prop.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void SetString(Object target, string field, string value)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(field);
            if (prop == null) return;
            prop.stringValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void SetEnum(Object target, string field, int value)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(field);
            if (prop == null) return;
            prop.intValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = System.IO.Path.GetDirectoryName(path)?.Replace('\\', '/');
            string leaf = System.IO.Path.GetFileName(path);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, leaf);
        }
    }
}
