using System;
using System.Threading;
using System.Threading.Tasks;

namespace XRLabs.Coach.Editor
{
    /// <summary>Datos puros de una petición de síntesis (se copian de VoiceSettings en el hilo principal).</summary>
    public sealed class TtsRequest
    {
        public string Text;
        public string VoiceId;
        public string ModelId;
        public string LanguageCode;

        /// <summary>Texto de las frases vecinas (mejora la entonación en ElevenLabs). Puede ser nulo.</summary>
        public string PreviousText;
        public string NextText;

        public bool UseSeed = true;
        public int Seed;

        // ElevenLabs
        public float Stability = 0.5f;
        public float SimilarityBoost = 0.75f;
        public float Style;

        // Fish Audio
        public float Temperature = 0.7f;
        public float Speed = 1f;
    }

    /// <summary>Audio devuelto por el proveedor; <see cref="Extension"/> va sin punto ("mp3", "wav").</summary>
    public readonly struct TtsResult
    {
        public readonly byte[] Audio;
        public readonly string Extension;

        public TtsResult(byte[] audio, string extension)
        {
            Audio = audio;
            Extension = string.IsNullOrEmpty(extension) ? "mp3" : extension.TrimStart('.');
        }
    }

    public enum TtsErrorKind
    {
        NoApiKey,
        Unauthorized,
        PaymentRequired,
        RateLimited,
        ServiceUnavailable,
        BadRequest,
        Network,
        Other
    }

    public sealed class TtsException : Exception
    {
        public TtsErrorKind Kind { get; }
        public int StatusCode { get; }

        public TtsException(TtsErrorKind kind, string message, int statusCode = 0, Exception inner = null)
            : base(message, inner)
        {
            Kind = kind;
            StatusCode = statusCode;
        }

        /// <summary>Errores que no tiene sentido reintentar con otra frase (clave, saldo): se aborta toda la tanda.</summary>
        public bool IsFatal => Kind == TtsErrorKind.NoApiKey
                               || Kind == TtsErrorKind.Unauthorized
                               || Kind == TtsErrorKind.PaymentRequired;

        public bool IsRetryable => Kind == TtsErrorKind.RateLimited
                                   || Kind == TtsErrorKind.ServiceUnavailable
                                   || Kind == TtsErrorKind.Network;
    }

    /// <summary>Proveedor de texto a voz. Solo se usa en el editor.</summary>
    public interface ITtsProvider
    {
        string Id { get; }
        string DisplayName { get; }

        /// <exception cref="TtsException">Error del proveedor o de red, con mensaje legible.</exception>
        /// <exception cref="OperationCanceledException">Cancelado por el token.</exception>
        Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken);
    }
}
