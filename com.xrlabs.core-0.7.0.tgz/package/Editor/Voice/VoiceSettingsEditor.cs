using UnityEditor;
using UnityEngine;

namespace XRLabs.Coach.Editor
{
    /// <summary>Inspector de VoiceSettings + gestión de las claves de API (EditorPrefs, nunca en el asset).</summary>
    [CustomEditor(typeof(VoiceSettings))]
    public class VoiceSettingsEditor : UnityEditor.Editor
    {
        /// <summary>Aviso del proveedor del sistema: es un relleno, la voz del producto sigue siendo la de ElevenLabs (D5).</summary>
        public const string ProvisionalNotice =
            "Proveedor «Sistema (macOS, provisional)»: voz local del say de macOS, sin clave ni red, solo para que el coach " +
            "hable mientras no está la clave de ElevenLabs. Es un relleno: cuando el dueño guarde la clave en las preferencias " +
            "del Editor (D5: nunca en assets ni en git), vuelve a ElevenLabs y regenera; todas las frases quedarán en «Texto cambiado».";

        private string _elevenKeyInput = string.Empty;
        private string _fishKeyInput = string.Empty;

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            var settings = (VoiceSettings)target;
            if (settings.provider == VoiceProviderKind.MacSay)
            {
                EditorGUILayout.HelpBox(ProvisionalNotice, MessageType.Warning);
                if (!MacSayProvider.IsSupported)
                    EditorGUILayout.HelpBox("Este Editor no es de macOS: el proveedor del sistema no puede generar audio aquí.", MessageType.Error);
            }
            if (!settings.OutputRootNormalized.StartsWith("Assets/"))
                EditorGUILayout.HelpBox("La carpeta de salida debe estar dentro de Assets/.", MessageType.Warning);

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("Claves de API", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "La clave se guarda solo en EditorPrefs de tu usuario (no va al repositorio ni a ningún build) " +
                "o se lee de una variable de entorno. EditorPrefs la guarda sin cifrar en tu perfil de usuario.",
                MessageType.Info);

            DrawKeyField(VoiceProviderKind.ElevenLabs, "ElevenLabs", ref _elevenKeyInput);
            DrawKeyField(VoiceProviderKind.FishAudio, "Fish Audio", ref _fishKeyInput);
        }

        private static void DrawKeyField(VoiceProviderKind kind, string label, ref string input)
        {
            var source = VoiceApiKeys.GetSource(kind);
            string state = source switch
            {
                VoiceKeySource.EditorPrefs => "guardada en EditorPrefs",
                VoiceKeySource.Environment => $"desde la variable {VoiceApiKeys.EnvVar(kind)}",
                _ => $"sin configurar (o define {VoiceApiKeys.EnvVar(kind)})"
            };

            EditorGUILayout.LabelField(label, state);
            EditorGUILayout.BeginHorizontal();
            input = EditorGUILayout.PasswordField(input);
            using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(input)))
            {
                if (GUILayout.Button("Guardar", GUILayout.Width(70)))
                {
                    VoiceApiKeys.Set(kind, input);
                    input = string.Empty;
                    GUI.FocusControl(null);
                }
            }
            using (new EditorGUI.DisabledScope(!EditorPrefs.HasKey(VoiceApiKeys.PrefsKey(kind))))
            {
                if (GUILayout.Button("Borrar", GUILayout.Width(60)))
                    VoiceApiKeys.Clear(kind);
            }
            EditorGUILayout.EndHorizontal();
        }
    }
}
