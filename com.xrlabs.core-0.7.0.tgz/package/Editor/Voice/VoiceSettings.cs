using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach.Editor
{
    public enum VoiceProviderKind
    {
        ElevenLabs,
        FishAudio,
        /// <summary>Relleno local y sin clave con el <c>say</c> de macOS (<see cref="MacSayProvider"/>) hasta que haya clave de ElevenLabs (D5).</summary>
        [InspectorName("Sistema (macOS, provisional)")] MacSay
    }

    /// <summary>Voz de cada proveedor para un idioma (los IDs de voz no son intercambiables entre proveedores).</summary>
    [Serializable]
    public class LanguageVoice
    {
        public CoachLanguage language;
        [Tooltip("voice_id de ElevenLabs.")] public string elevenLabsVoiceId;
        [Tooltip("reference_id de Fish Audio.")] public string fishVoiceId;
        [Tooltip("Voz del sistema para «Sistema (macOS, provisional)» (say -v '?'). Vacío = Paulina en español (México), Samantha en inglés.")]
        public string systemVoice;
    }

    /// <summary>
    /// Configuración del horneado de voz (solo editor). NO contiene la clave de API: esa vive en
    /// EditorPrefs o en variables de entorno (ver <see cref="VoiceApiKeys"/>). Cambiar proveedor,
    /// voz, modelo, ajustes o semilla cambia el hash de todas las frases → quedan en "Texto cambiado".
    /// </summary>
    [CreateAssetMenu(menuName = "XR Simulation/Voice Settings", fileName = "VoiceSettings")]
    public class VoiceSettings : ScriptableObject
    {
        public const string DefaultOutputRoot = "Assets/Voice";
        public const string DefaultAssetPath = "Assets/Voice/VoiceSettings.asset";

        [Header("Proveedor")]
        public VoiceProviderKind provider = VoiceProviderKind.ElevenLabs;
        public string elevenLabsModelId = "eleven_multilingual_v2";
        [Tooltip("s2.1-pro | s1 | s2-pro | s2.1-pro-free | drama-3-preview")]
        public string fishModelId = "s2.1-pro";

        [Header("Voz por idioma (misma voz de personaje en ambos idiomas)")]
        public List<LanguageVoice> voices = new()
        {
            new LanguageVoice { language = CoachLanguage.Spanish },
            new LanguageVoice { language = CoachLanguage.English }
        };

        [Header("ElevenLabs")]
        [Range(0f, 1f)] public float stability = 0.5f;
        [Range(0f, 1f)] public float similarityBoost = 0.75f;
        [Range(0f, 1f)] public float style = 0f;
        [Tooltip("Semilla fija: el personaje suena parejo entre frases. Solo ElevenLabs.")]
        public int seed = 1234;

        [Header("Fish Audio")]
        [Range(0f, 1f)] public float temperature = 0.7f;
        [Range(0.5f, 2f)] public float speed = 1f;

        [Header("Salida")]
        [Tooltip("Carpeta raíz de los clips: <raíz>/<librería>/<es|en>/<id>.mp3. Las librerías importadas de un guion (<experiencia>/Frases/) van a <experiencia>/Voces/<es|en>/.")]
        public string outputRoot = DefaultOutputRoot;
        [Range(1, 6)] public int maxConcurrency = 2;

        [Header("Validación antes del build")]
        [Tooltip("Si está activo, en Development Build una voz incompleta solo avisa (no bloquea). En builds de release siempre bloquea.")]
        public bool allowIncompleteVoiceInDevBuilds = false;

        public string ProviderId => provider switch
        {
            VoiceProviderKind.FishAudio => "fishaudio",
            VoiceProviderKind.MacSay => MacSayProvider.ProviderIdValue,
            _ => "elevenlabs"
        };

        public string ProviderDisplayName => provider switch
        {
            VoiceProviderKind.FishAudio => "Fish Audio",
            VoiceProviderKind.MacSay => MacSayProvider.DisplayNameValue,
            _ => "ElevenLabs"
        };

        /// <summary>Si el proveedor necesita clave de API. El del sistema (macOS) no: es local.</summary>
        public static bool RequiresApiKey(VoiceProviderKind kind) => kind != VoiceProviderKind.MacSay;

        public string ModelId => provider switch
        {
            VoiceProviderKind.FishAudio => string.IsNullOrWhiteSpace(fishModelId) ? "s2.1-pro" : fishModelId.Trim(),
            VoiceProviderKind.MacSay => "say",
            _ => string.IsNullOrWhiteSpace(elevenLabsModelId) ? "eleven_multilingual_v2" : elevenLabsModelId.Trim()
        };

        public int ConcurrencyClamped => Mathf.Clamp(maxConcurrency, 1, 6);

        public string OutputRootNormalized
        {
            get
            {
                string root = string.IsNullOrWhiteSpace(outputRoot) ? DefaultOutputRoot : outputRoot.Trim();
                return root.Replace('\\', '/').TrimEnd('/');
            }
        }

        /// <summary>Voice ID del proveedor activo para el idioma ("" si no está configurado).</summary>
        public string GetVoiceId(CoachLanguage language)
        {
            if (voices != null)
            {
                foreach (var v in voices)
                {
                    if (v == null || v.language != language) continue;
                    if (provider == VoiceProviderKind.MacSay) return SystemVoiceOrDefault(v.systemVoice, language);
                    string id = provider == VoiceProviderKind.FishAudio ? v.fishVoiceId : v.elevenLabsVoiceId;
                    return id?.Trim() ?? string.Empty;
                }
            }
            return provider == VoiceProviderKind.MacSay ? SystemVoiceOrDefault(null, language) : string.Empty;
        }

        private static string SystemVoiceOrDefault(string voice, CoachLanguage language) =>
            !string.IsNullOrWhiteSpace(voice) ? voice.Trim()
            : language == CoachLanguage.English ? MacSayProvider.DefaultEnglishVoice : MacSayProvider.DefaultSpanishVoice;

        /// <summary>Texto estable con los ajustes que afectan al audio del proveedor activo (entra al hash).</summary>
        public string SettingsSignature
        {
            get
            {
                var c = CultureInfo.InvariantCulture;
                return provider switch
                {
                    VoiceProviderKind.FishAudio => string.Format(c, "temp={0:0.000};speed={1:0.000}", temperature, speed),
                    VoiceProviderKind.MacSay => string.Format(c, "rate={0}", MacSayProvider.SampleRate),
                    _ => string.Format(c, "stab={0:0.000};sim={1:0.000};style={2:0.000}", stability, similarityBoost, style)
                };
            }
        }

        /// <summary>La semilla solo cuenta para ElevenLabs (Fish Audio no la recibe).</summary>
        public string SeedSignature => provider == VoiceProviderKind.ElevenLabs
            ? seed.ToString(CultureInfo.InvariantCulture)
            : "-";

        /// <summary>Primer VoiceSettings del proyecto (null si no hay).</summary>
        public static VoiceSettings Find()
        {
            string[] guids = AssetDatabase.FindAssets("t:VoiceSettings");
            if (guids.Length == 0) return null;
            Array.Sort(guids, (a, b) => string.CompareOrdinal(AssetDatabase.GUIDToAssetPath(a), AssetDatabase.GUIDToAssetPath(b)));
            return AssetDatabase.LoadAssetAtPath<VoiceSettings>(AssetDatabase.GUIDToAssetPath(guids[0]));
        }

        public static VoiceSettings CreateDefaultAsset()
        {
            string folder = System.IO.Path.GetDirectoryName(DefaultAssetPath)?.Replace('\\', '/');
            if (!string.IsNullOrEmpty(folder) && !AssetDatabase.IsValidFolder(folder))
                AssetDatabase.CreateFolder("Assets", "Voice");

            var asset = CreateInstance<VoiceSettings>();
            AssetDatabase.CreateAsset(asset, AssetDatabase.GenerateUniqueAssetPath(DefaultAssetPath));
            AssetDatabase.SaveAssets();
            return asset;
        }

        [MenuItem("Tools/XRLabs/Voice Settings")]
        private static void SelectOrCreate()
        {
            var settings = Find() ?? CreateDefaultAsset();
            Selection.activeObject = settings;
            EditorGUIUtility.PingObject(settings);
        }
    }
}
