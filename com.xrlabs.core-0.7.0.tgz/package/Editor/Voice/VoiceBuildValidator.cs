using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Falla el build si alguna frase con texto está en Sin audio, Texto cambiado o Error.
    /// Alcance: las LineLibrary referenciadas por las escenas activas de Build Settings (dependencias
    /// transitivas) más las que estén en carpetas Resources; si no hay escenas activas, todas las de Assets/.
    /// Opt-out: VoiceSettings.allowIncompleteVoiceInDevBuilds (solo en Development Build, avisa en vez de fallar).
    /// </summary>
    public sealed class VoiceBuildValidator : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(BuildReport report)
        {
            var settings = VoiceSettings.Find();
            var libraries = FindLibrariesForBuild();
            if (libraries.Count == 0) return;

            var problems = CollectProblems(settings, libraries);
            if (problems.Count == 0) return;

            bool isDev = (report.summary.options & BuildOptions.Development) != 0;
            string message = FormatMessage(problems);

            if (isDev && settings != null && settings.allowIncompleteVoiceInDevBuilds)
            {
                Debug.LogWarning("[XRLabs] Voz incompleta (permitido en Development Build por VoiceSettings).\n" + message);
                return;
            }

            throw new BuildFailedException(message);
        }

        /// <summary>Lista de problemas "librería/idioma/id: estado" (vacía si todo está al día).</summary>
        public static List<string> CollectProblems(VoiceSettings settings, IEnumerable<LineLibrary> libraries)
        {
            var problems = new List<string>();
            foreach (var library in libraries)
            {
                if (library == null) continue;
                foreach (var line in library.lines)
                {
                    if (line?.variants == null || string.IsNullOrEmpty(line.id)) continue;
                    foreach (var variant in line.variants)
                    {
                        var status = VoiceBaker.GetStatus(library, line, variant, settings);
                        if (status == VoiceStatus.UpToDate || status == VoiceStatus.Empty) continue;
                        problems.Add($"{library.name}/{LanguageService.ToCode(variant.language)}/{line.id}: {Describe(status)}");
                    }
                }
            }
            return problems;
        }

        /// <summary>Cuántas variantes de las librerías de la build no tienen la voz al día (0 = la build no necesita el permiso).</summary>
        public static int CountProblemsForBuild(VoiceSettings settings) =>
            CollectProblems(settings, FindLibrariesForBuild()).Count;

        public static List<LineLibrary> FindLibrariesForBuild()
        {
            var found = new Dictionary<string, LineLibrary>();

            string[] scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0)
            {
                foreach (string guid in AssetDatabase.FindAssets("t:LineLibrary", new[] { "Assets" }))
                    Add(found, AssetDatabase.GUIDToAssetPath(guid));
            }
            else
            {
                foreach (string dep in AssetDatabase.GetDependencies(scenes, true))
                    if (dep.EndsWith(".asset", StringComparison.OrdinalIgnoreCase)) Add(found, dep);

                foreach (string guid in AssetDatabase.FindAssets("t:LineLibrary", new[] { "Assets" }))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if (path.IndexOf("/Resources/", StringComparison.OrdinalIgnoreCase) >= 0) Add(found, path);
                }
            }
            return found.Values.ToList();
        }

        private static void Add(Dictionary<string, LineLibrary> found, string path)
        {
            if (found.ContainsKey(path)) return;
            var library = AssetDatabase.LoadAssetAtPath<LineLibrary>(path);
            if (library != null) found[path] = library;
        }

        private static string Describe(VoiceStatus status) => status switch
        {
            VoiceStatus.NoAudio => "sin audio",
            VoiceStatus.TextChanged => "texto o ajustes cambiaron (regenerar)",
            VoiceStatus.Error => "error en la última generación",
            _ => status.ToString()
        };

        private static string FormatMessage(List<string> problems)
        {
            const int max = 25;
            string list = string.Join("\n  ", problems.Take(max));
            string more = problems.Count > max ? $"\n  … y {problems.Count - max} más" : string.Empty;
            return $"[XRLabs] El build se detuvo: {problems.Count} frase(s) sin voz al día. " +
                   $"Abre la LineLibrary y pulsa \"Generar faltantes\".\n  {list}{more}";
        }

        [MenuItem("Tools/XRLabs/Validar voz del coach")]
        private static void ValidateMenu()
        {
            var problems = CollectProblems(VoiceSettings.Find(), FindLibrariesForBuild());
            if (problems.Count == 0) Debug.Log("[XRLabs] Voz del coach: todo al día.");
            else Debug.LogWarning(FormatMessage(problems));
        }
    }
}
