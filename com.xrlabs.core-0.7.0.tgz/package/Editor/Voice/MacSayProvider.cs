using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Proveedor provisional «Sistema (macOS, provisional)»: sintetiza con el <c>say</c> de macOS directo a WAV (16 bits,
    /// 22 050 Hz; <c>say</c> no acepta little-endian en AIFF, así que no hace falta <c>afconvert</c>), sin red y sin clave. Es un relleno para que el coach hable mientras el dueño no pone la clave de
    /// ElevenLabs en las preferencias del Editor (D5 no cambia: la clave nunca va a assets ni a git). Solo funciona en macOS.
    /// <c>VoiceId</c> es el nombre de la voz del sistema (p. ej. «Paulina», español de México).
    /// </summary>
    public sealed class MacSayProvider : ITtsProvider
    {
        public const string ProviderIdValue = "macos-say";
        public const string DisplayNameValue = "Sistema (macOS, provisional)";
        public const string DefaultSpanishVoice = "Paulina";
        public const string DefaultEnglishVoice = "Samantha";
        public const int SampleRate = 22050;

        public string Id => ProviderIdValue;
        public string DisplayName => DisplayNameValue;

        /// <summary>Si es true, sintetiza en el hilo que llama (para el horneado en batch, sin bucle de editor).</summary>
        public bool Synchronous { get; set; }

        public static bool IsSupported => Application.platform == RuntimePlatform.OSXEditor;

        public Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken)
        {
            if (Synchronous)
            {
                cancellationToken.ThrowIfCancellationRequested();
                return Task.FromResult(Synthesize(request));
            }
            return Task.Run(() => Synthesize(request), cancellationToken);
        }

        /// <summary>Genera el WAV (16 bits, 22 050 Hz) de la frase y devuelve sus bytes.</summary>
        public static TtsResult Synthesize(TtsRequest request)
        {
            if (!IsSupported)
                throw new TtsException(TtsErrorKind.Other, "El proveedor del sistema solo funciona en el Editor de macOS (usa say y afconvert).");
            if (request == null || string.IsNullOrWhiteSpace(request.Text))
                throw new TtsException(TtsErrorKind.BadRequest, "La frase no tiene texto.");

            string voice = string.IsNullOrWhiteSpace(request.VoiceId)
                ? (request.LanguageCode == "en" ? DefaultEnglishVoice : DefaultSpanishVoice)
                : request.VoiceId.Trim();
            string stem = Path.Combine(Path.GetTempPath(), "xrlabs-say-" + Guid.NewGuid().ToString("N"));
            string wav = stem + ".wav", txt = stem + ".txt";
            try
            {
                // El texto va por fichero (-f) para no pelear con comillas ni guiones al inicio.
                File.WriteAllText(txt, request.Text);
                Run("/usr/bin/say", new[] { "-v", voice, "-o", wav, "--file-format=WAVE", $"--data-format=LEI16@{SampleRate}", "-f", txt });
                byte[] audio = File.ReadAllBytes(wav);
                if (audio.Length <= 44)
                    throw new TtsException(TtsErrorKind.Other, $"say no produjo audio con la voz «{voice}» (¿está instalada? say -v '?').");
                return new TtsResult(audio, "wav");
            }
            finally
            {
                foreach (string f in new[] { wav, txt })
                    try { if (File.Exists(f)) File.Delete(f); } catch (IOException) { }
            }
        }

        // Comillas dobles para Process (las voces llevan espacios y paréntesis: «Eddy (Español (México))»).
        private static string Quote(string arg) => "\"" + arg.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";

        private static void Run(string exe, string[] args)
        {
            var psi = new ProcessStartInfo(exe, string.Join(" ", Array.ConvertAll(args, Quote)))
            {
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi) ?? throw new TtsException(TtsErrorKind.Other, $"No se pudo lanzar {exe}.");
            string err = p.StandardError.ReadToEnd();
            p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            if (p.ExitCode != 0)
                throw new TtsException(TtsErrorKind.Other, $"{Path.GetFileName(exe)} terminó con código {p.ExitCode}: {err.Trim()}");
        }
    }
}
