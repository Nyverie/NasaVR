using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Base HTTP de los proveedores: valida la clave antes de tocar la red, mapea errores a
    /// mensajes claros y reintenta 429/503 (y fallos de red) con espera exponencial.
    /// </summary>
    public abstract class HttpTtsProvider : ITtsProvider
    {
        private static readonly Lazy<HttpClient> SharedClient =
            new(() => new HttpClient { Timeout = TimeSpan.FromMinutes(2) });

        private readonly string _apiKey;
        private readonly HttpClient _client;

        /// <summary>Intentos totales por frase (1 = sin reintentos).</summary>
        public int MaxAttempts { get; set; } = 4;

        /// <summary>Espera base; el intento n espera Base × 2^(n-1). Sobrescribible para pruebas.</summary>
        public TimeSpan BaseDelay { get; set; } = TimeSpan.FromSeconds(1);

        /// <summary>Función de espera (inyectable para que las pruebas no esperen de verdad).</summary>
        public Func<TimeSpan, CancellationToken, Task> Delay { get; set; } = (t, ct) => Task.Delay(t, ct);

        protected HttpTtsProvider(string apiKey, HttpMessageHandler handler = null)
        {
            _apiKey = apiKey;
            _client = handler != null ? new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(2) } : SharedClient.Value;
        }

        public abstract string Id { get; }
        public abstract string DisplayName { get; }
        protected abstract string ApiKeyEnvVar { get; }
        protected abstract string OutputExtension { get; }

        protected abstract HttpRequestMessage BuildRequest(TtsRequest request, string apiKey);

        public async Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            if (string.IsNullOrWhiteSpace(_apiKey))
            {
                throw new TtsException(TtsErrorKind.NoApiKey,
                    $"No hay clave de API de {DisplayName}. Guárdala en el asset VoiceSettings (EditorPrefs) " +
                    $"o define la variable de entorno {ApiKeyEnvVar}.");
            }

            if (string.IsNullOrWhiteSpace(request.VoiceId))
                throw new TtsException(TtsErrorKind.BadRequest, "Falta el ID de voz para este idioma en VoiceSettings.");
            if (string.IsNullOrWhiteSpace(request.Text))
                throw new TtsException(TtsErrorKind.BadRequest, "El texto hablado está vacío.");

            int attempts = Math.Max(1, MaxAttempts);
            for (int attempt = 1; ; attempt++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                TtsException failure;
                TimeSpan? retryAfter = null;
                try
                {
                    using var message = BuildRequest(request, _apiKey);
                    using var response = await _client
                        .SendAsync(message, HttpCompletionOption.ResponseHeadersRead, cancellationToken)
                        .ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        // La respuesta puede llegar por trozos (chunked): se lee completa.
                        byte[] bytes = await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);
                        if (bytes == null || bytes.Length == 0)
                            throw new TtsException(TtsErrorKind.Other, $"{DisplayName} devolvió una respuesta vacía.");
                        return new TtsResult(bytes, OutputExtension);
                    }

                    string body = await SafeReadBody(response).ConfigureAwait(false);
                    retryAfter = response.Headers.RetryAfter?.Delta;
                    failure = MapError((int)response.StatusCode, body);
                }
                catch (TtsException)
                {
                    throw;
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (OperationCanceledException ex)
                {
                    failure = new TtsException(TtsErrorKind.Network, $"{DisplayName}: la petición excedió el tiempo de espera.", 0, ex);
                }
                catch (HttpRequestException ex)
                {
                    failure = new TtsException(TtsErrorKind.Network, $"{DisplayName}: error de red ({ex.Message}).", 0, ex);
                }

                if (!failure.IsRetryable || attempt >= attempts) throw failure;

                var wait = TimeSpan.FromTicks(BaseDelay.Ticks * (1L << (attempt - 1)));
                if (retryAfter.HasValue && retryAfter.Value > wait)
                    wait = retryAfter.Value > TimeSpan.FromSeconds(30) ? TimeSpan.FromSeconds(30) : retryAfter.Value;
                await Delay(wait, cancellationToken).ConfigureAwait(false);
            }
        }

        protected virtual TtsException MapError(int status, string body)
        {
            string detail = string.IsNullOrWhiteSpace(body) ? string.Empty : $" Detalle: {body}";
            switch (status)
            {
                case 401:
                    return new TtsException(TtsErrorKind.Unauthorized,
                        $"{DisplayName} rechazó la clave de API (401). Revisa la clave guardada.", status);
                case 402:
                    return new TtsException(TtsErrorKind.PaymentRequired,
                        $"{DisplayName}: saldo o cuota agotada (402). Recarga créditos o revisa tu plan.", status);
                case 429:
                    return new TtsException(TtsErrorKind.RateLimited,
                        $"{DisplayName}: demasiadas peticiones (429). Baja la concurrencia en VoiceSettings.", status);
                case 503:
                    return new TtsException(TtsErrorKind.ServiceUnavailable,
                        $"{DisplayName} está saturado (503). Se reintentó sin éxito; vuelve a probar en unos minutos.", status);
                case 400:
                case 404:
                case 422:
                    return new TtsException(TtsErrorKind.BadRequest,
                        $"{DisplayName} rechazó la petición ({status}). Revisa el ID de voz, el modelo y el texto.{detail}", status);
                default:
                    return new TtsException(TtsErrorKind.Other,
                        $"{DisplayName} respondió {status} ({(HttpStatusCode)status}).{detail}", status);
            }
        }

        private static async Task<string> SafeReadBody(HttpResponseMessage response)
        {
            try
            {
                string text = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if (text == null) return string.Empty;
                text = text.Replace('\n', ' ').Replace('\r', ' ').Trim();
                return text.Length > 240 ? text.Substring(0, 240) + "…" : text;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
