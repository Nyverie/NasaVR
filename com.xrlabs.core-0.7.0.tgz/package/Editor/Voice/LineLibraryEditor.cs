using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Inspector de LineLibrary: cabecera con "Generar faltantes" / "Regenerar todo", estado y acciones
    /// por frase e idioma, y debajo el inspector por defecto (la lista de frases sigue editable).
    /// </summary>
    [CustomEditor(typeof(LineLibrary))]
    public class LineLibraryEditor : UnityEditor.Editor
    {
        private static bool _showVoice = true;
        private static bool _showRows = true;

        private string _filter = string.Empty;
        private bool _onlyPending;
        private List<string> _orphans = new();
        private double _orphansCheckedAt;
        private VoiceSettings _settings;

        private void OnEnable()
        {
            _settings = VoiceSettings.Find();
            _orphansCheckedAt = -10;
        }

        private void OnDisable() => VoicePreview.Stop();

        public override void OnInspectorGUI()
        {
            var library = (LineLibrary)target;
            DrawVoicePanel(library);
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("Datos de la librería", EditorStyles.boldLabel);
            DrawDefaultInspector();
        }

        // ------------------------------------------------------------ panel de voz

        private void DrawVoicePanel(LineLibrary library)
        {
            _showVoice = EditorGUILayout.BeginFoldoutHeaderGroup(_showVoice, "Voz (TTS)");
            if (_showVoice)
            {
                if (!_settings) _settings = VoiceSettings.Find();

                if (!_settings)
                {
                    EditorGUILayout.HelpBox("No hay un asset VoiceSettings en el proyecto. Créalo para generar voz.", MessageType.Info);
                    if (GUILayout.Button("Crear VoiceSettings"))
                    {
                        _settings = VoiceSettings.CreateDefaultAsset();
                        Selection.activeObject = _settings;
                    }
                }
                else
                {
                    DrawSettingsSummary();
                    DrawToolbar(library);
                    DrawProgress(library);
                    DrawSummary(library);
                    DrawRows(library);
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawSettingsSummary()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(
                $"{_settings.ProviderDisplayName} · {_settings.ModelId} · ES: {Short(_settings.GetVoiceId(CoachLanguage.Spanish))} · EN: {Short(_settings.GetVoiceId(CoachLanguage.English))}",
                EditorStyles.miniLabel);
            if (GUILayout.Button("Ajustes", EditorStyles.miniButton, GUILayout.Width(60)))
            {
                Selection.activeObject = _settings;
                EditorGUIUtility.PingObject(_settings);
            }
            EditorGUILayout.EndHorizontal();

            if (!VoiceApiKeys.HasOrNotNeeded(_settings.provider))
                EditorGUILayout.HelpBox($"Falta la clave de {_settings.ProviderDisplayName} (ver VoiceSettings).", MessageType.Warning);
            if (_settings.provider == VoiceProviderKind.MacSay)
                EditorGUILayout.HelpBox(VoiceSettingsEditor.ProvisionalNotice, MessageType.Warning);
        }

        private void DrawToolbar(LineLibrary library)
        {
            var baker = new VoiceBaker(_settings, new NullProvider());
            var missing = baker.Plan(library, new BakeScope());
            var all = baker.Plan(library, new BakeScope { Force = true });

            EditorGUILayout.LabelField(
                $"Pendientes: {missing.Jobs.Count} · {missing.Characters} caracteres   |   Total: {all.Jobs.Count} · {all.Characters} caracteres",
                EditorStyles.miniLabel);

            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(VoiceBakeSession.Running || missing.Jobs.Count == 0))
            {
                if (GUILayout.Button($"Generar faltantes ({missing.Jobs.Count})", GUILayout.Height(24)))
                    RunBake(library, new BakeScope());
            }
            using (new EditorGUI.DisabledScope(VoiceBakeSession.Running || all.Jobs.Count == 0))
            {
                if (GUILayout.Button("Regenerar todo", GUILayout.Height(24)))
                {
                    bool confirmed = EditorUtility.DisplayDialog("Regenerar todo",
                        $"Se rehacerán {all.Jobs.Count} clips y se enviarán {all.Characters} caracteres a {_settings.ProviderDisplayName}.\n\n" +
                        "Cada llamada cuesta dinero y cambia ligeramente la entonación. ¿Continuar?",
                        "Regenerar", "Cancelar");
                    if (confirmed) RunBake(library, new BakeScope { Force = true });
                    GUIUtility.ExitGUI();
                }
            }
            EditorGUILayout.EndHorizontal();

            RefreshOrphans(library);
            if (_orphans.Count > 0)
            {
                using (new EditorGUI.DisabledScope(VoiceBakeSession.Running))
                {
                    if (GUILayout.Button($"Borrar clips huérfanos ({_orphans.Count})"))
                    {
                        bool confirmed = EditorUtility.DisplayDialog("Borrar clips huérfanos",
                            "Estos clips ya no corresponden a ninguna frase:\n\n" + string.Join("\n", _orphans.Take(15)) +
                            (_orphans.Count > 15 ? $"\n… y {_orphans.Count - 15} más" : string.Empty),
                            "Borrar", "Cancelar");
                        if (confirmed)
                        {
                            VoiceBaker.DeleteOrphans(_orphans);
                            _orphansCheckedAt = -10;
                        }
                        GUIUtility.ExitGUI();
                    }
                }
            }
        }

        private void RunBake(LineLibrary library, BakeScope scope)
        {
            if (!VoiceBakeSession.EnsureApiKey(_settings))
            {
                GUIUtility.ExitGUI();
                return;
            }
            VoiceBakeSession.Start(library, _settings, scope);
        }

        private void RefreshOrphans(LineLibrary library)
        {
            // La búsqueda toca el AssetDatabase: no hacerla en cada repintado.
            if (EditorApplication.timeSinceStartup - _orphansCheckedAt < 3.0) return;
            _orphansCheckedAt = EditorApplication.timeSinceStartup;
            _orphans = VoiceBaker.FindOrphans(_settings, library);
        }

        private void DrawProgress(LineLibrary library)
        {
            if (!VoiceBakeSession.Running || VoiceBakeSession.Library != library) return;

            var p = VoiceBakeSession.Progress;
            var rect = EditorGUILayout.GetControlRect(false, 20);
            string label = $"{p.Completed}/{p.Total}" + (string.IsNullOrEmpty(p.Current) ? string.Empty : $" · {p.Current}");
            EditorGUI.ProgressBar(rect, p.Fraction, label);
            if (GUILayout.Button("Cancelar")) VoiceBakeSession.Cancel();
            Repaint();
        }

        private static void DrawSummary(LineLibrary library)
        {
            var s = VoiceBakeSession.LastSummary;
            if (s == null || VoiceBakeSession.LastSummaryLibrary != library) return;
            EditorGUILayout.HelpBox(s.ToString(), s.Failed > 0 ? MessageType.Warning : MessageType.Info);
        }

        // ------------------------------------------------------------ filas por frase

        private void DrawRows(LineLibrary library)
        {
            EditorGUILayout.Space(4);
            _showRows = EditorGUILayout.Foldout(_showRows, $"Estado por frase ({library.lines.Count})", true);
            if (!_showRows) return;

            EditorGUILayout.BeginHorizontal();
            _filter = EditorGUILayout.TextField(_filter, EditorStyles.toolbarSearchField);
            _onlyPending = GUILayout.Toggle(_onlyPending, "Solo pendientes", EditorStyles.miniButton, GUILayout.Width(110));
            EditorGUILayout.EndHorizontal();

            foreach (var line in library.lines)
            {
                if (line == null || string.IsNullOrEmpty(line.id) || line.variants == null) continue;
                if (!MatchesFilter(line)) continue;

                var statuses = line.variants
                    .Where(v => v != null)
                    .Select(v => (variant: v, status: VoiceBaker.GetStatus(library, line, v, _settings)))
                    .ToList();
                if (_onlyPending && statuses.All(s => s.status == VoiceStatus.UpToDate || s.status == VoiceStatus.Empty)) continue;

                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.LabelField(line.id, EditorStyles.boldLabel);
                foreach (var (variant, status) in statuses)
                    DrawVariantRow(library, line, variant, status);
                EditorGUILayout.EndVertical();
            }
        }

        private bool MatchesFilter(VoiceLine line)
        {
            if (string.IsNullOrWhiteSpace(_filter)) return true;
            if (line.id.IndexOf(_filter, System.StringComparison.OrdinalIgnoreCase) >= 0) return true;
            return line.variants != null && line.variants.Any(v =>
                v != null && !string.IsNullOrEmpty(v.text) &&
                v.text.IndexOf(_filter, System.StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void DrawVariantRow(LineLibrary library, VoiceLine line, VoiceLineVariant variant, VoiceStatus status)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(LanguageService.ToCode(variant.language).ToUpperInvariant(), GUILayout.Width(24));

            var badge = new GUIStyle(EditorStyles.miniBoldLabel);
            badge.normal.textColor = StatusColor(status);
            EditorGUILayout.LabelField(StatusLabel(status), badge, GUILayout.Width(100));

            string preview = variant.text ?? string.Empty;
            if (preview.Length > 50) preview = preview.Substring(0, 50) + "…";
            EditorGUILayout.LabelField(preview.Replace('\n', ' '), EditorStyles.miniLabel);

            bool hasText = status != VoiceStatus.Empty;
            using (new EditorGUI.DisabledScope(VoiceBakeSession.Running || !hasText))
            {
                string verb = variant.clip ? "Regenerar" : "Generar";
                if (GUILayout.Button(verb, EditorStyles.miniButton, GUILayout.Width(70)))
                    RunBake(library, new BakeScope { Force = true, LineId = line.id, Language = variant.language });
            }
            using (new EditorGUI.DisabledScope(variant.clip == null))
            {
                if (GUILayout.Button("▶", EditorStyles.miniButton, GUILayout.Width(24)))
                    VoicePreview.Play(variant.clip);
            }
            EditorGUILayout.EndHorizontal();

            if (status == VoiceStatus.Error)
            {
                string error = VoiceBaker.GetLastError(library, line, variant);
                if (!string.IsNullOrEmpty(error)) EditorGUILayout.HelpBox(error, MessageType.Error);
            }
        }

        private static string StatusLabel(VoiceStatus status) => status switch
        {
            VoiceStatus.NoAudio => "● Sin audio",
            VoiceStatus.UpToDate => "● Al día",
            VoiceStatus.TextChanged => "● Texto cambiado",
            VoiceStatus.Error => "● Error",
            _ => "○ Sin texto"
        };

        private static Color StatusColor(VoiceStatus status)
        {
            bool dark = EditorGUIUtility.isProSkin;
            return status switch
            {
                VoiceStatus.UpToDate => dark ? new Color(0.45f, 0.85f, 0.5f) : new Color(0.1f, 0.5f, 0.15f),
                VoiceStatus.TextChanged => dark ? new Color(1f, 0.8f, 0.35f) : new Color(0.65f, 0.4f, 0f),
                VoiceStatus.Error => dark ? new Color(1f, 0.5f, 0.5f) : new Color(0.7f, 0.1f, 0.1f),
                VoiceStatus.NoAudio => dark ? new Color(0.75f, 0.75f, 0.75f) : new Color(0.35f, 0.35f, 0.35f),
                _ => Color.gray
            };
        }

        private static string Short(string id) =>
            string.IsNullOrEmpty(id) ? "—" : id.Length > 8 ? id.Substring(0, 8) + "…" : id;

        /// <summary>Proveedor nulo: el inspector solo usa Plan (no sintetiza).</summary>
        private sealed class NullProvider : ITtsProvider
        {
            public string Id => "none";
            public string DisplayName => "none";
            public System.Threading.Tasks.Task<TtsResult> SynthesizeAsync(TtsRequest request, System.Threading.CancellationToken cancellationToken) =>
                throw new System.NotSupportedException();
        }
    }
}
