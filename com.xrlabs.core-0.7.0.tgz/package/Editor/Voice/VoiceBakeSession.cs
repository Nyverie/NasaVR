using System;
using System.Collections.Generic;
using System.Threading;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Una tanda de horneado en curso desde el inspector (una a la vez). Es asíncrona: no bloquea el
    /// editor. Si el dominio se recarga (compilación, Play) la tanda se pierde, pero lo ya generado queda guardado.
    /// </summary>
    public static class VoiceBakeSession
    {
        public static bool Running { get; private set; }
        public static LineLibrary Library { get; private set; }
        public static BakeProgress Progress { get; private set; }
        public static BakeSummary LastSummary { get; private set; }
        public static LineLibrary LastSummaryLibrary { get; private set; }

        private static CancellationTokenSource _cts;

        public static void Cancel() => _cts?.Cancel();

        /// <summary>
        /// Comprueba que haya clave; si falta, avisa con un diálogo y devuelve false. Llamar desde el
        /// inspector (el diálogo es modal) antes de <see cref="Start"/>.
        /// </summary>
        public static bool EnsureApiKey(VoiceSettings settings)
        {
            var kind = settings.provider;
            if (VoiceApiKeys.HasOrNotNeeded(kind)) return true;

            bool open = EditorUtility.DisplayDialog("Falta la clave de API",
                $"No hay clave de {settings.ProviderDisplayName}. Guárdala en el asset VoiceSettings " +
                $"o define la variable de entorno {VoiceApiKeys.EnvVar(kind)}.",
                "Abrir VoiceSettings", "Cerrar");
            if (open)
            {
                Selection.activeObject = settings;
                EditorGUIUtility.PingObject(settings);
            }
            return false;
        }

        public static async void Start(LineLibrary library, VoiceSettings settings, BakeScope scope)
        {
            if (Running || !library || !settings) return;

            Running = true;
            Library = library;
            LastSummary = null;
            _cts = new CancellationTokenSource();
            Progress = new BakeProgress(0, 0, null);

            try
            {
                var baker = VoiceBaker.CreateDefault(settings);
                var progress = new System.Progress<BakeProgress>(p =>
                {
                    Progress = p;
                    InternalEditorUtility.RepaintAllViews();
                });

                var summary = await baker.BakeAsync(library, scope, progress, _cts.Token);
                LastSummary = summary;
                LastSummaryLibrary = library;

                if (summary.Failed > 0) Debug.LogWarning("[XRLabs] " + summary);
                else Debug.Log("[XRLabs] " + summary);
            }
            catch (Exception ex)
            {
                var summary = new BakeSummary { Failed = 1 };
                summary.Errors.Add(ex.Message);
                LastSummary = summary;
                LastSummaryLibrary = library;
                Debug.LogError($"[XRLabs] El horneado de voz falló: {ex.Message}");
            }
            finally
            {
                _cts?.Dispose();
                _cts = null;
                Running = false;
                Library = null;
                AssetDatabase.SaveAssets();
                InternalEditorUtility.RepaintAllViews();
            }
        }
    }
}
