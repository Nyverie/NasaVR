using System;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json.Linq;

namespace XRLabs.Coach.Editor
{
    /// <summary>POST https://api.fish.audio/v1/tts (respuesta por trozos).</summary>
    public sealed class FishAudioProvider : HttpTtsProvider
    {
        public const string Endpoint = "https://api.fish.audio/v1/tts";
        public const string DefaultModel = "s2.1-pro";

        public FishAudioProvider(string apiKey, HttpMessageHandler handler = null) : base(apiKey, handler) { }

        public override string Id => "fishaudio";
        public override string DisplayName => "Fish Audio";
        protected override string ApiKeyEnvVar => VoiceApiKeys.FishAudioEnvVar;
        protected override string OutputExtension => "mp3";

        protected override HttpRequestMessage BuildRequest(TtsRequest request, string apiKey)
        {
            var body = new JObject
            {
                ["text"] = request.Text,
                ["reference_id"] = request.VoiceId,
                ["format"] = "mp3",
                ["latency"] = "normal",
                ["temperature"] = Math.Round(request.Temperature, 3),
                ["prosody"] = new JObject { ["speed"] = Math.Round(request.Speed, 3) }
            };

            var message = new HttpRequestMessage(HttpMethod.Post, Endpoint)
            {
                Content = new StringContent(body.ToString(Newtonsoft.Json.Formatting.None), Encoding.UTF8, "application/json")
            };
            message.Headers.TryAddWithoutValidation("Authorization", "Bearer " + apiKey);
            message.Headers.TryAddWithoutValidation("model", string.IsNullOrWhiteSpace(request.ModelId) ? DefaultModel : request.ModelId);
            return message;
        }
    }
}
