using System;
using UnityEditor;

namespace XRLabs.Coach.Editor
{
    public enum VoiceKeySource
    {
        None,
        EditorPrefs,
        Environment
    }

    /// <summary>
    /// Claves de API de los proveedores de voz. Solo viven en EditorPrefs (por usuario y máquina)
    /// o en variables de entorno; nunca en un asset ni en un archivo del repositorio, y nunca se loguean.
    /// </summary>
    public static class VoiceApiKeys
    {
        public const string ElevenLabsEnvVar = "ELEVENLABS_API_KEY";
        public const string FishAudioEnvVar = "FISH_AUDIO_API_KEY";

        public static string PrefsKey(VoiceProviderKind kind) => $"XRLabs.Voice.ApiKey.{kind}";

        public static string EnvVar(VoiceProviderKind kind) =>
            kind == VoiceProviderKind.FishAudio ? FishAudioEnvVar : ElevenLabsEnvVar;

        /// <summary>Clave del proveedor ("" si no hay). EditorPrefs primero, variable de entorno como respaldo.</summary>
        public static string Get(VoiceProviderKind kind)
        {
            string stored = EditorPrefs.GetString(PrefsKey(kind), string.Empty);
            if (!string.IsNullOrWhiteSpace(stored)) return stored.Trim();

            string env = Environment.GetEnvironmentVariable(EnvVar(kind));
            return string.IsNullOrWhiteSpace(env) ? string.Empty : env.Trim();
        }

        public static VoiceKeySource GetSource(VoiceProviderKind kind)
        {
            if (!string.IsNullOrWhiteSpace(EditorPrefs.GetString(PrefsKey(kind), string.Empty)))
                return VoiceKeySource.EditorPrefs;
            if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(EnvVar(kind))))
                return VoiceKeySource.Environment;
            return VoiceKeySource.None;
        }

        public static bool Has(VoiceProviderKind kind) => GetSource(kind) != VoiceKeySource.None;

        /// <summary>Si se puede hornear con ese proveedor: hay clave, o el proveedor no la necesita (el del sistema, macOS).</summary>
        public static bool HasOrNotNeeded(VoiceProviderKind kind) => !VoiceSettings.RequiresApiKey(kind) || Has(kind);

        public static void Set(VoiceProviderKind kind, string key)
        {
            if (string.IsNullOrWhiteSpace(key)) Clear(kind);
            else EditorPrefs.SetString(PrefsKey(kind), key.Trim());
        }

        public static void Clear(VoiceProviderKind kind) => EditorPrefs.DeleteKey(PrefsKey(kind));
    }
}
