using System;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json.Linq;

namespace XRLabs.Coach.Editor
{
    /// <summary>POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id}?output_format=mp3_44100_128</summary>
    public sealed class ElevenLabsProvider : HttpTtsProvider
    {
        public const string Endpoint = "https://api.elevenlabs.io/v1/text-to-speech/";
        public const string OutputFormat = "mp3_44100_128";
        public const string DefaultModel = "eleven_multilingual_v2";

        public ElevenLabsProvider(string apiKey, HttpMessageHandler handler = null) : base(apiKey, handler) { }

        public override string Id => "elevenlabs";
        public override string DisplayName => "ElevenLabs";
        protected override string ApiKeyEnvVar => VoiceApiKeys.ElevenLabsEnvVar;
        protected override string OutputExtension => "mp3";

        protected override HttpRequestMessage BuildRequest(TtsRequest request, string apiKey)
        {
            var body = new JObject
            {
                ["text"] = request.Text,
                ["model_id"] = string.IsNullOrWhiteSpace(request.ModelId) ? DefaultModel : request.ModelId,
                ["voice_settings"] = new JObject
                {
                    ["stability"] = Math.Round(request.Stability, 3),
                    ["similarity_boost"] = Math.Round(request.SimilarityBoost, 3),
                    ["style"] = Math.Round(request.Style, 3)
                }
            };
            if (request.UseSeed) body["seed"] = Math.Max(0, request.Seed);
            if (!string.IsNullOrWhiteSpace(request.PreviousText)) body["previous_text"] = request.PreviousText;
            if (!string.IsNullOrWhiteSpace(request.NextText)) body["next_text"] = request.NextText;

            var message = new HttpRequestMessage(
                HttpMethod.Post,
                $"{Endpoint}{Uri.EscapeDataString(request.VoiceId)}?output_format={OutputFormat}")
            {
                Content = new StringContent(body.ToString(Newtonsoft.Json.Formatting.None), Encoding.UTF8, "application/json")
            };
            message.Headers.TryAddWithoutValidation("xi-api-key", apiKey);
            message.Headers.TryAddWithoutValidation("Accept", "audio/mpeg");
            return message;
        }
    }
}
