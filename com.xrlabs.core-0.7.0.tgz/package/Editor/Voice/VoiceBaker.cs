using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using XRLabs.Core;

namespace XRLabs.Coach.Editor
{
    /// <summary>Estado del audio de una variante (frase + idioma).</summary>
    public enum VoiceStatus
    {
        /// <summary>No hay clip.</summary>
        NoAudio,
        /// <summary>Clip generado con el texto y los ajustes actuales.</summary>
        UpToDate,
        /// <summary>Hay clip pero el texto hablado, la voz, el modelo o los ajustes cambiaron.</summary>
        TextChanged,
        /// <summary>La última generación falló (mensaje en <see cref="VoiceBaker.GetLastError"/>).</summary>
        Error,
        /// <summary>La variante no tiene texto: no necesita voz.</summary>
        Empty
    }

    /// <summary>Qué hornear. Por defecto: las variantes sin audio o con texto cambiado de toda la librería.</summary>
    public sealed class BakeScope
    {
        /// <summary>Rehacer también las que están al día.</summary>
        public bool Force;
        /// <summary>Solo esta frase (null = todas).</summary>
        public string LineId;
        /// <summary>Solo este idioma (null = todos).</summary>
        public CoachLanguage? Language;
    }

    public sealed class BakeJob
    {
        public LineLibrary Library;
        public VoiceLine Line;
        public VoiceLineVariant Variant;
        public CoachLanguage Language;
        public string SpokenText;
        public string Hash;
        public string FileStem;
        public string PreviousText;
        public string NextText;
        public string Label => $"{LanguageService.ToCode(Language)}/{Line.id}";
    }

    public sealed class BakePlan
    {
        public readonly List<BakeJob> Jobs = new();
        /// <summary>Variantes con texto que ya estaban al día y no se tocan.</summary>
        public int Skipped;
        public int Characters => Jobs.Sum(j => j.SpokenText.Length);
    }

    public readonly struct BakeProgress
    {
        public readonly int Completed;
        public readonly int Total;
        public readonly string Current;

        public BakeProgress(int completed, int total, string current)
        {
            Completed = completed;
            Total = total;
            Current = current;
        }

        public float Fraction => Total <= 0 ? 1f : (float)Completed / Total;
    }

    public sealed class BakeSummary
    {
        public int Generated;
        public int Skipped;
        public int Failed;
        /// <summary>Caracteres enviados al proveedor en las frases generadas con éxito.</summary>
        public int Characters;
        public bool Cancelled;
        /// <summary>Si la tanda se abortó por un error fatal (clave, saldo), el motivo.</summary>
        public string AbortReason;
        public readonly List<string> Errors = new();

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append($"Voz: {Generated} generadas, {Skipped} saltadas, {Failed} fallidas, {Characters} caracteres.");
            if (Cancelled) sb.Append(" (cancelado)");
            if (!string.IsNullOrEmpty(AbortReason)) sb.Append(" Abortado: ").Append(AbortReason);
            foreach (string e in Errors) sb.Append("\n  - ").Append(e);
            return sb.ToString();
        }
    }

    /// <summary>
    /// Horneado de voz: recorre una LineLibrary, calcula el hash de cada variante, genera con el
    /// proveedor solo lo que cambió y deja el clip importado y asignado. Solo editor; llamar siempre
    /// desde el hilo principal (escribe assets).
    /// </summary>
    public sealed class VoiceBaker
    {
        private static readonly Dictionary<string, string> LastErrors = new();
        private static readonly string[] AudioExtensions = { ".mp3", ".wav", ".ogg", ".aif", ".aiff" };

        private readonly VoiceSettings _settings;
        private readonly ITtsProvider _provider;

        public VoiceBaker(VoiceSettings settings, ITtsProvider provider)
        {
            _settings = settings ? settings : throw new ArgumentNullException(nameof(settings));
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
        }

        /// <summary>Baker con el proveedor activo en VoiceSettings y su clave (EditorPrefs / entorno).</summary>
        public static VoiceBaker CreateDefault(VoiceSettings settings)
        {
            ITtsProvider provider = settings.provider switch
            {
                VoiceProviderKind.MacSay => new MacSayProvider(),
                VoiceProviderKind.FishAudio => new FishAudioProvider(VoiceApiKeys.Get(settings.provider)),
                _ => new ElevenLabsProvider(VoiceApiKeys.Get(settings.provider))
            };
            return new VoiceBaker(settings, provider);
        }

        // ---------------------------------------------------------------- hash y estado

        /// <summary>SHA-256 de proveedor|voz|modelo|ajustes|semilla|idioma|textoHablado.</summary>
        public static string ComputeHash(VoiceSettings s, CoachLanguage language, string spokenText)
        {
            string raw = string.Join("|",
                s.ProviderId,
                s.GetVoiceId(language),
                s.ModelId,
                s.SettingsSignature,
                s.SeedSignature,
                LanguageService.ToCode(language),
                spokenText ?? string.Empty);

            using var sha = SHA256.Create();
            byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
            var sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        /// <summary>
        /// Estado de una variante. Sin VoiceSettings (null) solo se distingue Sin audio / Al día
        /// (no se puede comparar el hash).
        /// </summary>
        public static VoiceStatus GetStatus(LineLibrary library, VoiceLine line, VoiceLineVariant variant, VoiceSettings settings)
        {
            if (variant == null || line is { textOnly: true } ||
                string.IsNullOrWhiteSpace(variant.text) && string.IsNullOrWhiteSpace(variant.spokenText))
                return VoiceStatus.Empty;

            if (GetLastError(library, line, variant) != null) return VoiceStatus.Error;
            if (variant.clip == null) return VoiceStatus.NoAudio;
            if (settings == null) return VoiceStatus.UpToDate;

            string hash = ComputeHash(settings, variant.language, library.GetSpokenText(variant));
            return string.Equals(variant.bakeHash, hash, StringComparison.Ordinal)
                ? VoiceStatus.UpToDate
                : VoiceStatus.TextChanged;
        }

        public static string GetLastError(LineLibrary library, VoiceLine line, VoiceLineVariant variant) =>
            LastErrors.TryGetValue(ErrorKey(library, line?.id, variant != null ? variant.language : default), out var msg) ? msg : null;

        private static string ErrorKey(LineLibrary library, string lineId, CoachLanguage language) =>
            $"{(library ? library.GetInstanceID() : 0)}:{lineId}:{(int)language}";

        // ---------------------------------------------------------------- rutas

        /// <summary>Nombre de archivo seguro a partir de un ID de frase (conserva letras, dígitos, '.', '_' y '-').</summary>
        public static string SanitizeFileName(string id)
        {
            if (string.IsNullOrEmpty(id)) return "_";
            var sb = new StringBuilder(id.Length);
            foreach (char c in id)
                sb.Append(char.IsLetterOrDigit(c) || c == '.' || c == '_' || c == '-' ? c : '_');
            string result = sb.ToString().Trim('.');
            return result.Length == 0 ? "_" : result;
        }

        /// <summary>
        /// Carpeta de los clips de una librería e idioma. Una librería importada de un guion vive en
        /// <c>&lt;experiencia&gt;/Frases/</c>: sus clips van a <c>&lt;experiencia&gt;/Voces/&lt;es|en&gt;</c>, junto al resto
        /// de la experiencia. Cualquier otra, a <c>&lt;raíz de salida&gt;/&lt;librería&gt;/&lt;es|en&gt;</c>, como siempre.
        /// </summary>
        public static string GetClipFolder(VoiceSettings settings, LineLibrary library, CoachLanguage language)
        {
            string code = LanguageService.ToCode(language);
            string experienceDir = ExperienceDirOf(library);
            return experienceDir != null
                ? $"{experienceDir}/{ExperienceVoicesFolder}/{code}"
                : $"{settings.OutputRootNormalized}/{SanitizeFileName(library.name)}/{code}";
        }

        /// <summary>Nombre de la carpeta de voces dentro de una experiencia importada.</summary>
        public const string ExperienceVoicesFolder = "Voces";

        /// <summary>La carpeta de la experiencia si la librería está en <c>&lt;experiencia&gt;/Frases/</c>; si no, null.</summary>
        private static string ExperienceDirOf(LineLibrary library)
        {
            string path = library ? AssetDatabase.GetAssetPath(library) : null;
            if (string.IsNullOrEmpty(path)) return null;
            string dir = Path.GetDirectoryName(path)?.Replace('\\', '/');
            if (dir == null || !string.Equals(Path.GetFileName(dir), "Frases", StringComparison.Ordinal)) return null;
            string experienceDir = Path.GetDirectoryName(dir)?.Replace('\\', '/');
            return string.IsNullOrEmpty(experienceDir) ? null : experienceDir;
        }

        /// <summary>Nombre de archivo (sin extensión) de cada frase; desambigua IDs que se sanean igual.</summary>
        public static Dictionary<VoiceLine, string> BuildFileStems(LineLibrary library)
        {
            var stems = new Dictionary<VoiceLine, string>();
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var line in library.lines)
            {
                if (line == null || string.IsNullOrEmpty(line.id) || stems.ContainsKey(line)) continue;
                string stem = SanitizeFileName(line.id);
                if (!used.Add(stem))
                {
                    stem = $"{stem}_{ShortHash(line.id)}";
                    used.Add(stem);
                }
                stems[line] = stem;
            }
            return stems;
        }

        private static string ShortHash(string text)
        {
            using var sha = SHA256.Create();
            byte[] h = sha.ComputeHash(Encoding.UTF8.GetBytes(text));
            return h[0].ToString("x2") + h[1].ToString("x2") + h[2].ToString("x2");
        }

        // ---------------------------------------------------------------- plan

        public BakePlan Plan(LineLibrary library, BakeScope scope = null)
        {
            scope ??= new BakeScope();
            var plan = new BakePlan();
            var stems = BuildFileStems(library);

            for (int i = 0; i < library.lines.Count; i++)
            {
                var line = library.lines[i];
                if (line == null || string.IsNullOrEmpty(line.id) || line.variants == null || line.textOnly) continue;
                if (scope.LineId != null && line.id != scope.LineId) continue;

                foreach (var variant in line.variants)
                {
                    if (variant == null) continue;
                    if (scope.Language.HasValue && variant.language != scope.Language.Value) continue;

                    string spoken = library.GetSpokenText(variant);
                    if (string.IsNullOrWhiteSpace(spoken)) continue;

                    var status = GetStatus(library, line, variant, _settings);
                    if (!scope.Force && status == VoiceStatus.UpToDate)
                    {
                        plan.Skipped++;
                        continue;
                    }

                    plan.Jobs.Add(new BakeJob
                    {
                        Library = library,
                        Line = line,
                        Variant = variant,
                        Language = variant.language,
                        SpokenText = spoken,
                        Hash = ComputeHash(_settings, variant.language, spoken),
                        FileStem = stems[line],
                        PreviousText = NeighbourText(library, i - 1, variant.language),
                        NextText = NeighbourText(library, i + 1, variant.language)
                    });
                }
            }
            return plan;
        }

        private static string NeighbourText(LineLibrary library, int index, CoachLanguage language)
        {
            if (index < 0 || index >= library.lines.Count) return null;
            var variant = library.lines[index]?.GetVariant(language);
            if (variant == null) return null;
            string text = library.GetSpokenText(variant);
            return string.IsNullOrWhiteSpace(text) ? null : text;
        }

        // ---------------------------------------------------------------- horneado

        public async Task<BakeSummary> BakeAsync(
            LineLibrary library,
            BakeScope scope = null,
            IProgress<BakeProgress> progress = null,
            CancellationToken cancellationToken = default)
        {
            if (!library) throw new ArgumentNullException(nameof(library));

            var plan = Plan(library, scope);
            var summary = new BakeSummary { Skipped = plan.Skipped };
            int total = plan.Jobs.Count;
            int completed = 0;
            progress?.Report(new BakeProgress(0, total, null));
            if (total == 0) return summary;

            using var abort = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            using var gate = new SemaphoreSlim(_settings.ConcurrencyClamped);
            var sync = new object();

            async Task RunAsync(BakeJob job)
            {
                try
                {
                    await gate.WaitAsync(abort.Token);
                }
                catch (OperationCanceledException)
                {
                    return; // tanda cancelada o abortada antes de empezar esta frase
                }

                try
                {
                    abort.Token.ThrowIfCancellationRequested();
                    progress?.Report(new BakeProgress(Volatile.Read(ref completed), total, job.Label));

                    string voiceId = _settings.GetVoiceId(job.Language);
                    if (string.IsNullOrEmpty(voiceId))
                        throw new TtsException(TtsErrorKind.BadRequest,
                            $"Falta el ID de voz de {job.Language} para {_settings.ProviderDisplayName} en VoiceSettings.");

                    var result = await _provider.SynthesizeAsync(BuildRequest(job, voiceId), abort.Token);

                    // La continuación vuelve al hilo principal (contexto de Unity): ya se pueden escribir assets.
                    SaveClip(job, result);
                    lock (sync)
                    {
                        summary.Generated++;
                        summary.Characters += job.SpokenText.Length;
                    }
                    LastErrors.Remove(ErrorKey(library, job.Line.id, job.Language));
                }
                catch (OperationCanceledException)
                {
                    // cancelada: no cuenta como fallo
                }
                catch (Exception ex)
                {
                    string message = ex is TtsException ? ex.Message : $"{ex.GetType().Name}: {ex.Message}";
                    LastErrors[ErrorKey(library, job.Line.id, job.Language)] = message;
                    lock (sync)
                    {
                        summary.Failed++;
                        summary.Errors.Add($"{job.Label}: {message}");
                        if (ex is TtsException { IsFatal: true } && summary.AbortReason == null)
                        {
                            summary.AbortReason = message;
                            abort.Cancel();
                        }
                    }
                }
                finally
                {
                    gate.Release();
                    progress?.Report(new BakeProgress(Interlocked.Increment(ref completed), total, job.Label));
                }
            }

            await Task.WhenAll(plan.Jobs.Select(RunAsync));

            summary.Cancelled = cancellationToken.IsCancellationRequested || summary.AbortReason != null;
            if (library && EditorUtility.IsPersistent(library)) AssetDatabase.SaveAssetIfDirty(library);
            return summary;
        }

        private TtsRequest BuildRequest(BakeJob job, string voiceId) => new TtsRequest
        {
            Text = job.SpokenText,
            VoiceId = voiceId,
            ModelId = _settings.ModelId,
            LanguageCode = LanguageService.ToCode(job.Language),
            PreviousText = job.PreviousText,
            NextText = job.NextText,
            UseSeed = _settings.provider == VoiceProviderKind.ElevenLabs,
            Seed = _settings.seed,
            Stability = _settings.stability,
            SimilarityBoost = _settings.similarityBoost,
            Style = _settings.style,
            Temperature = _settings.temperature,
            Speed = _settings.speed
        };

        private void SaveClip(BakeJob job, TtsResult result)
        {
            string folder = GetClipFolder(_settings, job.Library, job.Language);
            string assetPath = $"{folder}/{job.FileStem}.{result.Extension}";
            string previousPath = job.Variant.clip ? AssetDatabase.GetAssetPath(job.Variant.clip) : null;

            EnsureFolder(folder);
            File.WriteAllBytes(AbsolutePath(assetPath), result.Audio);
            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
            ConfigureImporter(assetPath);

            var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
            if (clip == null)
                throw new IOException($"Unity no pudo importar el audio como AudioClip ({assetPath}).");

            job.Variant.clip = clip;
            job.Variant.bakeHash = job.Hash;
            EditorUtility.SetDirty(job.Library);
            if (EditorUtility.IsPersistent(job.Library)) AssetDatabase.SaveAssetIfDirty(job.Library);

            // Si cambió la extensión (p. ej. wav → mp3 al cambiar de proveedor), no dejar el clip viejo huérfano.
            if (!string.IsNullOrEmpty(previousPath)
                && !string.Equals(previousPath, assetPath, StringComparison.OrdinalIgnoreCase)
                && previousPath.StartsWith(folder + "/", StringComparison.OrdinalIgnoreCase))
            {
                AssetDatabase.DeleteAsset(previousPath);
            }
        }

        /// <summary>Mono, Vorbis, Compressed In Memory, calidad 0.5, carga en segundo plano.</summary>
        public static void ConfigureImporter(string assetPath)
        {
            if (AssetImporter.GetAtPath(assetPath) is not AudioImporter importer) return;

            var sample = importer.defaultSampleSettings;
            bool dirty = !importer.forceToMono || !importer.loadInBackground
                         || sample.loadType != AudioClipLoadType.CompressedInMemory
                         || sample.compressionFormat != AudioCompressionFormat.Vorbis
                         || Mathf.Abs(sample.quality - 0.5f) > 0.001f;
            if (!dirty) return;

            sample.loadType = AudioClipLoadType.CompressedInMemory;
            sample.compressionFormat = AudioCompressionFormat.Vorbis;
            sample.quality = 0.5f;
            sample.sampleRateSetting = AudioSampleRateSetting.PreserveSampleRate;
            importer.defaultSampleSettings = sample;
            importer.forceToMono = true;
            importer.loadInBackground = true;
            importer.SaveAndReimport();
        }

        // ---------------------------------------------------------------- huérfanos

        /// <summary>Clips en las carpetas de la librería cuyo ID de frase ya no existe (no los toca).</summary>
        public static List<string> FindOrphans(VoiceSettings settings, LineLibrary library)
        {
            var orphans = new List<string>();
            var stems = BuildFileStems(library);

            foreach (CoachLanguage language in Enum.GetValues(typeof(CoachLanguage)))
            {
                string folder = GetClipFolder(settings, library, language);
                if (!AssetDatabase.IsValidFolder(folder)) continue;

                var expected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var line in library.lines)
                {
                    if (line == null || !stems.TryGetValue(line, out string stem)) continue;
                    var variant = line.GetVariant(language);
                    if (variant == null) continue;
                    expected.Add(stem);
                    if (variant.clip)
                        expected.Add(Path.GetFileNameWithoutExtension(AssetDatabase.GetAssetPath(variant.clip)));
                }

                foreach (string guid in AssetDatabase.FindAssets("t:AudioClip", new[] { folder }))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if (!string.Equals(Path.GetDirectoryName(path)?.Replace('\\', '/'), folder, StringComparison.OrdinalIgnoreCase)) continue;
                    if (!AudioExtensions.Contains(Path.GetExtension(path).ToLowerInvariant())) continue;
                    if (!expected.Contains(Path.GetFileNameWithoutExtension(path))) orphans.Add(path);
                }
            }
            return orphans;
        }

        /// <summary>Borra los clips indicados (la UI debe pedir confirmación antes). Devuelve cuántos se borraron.</summary>
        public static int DeleteOrphans(IEnumerable<string> assetPaths)
        {
            int deleted = 0;
            foreach (string path in assetPaths)
                if (AssetDatabase.DeleteAsset(path)) deleted++;
            return deleted;
        }

        // ---------------------------------------------------------------- utilidades

        private static string ProjectRoot => Directory.GetParent(Application.dataPath)!.FullName;

        public static string AbsolutePath(string assetPath) => Path.Combine(ProjectRoot, assetPath);

        public static void EnsureFolder(string assetFolder)
        {
            if (AssetDatabase.IsValidFolder(assetFolder)) return;
            string parent = Path.GetDirectoryName(assetFolder)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) return;
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(assetFolder));
        }
    }
}
