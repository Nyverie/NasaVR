using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace XRLabs.Coach.Editor
{
    /// <summary>
    /// Reproduce un clip en el editor sin entrar en Play. Intenta la API interna UnityEditor.AudioUtil
    /// (reflexión) y, si cambia o falla, usa un AudioSource oculto.
    /// </summary>
    public static class VoicePreview
    {
        private static MethodInfo _play;
        private static MethodInfo _stopAll;
        private static bool _reflectionResolved;
        private static AudioSource _fallback;

        public static void Play(AudioClip clip)
        {
            if (clip == null) return;
            Stop();

            if (TryPlayWithAudioUtil(clip)) return;

            try
            {
                if (_fallback == null)
                {
                    var go = EditorUtility.CreateGameObjectWithHideFlags(
                        "XRLabs Voice Preview", HideFlags.HideAndDontSave, typeof(AudioSource));
                    _fallback = go.GetComponent<AudioSource>();
                    _fallback.playOnAwake = false;
                    _fallback.spatialBlend = 0f;
                }
                _fallback.clip = clip;
                _fallback.Play();
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[XRLabs] No se pudo reproducir la vista previa de audio: {ex.Message}");
            }
        }

        public static void Stop()
        {
            try
            {
                ResolveReflection();
                _stopAll?.Invoke(null, null);
            }
            catch
            {
                // ignorar: la vista previa es opcional
            }

            if (_fallback != null) _fallback.Stop();
        }

        private static bool TryPlayWithAudioUtil(AudioClip clip)
        {
            try
            {
                ResolveReflection();
                if (_play == null) return false;

                var parameters = _play.GetParameters();
                object[] args = parameters.Length switch
                {
                    1 => new object[] { clip },
                    2 => new object[] { clip, 0 },
                    3 => new object[] { clip, 0, false },
                    _ => null
                };
                if (args == null) return false;

                _play.Invoke(null, args);
                return true;
            }
            catch
            {
                _play = null; // no volver a intentarlo en esta sesión
                return false;
            }
        }

        private static void ResolveReflection()
        {
            if (_reflectionResolved) return;
            _reflectionResolved = true;

            try
            {
                var type = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.AudioUtil");
                if (type == null) return;

                const BindingFlags flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
                foreach (var m in type.GetMethods(flags))
                {
                    var p = m.GetParameters();
                    if (m.Name == "PlayPreviewClip" && p.Length >= 1 && p[0].ParameterType == typeof(AudioClip)
                        && (_play == null || p.Length > _play.GetParameters().Length))
                        _play = m;
                    else if (m.Name == "StopAllPreviewClips" && p.Length == 0)
                        _stopAll = m;
                }
            }
            catch
            {
                _play = null;
                _stopAll = null;
            }
        }
    }
}
