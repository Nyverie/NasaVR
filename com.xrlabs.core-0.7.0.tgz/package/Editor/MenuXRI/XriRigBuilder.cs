using System;
using System.Collections.Generic;
using Unity.XR.CoreUtils;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Attachment;
using UnityEngine.XR.Interaction.Toolkit.Feedback;
using UnityEngine.XR.Interaction.Toolkit.Inputs;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Haptics;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Readers;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Interactors.Casters;
using UnityEngine.XR.Interaction.Toolkit.Interactors.Visuals;
using UnityEngine.XR.Interaction.Toolkit.Locomotion;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Turning;
using XRLabs.Interactions;
using XRLabs.MenuXRI;
using Object = UnityEngine.Object;
using TrackedPoseDriver = UnityEngine.InputSystem.XR.TrackedPoseDriver;

namespace XRLabs.MenuXRI.Editor
{
    /// <summary>
    /// Arma por código el rig XRI del paquete (<c>Runtime/MenuXRI/XRLabsRig.prefab</c>, Documentation~/menu-xri.md §3.2 y §5):
    /// un <c>XROrigin</c> en modo suelo con <c>Camera Offset</c> y <c>Main Camera</c> (única con tag <c>MainCamera</c>), un
    /// <c>XRInteractionManager</c>, un <c>InputActionManager</c> que enciende las acciones, y dos mandos con
    /// <c>TrackedPoseDriver</c> y un <c>NearFarInteractor</c> (rayo lejano con cono, toque cercano con esfera y su línea
    /// visual). Las acciones son la copia del paquete (<c>XRLabs Input Actions.inputactions</c>, con GUID propio) de las
    /// <c>XRI Default Input Actions</c> de la muestra Starter Assets de XRI 3.3.1, que un paquete no puede referenciar.
    /// Se escribe todo con la API pública de XRI (compilada contra el paquete) y no con nombres de campos serializados, salvo
    /// lo que la API no expone. No usa red ni toca la escena.
    ///
    /// Teleportación (lote X2, 2026-10-10; Documentation~/menu-xri.md §9): en la raíz un <c>TeleportationProvider</c> con el
    /// <c>LocomotionMediator</c> y el <c>XRBodyTransformer</c> que XRI 3.3.1 le exige (sin mediador el proveedor se apaga con
    /// un error en Awake), y por mano un hijo <c>&lt;Lado&gt;_TeleportInteractor</c> (<c>XRRayInteractor</c> en proyectil, con su
    /// <c>XRInteractorLineVisual</c>) que solo ve la capa de interacción <c>Teleport</c>, metido con el <c>NearFarInteractor</c>
    /// en un <c>XRInteractionGroup</c> por mano (el de cerca/lejos primero). El rayo selecciona con la acción
    /// <c>XRI &lt;Lado&gt; Locomotion/Teleport Mode</c> (la muestra de XRI hace lo mismo: el <c>.inputactions</c> no trae una
    /// <c>Teleport Select</c>) y la <c>TeleportationArea</c> teleporta al soltarla. El interactor se guarda desactivado en el
    /// prefab, y un <c>TeleportModeActivator</c> en cada mando lo enciende mientras se mantiene <c>Teleport Mode</c> y lo
    /// apaga al soltarla o con <c>Teleport Mode Cancel</c> (la lógica de <c>ControllerInputActionManager</c>, un script de
    /// <c>Samples~</c> que un paquete no puede referenciar).
    ///
    /// Frotar con la mano y cambio de escena (auditoría del visor del 2026-10-18, correcciones 3 y 6; 2026-10-25): cada
    /// <c>&lt;Lado&gt;_NearFarInteractor</c> lleva un hijo <c>HandTrigger</c> con una esfera trigger de 5 cm y un
    /// <c>Rigidbody</c> cinemático sin gravedad, en la capa <c>Ignore Raycast</c>, para que una <c>ScrubSurface</c> (COMP-03)
    /// vea entrar y moverse la mano (el <c>NearFarInteractor</c> detecta con consultas de física y no tiene collider propio);
    /// la superficie la reconoce porque cuelga de un <c>IXRInteractor</c>. En la raíz, un <c>RigSceneGuard</c> junto al
    /// <c>InputActionManager</c> repone acciones, UI y gestor si otra escena que los compartía se descarga después de que este
    /// rig se encienda (no pasa con una carga Single; es el seguro para lo demás), y los interactores y grupos del rig van
    /// enlazados a su propio <c>XRInteractionManager</c>, no al que encuentre el buscador de XRI.
    /// </summary>
    public static class XriRigBuilder
    {
        public const string FolderPath = "Packages/com.xrlabs.core/Runtime/MenuXRI";
        public const string RigPrefabPath = FolderPath + "/XRLabsRig.prefab";
        public const string InputActionsPath = FolderPath + "/XRLabs Input Actions.inputactions";

        public const string RigRootName = "XR Origin (XR Rig)";
        public const string CameraOffsetName = "Camera Offset";
        public const string CameraName = "Main Camera";
        public const string LeftControllerName = "Left Controller";
        public const string RightControllerName = "Right Controller";

        /// <summary>Altura de la línea de rayo: la misma que usa la muestra de XRI (0,012 m a la salida del mando).</summary>
        private const float LineWidth = 0.012f;

        public const string TeleportInteractorSuffix = "_TeleportInteractor";

        /// <summary>Prioridad del proveedor de teleportación en la cola de transformaciones (la de la muestra de XRI).</summary>
        private const int TeleportationPriority = 20;

        /// <summary>Grados de cada giro por pasos del stick derecho (el valor por defecto de XRI 3.3.1, 2026-10-26).</summary>
        public const float SnapTurnDegrees = 45f;

        /// <summary>La acción del stick derecho que gira por pasos (la copia de las XRI Default Input Actions).</summary>
        public const string SnapTurnActionName = "XRI Right Locomotion/Snap Turn";

        /// <summary>El hijo de cada <c>&lt;Lado&gt;_NearFarInteractor</c> con la esfera trigger que frota (corrección 3).</summary>
        public const string HandTriggerName = "HandTrigger";

        /// <summary>Radio de la esfera de la mano: 5 cm, del tamaño de un puño, como pidió la auditoría (4–6 cm).</summary>
        public const float HandTriggerRadius = 0.05f;

        /// <summary>
        /// Capa de la esfera de la mano: <c>Ignore Raycast</c> (2, capa de Unity que existe en todo proyecto). Los triggers la
        /// siguen viendo (la matriz de colisiones no la excluye), y ningún <c>Physics.Raycast</c> con la máscara por defecto
        /// (el suelo del coach, el clic plano, la UI con oclusión 3D) choca con la mano.
        /// </summary>
        public const int HandTriggerLayer = 2;

        /// <summary>
        /// El prefab del rig. Si ya existe y está al día se devuelve tal cual (idempotente: regenerar el Menu no reescribe el
        /// prefab ni cambia su GUID); con <paramref name="rebuild"/>, o si el que hay es de antes del lote X2 (sin
        /// teleportación, ver <see cref="HasTeleportation"/>), se arma de nuevo y se guarda sobre el mismo fichero, que
        /// conserva su GUID. Lanza <see cref="InvalidOperationException"/> con un mensaje claro si falta el
        /// <c>.inputactions</c> del paquete o alguna de sus acciones.
        /// </summary>
        public static GameObject BuildRigPrefab(bool rebuild = false)
        {
            if (!rebuild)
            {
                var existing = AssetDatabase.LoadAssetAtPath<GameObject>(RigPrefabPath);
                if (existing != null && IsUpToDate(existing)) return existing;
            }

            var asset = LoadActionsAsset();
            var references = LoadActionReferences();

            var root = BuildRig(asset, references);
            try
            {
                var saved = PrefabUtility.SaveAsPrefabAsset(root, RigPrefabPath, out bool success);
                if (!success || saved == null)
                    throw new InvalidOperationException("No se pudo guardar el prefab del rig en " + RigPrefabPath + ".");
                return saved;
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        /// <summary>
        /// Para <c>-executeMethod XRLabs.MenuXRI.Editor.XriRigBuilder.RebuildFromCommandLine</c> (Unity en batch con
        /// <c>-projectPath</c>) y el menú <c>Tools/XRLabs/Regenerar rig XRI</c>: rehace el prefab del rig sobre el mismo fichero
        /// (conserva su GUID y los ids de los objetos que ya tenía) sin regenerar el Menu. Si falla, sale con código 1.
        /// </summary>
        [MenuItem("Tools/XRLabs/Regenerar rig XRI")]
        public static void RebuildFromCommandLine()
        {
            try
            {
                var rig = BuildRigPrefab(rebuild: true);
                Debug.Log("[MenuXRI] Rig regenerado en " + RigPrefabPath + " (al día: " + IsUpToDate(rig) + ").");
            }
            catch (Exception ex)
            {
                Debug.LogError("[MenuXRI] No se pudo regenerar el rig: " + ex);
                if (Application.isBatchMode) EditorApplication.Exit(1);
            }
        }

        /// <summary>
        /// Si el prefab del rig trae todo lo que arma este constructor hoy: la teleportación del lote X2
        /// (<see cref="HasTeleportation"/>), la esfera de frotar en las dos manos (<see cref="HasHandTriggers"/>) y el seguro
        /// del cambio de escena (<see cref="HasSceneGuard"/>). Uno de antes no pasa y <see cref="BuildRigPrefab"/> lo rehace.
        /// </summary>
        public static bool IsUpToDate(GameObject rig) =>
            HasTeleportation(rig) && HasHandTriggers(rig) && HasSceneGuard(rig) && HasHeadingAligner(rig) && HasSnapTurn(rig) && HasSnapTurnGuard(rig) && HasHandBusyBlocks(rig)
            && HasHaptics(rig) && HasInteractionFeedback(rig);

        // ── XR al día 2026-10-31 ──────────────────────────────────────────────
        // H1 del informe «OpenXR, Android XR y XRI al día»: el rig no tenía ningún HapticImpulsePlayer ni XRHapticsProvider, así
        // que FeedbackSystem.Haptics quedaba vacío y no vibraba nada. Ahora cada mando lleva un HapticImpulsePlayer (acción
        // «XRI <Lado>/Haptic Device»), su NearFarInteractor un SimpleHapticFeedback (apuntar suave, tomar claro, soltar breve,
        // cancelar) y su rayo de teletransporte otro (pulso breve al teletransportarse); la raíz, un XRHapticsProvider con los
        // dos players asignados (XRI 3.4+ ya no ordena por InstanceID: nada de buscarlos en la escena). P3/P4: la raíz lleva
        // también InteractionFeedback (realce y sonido) y un XRInputModalityManager cuyos grupos de mano son dos objetos vacíos
        // bajo Camera Offset (donde irá el rig de manos de la semana 4–5): los mandos NO van en sus huecos de mando, porque el
        // gestor los apagaría al rastrear manos y hoy son ellos los que leen el pellizco por <HandInteraction>/<MetaAimHand>,
        // y en el modo plano (sin dispositivos) los dejaría apagados.

        public const string LeftHandGroupName = "Grupo mano izquierda";
        public const string RightHandGroupName = "Grupo mano derecha";
        public const float HoverHapticAmplitude = 0.1f, HoverHapticSeconds = 0.03f;
        public const float SelectHapticAmplitude = 0.4f, SelectHapticSeconds = 0.08f;
        public const float ReleaseHapticAmplitude = 0.2f, ReleaseHapticSeconds = 0.05f;
        public const float CancelHapticAmplitude = 0.15f, CancelHapticSeconds = 0.05f;

        /// <summary>
        /// Si el rig vibra: cada <c>NearFarInteractor</c> tiene un <c>SimpleHapticFeedback</c> con hover y select encendidos y
        /// un <c>HapticImpulsePlayer</c> que lee la acción «Haptic Device» de su lado, y la raíz un <c>XRHapticsProvider</c>
        /// con exactamente esos dos players.
        /// </summary>
        public static bool HasHaptics(GameObject rig)
        {
            if (rig == null) return false;
            var interactors = rig.GetComponentsInChildren<NearFarInteractor>(true);
            if (interactors.Length != 2) return false;
            var players = new List<HapticImpulsePlayer>();
            foreach (var interactor in interactors)
            {
                var feedback = interactor.GetComponent<SimpleHapticFeedback>();
                if (feedback == null || feedback.hapticImpulsePlayer == null) return false;
                if (!feedback.playHoverEntered || !feedback.playSelectEntered || !feedback.playSelectExited) return false;
                var reference = feedback.hapticImpulsePlayer.hapticOutput?.inputActionReference;
                string side = interactor.handedness == InteractorHandedness.Left ? "Left" : "Right";
                if (reference == null || reference.action == null || reference.action.name != "Haptic Device"
                    || reference.action.actionMap == null || reference.action.actionMap.name != "XRI " + side) return false;
                players.Add(feedback.hapticImpulsePlayer);
            }
            var provider = rig.GetComponent<XRHapticsProvider>();
            if (provider == null) return false;
            using var so = new SerializedObject(provider);
            var list = so.FindProperty("players");
            if (list == null || list.arraySize != 2) return false;
            for (int i = 0; i < list.arraySize; i++)
                if (!players.Contains(list.GetArrayElementAtIndex(i).objectReferenceValue as HapticImpulsePlayer)) return false;
            return true;
        }

        /// <summary>
        /// Si la raíz trae el realce y sonido (<c>InteractionFeedback</c>) y el gestor de modalidad con los grupos de mano
        /// vacíos y sin mandos en sus huecos (ver el comentario de arriba).
        /// </summary>
        public static bool HasInteractionFeedback(GameObject rig)
        {
            if (rig == null || rig.GetComponent<InteractionFeedback>() == null) return false;
            var modality = rig.GetComponent<XRInputModalityManager>();
            return modality != null && modality.leftController == null && modality.rightController == null
                && modality.leftHand != null && modality.leftHand.name == LeftHandGroupName
                && modality.rightHand != null && modality.rightHand.name == RightHandGroupName
                && modality.leftHand.GetComponentInChildren<NearFarInteractor>(true) == null
                && modality.rightHand.GetComponentInChildren<NearFarInteractor>(true) == null;
        }

        private static HapticImpulsePlayer AddHapticPlayer(GameObject controller, string side, Dictionary<string, InputActionReference> references)
        {
            var player = controller.AddComponent<HapticImpulsePlayer>();
            player.hapticOutput = new XRInputHapticImpulseProvider(side + " Haptic", false, XRInputHapticImpulseProvider.InputSourceMode.InputActionReference)
            {
                inputActionReference = Need(references, "XRI " + side + "/Haptic Device"),
            };
            return player;
        }

        private static SimpleHapticFeedback AddHapticFeedback(GameObject interactorObject, IXRInteractor interactor, HapticImpulsePlayer player, bool hover)
        {
            var feedback = interactorObject.AddComponent<SimpleHapticFeedback>();
            feedback.hapticImpulsePlayer = player;
            feedback.SetInteractorSource(interactor);
            feedback.playHoverEntered = hover;
            feedback.hoverEnteredData = new HapticImpulseData { amplitude = HoverHapticAmplitude, duration = HoverHapticSeconds };
            feedback.playHoverExited = false;
            feedback.playHoverCanceled = false;
            feedback.allowHoverHapticsWhileSelecting = false;
            feedback.playSelectEntered = hover;
            feedback.selectEnteredData = new HapticImpulseData { amplitude = SelectHapticAmplitude, duration = SelectHapticSeconds };
            feedback.playSelectExited = true;
            feedback.selectExitedData = new HapticImpulseData { amplitude = ReleaseHapticAmplitude, duration = ReleaseHapticSeconds };
            feedback.playSelectCanceled = true;
            feedback.selectCanceledData = new HapticImpulseData { amplitude = CancelHapticAmplitude, duration = CancelHapticSeconds };
            return feedback;
        }

        private static void AddFeedbackAndModality(GameObject root, Transform offset, List<HapticImpulsePlayer> players)
        {
            var provider = root.AddComponent<XRHapticsProvider>();
            using (var so = new SerializedObject(provider))
            {
                var list = so.FindProperty("players");
                list.arraySize = players.Count;
                for (int i = 0; i < players.Count; i++) list.GetArrayElementAtIndex(i).objectReferenceValue = players[i];
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            root.AddComponent<InteractionFeedback>();

            var leftHand = new GameObject(LeftHandGroupName);
            leftHand.transform.SetParent(offset, false);
            var rightHand = new GameObject(RightHandGroupName);
            rightHand.transform.SetParent(offset, false);
            var modality = root.AddComponent<XRInputModalityManager>();
            modality.leftHand = leftHand;
            modality.rightHand = rightHand;
            modality.leftController = null;
            modality.rightController = null;
        }

        /// <summary>
        /// Si el rig ya trae el giro por pasos (2026-10-26): un único <c>SnapTurnProvider</c> en la raíz, de 45°, sin el giro de
        /// media vuelta (UX visor 2026-10-31), enlazado al mediador del rig, que lee solo la acción del stick derecho
        /// (<see cref="SnapTurnActionName"/>) y nada del izquierdo. Un prefab de antes no pasa y se rehace solo.
        /// </summary>
        public static bool HasSnapTurn(GameObject rig)
        {
            if (rig == null) return false;
            var providers = rig.GetComponentsInChildren<SnapTurnProvider>(true);
            if (providers.Length != 1) return false;
            var snap = providers[0];
            if (snap.gameObject != rig || snap.mediator == null || snap.mediator != rig.GetComponent<LocomotionMediator>()) return false;
            if (!Mathf.Approximately(snap.turnAmount, SnapTurnDegrees) || !snap.enableTurnLeftRight || snap.enableTurnAround) return false;   // UX visor 2026-10-31: sin media vuelta
            var right = snap.rightHandTurnInput.inputActionReference;
            return right != null && right.name == SnapTurnActionName && snap.leftHandTurnInput.inputActionReference == null;
        }

        /// <summary>Si la raíz del rig tiene el <c>RigHeadingAligner</c> (orientación al rumbo del inicio, 2026-10-25).</summary>
        public static bool HasHeadingAligner(GameObject rig) => rig != null && rig.GetComponent<RigHeadingAligner>() != null;

        // UX visor 2026-10-31 ------------------------------------------------------------------------------------------------

        /// <summary>El stick crudo de la mano del giro, sin zona muerta, que lee <see cref="SnapTurnGrabGuard"/>.</summary>
        public const string RightThumbstickActionName = "XRI Right/Thumbstick";

        /// <summary>
        /// Si el rig trae el seguro del giro (UX visor 2026-10-31, Documentation~/decisiones-ux-visor.md §1): un
        /// <see cref="SnapTurnGrabGuard"/> en la raíz enlazado al <c>SnapTurnProvider</c>, al interactor de la mano derecha (la
        /// del giro) y al stick derecho crudo, con el umbral de 0,75, y un HandBusyLocomotionBlock por mano. Un prefab de antes no pasa y se rehace solo.
        /// </summary>
        public static bool HasSnapTurnGuard(GameObject rig)
        {
            if (rig == null) return false;
            var guard = rig.GetComponent<SnapTurnGrabGuard>();
            if (guard == null || guard.SnapTurn == null || guard.HandInteractors == null || guard.HandInteractors.Length == 0) return false;
            foreach (var interactor in guard.HandInteractors)
                if (interactor == null || !interactor.name.StartsWith("Right", StringComparison.Ordinal)) return false;
            var stick = guard.StickInput != null ? guard.StickInput.inputActionReference : null;
            return stick != null && stick.name == RightThumbstickActionName
                && Mathf.Approximately(guard.TurnMagnitude, SnapTurnGrabGuard.DefaultTurnMagnitude);
        }

        private static void AddSnapTurnGuard(GameObject root, SnapTurnProvider snapTurn, Dictionary<string, InputActionReference> references)
        {
            var guard = root.AddComponent<SnapTurnGrabGuard>();
            guard.SnapTurn = snapTurn;
            var right = root.transform.Find(CameraOffsetName + "/" + RightControllerName);
            guard.HandInteractors = right != null ? right.GetComponentsInChildren<NearFarInteractor>(true) : new NearFarInteractor[0];
            guard.StickInput = new XRInputValueReader<Vector2>("Right Thumbstick")
            {
                inputActionReference = Need(references, RightThumbstickActionName),
            };
            guard.TurnMagnitude = SnapTurnGrabGuard.DefaultTurnMagnitude;
            guard.RearmMagnitude = SnapTurnGrabGuard.DefaultRearmMagnitude;

            // Mano ocupada, stick inerte: cada mando apaga su teletransporte mientras su interactor tiene algo seleccionado.
            foreach (var controllerName in new[] { LeftControllerName, RightControllerName })
            {
                var controller = root.transform.Find(CameraOffsetName + "/" + controllerName);
                if (controller == null) continue;
                var block = controller.gameObject.AddComponent<HandBusyLocomotionBlock>();
                block.Interactors = controller.GetComponentsInChildren<NearFarInteractor>(true);
                block.BlockWhileBusy = controller.GetComponents<TeleportModeActivator>();
            }
        }

        /// <summary>Si cada mando trae su <see cref="HandBusyLocomotionBlock"/> enlazado a su interactor y a su teletransporte.</summary>
        public static bool HasHandBusyBlocks(GameObject rig)
        {
            if (rig == null) return false;
            int found = 0;
            foreach (var block in rig.GetComponentsInChildren<HandBusyLocomotionBlock>(true))
                if (block.Interactors.Length > 0 && block.BlockWhileBusy.Length > 0 && block.BlockWhileBusy[0] is TeleportModeActivator) found++;
            return found == 2;
        }

        // fin UX visor 2026-10-31 --------------------------------------------------------------------------------------------

        /// <summary>
        /// Si cada uno de los dos <c>NearFarInteractor</c> del rig tiene su hijo <see cref="HandTriggerName"/> con una esfera
        /// trigger y un <c>Rigidbody</c> cinemático sin gravedad (corrección 3 de la auditoría del visor).
        /// </summary>
        public static bool HasHandTriggers(GameObject rig)
        {
            if (rig == null) return false;
            var interactors = rig.GetComponentsInChildren<NearFarInteractor>(true);
            if (interactors.Length != 2) return false;
            foreach (var interactor in interactors)
                if (FindHandTrigger(interactor) == null) return false;
            return true;
        }

        /// <summary>
        /// La esfera trigger de la mano de un interactor (hijo <see cref="HandTriggerName"/> con <c>SphereCollider</c> trigger y
        /// <c>Rigidbody</c> cinemático sin gravedad), o <c>null</c> si falta o no está así.
        /// </summary>
        public static SphereCollider FindHandTrigger(NearFarInteractor interactor)
        {
            if (interactor == null) return null;
            var child = interactor.transform.Find(HandTriggerName);
            if (child == null) return null;
            var sphere = child.GetComponent<SphereCollider>();
            var body = child.GetComponent<Rigidbody>();
            if (sphere == null || !sphere.isTrigger || body == null || !body.isKinematic || body.useGravity) return null;
            return sphere;
        }

        /// <summary>Si la raíz del rig tiene el <c>RigSceneGuard</c> junto a un <c>InputActionManager</c> (corrección 6).</summary>
        public static bool HasSceneGuard(GameObject rig) =>
            rig != null && rig.GetComponent<RigSceneGuard>() != null && rig.GetComponent<InputActionManager>() != null;

        /// <summary>
        /// Si el rig ya trae la teleportación del lote X2: un <c>TeleportationProvider</c>, un rayo de teleportación por mano y
        /// un <c>TeleportModeActivator</c> por mano enlazado a ese rayo y a las dos acciones. Un prefab armado antes de ese
        /// lote, o sin el activador, no pasa, y <see cref="BuildRigPrefab"/> lo rehace sin que nadie borre nada.
        /// </summary>
        public static bool HasTeleportation(GameObject rig)
        {
            if (rig == null || rig.GetComponentInChildren<TeleportationProvider>(true) == null) return false;
            int rays = 0;
            foreach (var ray in rig.GetComponentsInChildren<XRRayInteractor>(true))
                if (ray.name.EndsWith(TeleportInteractorSuffix, StringComparison.Ordinal)) rays++;
            if (rays != 2) return false;

            int activators = 0;
            foreach (var activator in rig.GetComponentsInChildren<TeleportModeActivator>(true))
                if (activator.TeleportInteractor != null && activator.TeleportMode != null && activator.TeleportModeCancel != null)
                    activators++;
            return activators == 2;
        }

        /// <summary>El <c>.inputactions</c> del paquete, o error claro si no está importado.</summary>
        public static InputActionAsset LoadActionsAsset()
        {
            var asset = AssetDatabase.LoadAssetAtPath<InputActionAsset>(InputActionsPath);
            if (asset == null)
                throw new InvalidOperationException("Falta " + InputActionsPath + " (o no se importó): es la copia de las XRI Default " +
                                                    "Input Actions que lleva el paquete.");
            return asset;
        }

        /// <summary>
        /// Las <c>InputActionReference</c> del <c>.inputactions</c> importado (sus sub-assets), por nombre
        /// <c>&lt;mapa&gt;/&lt;acción&gt;</c>, por ejemplo <c>XRI Head/Position</c>.
        /// </summary>
        public static Dictionary<string, InputActionReference> LoadActionReferences()
        {
            var references = new Dictionary<string, InputActionReference>();
            foreach (var sub in AssetDatabase.LoadAllAssetRepresentationsAtPath(InputActionsPath))
            {
                if (sub is not InputActionReference reference) continue;
                references[reference.name] = reference;
                var action = reference.action;
                if (action != null && action.actionMap != null)
                    references[action.actionMap.name + "/" + action.name] = reference;
            }
            return references;
        }

        private static InputActionReference Need(Dictionary<string, InputActionReference> references, string name)
        {
            if (references.TryGetValue(name, out var reference) && reference != null) return reference;
            throw new InvalidOperationException("La acción '" + name + "' no está en " + InputActionsPath +
                                                " (hay: " + string.Join(", ", references.Keys) + ").");
        }

        // ── El rig ────────────────────────────────────────────────────────────

        private static GameObject BuildRig(InputActionAsset asset, Dictionary<string, InputActionReference> references)
        {
            var root = new GameObject(RigRootName);

            var interactionManager = root.AddComponent<XRInteractionManager>();
            var actionManager = root.AddComponent<InputActionManager>();
            actionManager.actionAssets = new List<InputActionAsset> { asset };
            // El seguro del cambio de escena (corrección 6): repone acciones, UI y gestor si el rig anterior se apaga tarde.
            root.AddComponent<RigSceneGuard>();
            // El rumbo del inicio en el casco (cuarto recorrido, 2026-10-25): gira el origen para que la persona mire hacia la escena.
            root.AddComponent<RigHeadingAligner>();

            var offset = new GameObject(CameraOffsetName);
            offset.transform.SetParent(root.transform, false);

            var cameraObject = new GameObject(CameraName) { tag = "MainCamera" };
            cameraObject.transform.SetParent(offset.transform, false);
            var camera = cameraObject.AddComponent<Camera>();
            camera.nearClipPlane = 0.01f;
            camera.farClipPlane = 1000f;
            cameraObject.AddComponent<AudioListener>();
            var head = cameraObject.AddComponent<TrackedPoseDriver>();
            head.positionInput = new InputActionProperty(Need(references, "XRI Head/Position"));
            head.rotationInput = new InputActionProperty(Need(references, "XRI Head/Rotation"));
            head.trackingStateInput = new InputActionProperty(Need(references, "XRI Head/Tracking State"));

            // Suelo: el seguimiento da la altura real de la cabeza y el desplazamiento de la cámara se queda en 0.
            var origin = root.AddComponent<XROrigin>();
            origin.Origin = root;
            origin.CameraFloorOffsetObject = offset;
            origin.Camera = camera;
            origin.RequestedTrackingOriginMode = XROrigin.TrackingOriginMode.Floor;
            origin.CameraYOffset = 0f;

            // Teleportación: el proveedor necesita un mediador con su transformador de cuerpo en la jerarquía (XRI 3.3.1 lo
            // busca en el propio objeto y sus padres). El transformador se enlaza al XROrigin a mano: su Reset, al agregarlo
            // por código, buscaría el XROrigin de cualquier escena abierta.
            var mediator = root.AddComponent<LocomotionMediator>();   // agrega el XRBodyTransformer que exige
            var bodyTransformer = root.GetComponent<XRBodyTransformer>();
            bodyTransformer.xrOrigin = origin;
            var teleportation = root.AddComponent<TeleportationProvider>();
            teleportation.mediator = mediator;
            teleportation.transformationPriority = TeleportationPriority;

            // Giro por pasos (2026-10-26, «¿por qué tengo que dar una vuelta yo?»): el SnapTurnProvider de XRI bajo el mismo
            // mediador. Solo lee el stick derecho (izquierda/derecha = 45°, atrás = media vuelta); el izquierdo queda sin
            // acción para que no gire por accidente al apuntar el teletransporte. El stick adelante sigue siendo el arco: las
            // acciones Teleport Mode y Snap Turn usan sectores distintos del stick (adelante / lados y atrás).
            var snapTurn = root.AddComponent<SnapTurnProvider>();
            snapTurn.mediator = mediator;
            snapTurn.turnAmount = SnapTurnDegrees;
            snapTurn.enableTurnLeftRight = true;
            snapTurn.enableTurnAround = false;   // UX visor 2026-10-31: el stick atrás giraba 180° por accidente (decisiones-ux-visor.md §1)
            snapTurn.leftHandTurnInput = new XRInputValueReader<Vector2>("Left Hand Snap Turn");
            snapTurn.rightHandTurnInput = new XRInputValueReader<Vector2>("Right Hand Snap Turn")
            {
                inputActionReference = Need(references, SnapTurnActionName),
            };

            var players = new List<HapticImpulsePlayer>
            {
                BuildController(offset.transform, LeftControllerName, "Left", InteractorHandedness.Left, references, interactionManager),
                BuildController(offset.transform, RightControllerName, "Right", InteractorHandedness.Right, references, interactionManager),
            };
            AddSnapTurnGuard(root, snapTurn, references);   // UX visor 2026-10-31
            AddFeedbackAndModality(root, offset.transform, players);   // XR al día 2026-10-31
            return root;
        }

        // Un mando: el objeto que sigue la pose (TrackedPoseDriver) y, debajo, el interactor con sus casters, su controlador
        // de anclaje y su línea visual, como el prefab de la muestra (Left_NearFarInteractor), más la esfera que frota.
        // Interactores y grupo van enlazados al gestor del rig.
        private static HapticImpulsePlayer BuildController(Transform parent, string controllerName, string side, InteractorHandedness handedness,
            Dictionary<string, InputActionReference> references, XRInteractionManager interactionManager)
        {
            string pose = "XRI " + side;
            string interaction = "XRI " + side + " Interaction";

            var controller = new GameObject(controllerName);
            controller.transform.SetParent(parent, false);
            var driver = controller.AddComponent<TrackedPoseDriver>();
            driver.positionInput = new InputActionProperty(Need(references, pose + "/Position"));
            driver.rotationInput = new InputActionProperty(Need(references, pose + "/Rotation"));
            driver.trackingStateInput = new InputActionProperty(Need(references, pose + "/Tracking State"));

            var interactorObject = new GameObject(side + "_NearFarInteractor");
            interactorObject.transform.SetParent(controller.transform, false);
            var interactorTransform = interactorObject.transform;

            BuildHandTrigger(interactorTransform);

            var lineObject = new GameObject("LineVisual");
            lineObject.transform.SetParent(interactorTransform, false);
            var lineRenderer = lineObject.AddComponent<LineRenderer>();
            ConfigureLine(lineRenderer);

            var near = interactorObject.AddComponent<SphereInteractionCaster>();
            near.castOrigin = interactorTransform;
            near.enableStabilization = false;
            near.castRadius = 0.1f;

            var far = interactorObject.AddComponent<CurveInteractionCaster>();
            far.castOrigin = interactorTransform;
            far.enableStabilization = true;
            far.hitDetectionType = CurveInteractionCaster.HitDetectionType.ConeCast;
            far.castDistance = 10f;
            far.sphereCastRadius = 0.1f;
            far.coneCastAngle = 6f;
            far.targetNumCurveSegments = 1;

            var attach = interactorObject.AddComponent<InteractionAttachController>();
            attach.transformToFollow = interactorTransform;
            attach.useManipulationInput = true;
            attach.manipulationInput.inputActionReference = Need(references, interaction + "/Manipulation");

            var nearFar = interactorObject.AddComponent<NearFarInteractor>();
            nearFar.interactionManager = interactionManager;
            nearFar.handedness = handedness;
            nearFar.interactionAttachController = attach;
            nearFar.enableNearCasting = true;
            nearFar.nearInteractionCaster = near;
            nearFar.enableFarCasting = true;
            nearFar.farInteractionCaster = far;
            nearFar.enableUIInteraction = true;
            // Los rayos de agarre no ven la capa Teleport (2026-10-25): con el suelo teletransportable, agarrar apuntando al
            // suelo teletransportaría al soltar. Solo los rayos de teletransporte la ven.
            nearFar.interactionLayers = ~(int)XRLabs.Authoring.Editor.TeleportInteractionLayer.Mask;
            nearFar.blockUIOnInteractableSelection = true;

            // Los lectores de entrada leen las acciones del .inputactions del paquete (modo InputActionReference, el de la
            // muestra): sin esto no hay selección, activación ni clic sobre la UI.
            nearFar.selectInput.inputActionReferencePerformed = Need(references, interaction + "/Select");
            nearFar.selectInput.inputActionReferenceValue = Need(references, interaction + "/Select Value");
            nearFar.activateInput.inputActionReferencePerformed = Need(references, interaction + "/Activate");
            nearFar.activateInput.inputActionReferenceValue = Need(references, interaction + "/Activate Value");
            nearFar.uiPressInput.inputActionReferencePerformed = Need(references, interaction + "/UI Press");
            nearFar.uiPressInput.inputActionReferenceValue = Need(references, interaction + "/UI Press Value");
            nearFar.uiScrollInput.inputActionReference = Need(references, interaction + "/UI Scroll");

            // El rayo se estabiliza con la dirección del propio interactor.
            far.aimTarget = nearFar;

            var visual = lineObject.AddComponent<CurveVisualController>();
            visual.lineRenderer = lineRenderer;
            lineRenderer.useWorldSpace = true;   // el setter de lineRenderer lo apaga; el controlador lo vuelve a fijar al arrancar
            visual.curveInteractionDataProvider = nearFar;
            visual.overrideLineOrigin = true;
            visual.lineOriginTransform = interactorTransform;
            visual.customizeLinePropertiesForState = true;

            // Teleportación: el rayo de proyectil y el grupo que lo ordena después del NearFarInteractor (el de cerca/lejos
            // manda: si está seleccionando algo, el de teleportación no compite).
            var teleportRay = BuildTeleportInteractor(controller.transform, side, handedness, references);
            teleportRay.interactionManager = interactionManager;
            // El activador enciende el interactor solo mientras se mantiene Teleport Mode (el interactor queda desactivado en el prefab).
            var activator = controller.AddComponent<TeleportModeActivator>();
            activator.TeleportInteractor = teleportRay.gameObject;
            activator.TeleportMode = Need(references, "XRI " + side + " Locomotion/Teleport Mode");
            activator.TeleportModeCancel = Need(references, "XRI " + side + " Locomotion/Teleport Mode Cancel");
            teleportRay.gameObject.SetActive(false);

            // XR al día 2026-10-31 (H1): el player en el mando, y un SimpleHapticFeedback en el interactor de agarre y rayo y
            // otro en el de teletransporte (solo el pulso al soltar, que es cuando teletransporta).
            var hapticPlayer = AddHapticPlayer(controller, side, references);
            AddHapticFeedback(interactorObject, nearFar, hapticPlayer, hover: true);
            AddHapticFeedback(teleportRay.gameObject, teleportRay, hapticPlayer, hover: false);

            var group = controller.AddComponent<XRInteractionGroup>();
            group.interactionManager = interactionManager;
            group.startingGroupMembers = new List<Object> { nearFar, teleportRay };
            using (var so = new SerializedObject(group))
            {
                // El nombre del grupo no tiene setter público; la muestra lo llama «Left»/«Right».
                var groupName = so.FindProperty("m_GroupName");
                if (groupName != null) groupName.stringValue = side;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            return hapticPlayer;
        }

        // La esfera que frota (corrección 3 de la auditoría del visor): un hijo del interactor con un SphereCollider trigger de
        // 5 cm y un Rigidbody cinemático sin gravedad. Un trigger cinemático contra el trigger estático de una ScrubSurface sí
        // da OnTriggerEnter, y la superficie acepta la mano porque GetComponentInParent<IXRInteractor>() encuentra el
        // NearFarInteractor. Los casters de XRI ignoran triggers, así que la esfera no tapa el rayo ni el toque cercano; en la
        // capa Ignore Raycast tampoco la ven los Physics.Raycast con la máscara por defecto. La DropZone y la SnapZone la
        // ignoran (no cuelga de ningún InteractableBase).
        private static void BuildHandTrigger(Transform interactor)
        {
            var trigger = new GameObject(HandTriggerName) { layer = HandTriggerLayer };
            trigger.transform.SetParent(interactor, false);
            var body = trigger.AddComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
            var sphere = trigger.AddComponent<SphereCollider>();
            sphere.isTrigger = true;
            sphere.radius = HandTriggerRadius;
            sphere.center = Vector3.zero;
        }

        // El interactor de teleportación de una mano, como Teleport Interactor de la muestra de XRI 3.3.1 (rayo de proyectil,
        // línea propia, solo la capa Teleport, sin UI). Selecciona con la acción Teleport Mode, igual que la muestra: la
        // TeleportationArea teleporta al soltarla (OnSelectExited). No usa lo que no hace falta para teleportar: ni activación,
        // ni manipulación del ancla, ni hápticos.
        private static XRRayInteractor BuildTeleportInteractor(Transform parent, string side, InteractorHandedness handedness,
            Dictionary<string, InputActionReference> references)
        {
            string locomotion = "XRI " + side + " Locomotion";

            var teleportObject = new GameObject(side + TeleportInteractorSuffix);
            teleportObject.transform.SetParent(parent, false);
            var lineRenderer = teleportObject.AddComponent<LineRenderer>();
            ConfigureLine(lineRenderer);

            var ray = teleportObject.AddComponent<XRRayInteractor>();
            ray.handedness = handedness;
            ray.interactionLayers = XRLabs.Authoring.Editor.TeleportInteractionLayer.Mask;
            ray.rayOriginTransform = teleportObject.transform;
            ray.lineType = XRRayInteractor.LineType.ProjectileCurve;
            ray.velocity = 10f;
            ray.acceleration = 9.8f;
            ray.additionalGroundHeight = 0.1f;
            ray.additionalFlightTime = 0.5f;
            ray.sampleFrequency = 50;
            ray.maxRaycastDistance = 30f;
            ray.raycastTriggerInteraction = QueryTriggerInteraction.Ignore;
            ray.hitClosestOnly = true;
            ray.hoverToSelect = false;
            ray.enableUIInteraction = false;
            ray.manipulateAttachTransform = false;
            ray.selectActionTrigger = XRBaseInputInteractor.InputTriggerType.State;
            ray.selectInput.inputActionReferencePerformed = Need(references, locomotion + "/Teleport Mode");
            ray.selectInput.inputActionReferenceValue = Need(references, locomotion + "/Teleport Mode");

            var visual = teleportObject.AddComponent<XRInteractorLineVisual>();
            visual.lineWidth = 0.01f;
            visual.setLineColorGradient = true;
            visual.validColorGradient = SolidGradient(new Color(0.125f, 0.588f, 0.953f, 0.588f));
            visual.invalidColorGradient = SolidGradient(new Color(1f, 0f, 0f, 0.588f));   // el rojo de la muestra
            return ray;
        }

        private static Gradient SolidGradient(Color color)
        {
            var gradient = new Gradient();
            gradient.SetKeys(
                new[] { new GradientColorKey(new Color(color.r, color.g, color.b), 0f), new GradientColorKey(new Color(color.r, color.g, color.b), 1f) },
                new[] { new GradientAlphaKey(color.a, 0f), new GradientAlphaKey(color.a, 1f) });
            return gradient;
        }

        // La línea arranca apagada (la enciende el controlador visual cuando hay rayo) y con el material de línea por
        // defecto del motor, que es el que usa la muestra; sin material saldría rosa.
        private static void ConfigureLine(LineRenderer line)
        {
            line.enabled = false;
            line.useWorldSpace = true;
            line.widthCurve = AnimationCurve.Constant(0f, 1f, LineWidth);
            line.numCornerVertices = 8;
            line.numCapVertices = 8;
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            var material = AssetDatabase.GetBuiltinExtraResource<Material>("Default-Line.mat");
            if (material != null) line.sharedMaterial = material;
        }
    }
}
