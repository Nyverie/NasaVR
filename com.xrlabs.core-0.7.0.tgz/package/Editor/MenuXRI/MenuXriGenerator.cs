using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit.UI;
using XRLabs.Authoring.Editor;
using XRLabs.Platform;

namespace XRLabs.MenuXRI.Editor
{
    /// <summary>
    /// Genera el <c>Menu</c> sin el SDK de Meta (Documentation~/menu-xri.md §3, D23): copia <c>Runtime/Menu/Menu.unity</c> a
    /// <c>Runtime/MenuXRI/Menu.unity</c> y, sobre la copia, quita lo de Meta, pone el rig XRI del paquete, el módulo de
    /// entrada de UI de XRI y el modo plano. La escena y los prefabs de Meta no se tocan (D8): la fuente solo se abre y se
    /// copia, nunca se guarda. Es idempotente: si la escena destino existe se vuelve a generar desde la fuente y se
    /// sobrescribe, nunca se acumula. No usa red. Lo corre la sesión principal por lotes
    /// (<see cref="GenerateFromCommandLine"/>) cuando cambia <c>Menu.unity</c>, y un test comprueba que la copia commiteada
    /// está al día (<see cref="Fingerprint(Scene)"/>).
    /// </summary>
    public static class MenuXriGenerator
    {
        public const string DefaultSourceScenePath = "Packages/com.xrlabs.core/Runtime/Menu/Menu.unity";
        public const string DefaultTargetScenePath = "Packages/com.xrlabs.core/Runtime/MenuXRI/Menu.unity";

        /// <summary>Prefijo de los objetos que el SDK de Meta agrega a la escena (los Building Blocks).</summary>
        public const string BuildingBlockPrefix = "[BuildingBlock]";

        /// <summary>El objeto donde estaba el rig de Meta; el rig XRI se pone en su posición.</summary>
        public const string MetaCameraRigName = "[BuildingBlock] Camera Rig";

        public const string PlatformRootName = "[Platform]";
        public const string FlatRigName = "FlatRig";
        public const string FlatCameraName = "Camera";

        /// <summary>
        /// Tag de la cámara plana. Es MainCamera como la del rig plano documentado (platform-support.md): en modo plano el rig
        /// XR queda desactivado y esa cámara es la única activa, la que los canvas WorldSpace sin <c>worldCamera</c> usan como
        /// cámara de eventos (<c>Camera.main</c>) para que el ratón llegue a los botones del Menu. El rig plano arranca
        /// desactivado, así que en la escena guardada solo hay una cámara MainCamera activa.
        /// </summary>
        public const string FlatCameraTag = "MainCamera";

        /// <summary>Altura de ojos de la cámara plana sobre el rig, como la de <c>ScenePreparer</c>.</summary>
        public const float FlatEyeHeight = ScenePreparer.EyeHeight;

        // Los dos componentes de URP que el Menu trae y el anfitrión no tiene (menu-xri.md §5). Si el proyecto sí tiene URP no
        // están ausentes, y se quitan igual para que la escena generada sea la misma en cualquier proyecto.
        private static readonly string[] VendorTypeNames =
        {
            "UnityEngine.Rendering.Universal.UniversalAdditionalLightData",
            "UnityEngine.Rendering.Universal.UniversalAdditionalCameraData",
        };

        // ── Entradas ──────────────────────────────────────────────────────────

        [MenuItem("Tools/XRLabs/Generar Menu XRI")]
        public static void GenerateFromMenu()
        {
            var report = Generate();
            if (report.HasErrors) Debug.LogError("[MenuXRI] " + report.Summary());
            else Debug.Log("[MenuXRI] " + report.Summary());
        }

        /// <summary>
        /// Para <c>-executeMethod XRLabs.MenuXRI.Editor.MenuXriGenerator.GenerateFromCommandLine</c> (Unity en batch, con
        /// <c>-projectPath</c> explícito). Escribe el informe en el log y, si hubo errores, sale con código 1.
        /// </summary>
        public static void GenerateFromCommandLine()
        {
            var report = Generate();
            Debug.Log("[MenuXRI] " + report.Summary());
            if (!report.HasErrors) return;
            foreach (var error in report.Errors) Debug.LogError("[MenuXRI] " + error);
            EditorApplication.Exit(1);
        }

        /// <summary>
        /// Genera la escena del Menu sin Meta. Deja la escena generada abierta (en modo Single) y guardada. Precondición: la
        /// fuente existe; si no, error en el informe y no toca nada.
        /// </summary>
        public static ImportReport Generate(string sourceScenePath = DefaultSourceScenePath, string targetScenePath = DefaultTargetScenePath)
        {
            var report = new ImportReport();

            if (string.IsNullOrEmpty(sourceScenePath) || AssetDatabase.LoadAssetAtPath<SceneAsset>(sourceScenePath) == null)
            {
                report.Error("No existe la escena fuente " + sourceScenePath + ". No se tocó nada.");
                return report;
            }
            if (string.IsNullOrEmpty(targetScenePath) || !targetScenePath.EndsWith(".unity", StringComparison.Ordinal))
            {
                report.Error("La ruta de la escena destino no es un .unity: " + targetScenePath + ". No se tocó nada.");
                return report;
            }
            if (string.Equals(sourceScenePath, targetScenePath, StringComparison.OrdinalIgnoreCase))
            {
                report.Error("La escena destino no puede ser la fuente (la fuente no se toca). No se tocó nada.");
                return report;
            }

            // La persona puede tener abierta otra escena sin guardar: se le pregunta antes de cambiarla.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                report.Error("Se canceló: hay una escena abierta con cambios sin guardar y no se guardó.");
                return report;
            }

            try
            {
                bool rigExisted = AssetDatabase.LoadAssetAtPath<GameObject>(XriRigBuilder.RigPrefabPath) != null;
                var rigPrefab = XriRigBuilder.BuildRigPrefab();
                if (!rigExisted) report.Create(XriRigBuilder.RigPrefabPath + " (rig XRI armado por código)");

                var scene = CopySourceScene(sourceScenePath, targetScenePath, report);

                var rigPose = ReadMetaRigPose(scene, report);
                RemoveBuildingBlocks(scene, report);
                RemoveVendorComponents(scene, report);

                var rig = InstantiateRig(scene, rigPrefab, rigPose, report);
                EnsureUiInputModule(scene, report);
                AddTrackedDeviceRaycasters(scene, report);
                AddPlatformBootstrapper(scene, rig, rigPose, report);

                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                    report.Error("No se pudo guardar la escena " + targetScenePath + ".");
                AssetDatabase.SaveAssets();
            }
            catch (Exception ex)
            {
                report.Error("Generar el Menu XRI se interrumpió: " + ex);
            }
            return report;
        }

        /// <summary>El prefab del rig XRI (se crea por código si no existe). Ver <see cref="XriRigBuilder.BuildRigPrefab"/>.</summary>
        public static GameObject BuildRigPrefab(bool rebuild = false) => XriRigBuilder.BuildRigPrefab(rebuild);

        // ── 1. La copia ───────────────────────────────────────────────────────

        // Se abre la fuente solo para copiarla (SaveScene con saveAsCopy no la marca ni la guarda) y se abre la copia, que es
        // sobre la que se trabaja. Si el destino existe, se sobrescribe y conserva su GUID.
        private static Scene CopySourceScene(string source, string target, ImportReport report)
        {
            var sourceScene = EditorSceneManager.OpenScene(source, OpenSceneMode.Single);
            bool existed = AssetDatabase.LoadAssetAtPath<SceneAsset>(target) != null;

            EnsureFolder(Path.GetDirectoryName(target).Replace('\\', '/'));
            if (!EditorSceneManager.SaveScene(sourceScene, target, true))
                throw new IOException("No se pudo copiar " + source + " a " + target + ".");
            AssetDatabase.ImportAsset(target, ImportAssetOptions.ForceSynchronousImport);

            if (existed) report.Update(target + " (ya existía; se regeneró desde " + source + ")");
            else report.Create(target);
            return EditorSceneManager.OpenScene(target, OpenSceneMode.Single);
        }

        // ── 2. Dónde estaba el rig de Meta ────────────────────────────────────

        // Posición del rig de Meta y su giro sobre el eje vertical: el rig de suelo del XRI queda siempre derecho.
        private static Pose ReadMetaRigPose(Scene scene, ImportReport report)
        {
            var old = AllGameObjects(scene).FirstOrDefault(go => go.name == MetaCameraRigName);
            if (old == null)
            {
                report.Warn("No encontré '" + MetaCameraRigName + "' en la escena fuente: el rig XRI queda en el origen.");
                return new Pose(Vector3.zero, Quaternion.identity);
            }
            var yaw = Quaternion.Euler(0f, old.transform.eulerAngles.y, 0f);
            return new Pose(old.transform.position, yaw);
        }

        // ── 3. Quitar lo de Meta ──────────────────────────────────────────────

        private static void RemoveBuildingBlocks(Scene scene, ImportReport report)
        {
            var found = AllGameObjects(scene).Where(go => go.name.StartsWith(BuildingBlockPrefix, StringComparison.Ordinal)).ToList();
            foreach (var go in found)
                report.Delete(go.name);

            foreach (var go in found)
            {
                if (go == null) continue;   // ya se fue con su padre (el rig lleva dentro a los demás)
                if (PrefabUtility.IsPartOfPrefabInstance(go) && !PrefabUtility.IsOutermostPrefabInstanceRoot(go))
                {
                    var outermost = PrefabUtility.GetOutermostPrefabInstanceRoot(go);
                    PrefabUtility.UnpackPrefabInstance(outermost, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                    report.Update(outermost.name + " (desvinculada de su prefab para poder quitar '" + go.name + "')");
                }
                UnityEngine.Object.DestroyImmediate(go);
            }
        }

        // Todo componente cuyo script falta (los de Meta y los dos de URP en un proyecto sin esos paquetes) y, para que la
        // escena sea la misma en un proyecto que sí los tiene, los de Meta (Oculus.*, Meta.*) y los dos de URP aunque resuelvan.
        // Un componente de una instancia de prefab no se puede quitar de la instancia sin tocar el prefab: la instancia se
        // desvincula (Unpack) solo si la limpieza la necesita; los prefabs de los paneles no se tocan (D8).
        private static void RemoveVendorComponents(Scene scene, ImportReport report)
        {
            int removed = 0;
            var unpacked = new List<string>();

            foreach (var go in AllGameObjects(scene))
            {
                if (go == null) continue;
                if (!NeedsCleaning(go)) continue;

                if (PrefabUtility.IsPartOfPrefabInstance(go))
                {
                    var outermost = PrefabUtility.GetOutermostPrefabInstanceRoot(go);
                    if (outermost != null)
                    {
                        unpacked.Add(outermost.name);
                        PrefabUtility.UnpackPrefabInstance(outermost, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                    }
                }

                removed += GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);

                var components = go.GetComponents<Component>();
                for (int i = components.Length - 1; i >= 0; i--)   // los últimos dependen de los primeros
                {
                    var component = components[i];
                    if (component == null || !IsVendor(component)) continue;
                    UnityEngine.Object.DestroyImmediate(component);
                    removed++;
                }
            }

            if (unpacked.Count > 0)
                report.Update("Desvinculadas de su prefab para limpiarlas: " + string.Join(", ", unpacked.Distinct()));
            report.Delete(removed + " componentes de Meta o de URP (scripts ausentes incluidos)");

            // Lo que quede ausente es un fallo de la limpieza, no un aviso.
            int remaining = AllGameObjects(scene).Sum(go => GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(go));
            if (remaining > 0) report.Error("Quedan " + remaining + " componentes con el script ausente en la escena generada.");
        }

        private static bool NeedsCleaning(GameObject go)
        {
            if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(go) > 0) return true;
            return go.GetComponents<Component>().Any(c => c != null && IsVendor(c));
        }

        /// <summary>Si el componente es del SDK de Meta (<c>Oculus.*</c> o <c>Meta.*</c>) o uno de los dos de URP del Menu.</summary>
        public static bool IsVendor(Component component)
        {
            var type = component.GetType();
            var ns = type.Namespace ?? string.Empty;
            if (ns == "Oculus" || ns.StartsWith("Oculus.", StringComparison.Ordinal)) return true;
            if (ns == "Meta" || ns.StartsWith("Meta.", StringComparison.Ordinal)) return true;
            return Array.IndexOf(VendorTypeNames, type.FullName) >= 0;
        }

        // ── 4. Poner lo del XRI ───────────────────────────────────────────────

        private static GameObject InstantiateRig(Scene scene, GameObject rigPrefab, Pose pose, ImportReport report)
        {
            var rig = (GameObject)PrefabUtility.InstantiatePrefab(rigPrefab, scene);
            rig.transform.SetPositionAndRotation(pose.position, pose.rotation);
            report.Create(rig.name + " (instancia de " + XriRigBuilder.RigPrefabPath + " donde estaba el rig de Meta: " +
                          pose.position.ToString("F2") + ")");
            return rig;
        }

        // El EventSystem del Menu (PCM) solo tenía el módulo de Meta, ya quitado. XRUIInputModule atiende el rayo de los
        // mandos y también el ratón y el toque (el Editor en pantalla sigue funcionando). Con un módulo ya presente no se toca
        // nada, igual que UIFlowController.EnsureInputModule (D8).
        private static void EnsureUiInputModule(Scene scene, ImportReport report)
        {
            var eventSystems = AllComponents<EventSystem>(scene).ToList();
            if (eventSystems.Count == 0)
            {
                var go = new GameObject("EventSystem");
                SceneManager.MoveGameObjectToScene(go, scene);
                go.AddComponent<EventSystem>();
                go.AddComponent<XRUIInputModule>();
                report.Create("EventSystem con XRUIInputModule (la escena fuente no traía EventSystem)");
                return;
            }

            foreach (var eventSystem in eventSystems)
            {
                if (eventSystem.GetComponents<BaseInputModule>().Any(module => module != null))
                {
                    report.Warn("El EventSystem '" + eventSystem.name + "' ya tenía un módulo de entrada: no se agregó XRUIInputModule.");
                    continue;
                }
                eventSystem.gameObject.AddComponent<XRUIInputModule>();
                report.Create("XRUIInputModule en el EventSystem '" + eventSystem.name + "'");
            }
        }

        // Junto al GraphicRaycaster de uGUI (que atiende el ratón en pantalla), el de dispositivos rastreados, que atiende el
        // rayo y el toque de los mandos sobre los canvas en el mundo.
        private static void AddTrackedDeviceRaycasters(Scene scene, ImportReport report)
        {
            int added = 0;
            foreach (var canvas in AllComponents<Canvas>(scene))
            {
                if (!canvas.isRootCanvas || canvas.renderMode != RenderMode.WorldSpace) continue;
                if (canvas.GetComponent<TrackedDeviceGraphicRaycaster>() != null) continue;
                canvas.gameObject.AddComponent<TrackedDeviceGraphicRaycaster>();
                added++;
            }
            report.Create("TrackedDeviceGraphicRaycaster en " + added + " canvas WorldSpace");
        }

        // [Platform] con el PlatformBootstrapper (escribe sus campos privados con SerializedObject, como el Inspector, para no
        // tocar el runtime) y el rig plano, que arranca desactivado: el bootstrapper activa el que corresponde al arrancar.
        private static void AddPlatformBootstrapper(Scene scene, GameObject xrRig, Pose pose, ImportReport report)
        {
            var flatRig = new GameObject(FlatRigName);
            SceneManager.MoveGameObjectToScene(flatRig, scene);
            flatRig.transform.SetPositionAndRotation(pose.position, pose.rotation);

            var cameraObject = new GameObject(FlatCameraName) { tag = FlatCameraTag };
            cameraObject.transform.SetParent(flatRig.transform, false);
            cameraObject.transform.localPosition = Vector3.up * FlatEyeHeight;
            var camera = cameraObject.AddComponent<Camera>();
            camera.nearClipPlane = 0.01f;
            cameraObject.AddComponent<AudioListener>();
            cameraObject.AddComponent<FlatInteractionDriver>();
            flatRig.SetActive(false);

            var platform = new GameObject(PlatformRootName);
            SceneManager.MoveGameObjectToScene(platform, scene);
            var bootstrapper = platform.AddComponent<PlatformBootstrapper>();

            var so = new SerializedObject(bootstrapper);
            Prop(so, "xrRigRoot").objectReferenceValue = xrRig;
            Prop(so, "flatRigRoot").objectReferenceValue = flatRig;
            so.ApplyModifiedPropertiesWithoutUndo();

            report.Create(PlatformRootName + " con PlatformBootstrapper (xrRigRoot = " + xrRig.name + ", flatRigRoot = " + FlatRigName + ")");
            report.Create(FlatRigName + " con cámara y FlatInteractionDriver (desactivado hasta que el bootstrapper lo pida)");
        }

        // ── La huella (test 8) ────────────────────────────────────────────────

        /// <summary>
        /// La huella estructural de una escena: una línea por objeto, con su ruta en la jerarquía y los tipos de sus
        /// componentes (un script ausente figura como <c>&lt;missing&gt;</c>), ordenadas, más el recuento de objetos. No son
        /// bytes: no depende de IDs, posiciones ni del orden de los hermanos, y sí de que se agregue, quite o renombre un
        /// objeto o un componente. Sirve para comprobar que la copia commiteada sigue a <c>Menu.unity</c>.
        /// </summary>
        public static string Fingerprint(Scene scene)
        {
            var lines = new List<string>();
            foreach (var go in AllGameObjects(scene))
            {
                var types = go.GetComponents<Component>()
                    .Select(c => c == null ? "<missing>" : c.GetType().FullName)
                    .OrderBy(name => name, StringComparer.Ordinal);
                lines.Add(HierarchyPath(go.transform) + " [" + string.Join(",", types) + "]");
            }
            lines.Sort(StringComparer.Ordinal);
            return "objetos=" + lines.Count + "\n" + string.Join("\n", lines);
        }

        private static string HierarchyPath(Transform transform)
        {
            var parts = new List<string>();
            for (var t = transform; t != null; t = t.parent) parts.Add(t.name);
            parts.Reverse();
            return string.Join("/", parts);
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        // Todos los objetos de la escena, también los inactivos, con cada padre antes que sus hijos.
        private static List<GameObject> AllGameObjects(Scene scene)
        {
            var all = new List<GameObject>();
            foreach (var root in scene.GetRootGameObjects())
                foreach (var t in root.GetComponentsInChildren<Transform>(true))
                    all.Add(t.gameObject);
            return all;
        }

        private static IEnumerable<T> AllComponents<T>(Scene scene) where T : Component =>
            scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<T>(true));

        private static SerializedProperty Prop(SerializedObject so, string name) =>
            so.FindProperty(name) ?? throw new InvalidOperationException(
                $"{so.targetObject.GetType().Name} no tiene el campo serializado '{name}'.");

        private static void EnsureFolder(string folder)
        {
            if (string.IsNullOrEmpty(folder) || AssetDatabase.IsValidFolder(folder)) return;
            var parent = Path.GetDirectoryName(folder).Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) return;
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(folder));
        }
    }
}
