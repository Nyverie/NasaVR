using System.IO;
using UnityEditor;
using UnityEngine;
using XRLabs.Coach;

namespace XRLabs.Editor
{
    /// <summary>
    /// Genera el prefab HologramCoach (jerarquía, mallas procedurales y materiales) dentro del paquete.
    /// Es idempotente: reescribe los assets conservando sus GUID. También se puede ejecutar en batchmode:
    /// <c>-executeMethod XRLabs.Editor.HologramCoachPrefabEditor.Generate</c>.
    /// </summary>
    public static class HologramCoachPrefabEditor
    {
        public const string Folder = "Packages/com.xrlabs.core/Runtime/Coach/Hologram";
        public const string PrefabPath = Folder + "/HologramCoach.prefab";
        private const string MeshFolder = Folder + "/Meshes";
        private const string MaterialFolder = Folder + "/Materials";

        private const float DiscRadius = 0.24f;
        private const float DiscHeight = 1.7f;

        [MenuItem("Tools/XRLabs/Create Hologram Coach Prefab")]
        public static void Generate()
        {
            EnsureFolder(MeshFolder);
            EnsureFolder(MaterialFolder);

            var meshes = HologramCoachBuilder.CreateMeshes(DiscRadius, DiscHeight);
            var res = new HologramCoachBuilder.Resources
            {
                baseMesh = SaveMesh(meshes.baseMesh, "Holo_Base"),
                lensMesh = SaveMesh(meshes.lensMesh, "Holo_Lens"),
                coneMesh = SaveMesh(meshes.coneMesh, "Holo_Cone"),
                discMesh = SaveMesh(meshes.discMesh, "Holo_Disc"),
                ringMesh = SaveMesh(meshes.ringMesh, "Holo_Ring"),
                plateMesh = SaveMesh(meshes.plateMesh, "Holo_Plate"),
                barMesh = SaveMesh(meshes.barMesh, "Holo_PlateBar")
            };

            var lit = Shader.Find("Universal Render Pipeline/Lit");
            if (lit == null)
            {
                Debug.LogWarning("[HologramCoach] No se encontró 'Universal Render Pipeline/Lit': la base usará Standard. " +
                                 "Instalar URP (com.unity.render-pipelines.universal).");
                lit = Shader.Find("Standard");
            }

            res.baseMat = SaveMaterial("Holo_Base", lit, m => HologramCoachBuilder.ConfigureBase(m));
            res.lensMat = SaveGlow("Holo_Lens", HologramCoachBuilder.LensIntensity, true);
            res.coneMat = SaveMaterial("Holo_Cone", Require(HologramCoachBuilder.ShaderCone), null);
            res.discMat = SaveMaterial("Holo_Disc", Require(HologramCoachBuilder.ShaderDisc), null);
            res.ringMat = SaveGlow("Holo_Ring", HologramCoachBuilder.RingIntensity, true);
            res.waveMat = SaveGlow("Holo_Wave", HologramCoachBuilder.WaveIntensity, true);
            res.dotsMat = SaveMaterial("Holo_Dots", Require(HologramCoachBuilder.ShaderDots), null);
            res.plateMat = SaveGlow("Holo_Plate", 1f, false, new Color(0.03f, 0.08f, 0.09f, 0.85f));
            res.barMat = SaveGlow("Holo_PlateBar", HologramCoachBuilder.BarIntensity, true);

            var instance = HologramCoachBuilder.Build(res, "HologramCoach", DiscRadius, DiscHeight);
            try
            {
                var prefab = PrefabUtility.SaveAsPrefabAsset(instance.gameObject, PrefabPath);
                Debug.Log($"[HologramCoach] Prefab generado en {PrefabPath}", prefab);
            }
            finally
            {
                Object.DestroyImmediate(instance.gameObject);
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static Shader Require(string name)
        {
            var shader = Shader.Find(name);
            if (shader == null) throw new FileNotFoundException($"Shader '{name}' no encontrado: ¿compiló el paquete?");
            return shader;
        }

        private static Mesh SaveMesh(Mesh source, string name)
        {
            string path = $"{MeshFolder}/{name}.asset";
            var existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing == null)
            {
                source.name = name;
                AssetDatabase.CreateAsset(source, path);
                return source;
            }

            existing.Clear();
            EditorUtility.CopySerialized(source, existing);
            existing.name = name;
            Object.DestroyImmediate(source);
            EditorUtility.SetDirty(existing);
            return existing;
        }

        private static Material SaveMaterial(string name, Shader shader, System.Action<Material> configure)
        {
            string path = $"{MaterialFolder}/{name}.mat";
            var material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            configure?.Invoke(material);
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Material SaveGlow(string name, float intensity, bool additive, Color? fixedColor = null) =>
            SaveMaterial(name, Require(HologramCoachBuilder.ShaderGlow),
                m => HologramCoachBuilder.ConfigureGlow(m, intensity, additive, fixedColor));

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }
    }
}
