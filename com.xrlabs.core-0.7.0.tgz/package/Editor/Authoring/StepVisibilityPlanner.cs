using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using XRLabs.Core;
using XRLabs.Interactions;
using Object = UnityEngine.Object;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Calcula, desde el guion, qué pasos usa cada objeto y cada zona, y se lo escribe al <see cref="StepVisibilityController"/>
    /// de la raíz de la colocación (2026-10-26; Documentation~/autoria.md §12). Solo si la experiencia lo pide con
    /// <c>experiencia.visibilidadPorPaso</c>: sin la clave no añade nada, y si el componente estaba de una preparación
    /// anterior lo quita (D8). La parte que decide es pura (<see cref="Compute"/>); <see cref="Apply"/> solo la lleva a la escena.
    ///
    /// «Un paso usa un id» cuando el id aparece en: la condición (<c>objeto</c>, <c>objetos</c>, <c>zonas</c>, <c>opciones</c>,
    /// <c>herramienta</c>, las <c>reglas</c> de error de un llevar, los <c>equivocados</c> de un apuntar), en <c>activos</c> o
    /// en <c>senalar</c>. Además, un objeto <c>superficie</c> usado arrastra las <c>herramientas</c> con que se frota: sin ellas
    /// el paso no se podría hacer. La herramienta que carga una <c>fuente</c> no cuenta: es una plantilla, la pila la instancia.
    /// </summary>
    public static class StepVisibilityPlanner
    {
        /// <summary>El tramo de un id: primer y último paso que lo usan y todos los que lo usan, en el orden del guion.</summary>
        public sealed class Span
        {
            public string Id;
            public string FirstStepId;
            public string LastStepId;
            public readonly List<string> StepIds = new();
        }

        /// <summary>
        /// Los ids usados por algún paso, cada uno con su tramo. Un id que ningún paso usa no aparece. Función pura: no toca la escena.
        /// </summary>
        public static Dictionary<string, Span> Compute(GuionDocument guion)
        {
            var result = new Dictionary<string, Span>();
            if (guion?.Steps == null) return result;

            foreach (var step in guion.Steps)
            {
                if (step == null || string.IsNullOrEmpty(step.Id)) continue;
                foreach (var id in UsedIds(step, guion))
                {
                    if (!result.TryGetValue(id, out var span))
                        result[id] = span = new Span { Id = id, FirstStepId = step.Id };
                    span.LastStepId = step.Id;
                    span.StepIds.Add(step.Id);
                }
            }
            return result;
        }

        /// <summary>Los ids de objetos y zonas que usa un paso (sin repetidos, en orden de aparición).</summary>
        public static List<string> UsedIds(GuionDocument.StepEntry step, GuionDocument guion)
        {
            var ids = new List<string>();
            var seen = new HashSet<string>();
            void Add(string id)
            {
                if (!string.IsNullOrEmpty(id) && seen.Add(id)) ids.Add(id);
            }

            var c = step.Condition;
            if (c != null)
            {
                Add(c.ObjectId);
                foreach (var id in c.Objects ?? new List<string>()) Add(id);
                foreach (var id in c.Zones ?? new List<string>()) Add(id);
                foreach (var o in c.Options ?? new List<GuionDocument.ChoiceOptionEntry>()) Add(o?.ObjectId);
                Add(c.Tool);
                foreach (var r in c.Rules ?? new List<GuionDocument.DropRuleEntry>())
                {
                    Add(r?.ObjectId);
                    Add(r?.ZoneId);
                }
                foreach (var w in c.WrongTargets ?? new List<GuionDocument.WrongTargetEntry>()) Add(w?.ObjectId);
            }
            foreach (var id in step.ActiveTargetIds ?? new List<string>()) Add(id);
            Add(step.PointAtTargetId);

            // Las herramientas con que se frota una superficie usada: un nivel, sin recursión.
            int direct = ids.Count;
            for (int i = 0; i < direct; i++)
            {
                var entry = guion.FindObject(ids[i]);
                if (entry == null || entry.Kind != "superficie") continue;
                foreach (var tool in entry.Tools ?? new List<string>()) Add(tool);
            }
            return ids;
        }

        /// <summary>
        /// Pone (o quita) el <see cref="StepVisibilityController"/> en <paramref name="root"/> según la opción del guion y le
        /// escribe una entrada por cada <c>Objeto_*</c> y <c>Zona_*</c> hijo que tenga algo que gestionar. Idempotente.
        /// </summary>
        public static void Apply(Transform root, GuionDocument guion, ImportReport report)
        {
            if (root == null || guion == null) return;

            var controller = root.GetComponent<StepVisibilityController>();
            if (guion.Experience == null || !guion.Experience.VisibilityByStep)
            {
                if (controller == null) return;
                Object.DestroyImmediate(controller);
                report?.Update(root.name + ": se quitó StepVisibilityController (la experiencia ya no pide visibilidadPorPaso)");
                return;
            }

            bool created = controller == null;
            if (created) controller = root.gameObject.AddComponent<StepVisibilityController>();

            var plan = Compute(guion);
            var rows = new List<Row>();
            for (int i = 0; i < root.childCount; i++)
            {
                var child = root.GetChild(i);
                bool isZone;
                string id;
                if (child.name.StartsWith(ColocacionImporter.ObjectPrefix, System.StringComparison.Ordinal))
                {
                    isZone = false;
                    id = child.name.Substring(ColocacionImporter.ObjectPrefix.Length);
                }
                else if (child.name.StartsWith(ColocacionImporter.ZonePrefix, System.StringComparison.Ordinal))
                {
                    isZone = true;
                    id = child.name.Substring(ColocacionImporter.ZonePrefix.Length);
                }
                else continue;

                plan.TryGetValue(id, out var span);
                bool hasDrawing = child.Find(ColocacionImporter.LabelName) != null || child.Find(ColocacionImporter.ZoneFloorName) != null;
                // Una zona solo cambia su dibujo; un objeto sin tramo y sin etiqueta no tiene nada que gestionar.
                if (isZone ? !hasDrawing : span == null && !hasDrawing) continue;
                rows.Add(new Row { Id = id, Target = child, IsZone = isZone, Span = span });
            }

            WriteEntries(controller, rows, FindStepSystem(root));
            int withSpan = rows.FindAll(r => r.Span != null).Count;
            string text = $"{root.name}: StepVisibilityController con {rows.Count} entradas ({withSpan} con tramo; el resto, siempre a la vista)";
            if (created) report?.Create(text);
            else report?.Update(text);
        }

        private struct Row
        {
            public string Id;
            public Transform Target;
            public bool IsZone;
            public Span Span;
        }

        private static StepSystem FindStepSystem(Transform root)
        {
            var scene = root.gameObject.scene;
            if (!scene.IsValid() || !scene.isLoaded) return null;
            foreach (var go in scene.GetRootGameObjects())
            {
                var found = go.GetComponentInChildren<StepSystem>(true);
                if (found != null) return found;
            }
            return null;
        }

        // Escritura como lo haría el Inspector (D8: el runtime no cambia).
        private static void WriteEntries(StepVisibilityController controller, List<Row> rows, StepSystem stepSystem)
        {
            using var so = new SerializedObject(controller);
            if (stepSystem != null) so.FindProperty("stepSystem").objectReferenceValue = stepSystem;

            var list = so.FindProperty("entries");
            list.arraySize = rows.Count;
            for (int i = 0; i < rows.Count; i++)
            {
                var row = rows[i];
                var e = list.GetArrayElementAtIndex(i);
                e.FindPropertyRelative("id").stringValue = row.Id;
                e.FindPropertyRelative("target").objectReferenceValue = row.Target;
                e.FindPropertyRelative("isZone").boolValue = row.IsZone;
                e.FindPropertyRelative("firstStepId").stringValue = row.Span?.FirstStepId ?? string.Empty;
                e.FindPropertyRelative("lastStepId").stringValue = row.Span?.LastStepId ?? string.Empty;
                var labels = e.FindPropertyRelative("labelStepIds");
                int count = row.Span?.StepIds.Count ?? 0;
                labels.arraySize = count;
                for (int k = 0; k < count; k++)
                    labels.GetArrayElementAtIndex(k).stringValue = row.Span.StepIds[k];
            }
            so.ApplyModifiedPropertiesWithoutUndo();
        }
    }
}
