using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// La disposición del entorno de una muestra (2026-10-25): <c>Samples~/&lt;muestra&gt;/Entorno/entorno.json</c>, un fichero
    /// pequeño que dice qué FBX del arte van en la escena, dónde (posición, giro y escala de la raíz del FBX tal como los dejó
    /// el artista), con qué material, qué colliders se pisan y qué prefabs envoltorio (<c>modelos</c>) se arman para los
    /// objetos del guion. Sin el fichero, <see cref="EntornoBuilder"/> arma el telón de siempre (la muestra del INIA, D8).
    /// Sin nada de Unity: la lectura y las comprobaciones son funciones puras (<see cref="Problems"/>); las clases de datos no
    /// validan por sí mismas. Convención en Documentation~/autoria.md §11.
    /// </summary>
    public sealed class EntornoDisposicion
    {
        public const string FileName = "entorno.json";
        public const string SchemaId = "xrlabs.entorno/0.1";

        [JsonProperty("esquema")] public string Schema;
        [JsonProperty("descripcion")] public string Description;
        [JsonProperty("raiz")] public RootInfo Root = new();
        [JsonProperty("suelo")] public GroundInfo Ground;
        [JsonProperty("materiales")] public Dictionary<string, MaterialEntry> Materials = new();
        [JsonProperty("piezas")] public List<PieceEntry> Pieces = new();
        [JsonProperty("colliders")] public List<ColliderEntry> Colliders = new();
        [JsonProperty("modelos")] public List<ModelEntry> Models = new();
        [JsonProperty("omitidos")] public List<OmittedEntry> Omitted = new();

        /// <summary>Lee <c>entorno.json</c> de la carpeta Entorno de la muestra; null si no hay fichero (telón de siempre).</summary>
        public static EntornoDisposicion TryLoad(string entornoFolder)
        {
            string path = Path.Combine(entornoFolder ?? string.Empty, FileName);
            return File.Exists(path) ? Parse(File.ReadAllText(path)) : null;
        }

        /// <summary>Parsea el texto. Lanza <see cref="JsonException"/> si el JSON está mal formado. Las listas nunca quedan null.</summary>
        public static EntornoDisposicion Parse(string json)
        {
            var doc = JsonConvert.DeserializeObject<EntornoDisposicion>(json) ?? new EntornoDisposicion();
            doc.Root ??= new RootInfo();
            doc.Materials ??= new Dictionary<string, MaterialEntry>();
            doc.Pieces ??= new List<PieceEntry>();
            doc.Colliders ??= new List<ColliderEntry>();
            doc.Models ??= new List<ModelEntry>();
            doc.Omitted ??= new List<OmittedEntry>();
            return doc;
        }

        /// <summary>
        /// Lo que está mal en la disposición contra la carpeta Entorno: un FBX que no existe, un material que no se declara o
        /// cuya textura falta, un nombre de pieza repetido dentro de su grupo, un vector con la longitud equivocada, un FBX de
        /// la carpeta que nadie usa ni declara omitido. Vacío = está bien.
        /// </summary>
        public List<string> Problems(string entornoFolder)
        {
            var problems = new List<string>();
            string modelsDir = Path.Combine(entornoFolder, "Modelos");
            var used = new HashSet<string>();

            if (Schema != SchemaId) problems.Add($"esquema: se esperaba '{SchemaId}' y trae '{Schema}'.");
            if (Root.Pos == null || Root.Pos.Length != 3) problems.Add("raiz.pos: tiene que ser [x, y, z].");

            var names = new HashSet<string>();
            foreach (var piece in Pieces)
            {
                string who = $"piezas[{piece?.Name}]";
                if (piece == null || string.IsNullOrEmpty(piece.Name)) { problems.Add("Hay una pieza sin nombre."); continue; }
                if (!names.Add((piece.Group ?? string.Empty) + "/" + piece.Name)) problems.Add($"{who}: el nombre está repetido en su grupo.");
                CheckFbx(piece.Fbx, who, modelsDir, used, problems);
                CheckMaterial(piece.Material, who, problems);
                if (piece.Pos == null || piece.Pos.Length != 3) problems.Add($"{who}.pos: tiene que ser [x, y, z].");
                if (piece.Rot == null || piece.Rot.Length != 4) problems.Add($"{who}.rot: tiene que ser el cuaternión [x, y, z, w].");
                if (piece.Scale != null && piece.Scale.Length != 3) problems.Add($"{who}.escala: tiene que ser [x, y, z] o faltar.");
            }

            var modelNames = new HashSet<string>();
            foreach (var model in Models)
            {
                string who = $"modelos[{model?.Model}]";
                if (model == null || string.IsNullOrEmpty(model.Model)) { problems.Add("Hay un modelo sin nombre."); continue; }
                if (!modelNames.Add(model.Model)) problems.Add($"{who}: el nombre está repetido.");
                CheckFbx(model.Fbx, who, modelsDir, used, problems);
                CheckMaterial(model.Material, who, problems);
            }

            foreach (var omitted in Omitted)
                if (omitted != null && !string.IsNullOrEmpty(omitted.Fbx)) used.Add(omitted.Fbx);

            foreach (var collider in Colliders)
            {
                string who = $"colliders[{collider?.Name}]";
                if (collider == null || collider.Center == null || collider.Center.Length != 3 || collider.Size == null || collider.Size.Length != 3)
                    problems.Add($"{who}: centro y tamano tienen que ser [x, y, z].");
            }

            foreach (var pair in Materials)
            {
                CheckTexture(pair.Value?.Base, $"materiales[{pair.Key}].base", entornoFolder, problems);
                CheckTexture(pair.Value?.Normal, $"materiales[{pair.Key}].normal", entornoFolder, problems);
                CheckTexture(pair.Value?.MetalSmoothness, $"materiales[{pair.Key}].metalSuavidad", entornoFolder, problems);
            }

            if (Directory.Exists(modelsDir))
                foreach (var file in Directory.GetFiles(modelsDir, "*.fbx"))
                {
                    string stem = Path.GetFileNameWithoutExtension(file);
                    if (!used.Contains(stem)) problems.Add($"Modelos/{stem}.fbx: ninguna pieza ni modelo lo usa y no está en 'omitidos'.");
                }
            return problems;
        }

        private void CheckFbx(string fbx, string who, string modelsDir, HashSet<string> used, List<string> problems)
        {
            if (string.IsNullOrEmpty(fbx)) { problems.Add($"{who}.fbx: falta."); return; }
            used.Add(fbx);
            if (!File.Exists(Path.Combine(modelsDir, fbx + ".fbx"))) problems.Add($"{who}.fbx: no existe Modelos/{fbx}.fbx.");
        }

        private void CheckMaterial(string material, string who, List<string> problems)
        {
            if (string.IsNullOrEmpty(material) || !Materials.ContainsKey(material))
                problems.Add($"{who}.material: '{material}' no está en 'materiales'.");
        }

        private static void CheckTexture(string relative, string who, string entornoFolder, List<string> problems)
        {
            if (string.IsNullOrEmpty(relative)) return;
            if (!File.Exists(Path.Combine(entornoFolder, relative))) problems.Add($"{who}: no existe {relative}.");
        }

        public sealed class RootInfo
        {
            /// <summary>Desplazamiento (m, ejes de Unity) del prefab del artista a la escena.</summary>
            [JsonProperty("pos")] public float[] Pos = { 0f, 0f, 0f };
        }

        public sealed class GroundInfo
        {
            [JsonProperty("centro")] public float[] Center = { 0f, 0f, 0f };
            [JsonProperty("tamano")] public float[] Size = { 20f, 20f };
            [JsonProperty("color")] public float[] Color = { 0.42f, 0.33f, 0.22f };
            [JsonProperty("suavidad")] public float Smoothness = 0.1f;
        }

        public sealed class MaterialEntry
        {
            /// <summary>Textura de color (ruta relativa a la carpeta Entorno).</summary>
            [JsonProperty("base")] public string Base;
            [JsonProperty("normal")] public string Normal;
            /// <summary>Metálico en R y suavidad en A (lo que lee URP Lit), ya empaquetados.</summary>
            [JsonProperty("metalSuavidad")] public string MetalSmoothness;
            /// <summary>Color plano cuando no hay textura de color.</summary>
            [JsonProperty("color")] public float[] Color;
            [JsonProperty("suavidad")] public float? Smoothness;
            /// <summary>true = se ve por las dos caras (una plancha de calamina que se mira desde abajo no desaparece).</summary>
            [JsonProperty("dobleCara")] public bool DoubleSided;
        }

        public sealed class PieceEntry
        {
            [JsonProperty("nombre")] public string Name;
            [JsonProperty("grupo")] public string Group;
            [JsonProperty("fbx")] public string Fbx;
            [JsonProperty("material")] public string Material;
            /// <summary>Posición local de la raíz del FBX, en el espacio del prefab del artista.</summary>
            [JsonProperty("pos")] public float[] Pos;
            /// <summary>Cuaternión [x, y, z, w] de la raíz del FBX.</summary>
            [JsonProperty("rot")] public float[] Rot;
            /// <summary>Escala local de la raíz del FBX; sin ella, la que trae el FBX (100 en los de este arte).</summary>
            [JsonProperty("escala")] public float[] Scale;
        }

        public sealed class ColliderEntry
        {
            [JsonProperty("nombre")] public string Name;
            [JsonProperty("centro")] public float[] Center;
            [JsonProperty("tamano")] public float[] Size;
        }

        public sealed class ModelEntry
        {
            /// <summary>El <c>modelo</c> del guion: <c>Assets/Experiencias/&lt;id&gt;/Modelos/&lt;modelo&gt;.prefab</c>.</summary>
            [JsonProperty("modelo")] public string Model;
            [JsonProperty("fbx")] public string Fbx;
            [JsonProperty("material")] public string Material;
            /// <summary>Escala uniforme opcional del hijo Ajuste (por defecto 1: el tamaño del artista).</summary>
            [JsonProperty("escala")] public float? Scale;
        }

        public sealed class OmittedEntry
        {
            [JsonProperty("fbx")] public string Fbx;
            [JsonProperty("motivo")] public string Reason;
        }
    }
}
