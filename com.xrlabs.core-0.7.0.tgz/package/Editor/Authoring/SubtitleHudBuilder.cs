using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit.UI;
using XRLabs.Core;
using XRLabs.Platform;
using XRLabs.Simulations;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// El HUD mínimo de la escena preparada (2026-10-17, tras el primer recorrido de la muestra de compostaje en el Mac):
    /// una raíz <c>[HUD]</c> con un canvas de pantalla y el <see cref="SubtitlePanel"/> del paquete. Sin voces horneadas el
    /// coach «habla» con duración estimada, y sin este panel no se ve ni se oye nada de lo que dice: la escena parecía
    /// muerta. Es la misma construcción que <c>Editor/CoachDemoSetupEditor.BuildUi</c>, sin la checklist. Idempotente: si
    /// la raíz ya trae un SubtitlePanel, no se reconstruye (la persona puede haberlo movido o recoloreado; solo pasa a los
    /// tamaños del visor si conserva los de antes del 2026-10-25). También pone el
    /// botón «Comenzar» de los pasos manuales (<see cref="ManualStepButton"/>), el panel de desarrollo
    /// (<see cref="DevStepPanel"/>) y el EventSystem que los botones necesitan.
    /// </summary>
    public static class SubtitleHudBuilder
    {
        public const string RootName = "[HUD]";
        public const string CanvasName = "Canvas";
        public const string PanelName = "Subtitulo";

        /// <summary>La tecla que salta la frase en curso: Intro, no Espacio, que es «Comenzar» en los pasos manuales.</summary>
        public const KeyCode SkipKey = KeyCode.Return;

        public const string ButtonName = "Comenzar";
        public const string EventSystemName = "EventSystem";
        public const string DevPanelName = "PanelDesarrollo";
        /// <summary>
        /// La ayuda de mandos (cuarto recorrido del visor, 2026-10-25 23:50: «no sabía cómo teletransportarme, apreté todos los
        /// botones»): una línea fija sobre el subtítulo, en todas las builds, con lo que hace cada mando.
        /// </summary>
        public const string ControlsHelpName = "AyudaMandos";
        public const string ControlsHelpText =
            "Stick adelante y soltar: moverte · Stick derecho a los lados: girar · Gatillo lateral: agarrar · Gatillo: pulsar · B: completar paso · Y: saltar frase";
        public const float ControlsHelpMinSize = 18f;
        public const float ControlsHelpMaxSize = 28f;

        // Tamaños para el visor (2026-10-25, primera corrida en un Quest 3: «las letras del HUD están tan grandes y pegadas
        // que no entiendo qué es cada cosa»). Están en píxeles del canvas de referencia (1920 × 1080); en el visor el canvas
        // mide HudPlacement.DefaultWorldWidth metros de ancho.
        // Segunda tanda en el Quest 3 (2026-10-25, tarde): con 16–24 px el cuerpo medía 1–1,4 cm a 1,6 m (medio grado: «la
        // interfaz está muy lejos de mi vista, no veo bien»). Ahora el cuerpo mide 2–2,9 cm y el HUD está a 1,3 m
        // (HudPlacement.DefaultDistance): alrededor de 1° de alto, el mínimo cómodo para leer en un visor.
        public const float SubtitleBodyMinSize = 36f;
        public const float SubtitleBodyMaxSize = 50f;
        public const float SpeakerSize = 36f;
        public const float ButtonTextSize = 44f;
        public const float DevStatusSize = 30f;
        public const float DevNextSize = 26f;
        public const float DevButtonTextSize = 24f;
        public const float DevHintSize = 20f;

        // Los tamaños de antes (2026-10-17). Un HUD que todavía los trae se pasa a los del visor al volver a preparar; si la
        // persona los cambió, no coinciden y se respetan.
        private const float LegacyBodyMinSize = 20f;
        private const float LegacyBodyMaxSize = 32f;
        private const float LegacySpeakerSize = 26f;
        private const float LegacyButtonTextSize = 36f;
        private const float LegacyWorldWidth = 1.4f;
        private const float LegacyDrop = 0.25f;
        // Los del mediodía del 2026-10-25 (primera tanda en el Quest 3), que resultaron chicos: también se pasan a los nuevos.
        private const float LegacyVisorBodyMinSize = 16f;
        private const float LegacyVisorBodyMaxSize = 24f;
        private const float LegacyVisorSpeakerSize = 20f;
        private const float LegacyVisorButtonTextSize = 28f;
        private const float LegacyDistance = 1.6f;

        /// <summary>
        /// Devuelve true si creó la raíz; false si ya estaba. Cada parte se busca y solo se crea si falta: el panel de
        /// subtítulos, el botón «Comenzar» de los pasos manuales y el panel de desarrollo (los dos siempre reenlazados al
        /// StepSystem) y el EventSystem sin el que ningún botón recibe el clic. Un HUD que conserva los tamaños de antes del
        /// 2026-10-25 pasa a los del visor.
        /// </summary>
        public static bool Ensure(Scene scene, StepSystem steps, out GameObject root)
        {
            root = null;
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.name != RootName) continue;
                root = go;
                break;
            }

            bool created = root == null;
            if (created)
            {
                root = new GameObject(RootName);
                SceneManager.MoveGameObjectToScene(root, scene);
            }

            var canvas = EnsureCanvas(root);
            var subtitle = root.GetComponentInChildren<SubtitlePanel>(true);
            if (subtitle == null) BuildSubtitle(canvas.transform);
            else UpgradeSubtitle(subtitle);
            EnsureButton(canvas.transform, steps);
            EnsureDevPanel(canvas.transform, steps);
            EnsureControlsHelp(canvas.transform);
            EnsureUxVisor(canvas.transform, steps);   // UX visor 2026-10-31
            if (UsesTimeAdvance(steps)) EnsureCurtain(canvas.transform, steps); // 0.3 lote 2
            SyncIndicatorPanel(canvas.transform, steps); // 0.3 lote 4: solo si el guion declara indicadores
            EnsureWorldReady(canvas);
            EnsureEventSystem(root);

            EditorUtility.SetDirty(root);
            return created;
        }

        /// <summary>
        /// La línea de ayuda de mandos, justo encima del cuadro del subtítulo (que va de 0,04 a 0,30 del alto): fija, no se
        /// apaga con el subtítulo ni depende de que la build sea de desarrollo. Si ya estaba, solo se le repone el texto.
        /// </summary>
        public static TextMeshProUGUI EnsureControlsHelp(Transform canvas)
        {
            var existing = canvas.Find(ControlsHelpName);
            GameObject box = existing != null
                ? existing.gameObject
                : Box(ControlsHelpName, canvas, new Vector2(0.15f, 0.305f), new Vector2(0.85f, 0.36f), new Color(0.05f, 0.1f, 0.12f, 0.75f));
            box.GetComponent<Image>().raycastTarget = false;   // no tapa el rayo de los mandos
            var text = box.GetComponentInChildren<TextMeshProUGUI>(true);
            if (text == null)
            {
                text = Text("Texto", box.transform, new Vector2(0.02f, 0.05f), new Vector2(0.98f, 0.95f), ControlsHelpMaxSize, FontStyles.Normal);
                text.alignment = TextAlignmentOptions.Center;
                text.enableAutoSizing = true;
                text.fontSizeMin = ControlsHelpMinSize;
                text.fontSizeMax = ControlsHelpMaxSize;
                text.color = new Color(0.92f, 0.96f, 0.96f, 1f);
            }
            text.text = ControlsHelpText;
            return text;
        }

        // UX visor 2026-10-31 ─────────────────────────────────────────────
        // Documentation~/decisiones-ux-visor.md §4: el botón «¿Qué hago?» a la izquierda del subtítulo (solo en pasos
        // interactivos) y la ayuda de mandos con el control del paso en curso delante de la línea fija (dos líneas: el cuadro
        // crece hasta 0,40 del alto).

        public const string WhatToDoName = "QueHago";
        public static readonly Vector2 WhatToDoMin = new Vector2(0.01f, 0.05f);
        public static readonly Vector2 WhatToDoMax = new Vector2(0.14f, 0.17f);

        public static void EnsureUxVisor(Transform canvas, StepSystem steps)
        {
            var help = canvas.Find(ControlsHelpName);
            if (help != null && help.TryGetComponent<RectTransform>(out var helpRect))
            {
                helpRect.anchorMin = new Vector2(0.15f, 0.305f);
                helpRect.anchorMax = new Vector2(0.85f, 0.40f);
                var text = help.GetComponentInChildren<TextMeshProUGUI>(true);
                if (text != null)
                {
                    var hint = text.GetComponent<StepControlsHint>();
                    if (hint == null) hint = text.gameObject.AddComponent<StepControlsHint>();
                    hint.Steps = steps;
                    hint.BaseText = ControlsHelpText;
                    EditorUtility.SetDirty(hint);
                }
            }

            var existing = canvas.Find(WhatToDoName);
            GameObject go;
            if (existing != null) go = existing.gameObject;
            else
            {
                go = Box(WhatToDoName, canvas, WhatToDoMin, WhatToDoMax, new Color(0.98f, 0.78f, 0.18f, 1f));
                go.AddComponent<Button>();
                go.AddComponent<CanvasGroup>();
                var label = Text("Texto", go.transform, Vector2.zero, Vector2.one, ButtonTextSize, FontStyles.Bold);
                label.alignment = TextAlignmentOptions.Center;
                label.enableAutoSizing = true;
                label.fontSizeMin = 24f;
                label.fontSizeMax = ButtonTextSize;
                label.color = new Color(0.08f, 0.08f, 0.08f, 1f);
                label.text = WhatToDoButton.Label;
            }
            var button = go.GetComponent<WhatToDoButton>();
            if (button == null) button = go.AddComponent<WhatToDoButton>();
            button.Steps = steps;
            var so = new SerializedObject(button);
            so.FindProperty("group").objectReferenceValue = go.GetComponent<CanvasGroup>();
            so.ApplyModifiedPropertiesWithoutUndo();
        }
        // fin UX visor 2026-10-31

        private static Canvas EnsureCanvas(GameObject root)
        {
            var existing = root.GetComponentInChildren<Canvas>(true);
            if (existing != null) return existing;

            var canvasGo = new GameObject(CanvasName, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.transform.SetParent(root.transform, false);
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            return canvas;
        }

        // El botón de los pasos manuales, a la derecha del subtítulo. La frase del storyboard dice «pulsa Comenzar».
        private static void EnsureButton(Transform canvas, StepSystem steps)
        {
            var manual = canvas.GetComponentInChildren<ManualStepButton>(true);
            if (manual == null)
            {
                var go = Box(ButtonName, canvas, new Vector2(0.78f, 0.05f), new Vector2(0.97f, 0.15f), new Color(0.16f, 0.76f, 0.78f, 1f));
                var button = go.AddComponent<Button>();
                go.AddComponent<CanvasGroup>();
                var text = Text("Texto", go.transform, Vector2.zero, Vector2.one, ButtonTextSize, FontStyles.Bold);
                text.alignment = TextAlignmentOptions.Center;
                text.color = new Color(0.02f, 0.08f, 0.1f, 1f);
                text.text = ButtonName;
                manual = go.AddComponent<ManualStepButton>();
                var wired = new SerializedObject(manual);
                wired.FindProperty("button").objectReferenceValue = button;
                wired.FindProperty("label").objectReferenceValue = text;
                wired.FindProperty("labelText").stringValue = ButtonName;
                wired.ApplyModifiedPropertiesWithoutUndo();
            }
            // El botón se oculta con su CanvasGroup (nunca apagando el objeto, o su Start no corre): se garantiza y enlaza.
            if (!manual.TryGetComponent<CanvasGroup>(out var group)) group = manual.gameObject.AddComponent<CanvasGroup>();
            var so = new SerializedObject(manual);
            so.FindProperty("stepSystem").objectReferenceValue = steps;
            so.FindProperty("group").objectReferenceValue = group;
            so.ApplyModifiedPropertiesWithoutUndo();
            if (so.FindProperty("label").objectReferenceValue is TMP_Text label)
            {
                UpgradeSize(label, LegacyButtonTextSize, ButtonTextSize);
                UpgradeSize(label, LegacyVisorButtonTextSize, ButtonTextSize);
            }
        }

        /// <summary>
        /// El panel de desarrollo (2026-10-25, pedido del dueño desde el Quest 3: saltar frases y pasos y saber dónde está,
        /// como con el SimDebugHUD del Editor, que es IMGUI y no existe en el visor). Arriba a la izquierda: el paso en curso
        /// y el siguiente, cuatro botones (anterior, saltar frase, completar paso, siguiente) y los atajos B/Y. Idempotente:
        /// si el canvas ya trae un <see cref="DevStepPanel"/> no se reconstruye; solo se reenlaza al StepSystem.
        /// </summary>
        public static DevStepPanel EnsureDevPanel(Transform canvas, StepSystem steps)
        {
            var panel = canvas.GetComponentInChildren<DevStepPanel>(true);
            if (panel == null) panel = BuildDevPanel(canvas);
            var so = new SerializedObject(panel);
            so.FindProperty("stepSystem").objectReferenceValue = steps;
            // Se oculta con su CanvasGroup (fuera de desarrollo), nunca apagando el objeto.
            var group = so.FindProperty("group");
            if (group.objectReferenceValue == null)
            {
                if (!panel.TryGetComponent<CanvasGroup>(out var canvasGroup)) canvasGroup = panel.gameObject.AddComponent<CanvasGroup>();
                group.objectReferenceValue = canvasGroup;
            }
            so.ApplyModifiedPropertiesWithoutUndo();
            return panel;
        }

        private static DevStepPanel BuildDevPanel(Transform canvas)
        {
            var go = Box(DevPanelName, canvas, new Vector2(0.02f, 0.76f), new Vector2(0.48f, 0.98f), new Color(0.03f, 0.06f, 0.08f, 0.72f));
            var group = go.AddComponent<CanvasGroup>();
            var status = Text("Estado", go.transform, new Vector2(0.03f, 0.70f), new Vector2(0.97f, 0.96f), DevStatusSize, FontStyles.Bold);
            status.color = Color.white;
            status.overflowMode = TextOverflowModes.Ellipsis;
            var next = Text("Siguiente", go.transform, new Vector2(0.03f, 0.52f), new Vector2(0.97f, 0.70f), DevNextSize, FontStyles.Normal);
            next.color = new Color(0.75f, 0.86f, 0.88f, 1f);
            next.overflowMode = TextOverflowModes.Ellipsis;
            var previous = DevButton("Anterior", go.transform, 0, DevStepPanel.PreviousLabel);
            var skip = DevButton("SaltarFrase", go.transform, 1, DevStepPanel.SkipLineLabel);
            var complete = DevButton("CompletarPaso", go.transform, 2, DevStepPanel.CompleteStepLabel);
            var following = DevButton("SiguientePaso", go.transform, 3, DevStepPanel.NextLabel);
            var hint = Text("Atajos", go.transform, new Vector2(0.03f, 0.03f), new Vector2(0.97f, 0.17f), DevHintSize, FontStyles.Italic);
            hint.color = new Color(0.75f, 0.86f, 0.88f, 1f);
            hint.text = DevStepPanel.ShortcutsHint;

            var panel = go.AddComponent<DevStepPanel>();
            var so = new SerializedObject(panel);
            so.FindProperty("group").objectReferenceValue = group;
            so.FindProperty("statusText").objectReferenceValue = status;
            so.FindProperty("nextText").objectReferenceValue = next;
            so.FindProperty("skipLineButton").objectReferenceValue = skip;
            so.FindProperty("completeStepButton").objectReferenceValue = complete;
            so.FindProperty("previousButton").objectReferenceValue = previous;
            so.FindProperty("nextButton").objectReferenceValue = following;
            so.ApplyModifiedPropertiesWithoutUndo();
            return panel;
        }

        // Cuatro botones en fila, del mismo ancho, con 0,02 de separación.
        private static Button DevButton(string name, Transform panel, int slot, string label)
        {
            const float left = 0.02f, gap = 0.02f, width = (1f - 2f * left - 3f * gap) / 4f;
            float x = left + slot * (width + gap);
            var go = Box(name, panel, new Vector2(x, 0.21f), new Vector2(x + width, 0.48f), new Color(0.12f, 0.36f, 0.4f, 1f));
            var button = go.AddComponent<Button>();
            button.targetGraphic = go.GetComponent<Image>();
            var text = Text("Texto", go.transform, Vector2.zero, Vector2.one, DevButtonTextSize, FontStyles.Bold);
            text.alignment = TextAlignmentOptions.Center;
            text.color = Color.white;
            text.text = label;
            return button;
        }

        // Lote del visor (2026-10-17): el mismo HUD sirve en pantalla y en el visor. HudPlacement lo pasa al mundo cuando hay
        // visor y el TrackedDeviceGraphicRaycaster deja que el rayo de los mandos pulse sus botones (en pantalla no estorba).
        // 2026-10-25: un HudPlacement que conserva el ancho y la caída de antes (1,4 m y 0,25 m) pasa a los del visor.
        private static void EnsureWorldReady(Canvas canvas)
        {
            var placement = canvas.GetComponent<HudPlacement>();
            if (placement == null) canvas.gameObject.AddComponent<HudPlacement>();
            else
            {
                var so = new SerializedObject(placement);
                var width = so.FindProperty("worldWidth");
                if (Mathf.Approximately(width.floatValue, LegacyWorldWidth)) width.floatValue = HudPlacement.DefaultWorldWidth;
                var drop = so.FindProperty("drop");
                if (Mathf.Approximately(drop.floatValue, LegacyDrop)) drop.floatValue = HudPlacement.DefaultDrop;
                var dist = so.FindProperty("distance");
                if (Mathf.Approximately(dist.floatValue, LegacyDistance)) dist.floatValue = HudPlacement.DefaultDistance;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            if (canvas.GetComponent<TrackedDeviceGraphicRaycaster>() == null) canvas.gameObject.AddComponent<TrackedDeviceGraphicRaycaster>();
        }

        // Sin EventSystem ningún Button recibe el clic. El módulo es XRUIInputModule, que atiende el rayo de los mandos y
        // también el ratón y el toque (como en el Menu XRI, D23); si el HUD traía el módulo del Input System de la primera
        // versión, se cambia.
        private static void EnsureEventSystem(GameObject root)
        {
            var existing = Object.FindAnyObjectByType<EventSystem>(FindObjectsInactive.Include);
            if (existing == null)
            {
                var go = new GameObject(EventSystemName, typeof(EventSystem), typeof(XRUIInputModule));
                go.transform.SetParent(root.transform, false);
                return;
            }
            var legacy = existing.GetComponent<InputSystemUIInputModule>();
            if (legacy != null && existing.GetComponent<XRUIInputModule>() == null)
            {
                Object.DestroyImmediate(legacy);
                existing.gameObject.AddComponent<XRUIInputModule>();
            }
        }

        private static void BuildSubtitle(Transform canvasTransform)
        {
            // 2026-10-17: las frases del storyboard son párrafos; el cuadro va de 0,04 a 0,26 y el texto se autoajusta
            // para no salirse (el primer recorrido mostró la última línea fuera del cuadro). 2026-10-25: entre 16 y 24 y
            // el nombre a 20, porque en el visor se veían enormes (constantes de arriba).
            var panel = Box(PanelName, canvasTransform, new Vector2(0.15f, 0.04f), new Vector2(0.85f, 0.30f), new Color(0.05f, 0.1f, 0.12f, 0.85f));
            var accent = Box("Acento", panel.transform, new Vector2(0f, 0f), new Vector2(0.008f, 1f), new Color(0.16f, 0.76f, 0.78f, 1f));
            var speaker = Text("Quien", panel.transform, new Vector2(0.03f, 0.78f), new Vector2(0.97f, 0.96f), SpeakerSize, FontStyles.Bold);
            var body = Text("Texto", panel.transform, new Vector2(0.03f, 0.06f), new Vector2(0.97f, 0.78f), SubtitleBodyMaxSize, FontStyles.Normal);
            body.enableAutoSizing = true;
            body.fontSizeMin = SubtitleBodyMinSize;
            body.fontSizeMax = SubtitleBodyMaxSize;
            var group = panel.AddComponent<CanvasGroup>();
            var subtitle = panel.AddComponent<SubtitlePanel>();

            var so = new SerializedObject(subtitle);
            so.FindProperty("canvasGroup").objectReferenceValue = group;
            so.FindProperty("bodyText").objectReferenceValue = body;
            so.FindProperty("speakerText").objectReferenceValue = speaker;
            so.FindProperty("accentGraphic").objectReferenceValue = accent.GetComponent<Image>();
            so.FindProperty("skipKey").intValue = (int)SkipKey;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // Un SubtitlePanel que ya estaba no se reconstruye (la persona puede haberlo movido o recoloreado), pero si sus
        // textos conservan los tamaños de antes del 2026-10-25 pasan a los del visor, y sus textos dejan de tapar el rayo.
        private static void UpgradeSubtitle(SubtitlePanel subtitle)
        {
            var so = new SerializedObject(subtitle);
            if (so.FindProperty("bodyText").objectReferenceValue is TMP_Text body)
            {
                bool legacy17 = Mathf.Approximately(body.fontSizeMin, LegacyBodyMinSize) && Mathf.Approximately(body.fontSizeMax, LegacyBodyMaxSize);
                bool legacy25 = Mathf.Approximately(body.fontSizeMin, LegacyVisorBodyMinSize) && Mathf.Approximately(body.fontSizeMax, LegacyVisorBodyMaxSize);
                if (body.enableAutoSizing && (legacy17 || legacy25))
                {
                    body.fontSizeMin = SubtitleBodyMinSize;
                    body.fontSizeMax = SubtitleBodyMaxSize;
                    body.fontSize = SubtitleBodyMaxSize;
                }
                body.raycastTarget = false;
                EditorUtility.SetDirty(body);
            }
            if (so.FindProperty("speakerText").objectReferenceValue is TMP_Text speaker)
            {
                UpgradeSize(speaker, LegacySpeakerSize, SpeakerSize);
                UpgradeSize(speaker, LegacyVisorSpeakerSize, SpeakerSize);
            }
        }

        // ── 0.3 lote 2: cortinilla de 'avanzar' (contrato-0.3.md §2.3) ─────────────────────────────

        public const string CurtainName = "Cortinilla";
        public const float CurtainLabelSize = 64f;

        /// <summary>True si la secuencia del StepSystem tiene algún paso 'avanzar' (solo entonces se pone la cortinilla).</summary>
        public static bool UsesTimeAdvance(StepSystem steps)
        {
            var seq = steps != null ? steps.Sequence : null;
            if (seq == null || seq.steps == null) return false;
            foreach (var step in seq.steps)
                if (step != null && step.IsTimeAdvance) return true;
            return false;
        }

        /// <summary>
        /// La cortinilla negra a pantalla completa con la etiqueta al centro, la última del canvas para quedar por encima de
        /// todo. Idempotente: si el canvas ya trae una <see cref="TimeAdvanceCurtain"/>, solo se reenlaza al StepSystem.
        /// </summary>
        public static TimeAdvanceCurtain EnsureCurtain(Transform canvas, StepSystem steps)
        {
            var curtain = canvas.GetComponentInChildren<TimeAdvanceCurtain>(true);
            if (curtain == null)
            {
                var go = Box(CurtainName, canvas, Vector2.zero, Vector2.one, Color.black);
                go.GetComponent<Image>().raycastTarget = false;
                var group = go.AddComponent<CanvasGroup>();
                group.alpha = 0f;
                group.blocksRaycasts = false;
                group.interactable = false;
                var text = Text("Etiqueta", go.transform, new Vector2(0.1f, 0.4f), new Vector2(0.9f, 0.6f), CurtainLabelSize, FontStyles.Bold);
                text.alignment = TextAlignmentOptions.Center;
                text.color = Color.white;
                curtain = go.AddComponent<TimeAdvanceCurtain>();
                var wired = new SerializedObject(curtain);
                wired.FindProperty("group").objectReferenceValue = group;
                wired.FindProperty("label").objectReferenceValue = text;
                wired.ApplyModifiedPropertiesWithoutUndo();
            }
            curtain.transform.SetAsLastSibling();
            var so = new SerializedObject(curtain);
            so.FindProperty("stepSystem").objectReferenceValue = steps;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(curtain);
            return curtain;
        }

        #region 0.3 lote 4: panel de indicadores (contrato-0.3.md §2.9)

        public const string IndicatorPanelName = "Indicadores";
        /// <summary>Tamaño de los valores: el del nombre del subtítulo (36), legible en el visor a 1,3 m.</summary>
        public const float IndicatorTextMaxSize = SpeakerSize;
        public const float IndicatorTextMinSize = 28f;

        /// <summary>True si la secuencia del StepSystem declara algún indicador.</summary>
        public static bool UsesIndicators(StepSystem steps)
        {
            var seq = steps != null ? steps.Sequence : null;
            return seq != null && seq.indicators != null && seq.indicators.Count > 0;
        }

        /// <summary>
        /// Pone el panel de indicadores si la secuencia los declara (y lo reenlaza al StepSystem) y lo quita si ya no:
        /// idempotente. Arriba a la derecha del canvas, libre del panel de desarrollo (arriba a la izquierda), del subtítulo
        /// y del botón (abajo); en el visor el canvas entero es el HUD de 1,1 m a 1,3 m, así que queda a la vista.
        /// </summary>
        public static IndicatorPanel SyncIndicatorPanel(Transform canvas, StepSystem steps)
        {
            var panel = canvas.GetComponentInChildren<IndicatorPanel>(true);
            if (!UsesIndicators(steps))
            {
                if (panel != null) Object.DestroyImmediate(panel.gameObject);
                return null;
            }

            if (panel == null)
            {
                var go = Box(IndicatorPanelName, canvas, new Vector2(0.70f, 0.66f), new Vector2(0.98f, 0.97f), new Color(0.05f, 0.1f, 0.12f, 0.85f));
                go.GetComponent<Image>().raycastTarget = false;
                Box("Acento", go.transform, new Vector2(0f, 0f), new Vector2(0.012f, 1f), new Color(0.16f, 0.76f, 0.78f, 1f))
                    .GetComponent<Image>().raycastTarget = false;
                var group = go.AddComponent<CanvasGroup>();
                group.blocksRaycasts = false;
                group.interactable = false;
                var text = Text("Valores", go.transform, new Vector2(0.05f, 0.05f), new Vector2(0.97f, 0.95f), IndicatorTextMaxSize, FontStyles.Normal);
                text.enableAutoSizing = true;
                text.fontSizeMin = IndicatorTextMinSize;
                text.fontSizeMax = IndicatorTextMaxSize;
                text.alignment = TextAlignmentOptions.TopLeft;
                text.richText = true;
                text.color = Color.white;
                panel = go.AddComponent<IndicatorPanel>();
                var wired = new SerializedObject(panel);
                wired.FindProperty("group").objectReferenceValue = group;
                wired.FindProperty("valuesText").objectReferenceValue = text;
                wired.ApplyModifiedPropertiesWithoutUndo();
            }
            var so = new SerializedObject(panel);
            so.FindProperty("stepSystem").objectReferenceValue = steps;
            so.ApplyModifiedPropertiesWithoutUndo();
            var curtain = canvas.GetComponentInChildren<TimeAdvanceCurtain>(true);
            if (curtain != null) curtain.transform.SetAsLastSibling();   // la cortinilla, siempre por encima de todo
            EditorUtility.SetDirty(panel);
            return panel;
        }

        #endregion

        private static void UpgradeSize(TMP_Text text, float legacy, float size)
        {
            if (!text.enableAutoSizing && Mathf.Approximately(text.fontSize, legacy)) text.fontSize = size;
            text.raycastTarget = false;
            EditorUtility.SetDirty(text);
        }

        private static GameObject Box(string name, Transform parent, Vector2 min, Vector2 max, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            Anchor(go.GetComponent<RectTransform>(), min, max);
            go.GetComponent<Image>().color = color;
            return go;
        }

        private static TextMeshProUGUI Text(string name, Transform parent, Vector2 min, Vector2 max, float size, FontStyles style)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            Anchor(go.GetComponent<RectTransform>(), min, max);
            var text = go.GetComponent<TextMeshProUGUI>();
            text.fontSize = size;
            text.fontStyle = style;
            text.textWrappingMode = TextWrappingModes.Normal;
            text.text = string.Empty;
            text.raycastTarget = false;   // los textos no tapan el rayo de los mandos: solo los botones lo reciben
            return text;
        }

        private static void Anchor(RectTransform rect, Vector2 min, Vector2 max)
        {
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }
    }
}
