using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// El guion de una experiencia tal como lo escribe la persona (xrlabs.guion/0.1 y 0.2): pasos, condiciones, frases del
    /// coach por idioma, objetos y secciones. Sin nada de Unity. Lectura humana en Documentation~/autoria.md §3; el
    /// esquema formal en Schema/guion.schema.json. Las claves JSON van en español porque las lee quien escribe; las
    /// propiedades C# en inglés, como el resto del paquete. Clase de datos: no valida (eso es GuionValidator).
    /// </summary>
    public sealed class GuionDocument
    {
        /// <summary>La versión 0.1 (la de la experiencia cero). Sigue siendo válida: los validadores aceptan 0.1 y 0.2.</summary>
        public const string SchemaId = "xrlabs.guion/0.1";

        /// <summary>La versión 0.2 (lote A3, Documentation~/contrato-0.2.md): añade llevar, frotar, mantener, apuntar y elegir por objeto.</summary>
        public const string SchemaId02 = "xrlabs.guion/0.2";

        [JsonProperty("esquema")] public string Schema;
        [JsonProperty("experiencia")] public ExperienceInfo Experience = new();
        [JsonProperty("coach")] public CoachInfo Coach = new();
        [JsonProperty("lineas")] public Dictionary<string, LineEntry> Lines = new();
        [JsonProperty("objetos")] public List<ObjectEntry> Objects = new();
        [JsonProperty("secciones")] public List<SectionEntry> Sections = new();
        [JsonProperty("pasos")] public List<StepEntry> Steps = new();

        // 0.3 lotes 1 y 2 (contrato-0.3.md §2.1): la versión 0.3 y el estado de la escena. Una sola declaración de
        // 'estado' para los dos lotes (StateVarEntry, al final): de texto con 'valores' o numérica con 'inicial'.
        /// <summary>La versión 0.3 (Documentation~/contrato-0.3.md): estado, guardas, efectos, tiempo simulado, grupos y lo demás.</summary>
        public const string SchemaId03 = "xrlabs.guion/0.3";
        /// <summary>Variables de estado por nombre, en el orden del fichero. Null o vacío: la experiencia no usa estado (quien lo lee comprueba).</summary>
        [JsonProperty("estado")] public Dictionary<string, StateVarEntry> State;
        #region 0.3 lote 3: grupos y bloques (contrato-0.3.md §2.4)

        /// <summary>Pasos reutilizables: nombre → lista de pasos (o grupos). Los usa un grupo con <c>bloque</c>; GuionExpander los desenrolla.</summary>
        [JsonProperty("bloques")] public Dictionary<string, List<StepEntry>> Blocks;

        /// <summary>Claves de primer nivel que esta clase no declara (las de otros lotes): se conservan al desenrollar.</summary>
        [JsonExtensionData] public IDictionary<string, JToken> Extra;

        #endregion

        /// <summary>Lee y parsea el fichero. Lanza si no existe o si el JSON no es válido.</summary>
        public static GuionDocument Load(string path) => Parse(File.ReadAllText(path));

        /// <summary>Parsea el texto. Lanza <see cref="JsonException"/> si el JSON está mal formado.</summary>
        public static GuionDocument Parse(string json)
        {
            var doc = JsonConvert.DeserializeObject<GuionDocument>(json, Settings) ?? new GuionDocument();
            doc.Experience ??= new ExperienceInfo();
            doc.Coach ??= new CoachInfo();
            doc.Lines ??= new Dictionary<string, LineEntry>();
            doc.Objects ??= new List<ObjectEntry>();
            doc.Sections ??= new List<SectionEntry>();
            doc.Steps ??= new List<StepEntry>();
            return doc;
        }

        /// <summary>El objeto del guion con ese id, o null.</summary>
        public ObjectEntry FindObject(string id)
        {
            if (string.IsNullOrEmpty(id) || Objects == null) return null;
            foreach (var o in Objects)
                if (o != null && o.Id == id) return o;
            return null;
        }

        /// <summary>El paso con ese id, o null.</summary>
        public StepEntry FindStep(string id)
        {
            if (string.IsNullOrEmpty(id) || Steps == null) return null;
            foreach (var s in Steps)
                if (s != null && s.Id == id) return s;
            return null;
        }

        private static readonly JsonSerializerSettings Settings = new()
        {
            MissingMemberHandling = MissingMemberHandling.Ignore,
            NullValueHandling = NullValueHandling.Include
        };

        public sealed class ExperienceInfo
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("titulo")] public string Title;
            [JsonProperty("descripcion")] public string Description;
            [JsonProperty("escena")] public string SceneName;
            [JsonProperty("clave")] public string Key;
            [JsonProperty("idHeredado")] public int? LegacyId;
            /// <summary>"guiado" | "evaluacion".</summary>
            [JsonProperty("modo")] public string Mode;
            /// <summary>"es" y/o "en". Vacío = ["es"].</summary>
            [JsonProperty("idiomas")] public List<string> Languages = new();
            /// <summary>
            /// Opcional (por defecto false). Verdadero si la experiencia muestra su propio cierre y no vuelve sola al menú:
            /// "Preparar escena" deja <c>SessionManager.navigateOnEnd</c> apagado (autoria.md §10.1).
            /// </summary>
            [JsonProperty("cierrePropio")] public bool OwnEnding;
            /// <summary>
            /// Opcional (por defecto false). Verdadero si la escena muestra solo lo que usa el paso en curso: lo que ningún paso
            /// usa se ve siempre, lo que sí se usa solo del primer al último paso que lo usa, y las etiquetas y los recuadros
            /// de las zonas solo en los pasos que los usan de verdad (autoria.md §12). "Preparar escena" y el importador de la
            /// colocación ponen entonces el StepVisibilityController en <c>[Colocacion]</c>.
            /// </summary>
            [JsonProperty("visibilidadPorPaso")] public bool VisibilityByStep;
        }

        public sealed class CoachInfo
        {
            [JsonProperty("nombre")] public string Name;
        }

        public sealed class LineEntry
        {
            [JsonProperty("es")] public string Es;
            [JsonProperty("en")] public string En;
            [JsonProperty("nota")] public string Note;
            [JsonProperty("soloTexto")] public bool TextOnly;
            /// <summary>Texto para el TTS cuando difiere del subtítulo, por idioma ("es", "en").</summary>
            [JsonProperty("dicho")] public Dictionary<string, string> Spoken;

            /// <summary>El texto del idioma pedido ("es" | "en"), o null.</summary>
            public string TextFor(string language) => language == "en" ? En : language == "es" ? Es : null;

            /// <summary>El texto dicho del idioma pedido, o null.</summary>
            public string SpokenFor(string language) =>
                Spoken != null && Spoken.TryGetValue(language, out var s) ? s : null;
        }

        public sealed class ObjectEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("nombre")] public string Name;
            /// <summary>
            /// "objeto" | "hotspot" (0.1); "agarrable" | "fuente" | "superficie" | "boton" | "herramienta" (0.2,
            /// Documentation~/contrato-0.2.md §4).
            /// </summary>
            [JsonProperty("tipo")] public string Kind;
            [JsonProperty("modelo")] public string Model;
            [JsonProperty("etiqueta")] public string Tag;

            // Campos opcionales por tipo de objeto (0.2). Solo valen para su tipo: el validador avisa de los que sobran.

            /// <summary>Solo `fuente`: id de un objeto `herramienta` cuyo modelo es la herramienta que carga la pila.</summary>
            [JsonProperty("herramienta")] public string Tool;
            /// <summary>Solo `superficie`: metros de frotado hasta completar (por defecto 1).</summary>
            [JsonProperty("recorrido")] public float? Travel;
            /// <summary>Solo `boton`: segundos que hay que mantenerlo pulsado (por defecto 3).</summary>
            [JsonProperty("segundos")] public float? Seconds;
            /// <summary>Solo `superficie`: ids de objetos `herramienta` o `fuente` con los que se frota; vacío = con las manos.</summary>
            [JsonProperty("herramientas")] public List<string> Tools = new();

            public bool IsHotspot => Kind == "hotspot";

            /// <summary>Se puede agarrar y llevar a una zona: `agarrable`, `fuente` o `herramienta`.</summary>
            public bool IsGrabbable => Kind == "agarrable" || Kind == "fuente" || Kind == "herramienta";

            /// <summary>El tag de Unity que usan las condiciones que buscan por tag: la etiqueta o, si falta, el id.</summary>
            public string EffectiveTag => string.IsNullOrEmpty(Tag) ? Id : Tag;
        }

        public sealed class SectionEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("titulo")] public string Title;
            [JsonProperty("desde")] public string FromStepId;
        }

        public sealed class StepEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("titulo")] public string Title;
            [JsonProperty("descripcion")] public string Description;
            /// <summary>"narracion" | "tocar" | "elegir" | "manual" | "tiempo" | "girar" (0.1); "llevar" | "frotar" | "mantener" | "apuntar" (0.2).</summary>
            [JsonProperty("tipo")] public string Kind;
            [JsonProperty("intro")] public List<string> IntroLines = new();
            [JsonProperty("instruccion")] public string InstructionLine;
            [JsonProperty("pista")] public string HintLine;
            [JsonProperty("exito")] public string SuccessLine;
            [JsonProperty("retrasoPista")] public float? HintDelay;
            /// <summary>clave que reporta la condición -> id de frase.</summary>
            [JsonProperty("errores")] public Dictionary<string, string> ErrorLines = new();
            [JsonProperty("errorPorDefecto")] public string DefaultErrorLine;
            [JsonProperty("repetirInstruccionTrasError")] public bool RepeatInstructionAfterError;
            [JsonProperty("tarea")] public bool CountsAsTask;
            [JsonProperty("etiquetaTarea")] public string TaskLabel;
            [JsonProperty("ancla")] public string AnchorId;
            [JsonProperty("senalar")] public string PointAtTargetId;
            [JsonProperty("activos")] public List<string> ActiveTargetIds = new();
            [JsonProperty("tiempoMaximo")] public float? MaxAllowedTime;
            [JsonProperty("puntos")] public int? ScoreOnSuccess;
            [JsonProperty("penalizacion")] public int? PenaltyOnError;
            [JsonProperty("esperaCierreManual")] public bool WaitForManualCompletion;
            [JsonProperty("condicion")] public ConditionEntry Condition;
            // 0.3 lote 1: efectos al cumplirse la condición (contrato-0.3.md §2.1): variable -> texto, número o { "sumar": n }.
            [JsonProperty("alCompletar")] public Dictionary<string, JToken> OnComplete;

            // 0.3 lote 2 (contrato-0.3.md §2.1 y §2.3). Se guardan crudos (JToken): el validador dice qué forma está
            // mal y el importador los resuelve a StateCondition / StateEffect.

            /// <summary>'si': variable → valor, lista (cualquiera) o { "mayor": n, "menor": n }.</summary>
            [JsonProperty("si")] public Dictionary<string, JToken> Guard;
            /// <summary>'alIniciar': variable → texto, número o { "sumar": n }.</summary>
            [JsonProperty("alIniciar")] public Dictionary<string, JToken> OnStart;
            /// <summary>'alError': clave de error → efectos.</summary>
            [JsonProperty("alError")] public Dictionary<string, Dictionary<string, JToken>> OnError;
            /// <summary>avanzar: días que suma a 'dia' (entero ≥ 1, obligatorio). Double para que 7,5 llegue al validador.</summary>
            [JsonProperty("dias")] public double? Days;
            /// <summary>avanzar: id de la frase soloTexto de la cortinilla.</summary>
            [JsonProperty("etiqueta")] public string Label;
            /// <summary>avanzar: segundos de la cortinilla (0–5; por defecto 1,5).</summary>
            [JsonProperty("fundido")] public float? Fade;

            #region 0.3 lote 5: «Continuar» (contrato-0.3.md §2.7)
            /// <summary>Botón «Continuar» mientras el paso escucha. Null = sin botón (como 0.2).</summary>
            [JsonProperty("continuar")] public ContinueEntry Continue;
            #endregion

            public bool IsTimeAdvance => Kind == "avanzar";

            public bool IsNarration => Kind == "narracion";

            #region 0.3 lote 3: grupos (contrato-0.3.md §2.4)

            /// <summary>Solo en <c>tipo: "grupo"</c>: los pasos en línea (o grupos, hasta dos niveles). Excluye <c>bloque</c>.</summary>
            [JsonProperty("pasos")] public List<StepEntry> GroupSteps;
            /// <summary>Solo en <c>tipo: "grupo"</c>: nombre de un bloque de <c>bloques</c>. Excluye <c>pasos</c>.</summary>
            [JsonProperty("bloque")] public string Block;
            /// <summary>Solo en <c>tipo: "grupo"</c>: vueltas, de 1 a 20 (por defecto 1).</summary>
            [JsonProperty("repetir")] public int? Repeat;
            /// <summary>Solo en <c>tipo: "grupo"</c>: variable numérica que vale 1…repetir en cada vuelta.</summary>
            [JsonProperty("contador")] public string Counter;
            /// <summary>Solo en <c>tipo: "grupo"</c>: un objeto de estado por vuelta, aplicado al empezarla.</summary>
            [JsonProperty("porIteracion")] public List<JObject> PerIteration;
            /// <summary>Claves del paso que esta clase no declara (las de otros lotes, como <c>si</c> o los efectos): se conservan al desenrollar.</summary>
            [JsonExtensionData] public IDictionary<string, JToken> Extra;
            /// <summary>Si el paso sale de desenrollar un grupo: su grupo de primer nivel y su vuelta. Null en un paso escrito tal cual.</summary>
            [JsonIgnore] public GuionExpander.Origin ExpandedFrom;

            public bool IsGroup => Kind == GuionExpander.GroupKind;

            #endregion
        }

        /// <summary>
        /// La condición del paso. Qué claves aplican depende de StepEntry.Kind (autoria.md §3.4 y contrato-0.2.md §6): tocar →
        /// Objeto; elegir → Correct, Error, Warning (teclas) u Options (objetos); manual → Key; tiempo → Seconds; girar →
        /// Objeto, Degrees; llevar → Objects, Zones, Count, Rules, OutsideKey; frotar y mantener → Objeto, Threshold;
        /// apuntar → Objeto, Tool, Seconds, WrongTargets.
        /// </summary>
        public sealed class ConditionEntry
        {
            [JsonProperty("objeto")] public string ObjectId;
            [JsonProperty("correcta")] public string CorrectKey;
            [JsonProperty("error")] public KeyedSignal Error;
            [JsonProperty("aviso")] public KeyedSignal Warning;
            [JsonProperty("tecla")] public string Key;
            [JsonProperty("segundos")] public float? Seconds;
            [JsonProperty("grados")] public float? Degrees;

            // 0.2 (contrato-0.2.md §6). Las listas pueden llegar nulas si el JSON trae `null`: quien las lee comprueba.

            /// <summary>llevar: ids de los objetos que cuentan (`agarrable`, `fuente` o `herramienta`).</summary>
            [JsonProperty("objetos")] public List<string> Objects = new();
            /// <summary>llevar: ids de las zonas `soltar` de la colocación donde cuenta el soltado.</summary>
            [JsonProperty("zonas")] public List<string> Zones = new();
            /// <summary>llevar: cuántos soltados válidos completan el paso (por defecto 1).</summary>
            [JsonProperty("cantidad")] public int? Count;
            /// <summary>llevar: errores y avisos por pares objeto/zona, en orden; gana la primera que coincide.</summary>
            [JsonProperty("reglas")] public List<DropRuleEntry> Rules = new();
            /// <summary>llevar: clave de error al soltar en una zona que no es ninguna de las aceptadas.</summary>
            [JsonProperty("claveFuera")] public string OutsideKey;

            #region 0.3 lote 5: reacciones, faltantes y zonas distintas de `llevar` (contrato-0.3.md §2.6)
            /// <summary>Objeto → id de frase que se dice (sin bloquear ni contar) al aceptarse su soltado.</summary>
            [JsonProperty("reacciones")] public Dictionary<string, string> Reactions;
            /// <summary>Objeto → clave de `errores` que «Continuar» reporta si ese objeto falta.</summary>
            [JsonProperty("faltantes")] public Dictionary<string, string> Missing;
            /// <summary>true: un soltado cuenta solo si su zona aún no tenía uno.</summary>
            [JsonProperty("distintas")] public bool? Distinct;
            #endregion
            /// <summary>frotar y mantener: fracción del recorrido o del tiempo que completa el paso (0,05 a 1; por defecto 1).</summary>
            [JsonProperty("umbral")] public float? Threshold;
            /// <summary>apuntar: id del objeto `herramienta` con el que se apunta.</summary>
            [JsonProperty("herramienta")] public string Tool;
            /// <summary>apuntar: objetivos equivocados y la clave de error de cada uno.</summary>
            [JsonProperty("equivocados")] public List<WrongTargetEntry> WrongTargets = new();
            /// <summary>elegir por objeto: los hotspots entre los que se elige y qué resultado tiene cada uno.</summary>
            [JsonProperty("opciones")] public List<ChoiceOptionEntry> Options = new();

            #region 0.3 lote 4: elegir según el estado (contrato-0.3.md §2.5)
            /// <summary>elegir: variable de texto del estado que decide la opción correcta (la de 'valor' igual al estado).</summary>
            [JsonProperty("segun")] public string ByState;
            /// <summary>elegir con segun: valor de la variable → clave de error (con frase en 'errores'). Obligatorio y completo.</summary>
            [JsonProperty("errorPorEstado")] public Dictionary<string, string> ErrorsByState;
            #endregion
        }

        /// <summary>Una regla de llevar: objeto y zona opcionales (vacío = cualquiera), clave obligatoria y tipo "error" | "aviso".</summary>
        public sealed class DropRuleEntry
        {
            [JsonProperty("objeto")] public string ObjectId;
            [JsonProperty("zona")] public string ZoneId;
            [JsonProperty("clave")] public string SignalKey;
            /// <summary>"error" (por defecto) | "aviso".</summary>
            [JsonProperty("tipo")] public string Kind;
        }

        /// <summary>Un objetivo equivocado de apuntar: tras `Grace` segundos de apuntarle se reporta la clave.</summary>
        public sealed class WrongTargetEntry
        {
            [JsonProperty("objeto")] public string ObjectId;
            [JsonProperty("clave")] public string SignalKey;
            /// <summary>"error" (por defecto) | "aviso".</summary>
            [JsonProperty("tipo")] public string Kind;
            /// <summary>Segundos de gracia antes de reportar (por defecto 1).</summary>
            [JsonProperty("gracia")] public float? Grace;
        }

        /// <summary>Una opción de elegir por objeto: un hotspot y su resultado "correcta" | "error" | "aviso".</summary>
        public sealed class ChoiceOptionEntry
        {
            [JsonProperty("objeto")] public string ObjectId;
            [JsonProperty("resultado")] public string Outcome;
            /// <summary>Obligatoria en "error" y "aviso" (debe estar en `errores` del paso); "correcta" no lleva.</summary>
            [JsonProperty("clave")] public string SignalKey;
            // 0.3 lote 1: efectos al tocar la opción, antes de la corrección o del éxito (contrato-0.3.md §2.5).
            [JsonProperty("alElegir")] public Dictionary<string, JToken> OnChoose;
            #region 0.3 lote 4
            /// <summary>Con 'segun' en la condición: el valor de la variable para el que esta opción es la correcta (en vez de 'resultado').</summary>
            [JsonProperty("valor")] public string Value;
            #endregion
        }

        #region 0.3 lote 5: «Continuar» (contrato-0.3.md §2.7)
        /// <summary>`continuar` de un paso: la frase del botón y la clave que se reporta si falta algo y no hay `faltantes`.</summary>
        public sealed class ContinueEntry
        {
            /// <summary>La frase del botón cuando el guion no da `etiqueta`.</summary>
            public const string DefaultLabel = "ui.continuar";

            /// <summary>Id de frase del botón (por defecto `ui.continuar`, que tiene que existir).</summary>
            [JsonProperty("etiqueta")] public string Label;
            [JsonProperty("claveIncompleto")] public string IncompleteKey;
        }
        #endregion

        #region 0.3 lote 4: indicadores (contrato-0.3.md §2.9)

        /// <summary>`indicadores` de primer nivel. Null si el JSON no los trae.</summary>
        [JsonProperty("indicadores")] public List<IndicatorEntry> Indicators;

        /// <summary>Un indicador del panel del HUD: variable, etiqueta y cómo se muestra el valor.</summary>
        public sealed class IndicatorEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("estado")] public string Variable;
            [JsonProperty("etiqueta")] public string Label;
            /// <summary>Variable de texto: valor → id de frase soloTexto (obligatorio y completo).</summary>
            [JsonProperty("textos")] public Dictionary<string, string> Texts;
            [JsonProperty("unidad")] public string Unit;
            [JsonProperty("decimales")] public int? Decimals;
            [JsonProperty("desde")] public string FromStepId;
            [JsonProperty("hasta")] public string UntilStepId;
            [JsonProperty("enInforme")] public bool InReport;
        }

        #endregion

        // ── 0.3 lote 6: bloqueos (contrato-0.3.md §2.8) ───────────────────────

        /// <summary>`bloqueos` de primer nivel. Puede llegar null si el JSON no los trae: leer con <c>Locks ?? …</c>.</summary>
        [JsonProperty("bloqueos")] public List<LockEntry> Locks = new();

        /// <summary>Un bloqueo: `zona` u `objeto` (no los dos), `hasta`, y opcionales `desde` y `clave`.</summary>
        public sealed class LockEntry
        {
            [JsonProperty("zona")] public string ZoneId;
            [JsonProperty("objeto")] public string ObjectId;
            [JsonProperty("hasta")] public string UntilStepId;
            [JsonProperty("desde")] public string FromStepId;
            [JsonProperty("clave")] public string ErrorKey;
        }

        /// <summary>Una tecla que dispara una señal con una clave (la clave debe tener frase en StepEntry.ErrorLines).</summary>
        public sealed class KeyedSignal
        {
            [JsonProperty("tecla")] public string Key;
            [JsonProperty("clave")] public string SignalKey;
        }

        // 0.3 lote 1: una variable de `estado` (contrato-0.3.md §2.1, cierre).
        public sealed class StateVarEntry
        {
            /// <summary>Lista cerrada: la hace de texto.</summary>
            [JsonProperty("valores")] public List<string> Values;
            /// <summary>Texto de `valores` (por defecto el primero) o número (obligatorio en una numérica).</summary>
            [JsonProperty("inicial")] public JToken Initial;
            [JsonProperty("min")] public double? Min;
            [JsonProperty("max")] public double? Max;
            [JsonProperty("registrar")] public bool Register;

            public bool IsText => Values != null;
        }
    }
}
