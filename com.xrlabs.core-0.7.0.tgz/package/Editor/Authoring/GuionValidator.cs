using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Valida un <see cref="GuionDocument"/> antes de importarlo (Documentation~/autoria.md §3.7). Pura: sin Unity, sin
    /// disco. Los errores impiden importar; los avisos lo dejan. Cada hallazgo lleva la ruta dentro del fichero
    /// ("pasos[p3].condicion.error.clave") y un mensaje en español que dice qué cambiar.
    /// </summary>
    public static class GuionValidator
    {
        // Mismos patrones que Schema/guion.schema.json.
        private static readonly Regex ExperienceIdPattern = new(@"^[a-z0-9][a-z0-9-]*$", RegexOptions.CultureInvariant);
        private static readonly Regex IdPattern = new(@"^[a-zA-Z0-9][a-zA-Z0-9._-]*$", RegexOptions.CultureInvariant);

        /// <summary>Esquemas que se leen: 0.1 y 0.2 (contrato-0.2.md §3). Un 0.1 que use algo de 0.2 recibe un aviso.</summary>
        public static readonly string[] SupportedSchemas = { GuionDocument.SchemaId, GuionDocument.SchemaId02, GuionDocument.SchemaId03 };

        /// <summary>Tipos de paso que solo existen desde la versión 0.2.</summary>
        public static readonly string[] StepKinds02 = { "llevar", "frotar", "mantener", "apuntar" };

        /// <summary>Tipos de paso: los de la versión 0.1 y los de la 0.2.</summary>
        public static readonly string[] StepKinds =
            { "narracion", "tocar", "elegir", "manual", "tiempo", "girar", "llevar", "frotar", "mantener", "apuntar" };

        /// <summary>Tipos de objeto que solo existen desde la versión 0.2.</summary>
        public static readonly string[] ObjectKinds02 = { "agarrable", "fuente", "superficie", "boton", "herramienta" };

        /// <summary>Tipos de objeto: los de la versión 0.1 y los de la 0.2 (contrato-0.2.md §4).</summary>
        public static readonly string[] ObjectKinds =
            { "objeto", "hotspot", "agarrable", "fuente", "superficie", "boton", "herramienta" };

        // Resultados de una opción de «elegir» por objeto, y tipos de señal de reglas y equivocados.
        private static readonly string[] ChoiceOutcomes = { "correcta", "error", "aviso" };
        private static readonly string[] SignalKinds = { "error", "aviso" };

        /// <summary>Idiomas admitidos en <c>experiencia.idiomas</c> (los de CoachLanguage).</summary>
        public static readonly string[] SupportedLanguages = { "es", "en" };

        public static List<ValidationIssue> Validate(GuionDocument doc)
        {
            var issues = new List<ValidationIssue>();
            if (doc == null)
            {
                issues.Add(ValidationIssue.Error("", "No hay guion que validar."));
                return issues;
            }

            // 0.3: lo que el guion usa de la 0.3 (lotes 1, 2, 3 y 6), para un solo aviso si declara 0.1 o 0.2.
            var used03 = new List<string>();
            if (GuionExpander.UsesGroups(doc)) used03.Add("grupos o bloques");

            if (!ExpandGroups(ref doc, issues)) return issues;   // 0.3 lote 3: se valida el guion desenrollado

            var referenced = new HashSet<string>();

            ValidateHeader(doc, issues);
            var languages = ValidateLanguages(doc, issues);
            ValidateLines(doc, languages, issues);
            ValidateSteps(doc, referenced, issues);
            ValidateSections(doc, issues);
            ValidateObjects(doc, issues);
            ValidateState03(doc, used03, issues);   // 0.3 lote 1
            ValidateVersion03Lote2(doc, referenced, issues);
            ValidateLocks(doc, issues);   // 0.3 lote 6
            ValidateLote5(doc, referenced, used03, issues);   // 0.3 lote 5
            ValidateIndicators04(doc, used03, referenced, issues);   // 0.3 lote 4
            WarnSchema03(doc, used03, issues);
            ValidateUnreferencedLines(doc, referenced, issues);
            return issues;
        }

        #region 0.3 lote 3: grupos y bloques (contrato-0.3.md §2.4)

        /// <summary>El esquema que trae los grupos y los bloques (el mismo que <see cref="GuionDocument.SchemaId03"/>).</summary>
        public const string SchemaId03 = GuionDocument.SchemaId03;

        // Desenrolla los grupos (GuionExpander) y deja en doc el guion plano, que es el que validan las reglas de siempre: así
        // un id repetido, una frase que falta o una condición mal puesta se citan con el id desenrollado. Falso si la
        // estructura de los grupos tiene errores (grupo sin pasos, porIteracion de otro largo, bloque que se usa a sí mismo,
        // ids desenrollados repetidos o de más de 100 caracteres): no hay guion plano que validar.
        private static bool ExpandGroups(ref GuionDocument doc, List<ValidationIssue> issues)
        {
            if (!GuionExpander.UsesGroups(doc)) return true;
            var structural = new List<ValidationIssue>();
            var expanded = GuionExpander.Expand(doc, structural);
            issues.AddRange(structural);
            if (ValidationIssue.AnyError(structural)) return false;
            doc = expanded;   // el aviso de esquema, si declara 0.1 o 0.2, lo da WarnSchema03 junto con lo demás de la 0.3
            return true;
        }

        #endregion

        /// <summary>Idiomas efectivos del guion: los declarados o, si no hay ninguno, ["es"].</summary>
        public static List<string> EffectiveLanguages(GuionDocument doc)
        {
            var result = new List<string>();
            if (doc?.Experience?.Languages != null)
                foreach (var l in doc.Experience.Languages)
                    if (!string.IsNullOrEmpty(l) && !result.Contains(l)) result.Add(l);
            if (result.Count == 0) result.Add("es");
            return result;
        }

        // ── Cabecera ──────────────────────────────────────────────────────────

        private static void ValidateHeader(GuionDocument doc, List<ValidationIssue> issues)
        {
            if (System.Array.IndexOf(SupportedSchemas, doc.Schema) < 0)
                issues.Add(ValidationIssue.Error("esquema",
                    $"El esquema es '{doc.Schema}' y esta versión del framework lee '{GuionDocument.SchemaId}', '{GuionDocument.SchemaId02}' y '{GuionDocument.SchemaId03}'."));
            else if (doc.Schema == GuionDocument.SchemaId)
            {
                var used = UsedVersion02Features(doc);
                if (used.Count > 0)
                    issues.Add(ValidationIssue.Warning("esquema",
                        $"El guion declara '{GuionDocument.SchemaId}' y usa cosas de la 0.2 ({string.Join(", ", used)}): " +
                        $"usa '{GuionDocument.SchemaId02}' en 'esquema'."));
            }

            var id = doc.Experience.Id;
            if (string.IsNullOrEmpty(id))
                issues.Add(ValidationIssue.Error("experiencia.id", "Falta el id de la experiencia."));
            else if (!ExperienceIdPattern.IsMatch(id))
                issues.Add(ValidationIssue.Error("experiencia.id",
                    $"El id '{id}' solo puede llevar minúsculas, números y guiones, y empezar por letra o número."));

            if (string.IsNullOrEmpty(doc.Experience.SceneName))
                issues.Add(ValidationIssue.Error("experiencia.escena",
                    "Falta el nombre de la escena: sin él la experiencia no se puede lanzar desde el menú."));

            var mode = doc.Experience.Mode;
            if (mode != "guiado" && mode != "evaluacion")
                issues.Add(ValidationIssue.Error("experiencia.modo",
                    $"El modo '{mode}' no existe: usa 'guiado' o 'evaluacion'."));

            if (doc.Steps.Count == 0)
                issues.Add(ValidationIssue.Error("pasos", "El guion no tiene ningún paso."));
        }

        // Lo que un guion usa y solo existe desde la 0.2 (contrato-0.2.md §3): tipos de paso, tipos de objeto y las
        // opciones de «elegir». Una lista vacía = el guion es 0.1 de verdad.
        private static List<string> UsedVersion02Features(GuionDocument doc)
        {
            var used = new List<string>();
            foreach (var step in doc.Steps)
            {
                if (step == null) continue;
                if (System.Array.IndexOf(StepKinds02, step.Kind) >= 0)
                    AddOnce(used, $"paso '{step.Kind}'");
                if (step.Kind == "elegir" && step.Condition?.Options != null && step.Condition.Options.Count > 0)
                    AddOnce(used, "'opciones' en 'elegir'");
            }
            foreach (var obj in doc.Objects)
                if (obj != null && System.Array.IndexOf(ObjectKinds02, obj.Kind) >= 0)
                    AddOnce(used, $"objeto '{obj.Kind}'");
            return used;
        }

        private static void AddOnce(List<string> list, string item)
        {
            if (!list.Contains(item)) list.Add(item);
        }

        private static List<string> ValidateLanguages(GuionDocument doc, List<ValidationIssue> issues)
        {
            var declared = doc.Experience.Languages;
            if (declared != null)
            {
                for (int i = 0; i < declared.Count; i++)
                {
                    if (System.Array.IndexOf(SupportedLanguages, declared[i]) < 0)
                        issues.Add(ValidationIssue.Error($"experiencia.idiomas[{i}]",
                            $"El idioma '{declared[i]}' no está admitido: solo 'es' y 'en'."));
                }
            }
            return EffectiveLanguages(doc);
        }

        // ── Frases ────────────────────────────────────────────────────────────

        private static void ValidateLines(GuionDocument doc, List<string> languages, List<ValidationIssue> issues)
        {
            foreach (var pair in doc.Lines)
            {
                var path = $"lineas[{pair.Key}]";
                if (string.IsNullOrEmpty(pair.Key) || !IdPattern.IsMatch(pair.Key))
                    issues.Add(ValidationIssue.Error(path,
                        $"El id de frase '{pair.Key}' solo puede llevar letras, números, punto, guion y guion bajo."));

                foreach (var language in languages)
                {
                    if (System.Array.IndexOf(SupportedLanguages, language) < 0) continue;
                    if (string.IsNullOrWhiteSpace(pair.Value?.TextFor(language)))
                        issues.Add(ValidationIssue.Warning($"{path}.{language}",
                            $"La frase no tiene texto en '{language}' y el guion declara ese idioma."));
                }
            }
        }

        private static void ValidateUnreferencedLines(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues)
        {
            foreach (var id in doc.Lines.Keys)
                if (!referenced.Contains(id))
                    issues.Add(ValidationIssue.Warning($"lineas[{id}]",
                        "La frase está definida y ningún paso la usa."));
        }

        // Referencia obligatoria a una frase: error si el id no existe en 'lineas'.
        private static void RequireLine(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues,
            string path, string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                issues.Add(ValidationIssue.Error(path, "El id de frase está vacío."));
                return;
            }

            if (GuionStateRules.IsTemplate(id))
            {
                GuionStateRules.RequireTemplateLine(doc, referenced, issues, path, id); // 0.3 lote 2: {variable}
                return;
            }

            referenced.Add(id);
            if (!doc.Lines.ContainsKey(id))
                issues.Add(ValidationIssue.Error(path, $"La frase '{id}' no está definida en 'lineas'."));
        }

        // ── 0.3 lote 2 ────────────────────────────────────────────────────────

        // Estado, 'si', 'alIniciar', 'alError' y 'avanzar' (contrato-0.3.md §2.1–§2.3): las reglas viven en GuionStateRules,
        // que comparte el importador.
        private static void ValidateVersion03Lote2(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues) =>
            GuionStateRules.Validate(doc, referenced, issues);

        // ── Pasos ─────────────────────────────────────────────────────────────

        private static string StepPath(int index, GuionDocument.StepEntry step) =>
            $"pasos[{(string.IsNullOrEmpty(step?.Id) ? "#" + index : step.Id)}]";

        private static void ValidateSteps(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues)
        {
            var seen = new HashSet<string>();
            for (int i = 0; i < doc.Steps.Count; i++)
            {
                var step = doc.Steps[i];
                var path = StepPath(i, step);
                if (step == null)
                {
                    issues.Add(ValidationIssue.Error(path, "El paso está vacío."));
                    continue;
                }

                if (string.IsNullOrEmpty(step.Id))
                    issues.Add(ValidationIssue.Error(path + ".id", "Falta el id del paso."));
                else if (!IdPattern.IsMatch(step.Id))
                    issues.Add(ValidationIssue.Error(path + ".id",
                        $"El id de paso '{step.Id}' solo puede llevar letras, números, punto, guion y guion bajo (nombra el asset)."));
                else if (!seen.Add(step.Id))
                    issues.Add(ValidationIssue.Error(path + ".id", $"El id de paso '{step.Id}' está repetido."));

                ValidateStepLines(doc, step, path, referenced, issues);
                ValidateStepObjects(doc, step, path, issues);
                ValidateStepCondition(doc, step, path, issues);

                if (!step.IsNarration && System.Array.IndexOf(StepKinds, step.Kind) >= 0 && string.IsNullOrEmpty(step.InstructionLine))
                    issues.Add(ValidationIssue.Warning(path + ".instruccion",
                        "El paso espera una acción y no tiene frase de instrucción."));
            }
        }

        private static void ValidateStepLines(GuionDocument doc, GuionDocument.StepEntry step, string path,
            HashSet<string> referenced, List<ValidationIssue> issues)
        {
            if (step.IntroLines != null)
                for (int i = 0; i < step.IntroLines.Count; i++)
                    RequireLine(doc, referenced, issues, $"{path}.intro[{i}]", step.IntroLines[i]);

            if (!string.IsNullOrEmpty(step.InstructionLine))
                RequireLine(doc, referenced, issues, path + ".instruccion", step.InstructionLine);
            if (!string.IsNullOrEmpty(step.HintLine))
                RequireLine(doc, referenced, issues, path + ".pista", step.HintLine);
            if (!string.IsNullOrEmpty(step.SuccessLine))
                RequireLine(doc, referenced, issues, path + ".exito", step.SuccessLine);
            if (!string.IsNullOrEmpty(step.DefaultErrorLine))
                RequireLine(doc, referenced, issues, path + ".errorPorDefecto", step.DefaultErrorLine);

            if (step.ErrorLines != null)
                foreach (var pair in step.ErrorLines)
                    RequireLine(doc, referenced, issues, $"{path}.errores.{pair.Key}", pair.Value);

            // etiquetaTarea puede ser un id de frase o texto plano: solo es error probable si parece un id y no existe,
            // y aun así queda en aviso porque un texto de una palabra también cumple el patrón.
            var label = step.TaskLabel;
            if (!string.IsNullOrEmpty(label) && IdPattern.IsMatch(label))
            {
                if (doc.Lines.ContainsKey(label)) referenced.Add(label);
                else
                    issues.Add(ValidationIssue.Warning(path + ".etiquetaTarea",
                        $"'{label}' parece un id de frase y no está en 'lineas'; se mostrará como texto plano."));
            }
        }

        private static void ValidateStepObjects(GuionDocument doc, GuionDocument.StepEntry step, string path,
            List<ValidationIssue> issues)
        {
            if (!string.IsNullOrEmpty(step.PointAtTargetId) && doc.FindObject(step.PointAtTargetId) == null)
                issues.Add(ValidationIssue.Error(path + ".senalar",
                    $"El objeto '{step.PointAtTargetId}' no está definido en 'objetos'."));

            // 2026-10-17: un activo puede ser también una zona de la condición de un «llevar» (las zonas son SceneTarget y el
            // anillo marca adónde va lo que se lleva); los ids de zona se comprueban en la colocación.
            if (step.ActiveTargetIds != null)
                for (int i = 0; i < step.ActiveTargetIds.Count; i++)
                {
                    string id = step.ActiveTargetIds[i];
                    bool zoneOfStep = step.Kind == "llevar" && step.Condition?.Zones != null && step.Condition.Zones.Contains(id);
                    if (doc.FindObject(id) == null && !zoneOfStep)
                        issues.Add(ValidationIssue.Error($"{path}.activos[{i}]",
                            $"El objeto '{id}' no está definido en 'objetos' (ni es una zona de la condición de este paso)."));
                }
        }

        private static void ValidateStepCondition(GuionDocument doc, GuionDocument.StepEntry step, string path,
            List<ValidationIssue> issues)
        {
            var cond = step.Condition;
            var condPath = path + ".condicion";

            switch (step.Kind)
            {
                case "narracion":
                    if (cond != null)
                        issues.Add(ValidationIssue.Warning(condPath, "Un paso de narración no lleva condición; se ignora."));
                    break;

                case "tocar":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    var touched = doc.FindObject(cond.ObjectId);
                    if (string.IsNullOrEmpty(cond.ObjectId))
                        issues.Add(ValidationIssue.Error(condPath + ".objeto", "Falta el objeto que hay que tocar."));
                    else if (touched == null)
                        issues.Add(ValidationIssue.Error(condPath + ".objeto",
                            $"El objeto '{cond.ObjectId}' no está definido en 'objetos'."));
                    else if (!touched.IsHotspot)
                        issues.Add(ValidationIssue.Error(condPath + ".objeto",
                            $"Solo se puede tocar un objeto de tipo 'hotspot' y '{cond.ObjectId}' es '{touched.Kind}'."));
                    break;

                case "elegir":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    ValidateChoice(doc, step, cond, condPath, issues);
                    break;

                case "manual":
                    // La condición es opcional: sin ella se usa la barra espaciadora.
                    if (cond != null && cond.Key != null) CheckKey(issues, condPath + ".tecla", cond.Key);
                    break;

                case "tiempo":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    if (cond.Seconds == null || cond.Seconds <= 0f)
                        issues.Add(ValidationIssue.Error(condPath + ".segundos", "Faltan los segundos, o no son mayores que cero."));
                    break;

                case "girar":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    if (string.IsNullOrEmpty(cond.ObjectId))
                        issues.Add(ValidationIssue.Error(condPath + ".objeto", "Falta el objeto que hay que girar."));
                    else if (doc.FindObject(cond.ObjectId) == null)
                        issues.Add(ValidationIssue.Error(condPath + ".objeto",
                            $"El objeto '{cond.ObjectId}' no está definido en 'objetos'."));
                    if (cond.Degrees != null && cond.Degrees <= 0f)
                        issues.Add(ValidationIssue.Error(condPath + ".grados", "Los grados tienen que ser mayores que cero."));
                    break;

                case "llevar":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    ValidateDrop(doc, step, cond, condPath, issues);
                    break;

                case "frotar":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    RequireObject(doc, issues, condPath + ".objeto", cond.ObjectId, "Falta la superficie que hay que frotar.",
                        new[] { "superficie" }, "un objeto de tipo 'superficie'");
                    CheckThreshold(issues, condPath + ".umbral", cond.Threshold);
                    break;

                case "mantener":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    RequireObject(doc, issues, condPath + ".objeto", cond.ObjectId, "Falta el botón que hay que mantener.",
                        new[] { "boton" }, "un objeto de tipo 'boton'");
                    CheckThreshold(issues, condPath + ".umbral", cond.Threshold);
                    break;

                case "apuntar":
                    if (cond == null) { MissingCondition(issues, condPath, step.Kind); break; }
                    ValidateAim(doc, step, cond, condPath, issues);
                    break;

                case "avanzar":
                    break; // 0.3 lote 2: lo valida GuionStateRules (dias, etiqueta, fundido, sin condición)

                default:
                    issues.Add(ValidationIssue.Error(path + ".tipo",
                        $"El tipo de paso '{step.Kind}' no existe en esta versión: usa narracion, tocar, elegir, manual, tiempo, girar, llevar, frotar, mantener o apuntar."));
                    break;
            }
        }

        // «elegir» por teclas (0.1) o por objetos (0.2, contrato-0.2.md §6.5). Las dos a la vez, o ninguna, es un error.
        private static void ValidateChoice(GuionDocument doc, GuionDocument.StepEntry step, GuionDocument.ConditionEntry cond,
            string condPath, List<ValidationIssue> issues)
        {
            bool hasOptions = cond.Options != null && cond.Options.Count > 0;
            bool hasKeys = cond.CorrectKey != null || cond.Error != null || cond.Warning != null;

            if (hasOptions && hasKeys)
            {
                issues.Add(ValidationIssue.Error(condPath,
                    "Un paso 'elegir' elige teclas ('correcta', 'error', 'aviso') u objetos ('opciones'), no las dos cosas a la vez."));
                return;
            }
            if (!hasOptions && !hasKeys)
            {
                issues.Add(ValidationIssue.Error(condPath,
                    "Un paso 'elegir' necesita teclas ('correcta') u objetos ('opciones')."));
                return;
            }

            if (ValidateChoiceByState04(doc, step, cond, condPath, hasKeys, issues)) return;   // 0.3 lote 4: segun

            if (hasKeys)
            {
                CheckKey(issues, condPath + ".correcta", cond.CorrectKey);
                CheckSignal(step, issues, condPath + ".error", cond.Error);
                CheckSignal(step, issues, condPath + ".aviso", cond.Warning);
                return;
            }

            var optionsPath = condPath + ".opciones";
            if (cond.Options.Count < 2)
                issues.Add(ValidationIssue.Error(optionsPath, "Elegir entre objetos necesita al menos dos opciones."));

            int correct = 0;
            var seen = new HashSet<string>();
            for (int i = 0; i < cond.Options.Count; i++)
            {
                var option = cond.Options[i];
                var path = $"{optionsPath}[{i}]";
                if (option == null)
                {
                    issues.Add(ValidationIssue.Error(path, "La opción está vacía."));
                    continue;
                }

                RequireObject(doc, issues, path + ".objeto", option.ObjectId, "Falta el objeto que se elige.",
                    new[] { "hotspot" }, "un objeto de tipo 'hotspot'");
                if (!string.IsNullOrEmpty(option.ObjectId) && !seen.Add(option.ObjectId))
                    issues.Add(ValidationIssue.Error(path + ".objeto",
                        $"El objeto '{option.ObjectId}' está en dos opciones y no se sabría cuál vale."));

                if (System.Array.IndexOf(ChoiceOutcomes, option.Outcome) < 0)
                {
                    issues.Add(ValidationIssue.Error(path + ".resultado",
                        $"El resultado '{option.Outcome}' no existe: usa 'correcta', 'error' o 'aviso'."));
                    continue;
                }

                if (option.Outcome == "correcta")
                {
                    correct++;
                    if (!string.IsNullOrEmpty(option.SignalKey))
                        issues.Add(ValidationIssue.Warning(path + ".clave",
                            "La opción correcta no lleva clave; se ignora."));
                }
                else
                {
                    CheckErrorKey(step, issues, path + ".clave", option.SignalKey);
                }
            }

            if (correct == 0)
                issues.Add(ValidationIssue.Error(optionsPath, "Ninguna opción es 'correcta': el paso no se podría completar."));
        }

        // «llevar» → DropCondition (contrato-0.2.md §6.1). Los ids de zona solo se comprueban en la colocación.
        private static void ValidateDrop(GuionDocument doc, GuionDocument.StepEntry step, GuionDocument.ConditionEntry cond,
            string condPath, List<ValidationIssue> issues)
        {
            const string grabbable = "un objeto agarrable, fuente o herramienta";

            if (cond.Objects == null || cond.Objects.Count == 0)
                issues.Add(ValidationIssue.Error(condPath + ".objetos", "Faltan los objetos que hay que llevar (al menos uno)."));
            else
                for (int i = 0; i < cond.Objects.Count; i++)
                    RequireGrabbable(doc, issues, $"{condPath}.objetos[{i}]", cond.Objects[i], "Falta el id del objeto.", grabbable);

            if (cond.Zones == null || cond.Zones.Count == 0)
                issues.Add(ValidationIssue.Error(condPath + ".zonas", "Faltan las zonas donde hay que soltar (al menos una)."));
            else
                for (int i = 0; i < cond.Zones.Count; i++)
                    if (string.IsNullOrEmpty(cond.Zones[i]))
                        issues.Add(ValidationIssue.Error($"{condPath}.zonas[{i}]", "Falta el id de la zona."));

            if (cond.Count != null && cond.Count < 1)
                issues.Add(ValidationIssue.Error(condPath + ".cantidad", "La cantidad tiene que ser un entero de 1 en adelante."));

            if (cond.Rules != null)
            {
                for (int i = 0; i < cond.Rules.Count; i++)
                {
                    var rule = cond.Rules[i];
                    var path = $"{condPath}.reglas[{i}]";
                    if (rule == null)
                    {
                        issues.Add(ValidationIssue.Error(path, "La regla está vacía."));
                        continue;
                    }
                    // objeto y zona son opcionales (vacío = cualquiera, como DropRule); si vienen, el objeto tiene que existir.
                    if (!string.IsNullOrEmpty(rule.ObjectId))
                        RequireGrabbable(doc, issues, path + ".objeto", rule.ObjectId, null, grabbable);
                    CheckErrorKey(step, issues, path + ".clave", rule.SignalKey);
                    CheckSignalKind(issues, path + ".tipo", rule.Kind);
                }
            }

            if (!string.IsNullOrEmpty(cond.OutsideKey))
                CheckErrorKey(step, issues, condPath + ".claveFuera", cond.OutsideKey);
        }

        // «apuntar» → AimCondition (contrato-0.2.md §6.4).
        private static void ValidateAim(GuionDocument doc, GuionDocument.StepEntry step, GuionDocument.ConditionEntry cond,
            string condPath, List<ValidationIssue> issues)
        {
            RequireObject(doc, issues, condPath + ".objeto", cond.ObjectId, "Falta el objeto al que hay que apuntar.");
            RequireObject(doc, issues, condPath + ".herramienta", cond.Tool, "Falta la herramienta con la que se apunta.",
                new[] { "herramienta" }, "un objeto de tipo 'herramienta'");

            if (cond.Seconds != null && cond.Seconds <= 0f)
                issues.Add(ValidationIssue.Error(condPath + ".segundos", "Los segundos tienen que ser mayores que cero."));

            if (cond.WrongTargets == null) return;
            for (int i = 0; i < cond.WrongTargets.Count; i++)
            {
                var wrong = cond.WrongTargets[i];
                var path = $"{condPath}.equivocados[{i}]";
                if (wrong == null)
                {
                    issues.Add(ValidationIssue.Error(path, "El objetivo equivocado está vacío."));
                    continue;
                }
                RequireObject(doc, issues, path + ".objeto", wrong.ObjectId, "Falta el objeto equivocado.");
                CheckErrorKey(step, issues, path + ".clave", wrong.SignalKey);
                CheckSignalKind(issues, path + ".tipo", wrong.Kind);
                if (wrong.Grace != null && wrong.Grace < 0f)
                    issues.Add(ValidationIssue.Error(path + ".gracia", "La gracia no puede ser negativa."));
            }
        }

        // El objeto que nombra una condición: error si falta, no existe o no es de uno de los tipos permitidos
        // (allowedKinds null = cualquiera). Devuelve el objeto o null.
        private static GuionDocument.ObjectEntry RequireObject(GuionDocument doc, List<ValidationIssue> issues, string path,
            string id, string missingMessage, string[] allowedKinds = null, string allowedPhrase = null)
        {
            if (string.IsNullOrEmpty(id))
            {
                issues.Add(ValidationIssue.Error(path, missingMessage));
                return null;
            }
            var obj = doc.FindObject(id);
            if (obj == null)
            {
                issues.Add(ValidationIssue.Error(path, $"El objeto '{id}' no está definido en 'objetos'."));
                return null;
            }
            if (allowedKinds != null && System.Array.IndexOf(allowedKinds, obj.Kind) < 0)
                issues.Add(ValidationIssue.Error(path, $"'{id}' es de tipo '{obj.Kind}' y aquí hace falta {allowedPhrase}."));
            return obj;
        }

        private static void RequireGrabbable(GuionDocument doc, List<ValidationIssue> issues, string path, string id,
            string missingMessage, string phrase)
        {
            var obj = RequireObject(doc, issues, path, id, missingMessage ?? string.Empty);
            if (obj != null && !obj.IsGrabbable)
                issues.Add(ValidationIssue.Error(path, $"'{id}' es de tipo '{obj.Kind}' y aquí hace falta {phrase}."));
        }

        private static void CheckThreshold(List<ValidationIssue> issues, string path, float? threshold)
        {
            if (threshold != null && (threshold < 0.05f || threshold > 1f))
                issues.Add(ValidationIssue.Error(path, "El umbral tiene que estar entre 0,05 y 1."));
        }

        private static void CheckSignalKind(List<ValidationIssue> issues, string path, string kind)
        {
            if (string.IsNullOrEmpty(kind)) return; // por defecto: error
            if (System.Array.IndexOf(SignalKinds, kind) < 0)
                issues.Add(ValidationIssue.Error(path, $"El tipo '{kind}' no existe: usa 'error' o 'aviso'."));
        }

        private static void MissingCondition(List<ValidationIssue> issues, string path, string kind) =>
            issues.Add(ValidationIssue.Error(path, $"Un paso de tipo '{kind}' necesita 'condicion'."));

        private static void CheckKey(List<ValidationIssue> issues, string path, string key)
        {
            if (!KeyNames.ToKeyCode(key, out _))
                issues.Add(ValidationIssue.Error(path,
                    $"La tecla '{key}' no está admitida: usa 1 a 9, a a z, espacio o enter."));
        }

        private static void CheckSignal(GuionDocument.StepEntry step, List<ValidationIssue> issues, string path,
            GuionDocument.KeyedSignal signal)
        {
            if (signal == null) return;

            CheckKey(issues, path + ".tecla", signal.Key);
            CheckErrorKey(step, issues, path + ".clave", signal.SignalKey);
        }

        // Una clave de error o aviso tiene que existir y tener frase en 'errores' del paso.
        private static void CheckErrorKey(GuionDocument.StepEntry step, List<ValidationIssue> issues, string path, string key)
        {
            if (string.IsNullOrEmpty(key))
                issues.Add(ValidationIssue.Error(path, "Falta la clave que explica este error."));
            else if (step.ErrorLines == null || !step.ErrorLines.ContainsKey(key))
                issues.Add(ValidationIssue.Error(path, $"La clave '{key}' no tiene frase en 'errores' del paso."));
        }

        // ── 0.3 lote 6: bloqueos (contrato-0.3.md §2.8, cierre 2.8) ───────────
        // Errores: `zona` y `objeto` a la vez o ninguno; `hasta` que falta o no es paso ni grupo; `desde` que no lo es; objeto
        // que no está en `objetos`. Aviso: ningún paso entre `desde` y `hasta` declara la `clave` (nunca se diría); un guion
        // 0.1 o 0.2 que trae bloqueos (son de la 0.3). La zona se cruza con la colocación en ValidateLockZones.

        /// <summary>El esquema 0.3 del guion (el mismo que <see cref="GuionDocument.SchemaId03"/>).</summary>
        internal const string SchemaId03ForLocks = GuionDocument.SchemaId03;

        private static void ValidateLocks(GuionDocument doc, List<ValidationIssue> issues)
        {
            var locks = doc.Locks ?? new List<GuionDocument.LockEntry>();
            if (locks.Count == 0) return;

            // Un guion 0.1 o 0.2 con bloqueos recibe el aviso de esquema de WarnSchema03, junto con lo demás de la 0.3.

            for (int i = 0; i < locks.Count; i++)
            {
                var l = locks[i];
                string path = $"bloqueos[{i}]";
                if (l == null) { issues.Add(ValidationIssue.Error(path, "El bloqueo está vacío.")); continue; }

                bool hasZone = !string.IsNullOrEmpty(l.ZoneId);
                bool hasObject = !string.IsNullOrEmpty(l.ObjectId);
                if (hasZone == hasObject)
                    issues.Add(ValidationIssue.Error(path, hasZone
                        ? "Un bloqueo lleva 'zona' u 'objeto', no los dos."
                        : "Un bloqueo tiene que decir qué bloquea: 'zona' u 'objeto'."));
                if (hasObject && doc.FindObject(l.ObjectId) == null)
                    issues.Add(ValidationIssue.Error(path + ".objeto", $"'{l.ObjectId}' no es un objeto del guion."));

                int until = -1, from = 0;
                if (string.IsNullOrEmpty(l.UntilStepId))
                    issues.Add(ValidationIssue.Error(path + ".hasta", "Falta 'hasta': el paso hasta cuyo cierre dura el bloqueo."));
                else if ((until = LockStepIndex(doc, l.UntilStepId, last: true)) < 0)
                    issues.Add(ValidationIssue.Error(path + ".hasta", $"'{l.UntilStepId}' no es un paso ni un grupo del guion."));

                if (!string.IsNullOrEmpty(l.FromStepId) && (from = LockStepIndex(doc, l.FromStepId, last: false)) < 0)
                    issues.Add(ValidationIssue.Error(path + ".desde", $"'{l.FromStepId}' no es un paso ni un grupo del guion."));
                else if (until >= 0 && from > until)
                    issues.Add(ValidationIssue.Error(path + ".desde", $"'{l.FromStepId}' va después de '{l.UntilStepId}': el bloqueo no regiría nunca."));

                if (string.IsNullOrEmpty(l.ErrorKey) || until < 0 || from < 0) continue;
                bool declared = false;
                for (int s = from; s <= until && !declared; s++)
                {
                    var step = doc.Steps[s];
                    declared = step?.ErrorLines != null && step.ErrorLines.ContainsKey(l.ErrorKey);
                }
                if (!declared)
                    issues.Add(ValidationIssue.Warning(path + ".clave",
                        $"Ningún paso hasta '{l.UntilStepId}' declara la clave '{l.ErrorKey}' en 'errores': el bloqueo nunca la dirá."));
            }
        }

        // El paso con ese id o, si es un grupo, el último (o el primero) de sus pasos desenrollados «<grupo>.…».
        private static int LockStepIndex(GuionDocument doc, string id, bool last)
        {
            int found = -1;
            for (int i = 0; i < doc.Steps.Count; i++)
            {
                var stepId = doc.Steps[i]?.Id;
                if (stepId == id) return i;
                if (stepId == null || !stepId.StartsWith(id + ".", System.StringComparison.Ordinal)) continue;
                if (!last) return i;
                found = i;
            }
            return found;
        }

        /// <summary>
        /// 0.3 lote 6: referencia cruzada de `bloqueos[].zona` con la colocación (contrato-0.3.md §3): cada zona bloqueada
        /// tiene que ser una zona `soltar` declarada. La llama ColocacionValidator, que tiene los dos ficheros.
        /// </summary>
        public static void ValidateLockZones(GuionDocument guion, ICollection<string> dropZones, List<ValidationIssue> issues)
        {
            var locks = guion?.Locks ?? new List<GuionDocument.LockEntry>();
            for (int i = 0; i < locks.Count; i++)
            {
                var zone = locks[i]?.ZoneId;
                if (string.IsNullOrEmpty(zone) || dropZones.Contains(zone)) continue;
                issues.Add(ValidationIssue.Error($"bloqueos[{i}].zona",
                    $"El bloqueo nombra la zona '{zone}' y la colocación no la declara como zona 'soltar' en 'zonas'."));
            }
        }

        // ── Secciones y objetos ───────────────────────────────────────────────

        private static void ValidateSections(GuionDocument doc, List<ValidationIssue> issues)
        {
            for (int i = 0; i < doc.Sections.Count; i++)
            {
                var section = doc.Sections[i];
                var path = $"secciones[{(string.IsNullOrEmpty(section?.Id) ? "#" + i : section.Id)}]";
                if (section == null)
                {
                    issues.Add(ValidationIssue.Error(path, "La sección está vacía."));
                    continue;
                }
                if (doc.FindStep(section.FromStepId) == null)
                    issues.Add(ValidationIssue.Error(path + ".desde",
                        $"'{section.FromStepId}' no es un paso del guion."));
            }
        }

        private static void ValidateObjects(GuionDocument doc, List<ValidationIssue> issues)
        {
            foreach (var obj in doc.Objects)
            {
                if (obj == null) continue;
                if (string.IsNullOrEmpty(obj.Model))
                    issues.Add(ValidationIssue.Warning($"objetos[{obj.Id}].modelo",
                        "El objeto no tiene modelo: la colocación pondrá un cubo de marca en su lugar."));

                var path = $"objetos[{obj.Id}]";
                if (System.Array.IndexOf(ObjectKinds, obj.Kind) < 0)
                    issues.Add(ValidationIssue.Error(path + ".tipo",
                        $"El tipo de objeto '{obj.Kind}' no existe: usa objeto, hotspot, agarrable, fuente, superficie, boton o herramienta."));
                ValidateObjectFields(doc, obj, path, issues);
            }
        }

        // Los campos opcionales de un objeto (contrato-0.2.md §4) solo valen para su tipo: si sobran, aviso; si valen y
        // están mal, error.
        private static void ValidateObjectFields(GuionDocument doc, GuionDocument.ObjectEntry obj, string path,
            List<ValidationIssue> issues)
        {
            if (!string.IsNullOrEmpty(obj.Tool))
            {
                if (obj.Kind != "fuente")
                    issues.Add(ValidationIssue.Warning(path + ".herramienta",
                        $"'herramienta' solo vale en un objeto 'fuente' y '{obj.Id}' es '{obj.Kind}'; se ignora."));
                else
                    RequireObject(doc, issues, path + ".herramienta", obj.Tool, string.Empty,
                        new[] { "herramienta" }, "un objeto de tipo 'herramienta'");
            }

            if (obj.Travel != null)
            {
                if (obj.Kind != "superficie")
                    issues.Add(ValidationIssue.Warning(path + ".recorrido",
                        $"'recorrido' solo vale en un objeto 'superficie' y '{obj.Id}' es '{obj.Kind}'; se ignora."));
                else if (obj.Travel <= 0f)
                    issues.Add(ValidationIssue.Error(path + ".recorrido", "El recorrido tiene que ser mayor que cero."));
            }

            if (obj.Seconds != null)
            {
                if (obj.Kind != "boton")
                    issues.Add(ValidationIssue.Warning(path + ".segundos",
                        $"'segundos' solo vale en un objeto 'boton' y '{obj.Id}' es '{obj.Kind}'; se ignora."));
                else if (obj.Seconds <= 0f)
                    issues.Add(ValidationIssue.Error(path + ".segundos", "Los segundos tienen que ser mayores que cero."));
            }

            if (obj.Tools != null && obj.Tools.Count > 0)
            {
                if (obj.Kind != "superficie")
                    issues.Add(ValidationIssue.Warning(path + ".herramientas",
                        $"'herramientas' solo vale en un objeto 'superficie' y '{obj.Id}' es '{obj.Kind}'; se ignora."));
                else
                    for (int i = 0; i < obj.Tools.Count; i++)
                        RequireObject(doc, issues, $"{path}.herramientas[{i}]", obj.Tools[i], "Falta el id de la herramienta.",
                            new[] { "herramienta", "fuente" }, "un objeto de tipo 'herramienta' o 'fuente'");
            }
        }

        #region 0.3 lote 5: «Continuar», reacciones, faltantes y zonas distintas (contrato-0.3.md §2.6 y §2.7)

        /// <summary>Los tipos de paso que admiten `continuar` (cierre 2.7).</summary>
        public static readonly string[] ContinueKinds = { "llevar", "elegir", "frotar", "mantener", "apuntar" };

        // Cierre 2.6: objeto de `reacciones` o `faltantes` que no está en `objetos` (error); frase de reacción que no existe
        // (error); clave de `faltantes` sin frase en `errores` (error); `distintas: true` con menos zonas que `cantidad` (aviso:
        // no se puede completar). Cierre 2.7: `continuar` fuera de llevar, elegir, frotar, mantener o apuntar (error);
        // `etiqueta` (por defecto ui.continuar) que no existe (error); sin `faltantes`, `claveIncompleto` obligatoria (error);
        // `claveIncompleto` sin frase en `errores` (error). Todo cuenta para el aviso de esquema de un guion 0.1 o 0.2.
        private static void ValidateLote5(GuionDocument doc, HashSet<string> referenced, List<string> used, List<ValidationIssue> issues)
        {
            for (int i = 0; i < doc.Steps.Count; i++)
            {
                var step = doc.Steps[i];
                if (step == null) continue;
                string path = StepPath(i, step);
                var cond = step.Condition;

                if (cond != null && (cond.Reactions != null || cond.Missing != null || cond.Distinct != null))
                    ValidateDropLote5(doc, step, cond, path + ".condicion", referenced, used, issues);

                var cont = step.Continue;
                if (cont == null) continue;
                AddOnce(used, "'continuar'");
                string contPath = path + ".continuar";
                if (System.Array.IndexOf(ContinueKinds, step.Kind) < 0)
                {
                    issues.Add(ValidationIssue.Error(contPath,
                        $"'continuar' solo va en pasos llevar, elegir, frotar, mantener o apuntar, y este es '{step.Kind}'."));
                    continue;
                }
                RequireLine(doc, referenced, issues, contPath + ".etiqueta",
                    string.IsNullOrEmpty(cont.Label) ? GuionDocument.ContinueEntry.DefaultLabel : cont.Label);
                bool hasMissing = step.Kind == "llevar" && cond?.Missing != null && cond.Missing.Count > 0;
                if (!string.IsNullOrEmpty(cont.IncompleteKey))
                    CheckErrorKey(step, issues, contPath + ".claveIncompleto", cont.IncompleteKey);
                else if (!hasMissing)
                    issues.Add(ValidationIssue.Error(contPath + ".claveIncompleto",
                        "Sin 'faltantes' en la condición, 'continuar' necesita 'claveIncompleto' (lo que el coach dice si falta algo)."));
            }
        }

        private static void ValidateDropLote5(GuionDocument doc, GuionDocument.StepEntry step, GuionDocument.ConditionEntry cond,
            string condPath, HashSet<string> referenced, List<string> used, List<ValidationIssue> issues)
        {
            if (step.Kind != "llevar")
            {
                issues.Add(ValidationIssue.Error(condPath, "'reacciones', 'faltantes' y 'distintas' solo van en un paso 'llevar'."));
                return;
            }
            var objects = cond.Objects ?? new List<string>();

            if (cond.Reactions != null)
            {
                AddOnce(used, "'reacciones'");
                foreach (var pair in cond.Reactions)
                {
                    string p = $"{condPath}.reacciones[{pair.Key}]";
                    if (!objects.Contains(pair.Key))
                        issues.Add(ValidationIssue.Error(p, $"El objeto '{pair.Key}' no está en 'objetos' de la condición."));
                    RequireLine(doc, referenced, issues, p, pair.Value);
                }
            }

            if (cond.Missing != null)
            {
                AddOnce(used, "'faltantes'");
                foreach (var pair in cond.Missing)
                {
                    string p = $"{condPath}.faltantes[{pair.Key}]";
                    if (!objects.Contains(pair.Key))
                        issues.Add(ValidationIssue.Error(p, $"El objeto '{pair.Key}' no está en 'objetos' de la condición."));
                    CheckErrorKey(step, issues, p, pair.Value);
                }
            }

            if (cond.Distinct != null)
            {
                AddOnce(used, "'distintas'");
                int zones = cond.Zones?.Count ?? 0;
                int count = cond.Count ?? 1;
                if (cond.Distinct == true && zones < count)
                    issues.Add(ValidationIssue.Warning(condPath + ".distintas",
                        $"Con 'distintas' cada soltado necesita una zona propia: hay {zones} zona(s) y 'cantidad' pide {count}, así que el paso no se puede completar."));
            }
        }

        #endregion

        #region 0.3 lote 1

        // Contrato 0.3 §2.1 y §2.5: `estado` de primer nivel, `alCompletar` en los pasos y `alElegir` en las opciones de
        // elegir. Un guion 0.1 o 0.2 que los usa recibe un aviso (§4, como en 0.2), pero se valida igual.
        private static void ValidateState03(GuionDocument doc, List<string> used, List<ValidationIssue> issues)
        {
            // La declaración de 'estado' la valida GuionStateRules (lote 2), que también conoce 'dia': una sola vez.
            if (doc.State != null && doc.State.Count > 0) AddOnce(used, "'estado'");

            for (int i = 0; i < doc.Steps.Count; i++)
            {
                var step = doc.Steps[i];
                if (step == null) continue;
                string path = StepPath(i, step);
                if (step.OnComplete != null)
                {
                    AddOnce(used, "'alCompletar'");
                    StateAuthoring.ParseEffects(step.OnComplete, doc, path + ".alCompletar", issues);
                }
                var options = step.Condition?.Options;
                if (options == null) continue;
                for (int k = 0; k < options.Count; k++)
                {
                    var option = options[k];
                    if (option?.OnChoose == null) continue;
                    AddOnce(used, "'alElegir'");
                    StateAuthoring.ParseEffects(option.OnChoose, doc, $"{path}.condicion.opciones[{k}].alElegir", issues);
                }
            }
        }

        // Integración del 0.3 (2026-10-31): un solo aviso de esquema para un guion 0.1 o 0.2 que usa algo de la 0.3, con
        // todo lo que usa (grupos, estado, efectos, guardas, avanzar, bloqueos), en vez de uno por lote.
        private static void WarnSchema03(GuionDocument doc, List<string> used, List<ValidationIssue> issues)
        {
            foreach (var feature in GuionStateRules.UsedFeatures(doc)) AddOnce(used, feature);
            if (doc.Locks != null && doc.Locks.Count > 0) AddOnce(used, "'bloqueos'");
            if (used.Count == 0 || (doc.Schema != GuionDocument.SchemaId && doc.Schema != GuionDocument.SchemaId02)) return;
            issues.Add(ValidationIssue.Warning("esquema",
                $"El guion declara '{doc.Schema}' y usa cosas de la 0.3 ({string.Join(", ", used)}): " +
                $"usa '{GuionDocument.SchemaId03}' en 'esquema'."));
        }

        #endregion
        #region 0.3 lote 4: elegir según el estado e indicadores (contrato-0.3.md §2.5 y §2.9)

        /// <summary>Cuántos indicadores caben en el panel del HUD; con más, aviso.</summary>
        public const int MaxIndicators04 = 4;

        // §2.5. Devuelve true si el paso usa 'segun' o 'valor' (y entonces lo valida entero aquí). Errores: 'segun' sin
        // declarar o numérica; mezclar 'valor' y 'resultado' (o 'valor' sin 'segun'); un valor de la variable sin opción
        // (estado sin respuesta correcta) o repetido; 'errorPorEstado' que falta, que no cubre todos los valores o con una
        // clave sin frase en 'errores'.
        private static bool ValidateChoiceByState04(GuionDocument doc, GuionDocument.StepEntry step,
            GuionDocument.ConditionEntry cond, string condPath, bool hasKeys, List<ValidationIssue> issues)
        {
            var options = cond.Options ?? new List<GuionDocument.ChoiceOptionEntry>();
            bool anyValue = false;
            foreach (var o in options) anyValue |= o != null && o.Value != null;
            bool bySegun = !string.IsNullOrEmpty(cond.ByState);
            if (!bySegun && !anyValue && cond.ErrorsByState == null) return false;

            if (hasKeys)
            {
                issues.Add(ValidationIssue.Error(condPath, "'segun' elige entre objetos ('opciones'), no entre teclas."));
                return true;
            }
            if (!bySegun)
            {
                issues.Add(ValidationIssue.Error(condPath + ".segun",
                    "Las opciones llevan 'valor' (o hay 'errorPorEstado') y falta 'segun': di qué variable decide la correcta, o usa 'resultado'."));
                return true;
            }

            var vars = GuionStateRules.Variables(doc);
            GuionStateRules.VariableInfo variable = null;
            if (!vars.TryGetValue(cond.ByState, out variable))
                issues.Add(ValidationIssue.Error(condPath + ".segun", $"'{cond.ByState}' no está en 'estado'."));
            else if (variable.IsNumber)
            {
                issues.Add(ValidationIssue.Error(condPath + ".segun",
                    $"'{cond.ByState}' es numérica: 'segun' necesita una variable de texto (con 'valores')."));
                variable = null;
            }

            var optionsPath = condPath + ".opciones";
            if (options.Count < 2)
                issues.Add(ValidationIssue.Error(optionsPath, "Elegir entre objetos necesita al menos dos opciones."));

            var seenObjects = new HashSet<string>();
            var covered = new HashSet<string>();
            for (int i = 0; i < options.Count; i++)
            {
                var option = options[i];
                string path = $"{optionsPath}[{i}]";
                if (option == null) { issues.Add(ValidationIssue.Error(path, "La opción está vacía.")); continue; }

                RequireObject(doc, issues, path + ".objeto", option.ObjectId, "Falta el objeto que se elige.",
                    new[] { "hotspot" }, "un objeto de tipo 'hotspot'");
                if (!string.IsNullOrEmpty(option.ObjectId) && !seenObjects.Add(option.ObjectId))
                    issues.Add(ValidationIssue.Error(path + ".objeto",
                        $"El objeto '{option.ObjectId}' está en dos opciones y no se sabría cuál vale."));

                if (option.Outcome != null)
                    issues.Add(ValidationIssue.Error(path + ".resultado",
                        "Con 'segun', las opciones llevan 'valor' y no 'resultado': la correcta la decide el estado."));
                if (!string.IsNullOrEmpty(option.SignalKey))
                    issues.Add(ValidationIssue.Warning(path + ".clave",
                        "Con 'segun', la corrección sale de 'errorPorEstado' y no de la opción: esta 'clave' se ignora."));

                if (string.IsNullOrEmpty(option.Value))
                {
                    issues.Add(ValidationIssue.Error(path + ".valor", $"Falta 'valor': el de '{cond.ByState}' para el que esta opción es la correcta."));
                    continue;
                }
                if (variable != null && !variable.Values.Contains(option.Value))
                    issues.Add(ValidationIssue.Error(path + ".valor",
                        $"'{option.Value}' no está en los valores de '{cond.ByState}' ({string.Join(", ", variable.Values)})."));
                else if (!covered.Add(option.Value))
                    issues.Add(ValidationIssue.Error(path + ".valor",
                        $"Dos opciones con el valor '{option.Value}': con ese estado habría dos correctas."));
            }

            if (variable != null)
                foreach (var value in variable.Values)
                    if (!covered.Contains(value))
                        issues.Add(ValidationIssue.Error(optionsPath,
                            $"Ninguna opción tiene 'valor' '{value}': con '{cond.ByState}' = '{value}' no habría respuesta correcta."));

            string errorsPath = condPath + ".errorPorEstado";
            if (cond.ErrorsByState == null || cond.ErrorsByState.Count == 0)
            {
                issues.Add(ValidationIssue.Error(errorsPath,
                    "Con 'segun', 'errorPorEstado' es obligatorio: la clave de la corrección por cada valor de la variable."));
                return true;
            }
            foreach (var pair in cond.ErrorsByState)
            {
                if (variable != null && !variable.Values.Contains(pair.Key))
                    issues.Add(ValidationIssue.Error($"{errorsPath}.{pair.Key}", $"'{pair.Key}' no está en los valores de '{cond.ByState}'."));
                CheckErrorKey(step, issues, $"{errorsPath}.{pair.Key}", pair.Value);
            }
            if (variable != null)
                foreach (var value in variable.Values)
                    if (!cond.ErrorsByState.ContainsKey(value))
                        issues.Add(ValidationIssue.Error(errorsPath,
                            $"Falta la clave de '{value}': 'errorPorEstado' cubre todos los valores de '{cond.ByState}'."));
            return true;
        }

        // §2.9. Errores: id que falta o repetido; 'estado' sin declarar; etiqueta sin frase; 'textos' que falta, incompleto
        // o con un valor que no es de la variable (de texto); 'textos' en una numérica, o 'unidad'/'decimales' en una de
        // texto; 'decimales' fuera de 0–6; 'desde'/'hasta' que no son paso ni grupo, o al revés. Avisos: etiqueta o texto que
        // no es 'soloTexto' (el panel lo muestra, no lo dice); más de cuatro indicadores.
        private static void ValidateIndicators04(GuionDocument doc, List<string> used, HashSet<string> referenced,
            List<ValidationIssue> issues)
        {
            foreach (var step in doc.Steps)
                if (step?.Condition != null && (!string.IsNullOrEmpty(step.Condition.ByState) || step.Condition.ErrorsByState != null))
                    AddOnce(used, "'segun' en 'elegir'");

            var indicators = doc.Indicators;
            if (indicators == null || indicators.Count == 0) return;
            AddOnce(used, "'indicadores'");

            if (indicators.Count > MaxIndicators04)
                issues.Add(ValidationIssue.Warning("indicadores",
                    $"Hay {indicators.Count} indicadores y el panel del HUD está pensado para {MaxIndicators04}: en el visor no se leerían bien."));

            var vars = GuionStateRules.Variables(doc);
            var ids = new HashSet<string>();
            for (int i = 0; i < indicators.Count; i++)
            {
                var ind = indicators[i];
                string path = $"indicadores[{(string.IsNullOrEmpty(ind?.Id) ? "#" + i : ind.Id)}]";
                if (ind == null) { issues.Add(ValidationIssue.Error(path, "El indicador está vacío.")); continue; }

                if (string.IsNullOrEmpty(ind.Id))
                    issues.Add(ValidationIssue.Error(path + ".id", "Falta el id del indicador."));
                else if (!ids.Add(ind.Id))
                    issues.Add(ValidationIssue.Error(path + ".id", $"El id de indicador '{ind.Id}' está repetido."));

                GuionStateRules.VariableInfo variable = null;
                if (string.IsNullOrEmpty(ind.Variable))
                    issues.Add(ValidationIssue.Error(path + ".estado", "Falta 'estado': la variable que muestra el indicador."));
                else if (!vars.TryGetValue(ind.Variable, out variable))
                    issues.Add(ValidationIssue.Error(path + ".estado", $"'{ind.Variable}' no está en 'estado'."));

                if (string.IsNullOrEmpty(ind.Label))
                    issues.Add(ValidationIssue.Error(path + ".etiqueta", "Falta 'etiqueta': el id de la frase 'soloTexto' que nombra el indicador."));
                else
                    RequireTextOnlyLine04(doc, referenced, issues, path + ".etiqueta", ind.Label);

                if (variable != null && !variable.IsNumber)
                {
                    if (ind.Texts == null || ind.Texts.Count == 0)
                        issues.Add(ValidationIssue.Error(path + ".textos",
                            $"'{ind.Variable}' es de texto: 'textos' es obligatorio, con una frase por valor ({string.Join(", ", variable.Values)})."));
                    else
                    {
                        foreach (var pair in ind.Texts)
                        {
                            if (!variable.Values.Contains(pair.Key))
                                issues.Add(ValidationIssue.Error($"{path}.textos.{pair.Key}", $"'{pair.Key}' no está en los valores de '{ind.Variable}'."));
                            if (string.IsNullOrEmpty(pair.Value))
                                issues.Add(ValidationIssue.Error($"{path}.textos.{pair.Key}", "El id de frase está vacío."));
                            else
                                RequireTextOnlyLine04(doc, referenced, issues, $"{path}.textos.{pair.Key}", pair.Value);
                        }
                        foreach (var value in variable.Values)
                            if (!ind.Texts.ContainsKey(value))
                                issues.Add(ValidationIssue.Error(path + ".textos", $"Falta el texto de '{value}': 'textos' cubre todos los valores de '{ind.Variable}'."));
                    }
                    if (!string.IsNullOrEmpty(ind.Unit) || ind.Decimals.HasValue)
                        issues.Add(ValidationIssue.Error(path + (ind.Decimals.HasValue ? ".decimales" : ".unidad"),
                            $"'unidad' y 'decimales' son de las numéricas, y '{ind.Variable}' es de texto: usa 'textos'."));
                }
                else if (variable != null && ind.Texts != null && ind.Texts.Count > 0)
                    issues.Add(ValidationIssue.Error(path + ".textos",
                        $"'{ind.Variable}' es numérica: no lleva 'textos' (usa 'unidad' y 'decimales')."));

                if (ind.Decimals.HasValue && (ind.Decimals.Value < 0 || ind.Decimals.Value > 6))
                    issues.Add(ValidationIssue.Error(path + ".decimales", $"'decimales' es {ind.Decimals.Value}: va de 0 a 6."));

                int from = 0, until = doc.Steps.Count - 1;
                if (!string.IsNullOrEmpty(ind.FromStepId) && (from = LockStepIndex(doc, ind.FromStepId, last: false)) < 0)
                    issues.Add(ValidationIssue.Error(path + ".desde", $"'{ind.FromStepId}' no es un paso ni un grupo del guion."));
                if (!string.IsNullOrEmpty(ind.UntilStepId) && (until = LockStepIndex(doc, ind.UntilStepId, last: true)) < 0)
                    issues.Add(ValidationIssue.Error(path + ".hasta", $"'{ind.UntilStepId}' no es un paso ni un grupo del guion."));
                else if (from >= 0 && until >= 0 && from > until)
                    issues.Add(ValidationIssue.Error(path + ".desde", $"'{ind.FromStepId}' va después de '{ind.UntilStepId}': el indicador no se vería nunca."));
            }
        }

        // Una frase que el panel muestra y no dice: tiene que existir; si no es 'soloTexto', aviso.
        private static void RequireTextOnlyLine04(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues,
            string path, string id)
        {
            referenced.Add(id);
            if (!doc.Lines.TryGetValue(id, out var line))
                issues.Add(ValidationIssue.Error(path, $"La frase '{id}' no está definida en 'lineas'."));
            else if (line != null && !line.TextOnly)
                issues.Add(ValidationIssue.Warning(path, $"La frase '{id}' no es 'soloTexto': el panel de indicadores la muestra, no la dice."));
        }

        /// <summary>
        /// 0.3 lote 4: el índice del paso con ese id o, si es un grupo, del primero (<paramref name="last"/> = false) o el
        /// último de sus pasos desenrollados; -1 si no está. Lo usa el importador para <c>desde</c>/<c>hasta</c> de los indicadores.
        /// </summary>
        public static int StepOrGroupIndex04(GuionDocument doc, string id, bool last) => LockStepIndex(doc, id, last);

        #endregion

    }
}
