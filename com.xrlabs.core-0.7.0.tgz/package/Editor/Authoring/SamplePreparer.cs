using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Prepara en el anfitrión todas las muestras del paquete (<c>Samples~/&lt;muestra&gt;/guion.json</c> + <c>colocacion.json</c>)
    /// sin pasar por la ventana: importa el guion, prepara la escena, importa la colocación y guarda. Es lo que la noche
    /// del 2026-10-17 se hacía con un script suelto en el Mac; ahora es del paquete porque la build del visor lo necesita
    /// (las escenas de las muestras entran en Build Settings al prepararse). Menú <c>Tools/XRLabs/Preparar las muestras</c>
    /// y, en batch, <see cref="PrepareAllFromCommandLine"/>.
    /// </summary>
    public static class SamplePreparer
    {
        public const string MenuPath = "Tools/XRLabs/Preparar las muestras del paquete";

        [MenuItem(MenuPath)]
        public static void PrepareAllMenu()
        {
            var ok = PrepareAll(out var summary);
            Debug.Log(summary);
            if (!Application.isBatchMode) EditorUtility.DisplayDialog("Muestras del paquete", summary, "Cerrar");
            if (!ok) Debug.LogError("[Muestras] Alguna muestra no se preparó; ver arriba.");
        }

        public static void PrepareAllFromCommandLine()
        {
            bool ok = PrepareAll(out var summary);
            Debug.Log(summary);
            Debug.Log(ok ? "MUESTRAS: OK" : "MUESTRAS: ERROR");
            EditorApplication.Exit(ok ? 0 : 1);
        }

        /// <summary>La carpeta <c>Samples~</c> del paquete, esté como carpeta, embebido o por Git.</summary>
        public static string SamplesRoot()
        {
            var info = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(GuionDocument).Assembly);
            string packageRoot = info != null ? info.resolvedPath : Path.GetFullPath("Packages/com.xrlabs.core");
            return Path.Combine(packageRoot, "Samples~");
        }

        public static bool PrepareAll(out string summary)
        {
            var root = SamplesRoot();
            if (!Directory.Exists(root)) { summary = "[Muestras] No hay carpeta Samples~ en " + root; return false; }
            bool ok = true;
            var lines = new System.Text.StringBuilder("[Muestras] ");
            foreach (var folder in Directory.GetDirectories(root))
            {
                var guionPath = Path.Combine(folder, "guion.json");
                if (!File.Exists(guionPath)) continue;
                bool one = PrepareOne(folder, out var note);
                ok &= one;
                lines.Append(Path.GetFileName(folder)).Append(": ").Append(note).Append(". ");
            }
            summary = lines.ToString();
            return ok;
        }

        /// <summary>Una muestra: guion → escena → colocación → guardar. Devuelve false y el motivo si algo tuvo errores.</summary>
        public static bool PrepareOne(string folder, out string note)
        {
            var guion = GuionDocument.Load(Path.Combine(folder, "guion.json"));
            CopyModels(folder, guion);
            var r1 = GuionImporter.Import(guion);
            if (r1.HasErrors) { note = "guion con errores: " + r1.Summary(); return false; }
            // Las voces que viajan con la muestra (Samples~/<muestra>/Voces/) entran a la biblioteca de frases importada.
            int voices = SampleVoices.Link(folder, guion);
            var r2 = ScenePreparer.Prepare(guion);
            if (r2.HasErrors) { note = "escena con errores: " + r2.Summary(); return false; }

            var colocacionPath = Path.Combine(folder, "colocacion.json");
            if (File.Exists(colocacionPath))
            {
                var scene = SceneManager.GetActiveScene();
                Transform placementRoot = null;
                foreach (var go in scene.GetRootGameObjects())
                    if (go.name == ScenePreparer.PlacementRootName) placementRoot = go.transform;
                if (placementRoot == null)
                {
                    var created = new GameObject(ScenePreparer.PlacementRootName);
                    SceneManager.MoveGameObjectToScene(created, scene);
                    placementRoot = created.transform;
                }
                var colocacion = ColocacionDocument.Load(colocacionPath);
                var r3 = ColocacionImporter.Import(colocacion, guion, placementRoot, GuionImporter.DefaultAssetsRoot);
                if (r3.HasErrors) { note = "colocación con errores: " + r3.Summary(); return false; }
                EditorSceneManager.SaveScene(scene);
            }
            note = "lista (" + ScenePreparer.ScenePathFor(guion) + (voices > 0 ? $", {voices} voces de la muestra" : "") + ")";
            return true;
        }

        /// <summary>
        /// Los modelos que trae la muestra (<c>Samples~/&lt;muestra&gt;/Modelos/</c>: FBX, materiales y un prefab por
        /// <c>modelo</c> del guion, con sus .meta) se copian a <c>Assets/Experiencias/&lt;experiencia&gt;/Modelos/</c>, que es
        /// donde los busca la colocación (arte-compostaje.md §5.1). Solo se copia lo que cambió, para no forzar reimportaciones.
        /// Lo que no está en la muestra (lo que el equipo dejó a mano en el anfitrión) no se toca.
        /// </summary>
        public static int CopyModels(string folder, GuionDocument guion)
        {
            var source = Path.Combine(folder, "Modelos");
            string experienceId = guion?.Experience?.Id;
            if (!Directory.Exists(source) || string.IsNullOrEmpty(experienceId)) return 0;
            var target = Path.Combine(GuionImporter.DefaultAssetsRoot, experienceId, "Modelos");
            int copied = 0;
            foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                var dest = Path.Combine(target, Path.GetRelativePath(source, file));
                if (File.Exists(dest) && new FileInfo(dest).Length == new FileInfo(file).Length
                    && File.ReadAllBytes(dest).AsSpan().SequenceEqual(File.ReadAllBytes(file))) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                File.Copy(file, dest, true);
                copied++;
            }
            if (copied > 0) AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            return copied;
        }
    }
}
