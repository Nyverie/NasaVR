using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using XRLabs.Core;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// 0.3 lote 1: lectura del estado del guion (contrato-0.3.md §2.1) y de las claves que lo escriben y lo leen
    /// (<c>alCompletar</c>, <c>alElegir</c>, <c>visibleSi</c>), pasadas a los tipos del runtime
    /// (<see cref="StateVariableDef"/>, <see cref="StateEffect"/>, <see cref="StateCondition"/>). La usan los validadores
    /// (con lista de hallazgos) y los importadores (sin ella: el fichero ya pasó la validación). Pura, sin Unity.
    /// </summary>
    public static class StateAuthoring
    {
        public static bool UsesState(GuionDocument doc) => doc?.State != null && doc.State.Count > 0;

        /// <summary>Las variables declaradas, ya resueltas (inicial por defecto incluido), en el orden del fichero.</summary>
        public static List<StateVariableDef> BuildDefinitions(GuionDocument doc)
        {
            var result = new List<StateVariableDef>();
            if (!UsesState(doc)) return result;
            foreach (var pair in doc.State)
            {
                var v = pair.Value;
                if (v == null) continue;
                StateVariableDef d;
                if (v.IsText)
                {
                    string initial = v.Initial != null && v.Initial.Type == JTokenType.String ? (string)v.Initial : null;
                    d = StateVariableDef.Text(pair.Key, initial, v.Values.ToArray());
                    if (string.IsNullOrEmpty(d.initialText)) d.initialText = d.EffectiveInitialText;
                }
                else
                {
                    d = StateVariableDef.Number(pair.Key, IsNumber(v.Initial) ? (double)v.Initial : 0);
                    if (v.Min.HasValue) { d.hasMin = true; d.min = v.Min.Value; }
                    if (v.Max.HasValue) { d.hasMax = true; d.max = v.Max.Value; }
                }
                d.register = v.Register;
                result.Add(d);
            }
            return result;
        }

        // La declaración de 'estado' la valida GuionStateRules (lote 2, que también conoce 'dia'): una sola vez para los dos
        // lotes (integración del 0.3, 2026-10-31).

        /// <summary>
        /// Pasa un mapa de efectos (<c>alCompletar</c>, <c>alElegir</c>) a <see cref="StateEffect"/>. Con
        /// <paramref name="issues"/>, anota los errores (variable sin declarar, valor fuera de <c>valores</c>, <c>sumar</c>
        /// en una de texto); sin ella, se salta lo inválido.
        /// </summary>
        public static List<StateEffect> ParseEffects(Dictionary<string, JToken> map, GuionDocument doc, string path,
            List<ValidationIssue> issues)
        {
            var result = new List<StateEffect>();
            if (map == null) return result;
            foreach (var pair in map)
            {
                string p = $"{path}.{pair.Key}";
                var v = FindVariable(doc, pair.Key);
                if (v == null) { issues?.Add(ValidationIssue.Error(p, $"La variable '{pair.Key}' no está declarada en 'estado'.")); continue; }
                var token = pair.Value;
                if (token == null) { issues?.Add(ValidationIssue.Error(p, "El efecto está vacío.")); continue; }

                if (token.Type == JTokenType.String)
                {
                    string text = (string)token;
                    if (!v.IsText) { issues?.Add(ValidationIssue.Error(p, $"'{pair.Key}' es numérica y el efecto es un texto.")); continue; }
                    if (!v.Values.Contains(text))
                    {
                        issues?.Add(ValidationIssue.Error(p, $"'{text}' no está en los valores de '{pair.Key}' ({string.Join(", ", v.Values)})."));
                        continue;
                    }
                    result.Add(StateEffect.SetText(pair.Key, text));
                }
                else if (IsNumber(token))
                {
                    if (v.IsText) { issues?.Add(ValidationIssue.Error(p, $"'{pair.Key}' es de texto y el efecto es un número.")); continue; }
                    result.Add(StateEffect.SetNumber(pair.Key, (double)token));
                }
                else if (token is JObject obj && obj.Count == 1 && obj.TryGetValue("sumar", out var add) && IsNumber(add))
                {
                    if (v.IsText) { issues?.Add(ValidationIssue.Error(p, $"'sumar' solo vale en una variable numérica y '{pair.Key}' es de texto.")); continue; }
                    result.Add(StateEffect.Add(pair.Key, (double)add));
                }
                else
                    issues?.Add(ValidationIssue.Error(p, "Un efecto es un texto, un número o { \"sumar\": n }."));
            }
            return result;
        }

        /// <summary>
        /// Pasa un mapa con forma de <c>si</c> (aquí, <c>visibleSi</c>) a <see cref="StateCondition"/>: valor, lista
        /// (cualquiera), <c>{ "mayor": n }</c>, <c>{ "menor": n }</c> o los dos. Mismos errores que los efectos.
        /// </summary>
        public static List<StateCondition> ParseConditions(Dictionary<string, JToken> map, GuionDocument doc, string path,
            List<ValidationIssue> issues)
        {
            var result = new List<StateCondition>();
            if (map == null) return result;
            foreach (var pair in map)
            {
                string p = $"{path}.{pair.Key}";
                var v = FindVariable(doc, pair.Key);
                if (v == null) { issues?.Add(ValidationIssue.Error(p, $"La variable '{pair.Key}' no está declarada en el 'estado' del guion.")); continue; }
                var token = pair.Value;
                var list = token is JArray array ? new List<JToken>(array) : token != null && token.Type != JTokenType.Object ? new List<JToken> { token } : null;

                if (list != null)
                {
                    var cond = new StateCondition { variable = pair.Key };
                    bool ok = list.Count > 0;
                    foreach (var item in list)
                    {
                        if (v.IsText && item.Type == JTokenType.String && v.Values.Contains((string)item)) cond.anyText.Add((string)item);
                        else if (!v.IsText && IsNumber(item)) cond.anyNumber.Add((double)item);
                        else
                        {
                            ok = false;
                            issues?.Add(ValidationIssue.Error(p, v.IsText
                                ? $"'{item}' no está en los valores de '{pair.Key}' ({string.Join(", ", v.Values)})."
                                : $"'{pair.Key}' es numérica: '{item}' no es un número."));
                        }
                    }
                    if (list.Count == 0) issues?.Add(ValidationIssue.Error(p, "La lista de valores está vacía."));
                    if (ok) result.Add(cond);
                }
                else if (token is JObject obj)
                {
                    if (v.IsText) { issues?.Add(ValidationIssue.Error(p, $"'mayor' y 'menor' solo valen en una numérica y '{pair.Key}' es de texto.")); continue; }
                    bool hasG = obj.TryGetValue("mayor", out var g) && IsNumber(g);
                    bool hasL = obj.TryGetValue("menor", out var l) && IsNumber(l);
                    if (!hasG && !hasL || obj.Count != (hasG ? 1 : 0) + (hasL ? 1 : 0))
                    {
                        issues?.Add(ValidationIssue.Error(p, "La comparación es { \"mayor\": n }, { \"menor\": n } o las dos."));
                        continue;
                    }
                    result.Add(StateCondition.Between(pair.Key, hasG ? (double?)(double)g : null, hasL ? (double?)(double)l : null));
                }
                else
                    issues?.Add(ValidationIssue.Error(p, "La condición está vacía."));
            }
            return result;
        }

        public static GuionDocument.StateVarEntry FindVariable(GuionDocument doc, string name) =>
            doc?.State != null && name != null && doc.State.TryGetValue(name, out var v) ? v : null;

        private static bool IsNumber(JToken token) =>
            token != null && (token.Type == JTokenType.Integer || token.Type == JTokenType.Float);
    }
}
