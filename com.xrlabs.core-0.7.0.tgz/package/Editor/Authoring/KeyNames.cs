using UnityEngine;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Nombres de tecla del guion ("1" a "9", "a" a "z", "espacio", "enter") a <see cref="KeyCode"/>. Función pura, con test:
    /// la usan el validador (tecla no admitida es error) y el importador (para escribir las condiciones de teclado).
    /// Documentation~/autoria.md §3.4. Se admite exactamente lo que dice el esquema, en minúsculas.
    /// </summary>
    public static class KeyNames
    {
        /// <summary>Convierte el nombre de tecla del guion. False (y <see cref="KeyCode.None"/>) si no está admitido.</summary>
        public static bool ToKeyCode(string name, out KeyCode code)
        {
            code = KeyCode.None;
            if (string.IsNullOrEmpty(name)) return false;

            if (name == "espacio")
            {
                code = KeyCode.Space;
                return true;
            }

            if (name == "enter")
            {
                code = KeyCode.Return;
                return true;
            }

            if (name.Length != 1) return false;

            char c = name[0];
            if (c >= '1' && c <= '9')
            {
                code = KeyCode.Alpha1 + (c - '1');
                return true;
            }

            if (c >= 'a' && c <= 'z')
            {
                code = KeyCode.A + (c - 'a');
                return true;
            }

            return false;
        }
    }
}
