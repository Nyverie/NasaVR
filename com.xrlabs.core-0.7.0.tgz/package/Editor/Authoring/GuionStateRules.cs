using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;
using XRLabs.Core;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// 0.3 lote 2 (contrato-0.3.md §2.1–§2.3): reglas del estado del guion que comparten el validador y el importador.
    /// Valida 'estado' (la forma de las variables numéricas y de texto), 'si', 'alIniciar', 'alError', 'avanzar' y los
    /// ids de frase con <c>{variable}</c>; y resuelve los valores crudos del fichero a <see cref="StateCondition"/>,
    /// <see cref="StateEffect"/> y <see cref="StateVariableDef"/>. Pura: sin Unity, sin disco.
    /// </summary>
    public static class GuionStateRules
    {
        /// <summary>La variable que suma 'avanzar'; la declara el importador (numérica, desde 0).</summary>
        public const string DayVariable = StepSystem.DayVariable;

        /// <summary>El fundido de 'avanzar' por defecto, en segundos.</summary>
        public const float DefaultFade = 1.5f;

        /// <summary>Cuántos ids puede dar un id con {variable} al expandirse: más es casi seguro un error del guion.</summary>
        private const int MaxExpansions = 500;

        private static readonly Regex VariableName = new(@"^[a-z0-9][a-z0-9-]*$", RegexOptions.CultureInvariant);
        private static readonly Regex Placeholder = new(@"\{([^{}]*)\}", RegexOptions.CultureInvariant);

        /// <summary>Lo que el validador sabe de una variable declarada (o implícita, como 'dia').</summary>
        public sealed class VariableInfo
        {
            public string Name;
            public bool IsNumber;
            public List<string> Values = new();
        }

        // ── Declaraciones ─────────────────────────────────────────────────────

        /// <summary>True si el guion tiene algún paso 'avanzar'.</summary>
        public static bool UsesTimeAdvance(GuionDocument doc)
        {
            if (doc?.Steps == null) return false;
            foreach (var s in doc.Steps)
                if (s != null && s.IsTimeAdvance) return true;
            return false;
        }

        /// <summary>Las variables del guion: las de 'estado' bien formadas y 'dia' si hay un 'avanzar' y no está declarada.</summary>
        public static Dictionary<string, VariableInfo> Variables(GuionDocument doc)
        {
            var result = new Dictionary<string, VariableInfo>();
            if (doc?.State != null)
                foreach (var pair in doc.State)
                {
                    if (string.IsNullOrEmpty(pair.Key) || pair.Value == null) continue;
                    var info = new VariableInfo { Name = pair.Key, IsNumber = !pair.Value.IsText };
                    if (pair.Value.Values != null) info.Values.AddRange(pair.Value.Values);
                    result[pair.Key] = info;
                }
            if (UsesTimeAdvance(doc) && !result.ContainsKey(DayVariable))
                result[DayVariable] = new VariableInfo { Name = DayVariable, IsNumber = true };
            return result;
        }

        /// <summary>
        /// El estado inicial que va en la SimulationSequence: las variables de 'estado' y 'dia' (numérica, desde 0) si hay
        /// algún 'avanzar' y no se declaró.
        /// </summary>
        public static List<StateVariableDef> ToDefinitions(GuionDocument doc)
        {
            // Las de 'estado' las resuelve el lote 1 (StateAuthoring, con el inicial por defecto de una de texto): una sola
            // lectura de la declaración para los dos lotes.
            var result = StateAuthoring.BuildDefinitions(doc);
            if (UsesTimeAdvance(doc) && result.Find(d => d.name == DayVariable) == null)
                result.Add(StateVariableDef.Number(DayVariable, 0));
            return result;
        }

        // ── Resolución para el importador ─────────────────────────────────────

        /// <summary>'alIniciar' (o los efectos de una clave de 'alError') ya resueltos. Lo mal formado se omite.</summary>
        public static List<StateEffect> ToEffects(Dictionary<string, JToken> raw)
        {
            var result = new List<StateEffect>();
            if (raw == null) return result;
            foreach (var pair in raw)
            {
                var token = pair.Value;
                if (token == null) continue;
                if (token.Type == JTokenType.String) result.Add(StateEffect.SetText(pair.Key, (string)token));
                else if (IsNumber(token)) result.Add(StateEffect.SetNumber(pair.Key, (double)token));
                else if (token is JObject obj && IsNumber(obj["sumar"])) result.Add(StateEffect.Add(pair.Key, (double)obj["sumar"]));
            }
            return result;
        }

        /// <summary>'si' ya resuelto, una condición por variable. Lo mal formado se omite.</summary>
        public static List<StateCondition> ToConditions(Dictionary<string, JToken> raw)
        {
            var result = new List<StateCondition>();
            if (raw == null) return result;
            foreach (var pair in raw)
            {
                var token = pair.Value;
                if (token == null) continue;
                switch (token)
                {
                    case JValue _ when token.Type == JTokenType.String:
                        result.Add(StateCondition.TextIn(pair.Key, (string)token));
                        break;
                    case JValue _ when IsNumber(token):
                        result.Add(StateCondition.NumberIn(pair.Key, (double)token));
                        break;
                    case JArray array:
                    {
                        var c = new StateCondition { variable = pair.Key };
                        foreach (var item in array)
                        {
                            if (item.Type == JTokenType.String) c.anyText.Add((string)item);
                            else if (IsNumber(item)) c.anyNumber.Add((double)item);
                        }
                        result.Add(c);
                        break;
                    }
                    case JObject obj:
                    {
                        double? greater = IsNumber(obj["mayor"]) ? (double)obj["mayor"] : null;
                        double? less = IsNumber(obj["menor"]) ? (double)obj["menor"] : null;
                        result.Add(StateCondition.Between(pair.Key, greater, less));
                        break;
                    }
                }
            }
            return result;
        }

        // ── Validación ────────────────────────────────────────────────────────

        /// <summary>Lo que el guion usa de la 0.3 de este lote (para el aviso de un 0.1/0.2 que lo usa).</summary>
        public static List<string> UsedFeatures(GuionDocument doc)
        {
            var used = new List<string>();
            if (doc?.State != null && doc.State.Count > 0) used.Add("'estado'");
            if (doc?.Steps == null) return used;
            foreach (var s in doc.Steps)
            {
                if (s == null) continue;
                if (s.Guard != null && s.Guard.Count > 0 && !used.Contains("'si'")) used.Add("'si'");
                if (s.OnStart != null && s.OnStart.Count > 0 && !used.Contains("'alIniciar'")) used.Add("'alIniciar'");
                if (s.OnError != null && s.OnError.Count > 0 && !used.Contains("'alError'")) used.Add("'alError'");
                if (s.IsTimeAdvance && !used.Contains("paso 'avanzar'")) used.Add("paso 'avanzar'");
            }
            return used;
        }

        /// <summary>Todas las reglas del estado de este lote. Añade a <paramref name="referenced"/> las frases que usa.</summary>
        public static void Validate(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues)
        {
            if (doc == null) return;

            // El aviso de un 0.1/0.2 que usa esto lo da GuionValidator.WarnSchema03 con UsedFeatures, junto con lo de los
            // demás lotes (integración del 0.3, 2026-10-31).
            ValidateDeclarations(doc, issues);
            var vars = Variables(doc);

            for (int i = 0; i < doc.Steps.Count; i++)
            {
                var step = doc.Steps[i];
                if (step == null) continue;
                var path = $"pasos[{(string.IsNullOrEmpty(step.Id) ? "#" + i : step.Id)}]";

                ValidateGuard(vars, step.Guard, path + ".si", issues);
                ValidateEffects(vars, step.OnStart, path + ".alIniciar", issues);
                if (step.OnError != null)
                    foreach (var pair in step.OnError)
                    {
                        var errPath = $"{path}.alError.{pair.Key}";
                        if (step.ErrorLines == null || !step.ErrorLines.ContainsKey(pair.Key))
                            issues.Add(ValidationIssue.Warning(errPath,
                                $"'alError' usa la clave '{pair.Key}' y el paso no la tiene en 'errores': nunca se aplicará."));
                        ValidateEffects(vars, pair.Value, errPath, issues);
                    }

                ValidateTimeAdvance(doc, step, path, referenced, issues);
            }
        }

        private static void ValidateDeclarations(GuionDocument doc, List<ValidationIssue> issues)
        {
            if (doc.State == null) return;
            foreach (var pair in doc.State)
            {
                var path = $"estado.{pair.Key}";
                var v = pair.Value;
                if (string.IsNullOrEmpty(pair.Key) || !VariableName.IsMatch(pair.Key))
                    issues.Add(ValidationIssue.Error(path,
                        $"El nombre de variable '{pair.Key}' solo puede llevar minúsculas, cifras y guion, y empezar por letra o cifra."));
                if (v == null)
                {
                    issues.Add(ValidationIssue.Error(path, "La variable está vacía: dale 'valores' (de texto) o 'inicial' numérico."));
                    continue;
                }

                if (v.IsText)
                {
                    if (pair.Key == DayVariable)
                        issues.Add(ValidationIssue.Error(path,
                            "'dia' la declara el importador como numérica (la suma 'avanzar'): no la declares de texto."));
                    if (v.Values.Count < 2)
                        issues.Add(ValidationIssue.Error(path + ".valores", "Una variable de texto necesita 2 valores o más."));
                    var seen = new HashSet<string>();
                    foreach (var value in v.Values)
                        if (string.IsNullOrEmpty(value))
                            issues.Add(ValidationIssue.Error(path + ".valores", "Hay un valor vacío: cada valor es un texto con algo."));
                        else if (!seen.Add(value))
                            issues.Add(ValidationIssue.Error(path + ".valores", $"El valor '{value}' está repetido."));
                    if (v.Initial != null && v.Initial.Type != JTokenType.Null)
                    {
                        if (v.Initial.Type != JTokenType.String || !v.Values.Contains((string)v.Initial))
                            issues.Add(ValidationIssue.Error(path + ".inicial",
                                $"El valor inicial '{v.Initial}' no está en 'valores' ({string.Join(", ", v.Values)})."));
                    }
                    if (v.Min.HasValue || v.Max.HasValue)
                        issues.Add(ValidationIssue.Error(path, "'min' y 'max' solo valen en variables numéricas."));
                }
                else
                {
                    if (!IsNumber(v.Initial))
                        issues.Add(ValidationIssue.Error(path + ".inicial",
                            "Una variable numérica necesita 'inicial' numérico (o 'valores' si es de texto)."));
                    if (v.Min.HasValue && v.Max.HasValue && v.Min.Value > v.Max.Value)
                        issues.Add(ValidationIssue.Error(path, $"'min' ({v.Min}) es mayor que 'max' ({v.Max})."));
                }
            }
        }

        private static void ValidateGuard(Dictionary<string, VariableInfo> vars, Dictionary<string, JToken> guard, string path,
            List<ValidationIssue> issues)
        {
            if (guard == null) return;
            foreach (var pair in guard)
            {
                var p = $"{path}.{pair.Key}";
                if (!vars.TryGetValue(pair.Key, out var v))
                {
                    issues.Add(ValidationIssue.Error(p, $"La variable '{pair.Key}' no está declarada en 'estado'."));
                    continue;
                }
                var token = pair.Value;
                if (token is JObject obj)
                {
                    if (!v.IsNumber)
                    {
                        issues.Add(ValidationIssue.Error(p, $"'mayor' y 'menor' solo valen en variables numéricas; '{pair.Key}' es de texto."));
                        continue;
                    }
                    bool any = false;
                    foreach (var prop in obj.Properties())
                    {
                        if (prop.Name != "mayor" && prop.Name != "menor")
                            issues.Add(ValidationIssue.Error($"{p}.{prop.Name}", $"'{prop.Name}' no existe en 'si': usa 'mayor' o 'menor'."));
                        else if (!IsNumber(prop.Value))
                            issues.Add(ValidationIssue.Error($"{p}.{prop.Name}", $"'{prop.Name}' tiene que ser un número."));
                        else any = true;
                    }
                    if (!any)
                        issues.Add(ValidationIssue.Error(p, "La condición está vacía: pon 'mayor', 'menor' o los dos."));
                    else if (IsNumber(obj["mayor"]) && IsNumber(obj["menor"]) && (double)obj["mayor"] >= (double)obj["menor"])
                        issues.Add(ValidationIssue.Error(p, "'mayor' no es menor que 'menor': la condición no se cumple nunca."));
                    continue;
                }
                if (token is JArray array)
                {
                    if (array.Count == 0)
                        issues.Add(ValidationIssue.Error(p, "La lista está vacía: el paso no se haría nunca."));
                    foreach (var item in array) CheckValue(v, item, p, issues);
                    continue;
                }
                CheckValue(v, token, p, issues);
            }
        }

        private static void ValidateEffects(Dictionary<string, VariableInfo> vars, Dictionary<string, JToken> effects, string path,
            List<ValidationIssue> issues)
        {
            if (effects == null) return;
            foreach (var pair in effects)
            {
                var p = $"{path}.{pair.Key}";
                if (!vars.TryGetValue(pair.Key, out var v))
                {
                    issues.Add(ValidationIssue.Error(p, $"La variable '{pair.Key}' no está declarada en 'estado'."));
                    continue;
                }
                if (pair.Value is JObject obj)
                {
                    if (!v.IsNumber)
                        issues.Add(ValidationIssue.Error(p, $"'sumar' solo vale en variables numéricas; '{pair.Key}' es de texto."));
                    else if (!IsNumber(obj["sumar"]) || obj.Count != 1)
                        issues.Add(ValidationIssue.Error(p, "Un efecto con llaves solo puede ser { \"sumar\": número }."));
                    continue;
                }
                CheckValue(v, pair.Value, p, issues);
            }
        }

        // Un valor suelto (en 'si', en una lista de 'si' o en un efecto): texto de 'valores' o número, según la variable.
        private static void CheckValue(VariableInfo v, JToken token, string path, List<ValidationIssue> issues)
        {
            if (v.IsNumber)
            {
                if (!IsNumber(token))
                    issues.Add(ValidationIssue.Error(path, $"'{v.Name}' es numérica y el valor '{token}' no es un número."));
                return;
            }
            if (token == null || token.Type != JTokenType.String)
                issues.Add(ValidationIssue.Error(path, $"'{v.Name}' es de texto y el valor '{token}' no es texto."));
            else if (!v.Values.Contains((string)token))
                issues.Add(ValidationIssue.Error(path,
                    $"El valor '{token}' no está en los 'valores' de '{v.Name}' ({string.Join(", ", v.Values)})."));
        }

        private static void ValidateTimeAdvance(GuionDocument doc, GuionDocument.StepEntry step, string path,
            HashSet<string> referenced, List<ValidationIssue> issues)
        {
            if (!step.IsTimeAdvance)
            {
                if (step.Days.HasValue || !string.IsNullOrEmpty(step.Label) || step.Fade.HasValue)
                    issues.Add(ValidationIssue.Warning(path,
                        "'dias', 'etiqueta' y 'fundido' solo valen en pasos 'avanzar': aquí no hacen nada."));
                return;
            }

            if (!step.Days.HasValue)
                issues.Add(ValidationIssue.Error(path + ".dias", "Un paso 'avanzar' necesita 'dias' (entero, 1 o más)."));
            else if (step.Days.Value < 1 || System.Math.Abs(step.Days.Value - System.Math.Round(step.Days.Value)) > 1e-9)
                issues.Add(ValidationIssue.Error(path + ".dias",
                    $"'dias' es {step.Days.Value.ToString(CultureInfo.InvariantCulture)}: tiene que ser un entero, 1 o más."));

            if (step.Condition != null)
                issues.Add(ValidationIssue.Error(path + ".condicion", "Un paso 'avanzar' no lleva 'condicion': avanza solo."));

            if (step.Fade.HasValue && (step.Fade.Value < 0f || step.Fade.Value > 5f))
                issues.Add(ValidationIssue.Error(path + ".fundido", $"'fundido' es {step.Fade.Value}: va de 0 a 5 segundos."));

            if (!string.IsNullOrEmpty(step.Label))
            {
                referenced.Add(step.Label);
                if (!doc.Lines.TryGetValue(step.Label, out var line))
                    issues.Add(ValidationIssue.Error(path + ".etiqueta", $"La frase '{step.Label}' no está definida en 'lineas'."));
                else
                {
                    if (line != null && !line.TextOnly)
                        issues.Add(ValidationIssue.Warning(path + ".etiqueta",
                            $"La etiqueta '{step.Label}' no es 'soloTexto': la cortinilla solo la muestra, no la dice."));
                    var vars = Variables(doc);
                    foreach (var language in GuionValidator.EffectiveLanguages(doc))
                        CheckTextPlaceholders(vars, line?.TextFor(language), $"lineas[{step.Label}].{language}", issues);
                }
            }
        }

        // {variable} dentro del texto de una frase soloTexto: la variable tiene que existir (cualquier tipo: se ve su valor).
        private static void CheckTextPlaceholders(Dictionary<string, VariableInfo> vars, string text, string path,
            List<ValidationIssue> issues)
        {
            if (string.IsNullOrEmpty(text)) return;
            foreach (Match m in Placeholder.Matches(text))
                if (!vars.ContainsKey(m.Groups[1].Value))
                    issues.Add(ValidationIssue.Error(path, $"El texto usa '{{{m.Groups[1].Value}}}' y esa variable no está en 'estado'."));
        }

        // ── {variable} en ids de frase (§2.2) ─────────────────────────────────

        /// <summary>True si el id de frase lleva <c>{variable}</c>.</summary>
        public static bool IsTemplate(string id) => !string.IsNullOrEmpty(id) && id.IndexOf('{') >= 0;

        /// <summary>
        /// Un id de frase con <c>{variable}</c>: cada variable tiene que existir y ser de texto (una numérica que no es contador
        /// no vale; los contadores llegan con los grupos, lote 3), y cada id expandido tiene que estar en 'lineas'.
        /// </summary>
        public static void RequireTemplateLine(GuionDocument doc, HashSet<string> referenced, List<ValidationIssue> issues,
            string path, string id)
        {
            var vars = Variables(doc);
            var names = new List<string>();
            foreach (Match m in Placeholder.Matches(id))
            {
                var name = m.Groups[1].Value;
                if (!vars.TryGetValue(name, out var v))
                {
                    issues.Add(ValidationIssue.Error(path, $"El id '{id}' usa '{{{name}}}' y esa variable no está en 'estado'."));
                    return;
                }
                if (v.IsNumber)
                {
                    issues.Add(ValidationIssue.Error(path,
                        $"El id '{id}' usa '{{{name}}}', que es numérica: en un id de frase solo valen variables de texto (y los contadores de un grupo)."));
                    return;
                }
                if (!names.Contains(name)) names.Add(name);
            }

            var expanded = Expand(id, names, vars);
            if (expanded == null)
            {
                issues.Add(ValidationIssue.Error(path, $"El id '{id}' da más de {MaxExpansions} frases al expandirse."));
                return;
            }
            foreach (var concrete in expanded)
            {
                referenced.Add(concrete);
                if (!doc.Lines.ContainsKey(concrete))
                    issues.Add(ValidationIssue.Error(path, $"El id '{id}' necesita la frase '{concrete}' y no está definida en 'lineas'."));
            }
        }

        /// <summary>Los ids concretos de un id con {variable}, uno por combinación de valores; null si son demasiados.</summary>
        public static List<string> Expand(string id, List<string> names, Dictionary<string, VariableInfo> vars)
        {
            var result = new List<string> { id };
            foreach (var name in names)
            {
                var next = new List<string>();
                foreach (var partial in result)
                    foreach (var value in vars[name].Values)
                        next.Add(partial.Replace("{" + name + "}", value));
                if (next.Count > MaxExpansions) return null;
                result = next;
            }
            return result;
        }

        private static bool IsNumber(JToken token) =>
            token != null && (token.Type == JTokenType.Integer || token.Type == JTokenType.Float);
    }
}
