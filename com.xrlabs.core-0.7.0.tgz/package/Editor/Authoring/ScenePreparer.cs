using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using XRLabs.Coach;
using XRLabs.Core;
using XRLabs.Interactions;
using XRLabs.Networking;
using XRLabs.Platform;
using XRLabs.UI;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// «Preparar escena» (Documentation~/autoria.md §10.1): deja lista, a partir de un guion ya importado, la escena que la
    /// persona recorre en el Editor en modo plano, para que no tenga que armarla en el Inspector (D19). Crea o abre
    /// <c>&lt;assetsRoot&gt;/&lt;id&gt;/Escenas/&lt;escena&gt;.unity</c> con <c>[Simulation]</c> (los siete sistemas con la
    /// secuencia y la biblioteca de frases asignadas), <c>[Session]</c>, <c>[ApiTelemetry]</c> (el puente de la telemetría al API),
    /// <c>[Colocacion]</c>, <c>[Coach]</c> (el holograma con su
    /// director) y la cámara a 1,6 m con el driver de interacción plano; crea el <c>ApiSettings</c> del Menu si falta; y pone el Menu y la escena en Build
    /// Settings. Es idempotente: cada objeto y componente se busca antes de crearse y las referencias se reescriben
    /// siempre. Los campos privados se escriben con SerializedObject, como lo haría el Inspector, para no tocar el runtime
    /// (D8). No usa red.
    /// </summary>
    public static class ScenePreparer
    {
        public const string SimulationRootName = "[Simulation]";
        public const string SessionRootName = "[Session]";
        public const string PlacementRootName = "[Colocacion]";
        public const string CoachRootName = "[Coach]";
        public const string HudRootName = SubtitleHudBuilder.RootName;
        /// <summary>La raíz del PlatformBootstrapper que elige rig XR o cámara plana al arrancar (lote del visor).</summary>
        public const string PlatformRootName = "[Platform]";
        /// <summary>El panel de depuración de siempre (SimDebugHUD + SimulationDebugger): F1 panel, F2 completar el paso, F4 saltar a un paso, F7 registro. Solo en pantalla (IMGUI).</summary>
        public const string DebugRootName = "[Debug]";
        /// <summary>
        /// La raíz del ApiTelemetryBridge, solo en ella: el puente que lleva la sesión, los errores de los pasos y el cierre
        /// al cliente del API (el real o el mock). El mismo nombre que pedía a mano telemetria-extremo-a-extremo.md §3.3.
        /// </summary>
        public const string ApiTelemetryRootName = "[ApiTelemetry]";
        /// <summary>El rig XRI del paquete (D23), instanciado bajo [Platform] y apagado en edición: el bootstrapper lo enciende en el visor.</summary>
        public const string RigPrefabGuid = "ff4591db79362394f8dac13b9caab05b";
        public const string RigPrefabPath = "Packages/com.xrlabs.core/Runtime/MenuXRI/XRLabsRig.prefab";
        public const string RigInstanceName = "XRLabsRig";

        /// <summary>El hijo de <c>[Coach]</c> que es la instancia del prefab del holograma.</summary>
        public const string CoachInstanceName = "Coach";

        /// <summary>
        /// El prefab del holograma del coach, en el paquete (contrato-0.2.md §8). Se busca primero por GUID, que no cambia
        /// si el paquete llega como carpeta, embebido o por Git, y si no, por la ruta de <c>Packages/</c>.
        /// </summary>
        public const string CoachPrefabGuid = "c0c74d895bffc4a2b9dca4b6ddf768a6";
        public const string CoachPrefabPath = "Packages/com.xrlabs.core/Runtime/Coach/Hologram/HologramCoach.prefab";

        /// <summary>La escena Menu del paquete: login, menú y lista de experiencias (D9: índice 0 de Build Settings).</summary>
        public const string MenuScenePath = "Packages/com.xrlabs.core/Runtime/Menu/Menu.unity";
        public const string MenuSceneName = "Menu";

        /// <summary>
        /// El mismo Menu sin el SDK de Meta, generado por <c>Tools/XRLabs/Generar Menu XRI</c> (D23, Documentation~/menu-xri.md).
        /// Tiene el mismo nombre de escena, así que el flujo por nombre no cambia; un proyecto pone solo una de las dos.
        /// </summary>
        public const string MenuXriScenePath = "Packages/com.xrlabs.core/Runtime/MenuXRI/Menu.unity";

        /// <summary>El paquete del SDK de Meta que decide cuál de los dos Menu va al índice 0.</summary>
        public const string MetaSdkPackageName = "com.meta.xr.sdk.core";

        /// <summary>Donde el tutorial pide el ApiSettings del proyecto.</summary>
        public const string DefaultApiSettingsPath = "Assets/Config/ApiSettings.asset";

        /// <summary>
        /// El GUID con que la escena Menu del paquete referencia su ApiSettings (README.md, «Escena de Menú»). Un asset
        /// con ese GUID es el que el ApiClient del Menu encuentra solo.
        /// </summary>
        public const string MenuApiSettingsGuid = "35d5b021ba32f794481c31931cd4198b";

        public const float EyeHeight = 1.6f;

        /// <summary>
        /// Prepara la escena de la experiencia. Precondición: el guion ya importado (existen <c>Secuencias/&lt;id&gt;.asset</c>
        /// y <c>Frases/&lt;id&gt;.asset</c>); si no, error en el informe y no toca nada. <paramref name="apiSettingsPath"/>
        /// es donde va el ApiSettings del Menu si falta: el valor por defecto es el de los proyectos consumidores; los tests
        /// pasan una ruta propia para no tocar la del anfitrión.
        /// </summary>
        public static ImportReport Prepare(GuionDocument guion, string assetsRoot = GuionImporter.DefaultAssetsRoot,
            string apiSettingsPath = DefaultApiSettingsPath, bool? hasMetaSdk = null)
        {
            var report = new ImportReport();
            guion = GuionExpander.Expand(guion);   // 0.3 lote 3: la escena ve los pasos desenrollados, como el importador

            if (!TryResolve(guion, assetsRoot, report, out var sequence, out var library, out var scenePath))
                return report;

            // La persona puede tener abierta otra escena sin guardar: se le pregunta antes de cambiarla.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                report.Error("Se canceló: hay una escena abierta con cambios sin guardar y no se guardó.");
                return report;
            }

            try
            {
                var scene = OpenOrCreateScene(scenePath, report);

                // 2026-10-10: los assets que acaba de crear el importador del guion se reimportan cuando la escena nueva se
                // guarda (AssetDatabase.Refresh), y la instancia cargada antes queda destruida (MissingReferenceException en
                // el sello). Se vuelven a cargar por ruta ya con la escena en su sitio.
                AssetDatabase.Refresh();
                sequence = AssetDatabase.LoadAssetAtPath<SimulationSequence>(AssetPath(assetsRoot, guion.Experience.Id, "Secuencias"));
                library = AssetDatabase.LoadAssetAtPath<LineLibrary>(AssetPath(assetsRoot, guion.Experience.Id, "Frases"));
                if (sequence == null || library == null)
                    throw new InvalidOperationException("la secuencia o la biblioteca de frases desaparecieron al crear la escena");

                PrepareSimulation(scene, guion, sequence, library, report);
                PrepareLocks(scene, sequence, report);   // 0.3 lote 6
                PrepareSession(scene, guion, report);
                PrepareApiTelemetry(scene, report);   // lo que SessionManager necesita para abrir y cerrar la sesión
                PreparePlacementRoot(scene, guion, report);
                PrepareCamera(scene, report);
                PreparePlatform(scene, report);   // después de la cámara: es el rig plano del bootstrapper
                PrepareCoach(scene, report);   // después de [Simulation] y de la cámara: enlaza a las dos
                PrepareHud(scene, report);
                PrepareDebug(scene, report);
                EntornoBuilder.Prepare(scene, guion.Experience.Id, assetsRoot, report);   // suelo, planta y sol si la muestra trae Entorno/
                EnsureApiSettings(apiSettingsPath, report);
                EnsureBuildSettings(scenePath, report, hasMetaSdk ?? ProjectHasMetaSdk());

                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                    report.Error("No se pudo guardar la escena " + scenePath + ".");
                AssetDatabase.SaveAssets();
            }
            catch (Exception ex)
            {
                report.Error("Preparar la escena se interrumpió: " + ex);
            }
            return report;
        }

        /// <summary>La ruta del asset de una carpeta de la experiencia (<c>Secuencias</c>, <c>Frases</c>): <c>&lt;assetsRoot&gt;/&lt;id&gt;/&lt;carpeta&gt;/&lt;id&gt;.asset</c>.</summary>
        private static string AssetPath(string assetsRoot, string id, string folder)
        {
            var root = (string.IsNullOrEmpty(assetsRoot) ? GuionImporter.DefaultAssetsRoot : assetsRoot).Replace('\\', '/').TrimEnd('/');
            return $"{root}/{id}/{folder}/{id}.asset";
        }

        /// <summary>La ruta de la escena de una experiencia: <c>&lt;assetsRoot&gt;/&lt;id&gt;/Escenas/&lt;escena&gt;.unity</c>.</summary>
        public static string ScenePathFor(GuionDocument guion, string assetsRoot = GuionImporter.DefaultAssetsRoot)
        {
            var root = (string.IsNullOrEmpty(assetsRoot) ? GuionImporter.DefaultAssetsRoot : assetsRoot).Replace('\\', '/').TrimEnd('/');
            return $"{root}/{guion.Experience.Id}/Escenas/{guion.Experience.SceneName}.unity";
        }

        // ── Precondiciones ────────────────────────────────────────────────────

        private static bool TryResolve(GuionDocument guion, string assetsRoot, ImportReport report,
            out SimulationSequence sequence, out LineLibrary library, out string scenePath)
        {
            sequence = null;
            library = null;
            scenePath = null;

            if (guion == null || guion.Experience == null)
            {
                report.Error("No hay guion que preparar.");
                return false;
            }

            var id = guion.Experience.Id;
            var sceneName = guion.Experience.SceneName;
            if (string.IsNullOrEmpty(id))
                report.Error("El guion no trae experiencia.id.");
            if (string.IsNullOrEmpty(sceneName) || sceneName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                report.Error("El guion no trae un experiencia.escena válido (es el nombre del fichero de la escena).");
            if (report.HasErrors) return false;

            var root = (string.IsNullOrEmpty(assetsRoot) ? GuionImporter.DefaultAssetsRoot : assetsRoot).Replace('\\', '/').TrimEnd('/');
            var sequencePath = $"{root}/{id}/Secuencias/{id}.asset";
            var libraryPath = $"{root}/{id}/Frases/{id}.asset";
            sequence = AssetDatabase.LoadAssetAtPath<SimulationSequence>(sequencePath);
            library = AssetDatabase.LoadAssetAtPath<LineLibrary>(libraryPath);

            if (sequence == null || library == null)
            {
                report.Error("Importa primero el guion: falta " +
                             (sequence == null ? sequencePath : libraryPath) + ". No se tocó nada.");
                return false;
            }

            scenePath = ScenePathFor(guion, assetsRoot);
            return true;
        }

        // ── 1. La escena ──────────────────────────────────────────────────────

        private static Scene OpenOrCreateScene(string scenePath, ImportReport report)
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) != null)
            {
                var opened = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                report.Update(scenePath + " (ya existía; se abrió)");
                return opened;
            }

            EnsureFolder(Path.GetDirectoryName(scenePath).Replace('\\', '/'));
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            if (!EditorSceneManager.SaveScene(scene, scenePath))
                throw new IOException("No se pudo guardar la escena nueva en " + scenePath + ".");
            report.Create(scenePath);
            return scene;
        }

        // ── 2. [Simulation] ───────────────────────────────────────────────────

        private static void PrepareSimulation(Scene scene, GuionDocument guion, SimulationSequence sequence,
            LineLibrary library, ImportReport report)
        {
            var go = FindOrCreateRoot(scene, SimulationRootName, out bool created);

            var manager = GetOrAdd<SimulationManager>(go);
            var steps = GetOrAdd<StepSystem>(go);
            var scoring = GetOrAdd<ScoringSystem>(go);
            var telemetry = GetOrAdd<TelemetryClient>(go);
            var voice = GetOrAdd<VOManager>(go);   // RequireComponent trae el AudioSource
            GetOrAdd<HintSystem>(go);
            GetOrAdd<FeedbackSystem>(go);
            PrepareState03(go, guion, sequence, report);   // 0.3 lote 1
            PrepareGuidanceUxVisor(go, steps);   // UX visor 2026-10-31

            var so = new SerializedObject(manager);
            Prop(so, "simulationMode").enumValueIndex =
                guion.Experience.Mode == "evaluacion" ? (int)XRLabs.Core.SimulationMode.Evaluation : (int)XRLabs.Core.SimulationMode.Guided;
            Prop(so, "stepSystem").objectReferenceValue = steps;
            Prop(so, "scoringSystem").objectReferenceValue = scoring;
            Prop(so, "telemetryClient").objectReferenceValue = telemetry;
            so.ApplyModifiedPropertiesWithoutUndo();

            so = new SerializedObject(steps);
            Prop(so, "sequence").objectReferenceValue = sequence;
            so.ApplyModifiedPropertiesWithoutUndo();

            // 2026-10-25: el puntaje del coach (coach.md, «Puntaje»): precisión por tareas y errores, menos 2 por ayuda. Con
            // TimeBased, el valor por defecto del componente, una experiencia guiada cerraba siempre con 100 aunque hubiera
            // errores (segundo recorrido en el Quest 3). Un guion que reparte puntos o penalización por paso conserva
            // TimeBased, que es la regla que los usa. Se escribe cada vez, para corregir las escenas ya preparadas.
            var rule = UsesStepPoints(sequence) ? ScoringRule.TimeBased : ScoringRule.TasksErrorsHints;
            so = new SerializedObject(scoring);
            Prop(so, "rule").enumValueIndex = (int)rule;
            so.ApplyModifiedPropertiesWithoutUndo();

            so = new SerializedObject(voice);
            var libraries = Prop(so, "lineLibraries");
            libraries.arraySize = 1;
            libraries.GetArrayElementAtIndex(0).objectReferenceValue = library;
            so.ApplyModifiedPropertiesWithoutUndo();

            // La voz del coach no es espacial ni suena sola al cargar la escena.
            var audio = GetOrAdd<AudioSource>(go);
            audio.playOnAwake = false;
            audio.spatialBlend = 0f;

            EditorUtility.SetDirty(go);
            Note(report, created, SimulationRootName + " con SimulationManager, StepSystem, ScoringSystem (regla " + rule + "), " +
                                  "TelemetryClient, VOManager, HintSystem y FeedbackSystem (secuencia " + sequence.name + ", frases " +
                                  library.name + ")");
        }

        // 0.3 lote 6: LockEnforcer en [Simulation] solo si el guion trae `bloqueos` (contrato-0.3.md §4); idempotente: si ya
        // está, se reusa y se vuelve a enlazar. Un guion que deja de traerlos no lo conserva (sin bloqueos no haría nada).
        private static void PrepareLocks(Scene scene, SimulationSequence sequence, ImportReport report)
        {
            var steps = FindStepSystem(scene);
            if (steps == null) return;
            var existing = steps.GetComponent<LockEnforcer>();
            if (!UsesLocks(sequence))
            {
                if (existing != null)
                {
                    UnityEngine.Object.DestroyImmediate(existing);
                    report.Delete(SimulationRootName + ": LockEnforcer (el guion ya no trae bloqueos)");
                }
                return;
            }

            bool created = existing == null;
            var enforcer = created ? steps.gameObject.AddComponent<LockEnforcer>() : existing;
            var so = new SerializedObject(enforcer);
            Prop(so, "stepSystem").objectReferenceValue = steps;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(steps.gameObject);
            Note(report, created, SimulationRootName + " con LockEnforcer (" + sequence.locks.Count + " bloqueos)");
        }

        /// <summary>Verdadero si la secuencia trae `bloqueos` del guion (0.3 lote 6).</summary>
        internal static bool UsesLocks(SimulationSequence sequence) =>
            sequence != null && sequence.locks != null && sequence.locks.Count > 0;

        /// <summary>Verdadero si algún paso trae `puntos` o `penalizacion` del guion (scoreOnSuccess, penaltyOnError).</summary>
        internal static bool UsesStepPoints(SimulationSequence sequence)
        {
            if (sequence == null || sequence.steps == null) return false;
            foreach (var step in sequence.steps)
                if (step != null && (step.scoreOnSuccess != 0 || step.penaltyOnError != 0)) return true;
            return false;
        }

        // ── 3. [Session] ──────────────────────────────────────────────────────

        private static void PrepareSession(Scene scene, GuionDocument guion, ImportReport report)
        {
            var go = FindOrCreateRoot(scene, SessionRootName, out bool created);
            var session = GetOrAdd<SessionManager>(go);

            var so = new SerializedObject(session);
            Prop(so, "mainMenuScene").stringValue = MenuSceneName;
            Prop(so, "nextScene").stringValue = string.Empty;
            // cierrePropio: la experiencia muestra su cierre y no vuelve sola al menú (D8: ausente = como siempre).
            Prop(so, "navigateOnEnd").boolValue = !guion.Experience.OwnEnding;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(go);
            Note(report, created, SessionRootName + " con SessionManager (vuelve al " + MenuSceneName + ": " +
                                  (guion.Experience.OwnEnding ? "no, cierre propio" : "sí") + ")");
        }

        // ── 3b. [ApiTelemetry] ────────────────────────────────────────────────

        // 2026-10-25 (telemetria-extremo-a-extremo.md §3.3, riesgo 1): ninguna escena preparada traía el ApiTelemetryBridge,
        // así que SessionManager.InitSession salía en su primera línea y el intento se cerraba «localmente», sin error rojo:
        // ni el inicio, ni los errores de los pasos, ni el cierre llegaban al cliente del API, real o mock.
        // Va en su propia raíz y no en [Session] ni en [Platform]: su Awake hace DontDestroyOnLoad de su objeto (que solo
        // vale en una raíz) y, si ya hay un bridge vivo (el del intento anterior, que volvió al Menu con él), destruye su
        // objeto entero. En [Session] se llevaría el SessionManager al Menu y en el segundo intento borraría el [Session]
        // nuevo; en [Platform] haría lo mismo con el rig; de hijo, DontDestroyOnLoad no actúa. No hay nada que enlazar: el
        // cliente del API (ApiClient, con el token del PIN), el usuario (AuthManager) y la experiencia elegida (AppState) los
        // trae el Menu en sus singletons, y SessionManager encuentra el bridge por ApiTelemetryBridge.Instance. Sin ApiClient
        // (escena abierta sin pasar por el Menu) o con useMockData, el bridge manda todo al mock y nunca a la red.
        // Idempotente: si la escena ya tiene un bridge, en [ApiTelemetry] o puesto a mano en otro objeto, no se agrega otro;
        // persistPendingEvents se deja como esté (por defecto encendido).
        private static void PrepareApiTelemetry(Scene scene, ImportReport report)
        {
            ApiTelemetryBridge existing = null;
            foreach (var go in scene.GetRootGameObjects())
            {
                existing = go.GetComponentInChildren<ApiTelemetryBridge>(true);
                if (existing != null) break;
            }

            if (existing != null && existing.gameObject.name != ApiTelemetryRootName)
            {
                var path = HierarchyPath(existing.transform);
                report.Update("ApiTelemetryBridge (ya estaba en «" + path + "»; no se agrega otro)");
                if (existing.transform.parent != null || existing.GetComponents<Component>().Length > 2)
                    report.Warn("El ApiTelemetryBridge de «" + path + "» no está solo en un objeto raíz: al arrancar hace DontDestroyOnLoad " +
                                "de su objeto y, en el segundo intento, lo destruye entero. Muévelo a un objeto raíz propio o bórralo y vuelve a preparar.");
                return;
            }

            // Sin bridge en la escena se agrega uno (en un [ApiTelemetry] hecho a mano, si lo hay); con él, se deja como está.
            bool created = existing == null;
            var root = created ? FindOrCreateRoot(scene, ApiTelemetryRootName, out _) : existing.gameObject;
            GetOrAdd<ApiTelemetryBridge>(root);
            if (root.transform.parent != null)
                report.Warn(ApiTelemetryRootName + " no es un objeto raíz: el ApiTelemetryBridge necesita serlo (DontDestroyOnLoad).");

            EditorUtility.SetDirty(root);
            Note(report, created, ApiTelemetryRootName + " con ApiTelemetryBridge (sesión, errores de los pasos y cierre al cliente del API; " +
                                  "sin ApiClient o con useMockData, al mock)");
        }

        private static string HierarchyPath(Transform t) =>
            t.parent == null ? t.name : HierarchyPath(t.parent) + "/" + t.name;

        // ── 4. [Colocacion] ───────────────────────────────────────────────────

        private static void PreparePlacementRoot(Scene scene, GuionDocument guion, ImportReport report)
        {
            var root = FindOrCreateRoot(scene, PlacementRootName, out bool created);
            if (created) report.Create(PlacementRootName + " (la raíz donde «Importar colocación» pone las cosas)");

            // 2026-10-26: si la colocación ya estaba importada y el guion pide visibilidadPorPaso (o dejó de pedirla), los
            // tramos se recalculan al reprepararla; «Importar colocación» hace lo mismo al terminar (autoria.md §12).
            StepVisibilityPlanner.Apply(root.transform, guion, report);
        }

        // ── 5. Modo plano en el Editor ────────────────────────────────────────

        // La cámara a 1,6 m en el Inicio de la colocación (si ya está importada; si no, en el origen) con el driver de
        // interacción plano de Runtime/Platform, para que el clic del ratón llegue a los TouchableHotspot sin rig XRI
        // (platform-support.md). Se agrega también el orbitador, que es la cámara del rig plano documentado y permite
        // mirar alrededor con el botón derecho. No se agrega PlatformBootstrapper ni FlatScreenLayout: son del rig
        // completo (dock de UI) y exigen el rig XR de la escena, que es del lote aparte del visor.
        private static void PrepareCamera(Scene scene, ImportReport report)
        {
            var camera = FindCamera(scene, out bool created);

            var pose = StartPose(scene);
            camera.transform.SetPositionAndRotation(pose.position + Vector3.up * EyeHeight, pose.rotation);

            GetOrAdd<FlatInteractionDriver>(camera.gameObject);
            GetOrAdd<OrbitCameraController>(camera.gameObject);

            EditorUtility.SetDirty(camera.gameObject);
            Note(report, created, "Cámara principal a " + EyeHeight.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) +
                                  " m con FlatInteractionDriver y OrbitCameraController (modo plano: clic del ratón sobre los hotspots)");
        }

        private static Camera FindCamera(Scene scene, out bool created)
        {
            created = false;
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.CompareTag("MainCamera") && go.TryGetComponent<Camera>(out var tagged)) return tagged;
            }
            foreach (var go in scene.GetRootGameObjects())
            {
                var any = go.GetComponentInChildren<Camera>(true);
                if (any != null) return any;
            }

            var cameraObject = new GameObject("Main Camera") { tag = "MainCamera" };
            SceneManager.MoveGameObjectToScene(cameraObject, scene);
            created = true;
            return cameraObject.AddComponent<Camera>();
        }

        private static (Vector3 position, Quaternion rotation) StartPose(Scene scene)
        {
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.name != PlacementRootName) continue;
                var start = go.transform.Find(ColocacionImporter.StartName);
                if (start != null) return (start.position, start.rotation);
            }
            return (Vector3.zero, Quaternion.identity);
        }

        // ── 5a. [Platform] ────────────────────────────────────────────────────

        // Lote del visor (2026-10-17): la escena preparada solo tenía la cámara plana, así que en un visor no había rig ni
        // manos. [Platform] lleva el PlatformBootstrapper del paquete con xrRigRoot = una instancia del rig XRI (D23) y
        // flatRigRoot = la Main Camera plana de PrepareCamera; al arrancar enciende uno y apaga el otro según haya visor.
        // El rig nace apagado para que en el Editor en pantalla todo siga igual (una sola MainCamera y un solo
        // AudioListener activos). Idempotente: el rig se busca por nombre y por prefab antes de instanciarse.
        private static void PreparePlatform(Scene scene, ImportReport report)
        {
            var prefab = LoadRigPrefab();
            if (prefab == null)
            {
                report.Warn("No encuentro el rig XRI (" + RigPrefabPath + "): la escena queda sin [Platform] y solo sirve en pantalla.");
                return;
            }

            var camera = FindCamera(scene, out _);
            var platform = FindOrCreateRoot(scene, PlatformRootName, out bool created);

            var rig = platform.transform.Find(RigInstanceName);
            if (rig == null)
            {
                var made = (GameObject)PrefabUtility.InstantiatePrefab(prefab, platform.transform);
                made.name = RigInstanceName;
                rig = made.transform;
            }
            // En el Inicio de la colocación, al nivel del suelo y con el giro de la cámara (la cámara está a la altura de los ojos).
            var pose = StartPose(scene);
            rig.SetPositionAndRotation(pose.position, pose.rotation);
            rig.gameObject.SetActive(false);

            var bootstrapper = GetOrAdd<PlatformBootstrapper>(platform);
            var so = new SerializedObject(bootstrapper);
            Prop(so, "xrRigRoot").objectReferenceValue = rig.gameObject;
            Prop(so, "flatRigRoot").objectReferenceValue = camera.gameObject;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(platform);
            Note(report, created, PlatformRootName + " con PlatformBootstrapper (rig XRI apagado en edición; la Main Camera plana como rig plano)");
        }

        private static GameObject LoadRigPrefab()
        {
            var path = AssetDatabase.GUIDToAssetPath(RigPrefabGuid);
            if (string.IsNullOrEmpty(path)) path = RigPrefabPath;
            return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }

        // ── 5b. [Coach] ───────────────────────────────────────────────────────

        // 2026-10-10 (lote A4, contrato-0.2.md §8): el coach es el producto (guía, señala, corrige y repite), y la escena
        // preparada del lote A2 no lo traía: D22 lo dejó para después. Ahora [Coach] lleva el holograma del paquete
        // (instancia del prefab, que sigue enlazada a él), el CoachDirector y el StepTargetHighlighter, ambos enlazados al
        // StepSystem de [Simulation]. El director es lo que mueve y hace señalar al coach según el paso, y la voz la toma
        // de VOManager.Instance (el de [Simulation], con la biblioteca de frases): el HologramCoach no guarda ninguna
        // referencia a LineLibrary ni a la voz, así que no hay nada más que asignar. El highlighter va aquí y no en
        // [Simulation] para que esa raíz siga teniendo los siete sistemas del documento; el anillo del paso es parte de
        // cómo el coach muestra qué usar. Sin el prefab (paquete sin esa carpeta) solo se avisa: la escena sigue sin coach.
        private static void PrepareCoach(Scene scene, ImportReport report)
        {
            var prefab = LoadCoachPrefab();
            if (prefab == null)
            {
                report.Warn("No encuentro el prefab del coach (" + CoachPrefabPath + "): la escena queda sin [Coach]. " +
                            "Genéralo con Tools > XRLabs > Create Hologram Coach Prefab y vuelve a preparar.");
                return;
            }

            var steps = FindStepSystem(scene);
            if (steps == null)
                throw new InvalidOperationException("no hay StepSystem en " + SimulationRootName + " para enlazar el coach");

            var go = FindOrCreateRoot(scene, CoachRootName, out bool created);
            var camera = FindCamera(scene, out _);

            // La instancia del prefab: se busca por nombre y por componente, y solo se instancia si falta (idempotente).
            var instance = go.transform.Find(CoachInstanceName);
            if (instance == null || instance.GetComponentInChildren<CoachPresence>(true) == null)
            {
                var made = (GameObject)PrefabUtility.InstantiatePrefab(prefab, go.transform);
                made.name = CoachInstanceName;
                instance = made.transform;

                // Solo al crear: a 2 m delante de la cámara, en el suelo y mirando a la persona (la misma regla que
                // CoachDemoSetupEditor), para que no nazca encima de la cámara mientras el director no lo reubica.
                var forward = Vector3.ProjectOnPlane(camera.transform.forward, Vector3.up);
                forward = forward.sqrMagnitude < 1e-4f ? Vector3.forward : forward.normalized;
                var ground = new Vector3(camera.transform.position.x, 0f, camera.transform.position.z);
                instance.position = ground + forward * 2f;
                instance.rotation = Quaternion.LookRotation(-forward, Vector3.up);
            }
            var presence = instance.GetComponentInChildren<CoachPresence>(true);
            var director = GetOrAdd<CoachDirector>(go);
            var so = new SerializedObject(director);
            Prop(so, "stepSystem").objectReferenceValue = steps;
            Prop(so, "presence").objectReferenceValue = presence;
            // Lote del visor: la cabeza es Camera.main en tiempo de ejecución (la cámara plana o la del rig XRI, la que el
            // PlatformBootstrapper deje encendida); CoachDirector ya cae en Camera.main cuando el campo está vacío.
            Prop(so, "head").objectReferenceValue = null;
            so.ApplyModifiedPropertiesWithoutUndo();

            var highlighter = GetOrAdd<StepTargetHighlighter>(go);
            so = new SerializedObject(highlighter);
            Prop(so, "stepSystem").objectReferenceValue = steps;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(go);
            Note(report, created, CoachRootName + " con el holograma del coach, CoachDirector (StepSystem, presencia y cámara) " +
                                  "y StepTargetHighlighter");
        }

        // ── 5c. [HUD] ─────────────────────────────────────────────────────────

        // 2026-10-17: el primer recorrido de la muestra de compostaje en el Mac no mostró nada: sin voces horneadas y sin
        // panel de subtítulos, lo que el coach dice no llega a la persona. El SubtitlePanel del paquete «siempre aparece,
        // haya o no audio»: la escena preparada lo trae en [HUD] (SubtitleHudBuilder), con Intro para saltar la frase.
        private static void PrepareHud(Scene scene, ImportReport report)
        {
            bool created = SubtitleHudBuilder.Ensure(scene, FindStepSystem(scene), out _);
            Note(report, created, HudRootName + " con el canvas, el SubtitlePanel del coach (subtítulos aunque no haya voz; Intro salta la frase), " +
                                  "el botón Comenzar de los pasos manuales y el EventSystem");
        }

        // UX visor 2026-10-31 ─────────────────────────────────────────────
        // La guía cuando pasa el tiempo (Documentation~/decisiones-ux-visor.md §4) va con los sistemas de la simulación,
        // enlazada al StepSystem; el botón «¿Qué hago?» y la ayuda de mandos por paso los pone SubtitleHudBuilder.
        private static void PrepareGuidanceUxVisor(GameObject go, StepSystem steps)
        {
            var guidance = GetOrAdd<StepGuidance>(go);
            var so = new SerializedObject(guidance);
            Prop(so, "stepSystem").objectReferenceValue = steps;
            so.ApplyModifiedPropertiesWithoutUndo();
        }
        // fin UX visor 2026-10-31

        // ── 5d. [Debug] ───────────────────────────────────────────────────────

        // 2026-10-18 (pedido del dueño al recorrer: «dónde estoy, qué sigue y comandos para avanzar»): el panel de depuración
        // que ya existía en Runtime/Debug (lo montaba Tools/XR Simulation/Setup Sim Debugger Scene) va también en la escena
        // preparada. IMGUI: solo se ve en pantalla; en el visor no estorba. F1 abre el panel con el paso en curso y el
        // siguiente; F2 completa el paso; F4 abre la lista para saltar; Shift+número salta; F7 el registro de eventos.
        private static void PrepareDebug(Scene scene, ImportReport report)
        {
            var steps = FindStepSystem(scene);
            if (steps == null) return;
            var simulation = steps.GetComponent<SimulationManager>();
            var scoring = steps.GetComponent<ScoringSystem>();

            var go = FindOrCreateRoot(scene, DebugRootName, out bool created);
            var debugger = GetOrAdd<XRLabs.DebugTools.SimulationDebugger>(go);
            GetOrAdd<XRLabs.DebugTools.SimDebugHUD>(go);
            var so = new SerializedObject(debugger);
            Prop(so, "stepSystem").objectReferenceValue = steps;
            Prop(so, "simulationManager").objectReferenceValue = simulation;
            Prop(so, "scoringSystem").objectReferenceValue = scoring;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(go);
            Note(report, created, DebugRootName + " con SimulationDebugger y SimDebugHUD (F1 panel, F2 completar el paso, F4 saltar, F7 registro)");
        }

        private static GameObject LoadCoachPrefab()
        {
            var path = AssetDatabase.GUIDToAssetPath(CoachPrefabGuid);
            if (string.IsNullOrEmpty(path)) path = CoachPrefabPath;
            return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }

        private static StepSystem FindStepSystem(Scene scene)
        {
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.name == SimulationRootName && go.TryGetComponent<StepSystem>(out var steps)) return steps;
            }
            return null;
        }

        // ── 6. ApiSettings ────────────────────────────────────────────────────

        // El Menu necesita un ApiSettings con useMockData encendido para el login con PIN sin backend. Si ya existe uno en
        // esa ruta no se toca. La escena Menu del paquete lo referencia por GUID (MenuApiSettingsGuid): si el GUID está
        // libre, el asset nuevo se escribe con él para que el ApiClient del Menu lo encuentre sin reasignar nada; si otro
        // asset ya lo tiene, el proyecto ya tiene el que usa el Menu y no se crea otro.
        private static void EnsureApiSettings(string path, ImportReport report)
        {
            if (AssetDatabase.LoadAssetAtPath<ApiSettings>(path) != null)
                return;

            if (!string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(path)))
            {
                report.Warn(path + " existe y no es un ApiSettings: no se creó el ApiSettings del Menu.");
                return;
            }

            var owner = AssetDatabase.GUIDToAssetPath(MenuApiSettingsGuid);
            // 2026-10-25: la base de assets recuerda durante un arranque un ApiSettings ya borrado del disco (pasa tras cada
            // build del visor, que lo crea, y su borrado antes de sellar): una ruta sin fichero cuenta como GUID libre.
            if (!string.IsNullOrEmpty(owner) && !File.Exists(owner)) owner = string.Empty;
            if (!string.IsNullOrEmpty(owner) && AssetDatabase.LoadAssetAtPath<ApiSettings>(owner) != null)
                return;   // el Menu ya encuentra su ApiSettings en ese asset

            EnsureFolder(Path.GetDirectoryName(path).Replace('\\', '/'));

            if (string.IsNullOrEmpty(owner) && TryWriteApiSettingsWithMenuGuid(path))
            {
                report.Create(path + " (useMockData encendido; con el GUID que el Menu espera)");
                return;
            }

            var asset = ScriptableObject.CreateInstance<ApiSettings>();
            asset.useMockData = true;
            AssetDatabase.CreateAsset(asset, path);
            report.Create(path + " (useMockData encendido)");
            report.Warn("El ApiSettings se creó con un GUID nuevo: reasígnalo al ApiClient de la escena Menu si el login no encuentra la configuración.");
        }

        // Escribe a mano el .asset y su .meta con el GUID del Menu (un asset no puede elegir su GUID desde la API). Solo
        // lleva useMockData: lo demás toma los valores por defecto de la clase al cargar. Si Unity no lo importa tal cual,
        // se borra y devuelve false para que el llamador lo cree por la vía normal.
        private static bool TryWriteApiSettingsWithMenuGuid(string path)
        {
            var temp = ScriptableObject.CreateInstance<ApiSettings>();
            string scriptGuid;
            try
            {
                var script = MonoScript.FromScriptableObject(temp);
                scriptGuid = script != null ? AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(script)) : null;
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(temp);
            }
            if (string.IsNullOrEmpty(scriptGuid)) return false;

            var yaml =
                "%YAML 1.1\n" +
                "%TAG !u! tag:unity3d.com,2011:\n" +
                "--- !u!114 &11400000\n" +
                "MonoBehaviour:\n" +
                "  m_ObjectHideFlags: 0\n" +
                "  m_CorrespondingSourceObject: {fileID: 0}\n" +
                "  m_PrefabInstance: {fileID: 0}\n" +
                "  m_PrefabAsset: {fileID: 0}\n" +
                "  m_GameObject: {fileID: 0}\n" +
                "  m_Enabled: 1\n" +
                "  m_EditorHideFlags: 0\n" +
                "  m_Script: {fileID: 11500000, guid: " + scriptGuid + ", type: 3}\n" +
                "  m_Name: " + Path.GetFileNameWithoutExtension(path) + "\n" +
                "  m_EditorClassIdentifier: XRLabs.Networking::XRLabs.Networking.ApiSettings\n" +
                "  useMockData: 1\n";
            var meta =
                "fileFormatVersion: 2\n" +
                "guid: " + MenuApiSettingsGuid + "\n" +
                "NativeFormatImporter:\n" +
                "  externalObjects: {}\n" +
                "  mainObjectFileID: 11400000\n" +
                "  userData: \n" +
                "  assetBundleName: \n" +
                "  assetBundleVariant: \n";

            var absolute = AbsolutePath(path);
            File.WriteAllText(absolute, yaml);
            File.WriteAllText(absolute + ".meta", meta);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);

            var loaded = AssetDatabase.LoadAssetAtPath<ApiSettings>(path);
            if (loaded != null && loaded.useMockData && AssetDatabase.AssetPathToGUID(path) == MenuApiSettingsGuid)
                return true;

            AssetDatabase.DeleteAsset(path);
            return false;
        }

        private static string AbsolutePath(string assetPath) =>
            Path.Combine(Directory.GetParent(Application.dataPath)!.FullName, assetPath);

        // ── 7. Build Settings ─────────────────────────────────────────────────

        /// <summary>
        /// Cuál de los dos Menu del paquete va al índice 0: el de Meta si el proyecto tiene el SDK de Meta; si no, el generado
        /// con el rig XRI (D23). Nunca los dos. Es la parte pura de la decisión, para probarla sin tocar Build Settings.
        /// </summary>
        public static string MenuScenePathFor(bool hasMetaSdk) => hasMetaSdk ? MenuScenePath : MenuXriScenePath;

        /// <summary>
        /// Si el proyecto tiene el SDK de Meta: el paquete <c>com.meta.xr.sdk.core</c> está resuelto (también si entra como
        /// dependencia de otro) o aparece en <c>Packages/manifest.json</c>. No se usa el define <c>META_XR_SDK</c>: es una
        /// <c>versionDefine</c> de XRLabs.Platform y este ensamblado no lo recibe.
        /// </summary>
        public static bool ProjectHasMetaSdk()
        {
            try
            {
                if (UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/" + MetaSdkPackageName) != null)
                    return true;
            }
            catch (Exception)
            {
                // Sin información del Package Manager se decide por el manifest.
            }

            try
            {
                var manifest = Path.Combine(Directory.GetParent(Application.dataPath)!.FullName, "Packages", "manifest.json");
                return File.Exists(manifest) && File.ReadAllText(manifest).Contains("\"" + MetaSdkPackageName + "\"");
            }
            catch (IOException)
            {
                return false;
            }
        }

        // Menu del paquete en el índice 0 solo si no hay ninguna escena llamada Menu (D9): el de Meta o el generado con XRI
        // según haya SDK de Meta, nunca los dos; la escena de la experiencia después, si no está. Nunca se quita ni se
        // reordena lo que ya hay: solo se agrega.
        private static void EnsureBuildSettings(string scenePath, ImportReport report, bool hasMetaSdk)
        {
            var scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            bool changed = false;

            int menuIndex = scenes.FindIndex(s => Path.GetFileNameWithoutExtension(s.path) == MenuSceneName);
            if (menuIndex < 0)
            {
                string menuPath = MenuScenePathFor(hasMetaSdk);
                if (string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(menuPath)))
                    report.Warn("No encuentro la escena Menu del paquete (" + menuPath + "): ponla tú en Build Settings, índice 0" +
                                (hasMetaSdk ? "." : " (se genera con Tools/XRLabs/Generar Menu XRI)."));
                else
                {
                    scenes.Insert(0, new EditorBuildSettingsScene(menuPath, true));
                    report.Create("Build Settings: Menu en el índice 0 (" + (hasMetaSdk ? "con el SDK de Meta" : "sin el SDK de Meta, rig XRI") + ")");
                    changed = true;
                }
            }
            else if (menuIndex != 0 || !scenes[menuIndex].enabled)
            {
                report.Warn("En Build Settings la escena Menu no está activa en el índice 0 (" + scenes[menuIndex].path +
                            "): no se cambió lo que ya había.");
            }

            int sceneIndex = scenes.FindIndex(s => s.path == scenePath);
            if (sceneIndex < 0)
            {
                scenes.Add(new EditorBuildSettingsScene(scenePath, true));
                report.Create("Build Settings: " + scenePath);
                changed = true;
            }
            else if (!scenes[sceneIndex].enabled)
            {
                report.Warn("En Build Settings la escena " + scenePath + " está desactivada: no se cambió.");
            }

            if (changed) EditorBuildSettings.scenes = scenes.ToArray();
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        private static void Note(ImportReport report, bool created, string what)
        {
            if (created) report.Create(what);
            else report.Update(what);
        }

        private static GameObject FindOrCreateRoot(Scene scene, string name, out bool created)
        {
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.name != name) continue;
                created = false;
                return go;
            }

            var made = new GameObject(name);
            SceneManager.MoveGameObjectToScene(made, scene);
            created = true;
            return made;
        }

        private static T GetOrAdd<T>(GameObject target) where T : Component
        {
            var component = target.GetComponent<T>();
            return component != null ? component : target.AddComponent<T>();
        }

        private static SerializedProperty Prop(SerializedObject so, string name) =>
            so.FindProperty(name) ?? throw new InvalidOperationException(
                $"{so.targetObject.GetType().Name} no tiene el campo serializado '{name}'.");

        private static void EnsureFolder(string folder)
        {
            if (string.IsNullOrEmpty(folder) || AssetDatabase.IsValidFolder(folder)) return;
            var parent = Path.GetDirectoryName(folder).Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) return;
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(folder));
        }

        #region 0.3 lote 1

        // Contrato 0.3 §4: SimulationStateHost solo si el guion declara 'estado'; si ya no lo declara, se quita. Idempotente.
        private static void PrepareState03(GameObject go, GuionDocument guion, SimulationSequence sequence, ImportReport report)
        {
            var host = go.GetComponent<SimulationStateHost>();
            if (!StateAuthoring.UsesState(guion))
            {
                if (host != null)
                {
                    UnityEngine.Object.DestroyImmediate(host);
                    report.Update(SimulationRootName + ": se quitó SimulationStateHost (el guion ya no declara 'estado')");
                }
                return;
            }
            bool created = host == null;
            if (created) host = go.AddComponent<SimulationStateHost>();
            var so = new SerializedObject(host);
            Prop(so, "sequence").objectReferenceValue = sequence;
            so.ApplyModifiedPropertiesWithoutUndo();
            if (created) report.Create(SimulationRootName + ": SimulationStateHost (el guion declara 'estado')");
            else report.Update(SimulationRootName + ": SimulationStateHost");
        }

        #endregion
    }
}
