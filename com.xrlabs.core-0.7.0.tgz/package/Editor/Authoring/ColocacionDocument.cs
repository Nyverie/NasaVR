using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// La colocación de una experiencia tal como la escribe quien coloca (xrlabs.colocacion/0.1 y 0.2): punto de inicio, anclas
    /// del coach, objetos y zonas, en metros y en los ejes del GLB del entorno (glTF). Sin nada de Unity: la conversión a los
    /// ejes de Unity la hace <see cref="GltfToUnity"/> al importar. Lectura humana en Documentation~/autoria.md §4 y, para
    /// las zonas `soltar` de la 0.2, en Documentation~/contrato-0.2.md §5; el esquema formal en Schema/colocacion.schema.json. Las claves JSON van en español, las propiedades C# en inglés.
    /// Clase de datos: no valida (eso es <see cref="ColocacionValidator"/>).
    /// </summary>
    public sealed class ColocacionDocument
    {
        public const string SchemaId = "xrlabs.colocacion/0.1";
        /// <summary>La versión 0.2 (contrato-0.2.md §3): añade las zonas `soltar`. Todo lo de 0.1 sigue significando lo mismo.</summary>
        public const string SchemaId02 = "xrlabs.colocacion/0.2";

        [JsonProperty("esquema")] public string Schema;
        /// <summary>El id del guion al que pertenece.</summary>
        [JsonProperty("experiencia")] public string Experience;
        [JsonProperty("entorno")] public EnvironmentInfo Environment = new();
        /// <summary>Punto de aparición del usuario. Null si el fichero no lo trae (el validador lo marca).</summary>
        [JsonProperty("inicio")] public PoseEntry Start;
        [JsonProperty("anclas")] public List<AnchorEntry> Anchors = new();
        [JsonProperty("objetos")] public List<PlacedObject> Objects = new();
        [JsonProperty("zonas")] public List<ZoneEntry> Zones = new();

        // 0.3 lote 1 (contrato-0.3.md §2.10 y §3).
        /// <summary>La versión 0.3: añade `visibleSi`, `conjuntos` (y `medir`, del lote 6).</summary>
        public const string SchemaId03 = "xrlabs.colocacion/0.3";
        /// <summary>Grupos de objetos, zonas y anclas que se mueven y se ocultan juntos. Null o vacío: ninguno.</summary>
        [JsonProperty("conjuntos")] public List<SetEntry> Sets;

        /// <summary>Lee y parsea el fichero. Lanza si no existe o si el JSON no es válido.</summary>
        public static ColocacionDocument Load(string path) => Parse(File.ReadAllText(path));

        /// <summary>Parsea el texto. Lanza <see cref="JsonException"/> si el JSON está mal formado. Las listas nunca quedan null.</summary>
        public static ColocacionDocument Parse(string json)
        {
            var doc = JsonConvert.DeserializeObject<ColocacionDocument>(json, Settings) ?? new ColocacionDocument();
            doc.Environment ??= new EnvironmentInfo();
            doc.Anchors ??= new List<AnchorEntry>();
            doc.Objects ??= new List<PlacedObject>();
            doc.Zones ??= new List<ZoneEntry>();
            return doc;
        }

        private static readonly JsonSerializerSettings Settings = new()
        {
            MissingMemberHandling = MissingMemberHandling.Ignore,
            NullValueHandling = NullValueHandling.Include
        };

        /// <summary>Qué entregaron los modeladores. El importador de Unity no lo lee en 0.1 (autoria.md §4).</summary>
        public sealed class EnvironmentInfo
        {
            [JsonProperty("glb")] public string Glb;
            [JsonProperty("fbx")] public string Fbx;
            [JsonProperty("unidades")] public string Units;
            [JsonProperty("ejes")] public string Axes;
        }

        /// <summary>Un punto con orientación: <c>pos</c> [x, y, z] en metros y <c>giro</c> alrededor de Y en grados, ejes del GLB.</summary>
        public class PoseEntry
        {
            [JsonProperty("pos")] public float[] Pos;
            [JsonProperty("giro")] public float Yaw;
        }

        public sealed class AnchorEntry : PoseEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("mirarUsuario")] public bool FaceUser = true;
        }

        public sealed class PlacedObject : PoseEntry
        {
            [JsonProperty("id")] public string Id;
            [JsonProperty("escala")] public float Scale = 1f;
            // 0.3 lote 1: forma de `si` del guion (variable -> valor, lista, { "mayor": n } / { "menor": n }).
            [JsonProperty("visibleSi")] public Dictionary<string, JToken> VisibleIf;
        }

        public sealed class ZoneEntry : PoseEntry
        {
            /// <summary>Alto de una zona `soltar` cuando el fichero no trae `alto` (contrato-0.2.md §5).</summary>
            public const float DefaultDropHeight = 0.5f;

            [JsonProperty("id")] public string Id;
            /// <summary>"teleport" (0.1) o "soltar" (0.2).</summary>
            [JsonProperty("tipo")] public string Kind;
            /// <summary>[ancho, largo] en el suelo, en metros. La altura de `teleport` es fija; la de `soltar` es <see cref="Height"/>.</summary>
            [JsonProperty("tamano")] public float[] Size;

            // Campos de la zona `soltar` (0.2). En una zona `teleport` el validador avisa de los que sobran.

            /// <summary>Solo `soltar`: alto del volumen en metros; null = <see cref="DefaultDropHeight"/>.</summary>
            [JsonProperty("alto")] public float? Height;
            /// <summary>Solo `soltar`: ids de objetos del guion (`agarrable`, `fuente` o `herramienta`) que la zona acepta; al menos uno. Puede llegar nula si el JSON trae `null`.</summary>
            [JsonProperty("acepta")] public List<string> Accepts = new();
            /// <summary>Solo `soltar`: true = la zona encaja lo que entra (SnapZone) en vez de solo contarlo (DropZone).</summary>
            [JsonProperty("imantar")] public bool Snap;

            // 0.3 lote 6
            /// <summary>Solo `soltar` (0.3, contrato-0.3.md §3): "contacto" (null = por defecto) o "centro".</summary>
            [JsonProperty("medir")] public string Measure;
            // 0.3 lote 1: desactiva la zona (no acepta ni se resalta) cuando no se cumple.
            [JsonProperty("visibleSi")] public Dictionary<string, JToken> VisibleIf;
            // UX visor 2026-10-31: solo `teleport`. Id de un ancla, objeto o zona hacia el que mira la persona al llegar;
            // null = lo que usa el primer paso que nombra la zona o, si no, el ancla del coach (ColocacionImporter.ApplyTeleportGuides).
            [JsonProperty("mirarHacia")] public string LookAt;
        }

        // 0.3 lote 1: un conjunto (contrato-0.3.md §2.10).
        public sealed class SetEntry
        {
            [JsonProperty("id")] public string Id;
            /// <summary>Punto del conjunto que se lleva al lugar, [x, y, z] en ejes del GLB.</summary>
            [JsonProperty("origen")] public float[] Origin;
            [JsonProperty("miembros")] public SetMembers Members = new();
            [JsonProperty("visibleSi")] public Dictionary<string, JToken> VisibleIf;
            [JsonProperty("posicionSegun")] public PositionByState PositionBy;
        }

        public sealed class SetMembers
        {
            [JsonProperty("objetos")] public List<string> Objects = new();
            [JsonProperty("zonas")] public List<string> Zones = new();
            [JsonProperty("anclas")] public List<string> Anchors = new();
        }

        public sealed class PositionByState
        {
            /// <summary>Variable de texto del estado del guion.</summary>
            [JsonProperty("estado")] public string Variable;
            /// <summary>valor -> id de objeto de la colocación (toma su `pos` y `giro`) o { "pos": [...], "giro": g }.</summary>
            [JsonProperty("lugares")] public Dictionary<string, JToken> Places;
            [JsonProperty("girar")] public bool Rotate;
            [JsonProperty("desplazar")] public float[] Offset;
        }
    }
}
