using System.Collections.Generic;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Un hallazgo de la validación de un guion o de una colocación: error (impide importar) o aviso (deja importar), con la
    /// ruta dentro del fichero que lo explica (p. ej. "pasos[p3].condicion.error.clave") y el mensaje en español.
    /// Documentation~/autoria.md §3.7 y §4.2.
    /// </summary>
    public sealed class ValidationIssue
    {
        public readonly bool IsError;
        public readonly string Path;
        public readonly string Message;

        private ValidationIssue(bool isError, string path, string message)
        {
            IsError = isError;
            Path = path ?? string.Empty;
            Message = message ?? string.Empty;
        }

        public static ValidationIssue Error(string path, string message) => new(true, path, message);
        public static ValidationIssue Warning(string path, string message) => new(false, path, message);

        public override string ToString() => (IsError ? "ERROR " : "aviso ") + Path + ": " + Message;

        /// <summary>Verdadero si alguna entrada es error.</summary>
        public static bool AnyError(IEnumerable<ValidationIssue> issues)
        {
            if (issues == null) return false;
            foreach (var i in issues)
                if (i != null && i.IsError) return true;
            return false;
        }
    }
}
