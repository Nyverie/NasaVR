using UnityEngine;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Conversión de los ejes del GLB (glTF: Y arriba, mano derecha, +Z hacia el espectador) a los de Unity (Y arriba, mano
    /// izquierda). Funciones puras.
    ///
    /// REGLA PROVISIONAL (Documentation~/autoria.md §4 y D21): x_unity = -x, y_unity = y, z_unity = z, y giro_unity = -giro.
    /// La comprobación real la da el fixture de los modeladores (autoria.md §6, FixtureCoordenadasTests): hasta que el cubo
    /// del fixture caiga en el mismo sitio en el GLB y en el FBX, esta regla puede cambiar. Si cambia, se cambia SOLO AQUÍ,
    /// en <see cref="Position"/> y <see cref="Yaw"/>; ningún otro fichero convierte ejes.
    /// </summary>
    public static class GltfToUnity
    {
        /// <summary>Posición glTF (x, y, z) en metros → posición de Unity.</summary>
        public static Vector3 Position(float x, float y, float z) => new Vector3(-x, y, z);

        /// <summary>Giro alrededor de Y en grados, en el sistema glTF → rotación de Unity.</summary>
        public static Quaternion Yaw(float degrees) => Quaternion.Euler(0f, -degrees, 0f);
    }
}
