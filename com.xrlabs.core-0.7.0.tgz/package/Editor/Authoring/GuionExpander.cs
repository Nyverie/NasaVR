using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// 0.3 lote 3 (Documentation~/contrato-0.3.md §2.4). Desenrolla los pasos <c>grupo</c> y los <c>bloques</c> de un guion en la
    /// lista plana de pasos del 0.2, que es lo único que conocen el validador, el importador y el runtime. Cada vuelta
    /// <i>k</i> de un grupo copia sus pasos con id <c>&lt;grupo&gt;.&lt;k&gt;.&lt;paso&gt;</c> (<c>&lt;grupo&gt;.&lt;paso&gt;</c> si
    /// <c>repetir</c> es 1); el primer paso de la vuelta recibe en <c>alIniciar</c> el contador (<c>{ "ciclo": k }</c>) y el
    /// <i>k</i>-ésimo objeto de <c>porIteracion</c>, por debajo de su propio <c>alIniciar</c> (lo aplica el runtime del lote 2);
    /// <c>{contador}</c> en los ids de frase se sustituye ya aquí por <i>k</i>, así la frase de cada vuelta existe sin
    /// esperar al runtime. El <c>si</c> del grupo se suma al de cada paso; <c>tarea</c> en el grupo cuenta solo su último
    /// paso; un <c>desde</c> de <c>secciones</c> que nombra un grupo pasa a su primer paso; cada contador se declara en
    /// <c>estado</c> como numérica. Pura: sin Unity ni disco. Trabaja sobre el JSON para llevar intactas las claves de otros
    /// lotes (<c>si</c>, efectos) que esta clase no necesita conocer.
    /// </summary>
    public static class GuionExpander
    {
        public const string GroupKind = "grupo";
        public const int MaxRepeat = 20;
        public const int WarnRepeat = 10;
        public const int MaxDepth = 2;
        public const int MaxIdLength = 100;

        private static readonly Regex CounterPattern = new(@"^[a-z0-9][a-z0-9-]*$", RegexOptions.CultureInvariant);
        private static readonly string[] GroupKeys = { "pasos", "bloque", "repetir", "contador", "porIteracion", "IsGroup", "IsNarration", "IsTimeAdvance" };
        private static readonly string[] PhraseKeys = { "instruccion", "pista", "exito", "errorPorDefecto" };
        private static readonly string[] EffectKeys = { "alIniciar", "alCompletar" };

        private static readonly JsonSerializer Serializer = JsonSerializer.Create(new JsonSerializerSettings
        {
            MissingMemberHandling = MissingMemberHandling.Ignore,
            NullValueHandling = NullValueHandling.Ignore
        });

        /// <summary>De dónde sale un paso desenrollado: id final, grupo de primer nivel, vuelta y la ruta para los mensajes.</summary>
        public sealed class Origin
        {
            public string Id;
            public string Group;
            public int Iteration;
            public string Path;
        }

        /// <summary>Verdadero si el guion trae algún grupo o algún bloque: sin ellos, desenrollar no cambia nada.</summary>
        public static bool UsesGroups(GuionDocument doc)
        {
            if (doc == null) return false;
            if (doc.Blocks != null && doc.Blocks.Count > 0) return true;
            if (doc.Steps != null)
                foreach (var s in doc.Steps)
                    if (s != null && s.Kind == GroupKind) return true;
            return false;
        }

        /// <summary>
        /// El guion desenrollado. Sin grupos ni bloques, el mismo objeto. Si la estructura de los grupos tiene errores, también
        /// el mismo objeto (el validador los cuenta con <see cref="Expand(GuionDocument, List{ValidationIssue})"/>).
        /// </summary>
        public static GuionDocument Expand(GuionDocument doc) => Expand(doc, null);

        /// <summary>
        /// Desenrolla y añade a <paramref name="issues"/> (si no es null) los errores y avisos de la estructura de grupos
        /// (contrato-0.3.md, cierre 2.4). Con algún error devuelve el guion original sin tocar.
        /// </summary>
        public static GuionDocument Expand(GuionDocument doc, List<ValidationIssue> issues)
        {
            if (!UsesGroups(doc)) return doc;
            var run = new Run(doc);
            run.ExpandTopLevel();
            issues?.AddRange(run.Issues);
            if (ValidationIssue.AnyError(run.Issues)) return doc;
            return run.Build();
        }

        /// <summary>
        /// Para el importador: desenrolla y lista en el informe cada id desenrollado con su grupo y su vuelta. Con errores de
        /// estructura devuelve el original, que el validador rechaza con el motivo.
        /// </summary>
        public static GuionDocument ExpandForImport(GuionDocument doc, ImportReport report)
        {
            var expanded = Expand(doc);
            if (ReferenceEquals(expanded, doc) || report == null) return expanded;
            foreach (var step in expanded.Steps)
                if (step?.ExpandedFrom != null)
                    report.Expand(step.ExpandedFrom.Iteration > 0
                        ? $"{step.Id} ← grupo {step.ExpandedFrom.Group}, vuelta {step.ExpandedFrom.Iteration}"
                        : $"{step.Id} ← grupo {step.ExpandedFrom.Group}");
            return expanded;
        }

        // Una pasada de desenrollado: la salida plana, sus orígenes y los hallazgos.
        private sealed class Run
        {
            private readonly GuionDocument _doc;
            public readonly List<ValidationIssue> Issues = new();
            private readonly List<JObject> _steps = new();
            private readonly List<Origin> _origins = new();
            private readonly Dictionary<string, string> _groupFirstStep = new();
            private readonly Dictionary<string, int> _counters = new();   // contador -> repetir más alto
            private readonly HashSet<string> _usedBlocks = new();

            public Run(GuionDocument doc) => _doc = doc;

            private sealed class Ctx
            {
                public string Prefix = "";
                public string TopGroup;
                public int TopIteration;
                public int Depth;
                public JObject Si;
                public string SiOwner;
                public Dictionary<string, int> CounterValues = new();
                public List<string> BlockStack = new();
            }

            public void ExpandTopLevel()
            {
                ExpandList(_doc.Steps, new Ctx(), "pasos");
                CheckIds();
                CheckSections();
                if (_doc.Blocks != null)
                    foreach (var name in _doc.Blocks.Keys)
                        if (!_usedBlocks.Contains(name))
                            Issues.Add(ValidationIssue.Warning($"bloques.{name}", $"El bloque '{name}' no lo usa ningún grupo."));
            }

            private void ExpandList(List<GuionDocument.StepEntry> steps, Ctx ctx, string path)
            {
                if (steps == null) return;
                foreach (var step in steps)
                {
                    if (step == null) continue;
                    var stepPath = $"{path}[{step.Id}]";
                    if (step.Kind == GroupKind) ExpandGroup(step, ctx, stepPath);
                    else EmitLeaf(step, ctx, stepPath);
                }
            }

            private void EmitLeaf(GuionDocument.StepEntry step, Ctx ctx, string path)
            {
                var jo = JObject.FromObject(step, Serializer);
                foreach (var k in GroupKeys) jo.Remove(k);
                jo["id"] = ctx.Prefix + step.Id;

                if (ctx.Si != null)
                {
                    var own = jo["si"] as JObject;
                    if (own != null)
                        foreach (var p in own.Properties())
                            if (ctx.Si[p.Name] != null)
                                Issues.Add(ValidationIssue.Warning(path + ".si",
                                    $"El paso '{ctx.Prefix + step.Id}' vuelve a poner '{p.Name}' en su 'si', que ya guarda el grupo '{ctx.SiOwner}': vale el del paso."));
                    jo["si"] = MergeUnder(own, ctx.Si);
                    foreach (var written in WrittenVariables(jo))
                        if (ctx.Si[written] != null)
                            Issues.Add(ValidationIssue.Warning(path,
                                $"El paso '{ctx.Prefix + step.Id}' escribe '{written}', que guarda el 'si' del grupo '{ctx.SiOwner}': los pasos siguientes de la vuelta pueden saltarse."));
                }

                if (ctx.CounterValues.Count > 0) SubstituteCounters(jo, ctx.CounterValues);

                _steps.Add(jo);
                _origins.Add(ctx.TopGroup == null ? null : new Origin
                {
                    Id = ctx.Prefix + step.Id, Group = ctx.TopGroup, Iteration = ctx.TopIteration, Path = path
                });
            }

            private void ExpandGroup(GuionDocument.StepEntry g, Ctx ctx, string path)
            {
                var gid = g.Id;
                if (string.IsNullOrEmpty(gid))
                {
                    Issues.Add(ValidationIssue.Error(path + ".id", "Un grupo no tiene id: el id del grupo forma los ids de sus pasos."));
                    return;
                }
                if (ctx.Depth >= MaxDepth)
                {
                    Issues.Add(ValidationIssue.Error(path,
                        $"El grupo '{ctx.Prefix + gid}' está dentro de {ctx.Depth} grupos: se admiten {MaxDepth} niveles como mucho."));
                    return;
                }

                bool hasInline = g.GroupSteps != null;
                bool hasBlock = !string.IsNullOrEmpty(g.Block);
                List<GuionDocument.StepEntry> body = null;
                string bodyPath = path + ".pasos";
                if (hasInline && hasBlock)
                {
                    Issues.Add(ValidationIssue.Error(path,
                        $"El grupo '{gid}' trae 'pasos' y 'bloque' a la vez: usa uno de los dos."));
                    return;
                }
                if (hasBlock)
                {
                    if (ctx.BlockStack.Contains(g.Block))
                    {
                        Issues.Add(ValidationIssue.Error(path + ".bloque",
                            $"El bloque '{g.Block}' se usa a sí mismo ({string.Join(" → ", ctx.BlockStack)} → {g.Block})."));
                        return;
                    }
                    if (_doc.Blocks == null || !_doc.Blocks.TryGetValue(g.Block, out body))
                    {
                        Issues.Add(ValidationIssue.Error(path + ".bloque",
                            $"El grupo '{gid}' usa el bloque '{g.Block}', que no está en 'bloques'."));
                        return;
                    }
                    _usedBlocks.Add(g.Block);
                    bodyPath = $"bloques.{g.Block}";
                }
                else body = g.GroupSteps;

                if (body == null || body.Count == 0)
                {
                    Issues.Add(ValidationIssue.Error(path,
                        hasBlock
                            ? $"El grupo '{gid}' no tiene pasos: el bloque '{g.Block}' está vacío."
                            : $"El grupo '{gid}' no tiene pasos: pon la lista en 'pasos' o nombra un bloque en 'bloque'."));
                    return;
                }

                int repeat = g.Repeat ?? 1;
                if (repeat < 1 || repeat > MaxRepeat)
                {
                    Issues.Add(ValidationIssue.Error(path + ".repetir",
                        $"El grupo '{gid}' pide repetir {repeat} veces: 'repetir' va de 1 a {MaxRepeat}."));
                    return;
                }
                if (repeat > WarnRepeat)
                    Issues.Add(ValidationIssue.Warning(path + ".repetir",
                        $"El grupo '{gid}' se repite {repeat} veces: más de {WarnRepeat} vueltas se hace largo de recorrer."));

                if (g.PerIteration != null && g.PerIteration.Count != repeat)
                {
                    Issues.Add(ValidationIssue.Error(path + ".porIteracion",
                        $"El grupo '{gid}' tiene {g.PerIteration.Count} elementos en 'porIteracion' y se repite {repeat} veces: tiene que haber uno por vuelta."));
                    return;
                }

                var counter = g.Counter;
                if (!string.IsNullOrEmpty(counter))
                {
                    if (!CounterPattern.IsMatch(counter))
                    {
                        Issues.Add(ValidationIssue.Error(path + ".contador",
                            $"El contador '{counter}' solo puede llevar minúsculas, cifras y guiones."));
                        return;
                    }
                    if (ctx.CounterValues.ContainsKey(counter))
                    {
                        Issues.Add(ValidationIssue.Error(path + ".contador",
                            $"El contador '{counter}' ya lo usa un grupo que contiene a '{gid}': ponle otro nombre."));
                        return;
                    }
                    _counters[counter] = _counters.TryGetValue(counter, out var r) ? System.Math.Max(r, repeat) : repeat;
                }

                var groupJson = JObject.FromObject(g, Serializer);
                var groupSi = groupJson["si"] as JObject;
                bool groupTask = g.CountsAsTask;

                int groupStart = _steps.Count;
                for (int k = 1; k <= repeat; k++)
                {
                    var inner = new Ctx
                    {
                        Prefix = ctx.Prefix + gid + (repeat > 1 ? "." + k : "") + ".",
                        TopGroup = ctx.TopGroup ?? gid,
                        TopIteration = ctx.TopGroup == null ? (repeat > 1 ? k : 0) : ctx.TopIteration,
                        Depth = ctx.Depth + 1,
                        Si = groupSi != null ? MergeUnder(groupSi, ctx.Si) : ctx.Si,
                        SiOwner = groupSi != null ? gid : ctx.SiOwner,
                        CounterValues = new Dictionary<string, int>(ctx.CounterValues),
                        BlockStack = new List<string>(ctx.BlockStack)
                    };
                    if (!string.IsNullOrEmpty(counter)) inner.CounterValues[counter] = k;
                    if (hasBlock) inner.BlockStack.Add(g.Block);

                    int first = _steps.Count;
                    ExpandList(body, inner, bodyPath);
                    if (_steps.Count == first) continue;

                    // El estado de la vuelta, por debajo del alIniciar del primer paso: contador, después porIteracion.
                    var start = new JObject();
                    if (!string.IsNullOrEmpty(counter)) start[counter] = k;
                    if (g.PerIteration != null && g.PerIteration[k - 1] != null)
                        foreach (var p in g.PerIteration[k - 1].Properties()) start[p.Name] = p.Value.DeepClone();
                    if (start.Count > 0)
                        _steps[first]["alIniciar"] = MergeUnder(_steps[first]["alIniciar"] as JObject, start);
                }

                if (_steps.Count > groupStart)
                {
                    _groupFirstStep[ctx.Prefix + gid] = (string)_steps[groupStart]["id"];
                    if (groupTask)
                    {
                        var last = _steps[_steps.Count - 1];
                        last["tarea"] = true;
                        if (!string.IsNullOrEmpty(g.TaskLabel)) last["etiquetaTarea"] = g.TaskLabel;
                    }
                }
            }

            private void CheckIds()
            {
                var seen = new Dictionary<string, int>();
                for (int i = 0; i < _steps.Count; i++)
                {
                    var id = (string)_steps[i]["id"] ?? "";
                    var origin = _origins[i];
                    var where = origin != null ? $" (del grupo '{origin.Group}', en {origin.Path})" : "";
                    if (id.Length > MaxIdLength)
                        Issues.Add(ValidationIssue.Error($"pasos[{id}].id",
                            $"El id desenrollado '{id}'{where} tiene {id.Length} caracteres: el backend admite {MaxIdLength}. Acorta el id del grupo o del paso."));
                    if (seen.TryGetValue(id, out var before))
                    {
                        var otherOrigin = _origins[before];
                        var other = otherOrigin != null ? $"el grupo '{otherOrigin.Group}'" : "un paso de primer nivel";
                        Issues.Add(ValidationIssue.Error($"pasos[{id}].id",
                            $"El id desenrollado '{id}'{where} se repite con {other}: cambia el id del grupo o del paso."));
                    }
                    else seen[id] = i;
                }
            }

            private void CheckSections()
            {
                if (_doc.Sections == null) return;
                foreach (var s in _doc.Sections)
                    if (s != null && !string.IsNullOrEmpty(s.FromStepId) && _groupFirstStep.TryGetValue(s.FromStepId, out var firstId))
                        _sectionTargets[s.FromStepId] = firstId;
            }

            private readonly Dictionary<string, string> _sectionTargets = new();

            public GuionDocument Build()
            {
                var root = JObject.FromObject(_doc, Serializer);
                root.Remove("bloques");
                var steps = new JArray();
                foreach (var s in _steps) steps.Add(s);
                root["pasos"] = steps;

                if (root["secciones"] is JArray sections)
                    foreach (var s in sections)
                        if (s is JObject so && so["desde"] != null && _sectionTargets.TryGetValue((string)so["desde"], out var to))
                            so["desde"] = to;

                if (_counters.Count > 0)
                {
                    var state = root["estado"] as JObject ?? new JObject();
                    foreach (var c in _counters)
                        if (state[c.Key] == null) state[c.Key] = new JObject { ["inicial"] = 0 };
                    root["estado"] = state;
                }

                var expanded = GuionDocument.Parse(root.ToString(Formatting.None));
                for (int i = 0; i < expanded.Steps.Count && i < _origins.Count; i++)
                    expanded.Steps[i].ExpandedFrom = _origins[i];
                return expanded;
            }
        }

        // ── Ayudas ───────────────────────────────────────────────────────────

        // Copia de "over" con lo de "under" que no está en él (los valores de "over" ganan); null si los dos lo son.
        private static JObject MergeUnder(JObject over, JObject under)
        {
            if (under == null) return over == null ? null : (JObject)over.DeepClone();
            var result = (JObject)under.DeepClone();
            if (over != null)
                foreach (var p in over.Properties()) result[p.Name] = p.Value.DeepClone();
            return result;
        }

        // Variables que escribe un paso: claves de alIniciar y alCompletar, y de cada efecto de alError.
        private static IEnumerable<string> WrittenVariables(JObject step)
        {
            foreach (var key in EffectKeys)
                if (step[key] is JObject effects)
                    foreach (var p in effects.Properties()) yield return p.Name;
            if (step["alError"] is JObject byKey)
                foreach (var e in byKey.Properties())
                    if (e.Value is JObject effects)
                        foreach (var p in effects.Properties()) yield return p.Name;
        }

        /// <summary>Sustituye <c>{contador}</c> por su valor en los ids de frase de un paso (cierre 2.2): intro, instruccion, pista, exito, errores.</summary>
        private static void SubstituteCounters(JObject step, Dictionary<string, int> values)
        {
            foreach (var key in PhraseKeys)
                if (step[key] is JValue v && v.Type == JTokenType.String)
                    step[key] = Substitute((string)v, values);
            if (step["intro"] is JArray intro)
                for (int i = 0; i < intro.Count; i++)
                    if (intro[i].Type == JTokenType.String) intro[i] = Substitute((string)intro[i], values);
            if (step["errores"] is JObject errors)
                foreach (var p in errors.Properties())
                    if (p.Value.Type == JTokenType.String) p.Value = Substitute((string)p.Value, values);
        }

        public static string Substitute(string text, Dictionary<string, int> values)
        {
            if (string.IsNullOrEmpty(text) || text.IndexOf('{') < 0) return text;
            foreach (var kv in values) text = text.Replace("{" + kv.Key + "}", kv.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
            return text;
        }
    }
}
