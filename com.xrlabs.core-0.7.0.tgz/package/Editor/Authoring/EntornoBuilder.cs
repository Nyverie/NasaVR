using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// El entorno de una muestra (2026-10-25): si la muestra trae <c>Samples~/&lt;muestra&gt;/Entorno/</c> (FBX y texturas del
    /// arte del equipo), se copia a <c>&lt;assetsRoot&gt;/&lt;id&gt;/Entorno/Arte/</c>, se arma
    /// <c>&lt;assetsRoot&gt;/&lt;id&gt;/Entorno/Entorno.prefab</c> (suelo de tierra, la planta de concreto como telón de fondo
    /// y un sol cálido sin sombras) y se instancia como raíz suelta <c>Entorno</c> de la escena, fuera de
    /// <c>[Colocacion]</c>, como el terreno (arte-compostaje.md §5.2). Sin colliders: los recuadros traen el suyo.
    /// Coordenadas en ejes glTF de la colocación, convertidas con <see cref="GltfToUnity"/>. Convención en autoria.md.
    /// <para>
    /// Si la carpeta Entorno trae <c>entorno.json</c> (<see cref="EntornoDisposicion"/>, 2026-10-25: la planta completa del
    /// artista de la réplica del web), ese fichero manda: las piezas van donde las dejó el artista en su prefab, con
    /// materiales URP Lit de sus texturas (color y normal; metálico y suavidad ya empaquetados), colliders solo donde se pisa y
    /// los prefabs envoltorio <c>Assets/Experiencias/&lt;id&gt;/Modelos/&lt;modelo&gt;.prefab</c> de los objetos del guion, cada
    /// uno con un hijo <c>Ajuste</c>. Sin el fichero, todo lo de arriba sigue igual (D8).
    /// </para>
    /// <para>
    /// Si la carpeta Entorno trae <c>terreno.json</c> (2026-10-31, el terreno low-poly <c>CampoCompostaje</c> que escribe
    /// <c>Tools~/arte/generar_terreno.py</c>), el entorno es ese terreno en lugar del suelo liso y la planta de concreto: el
    /// FBX con sus materiales URP Lit de color plano, las cajas de colisión de la pirca, el corral y el cobertizo, y un
    /// <c>Suelo</c> invisible y teletransportable a la altura del terreno (arte-compostaje.md §3).
    /// </para>
    /// </summary>
    public static class EntornoBuilder
    {
        public const string RootName = "Entorno";
        public const string FolderName = "Entorno";

        /// <summary>Llamado por ScenePreparer.Prepare. Sin carpeta Entorno en la muestra, no hace nada.</summary>
        public static void Prepare(Scene scene, string experienceId, string assetsRoot, ImportReport report)
        {
            try
            {
                string source = FindSampleEntorno(experienceId);
                if (source == null) return;
                var prefab = BuildPrefab(source, $"{assetsRoot}/{experienceId}/{FolderName}");
                if (prefab == null) { report.Warn("Entorno: no se pudo armar el prefab."); return; }
                foreach (var go in scene.GetRootGameObjects())
                    if (go.name == RootName) return;
                var made = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
                made.name = RootName;
                report.Create(RootName + (made.transform.Find(TerrenoName) != null
                    ? " (terreno CampoCompostaje low-poly y sol)"
                    : " (suelo, planta de concreto y sol del arte del equipo)"));
            }
            catch (Exception ex)
            {
                report.Warn("Entorno: se omitió (" + ex.Message + ").");
            }
        }

        /// <summary>La carpeta <c>Entorno</c> de la muestra cuyo guion tiene ese id, o null.</summary>
        public static string FindSampleEntorno(string experienceId)
        {
            string root = SamplePreparer.SamplesRoot();
            if (!Directory.Exists(root)) return null;
            foreach (var dir in Directory.GetDirectories(root))
            {
                string guion = Path.Combine(dir, "guion.json"), entorno = Path.Combine(dir, FolderName);
                if (!File.Exists(guion) || !Directory.Exists(entorno)) continue;
                if (GuionDocument.Load(guion).Experience.Id == experienceId) return entorno;
            }
            return null;
        }

        /// <summary>Copia el arte (si falta) y arma o rehace <c>Entorno.prefab</c> en <paramref name="folder"/>.</summary>
        public static GameObject BuildPrefab(string sourceDir, string folder)
        {
            string art = folder + "/Arte";
            CopyMissing(sourceDir, AbsolutePath(art));
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

            var layout = EntornoDisposicion.TryLoad(sourceDir);
            if (layout != null) return BuildFromLayout(layout, sourceDir, art, folder);
            var terreno = TryLoadTerreno(sourceDir);
            if (terreno != null) return BuildFromTerreno(terreno, art, folder);

            string mats = folder + "/Materiales";
            EnsureFolders(mats);
            var concreto = Lit(mats + "/Concreto.mat", Color.white, 0.2f, art + "/Texturas/concreto_BaseColor.png");
            var calamina = Lit(mats + "/Calamina.mat", Color.white, 0.3f, art + "/Texturas/calamina y maderos_BaseColor_sRGB.png");
            var tierra = Lit(mats + "/Tierra.mat", new Color(0.42f, 0.33f, 0.22f), 0.1f);
            var bloque = Lit(mats + "/Bloque.mat", new Color(0.62f, 0.60f, 0.57f), 0.15f);
            var tanque = Lit(mats + "/Tanque.mat", new Color(0.10f, 0.11f, 0.12f), 0.4f);
            var humus = Lit(mats + "/Contenedor.mat", new Color(0.18f, 0.30f, 0.20f), 0.3f);

            var root = new GameObject(RootName);
            try
            {
                // Suelo de tierra de 24 × 22 m, centrado en (3, 0, −3) glTF: cubre el inicio, las zonas y la planta.
                var suelo = GameObject.CreatePrimitive(PrimitiveType.Plane);
                suelo.name = "Suelo";
                UnityEngine.Object.DestroyImmediate(suelo.GetComponent<Collider>());
                suelo.transform.SetParent(root.transform, false);
                suelo.transform.localPosition = GltfToUnity.Position(3f, 0f, -3f);
                suelo.transform.localScale = new Vector3(2.4f, 1f, 2.2f);
                SetMaterial(suelo, tierra);

                // La planta de concreto, telón de fondo detrás de la pila y de la zona D (x glTF > 8,4: fuera de zonas,
                // recuadros y objetos, que llegan a x 7,2). Losa de 6,27 × 3,54 con el lado largo a lo largo de z.
                var planta = new GameObject("PlantaConcreto");
                planta.transform.SetParent(root.transform, false);
                Place(planta, art, "base_de_concreto_low", "Losa", 10.2f, -4.5f, 90f, concreto);
                for (int i = 0; i < 3; i++)
                    Place(planta, art, "muro_1", "MuroFondo" + i, 12.25f, -2.14f - 2.36f * i, 90f, bloque);
                Place(planta, art, "muro_2", "MuroLado0", 11.45f, -7.85f, 90f, bloque);
                Place(planta, art, "muro_2", "MuroLado1", 11.45f, -1.15f, 90f, bloque);
                float[] cx = { 8.55f, 11.95f }, cz = { -1.45f, -4.5f, -7.55f };
                int n = 0;
                foreach (var x in cx)
                foreach (var z in cz)
                    Place(planta, art, "columna", "Columna" + n++, x, z, 0f, concreto, new Vector3(1f, 2f, 1f));
                for (int i = 0; i < 5; i++)
                    Place(planta, art, "calamina", "Calamina" + i, 10.25f, -1.8f - 1.35f * i, 90f, calamina, Vector3.one, 2.42f);
                Place(planta, art, "rotoplas", "Tanque", 8.7f, -8.6f, 0f, tanque);
                Place(planta, art, "contenedor_de_humus", "ContenedorHumus", 9.4f, 0.4f, 90f, humus);

                AddSun(root.transform);

                foreach (var c in root.GetComponentsInChildren<Collider>(true)) UnityEngine.Object.DestroyImmediate(c);
                foreach (var r in root.GetComponentsInChildren<Renderer>(true)) r.shadowCastingMode = ShadowCastingMode.Off;
                MakeTeleportable(suelo);

                string path = folder + "/" + RootName + ".prefab";
                return PrefabUtility.SaveAsPrefabAsset(root, path);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        // terreno 2026-10-31 ─────────────────────────────────────────────────

        /// <summary>El manifiesto del terreno low-poly en la carpeta Entorno de la muestra.</summary>
        public const string TerrenoFile = "terreno.json";
        /// <summary>El hijo del entorno con el FBX del terreno (bajado <see cref="SueloDrop"/>, como el suelo).</summary>
        public const string TerrenoName = "Terreno";
        /// <summary>El hijo con las cajas de colisión del terreno (pirca, corral, cobertizo).</summary>
        public const string TerrenoCollidersName = "Colliders";

        /// <summary><c>terreno.json</c> de la carpeta, o null si no está.</summary>
        public static JObject TryLoadTerreno(string entornoFolder)
        {
            string path = Path.Combine(entornoFolder ?? string.Empty, TerrenoFile);
            return File.Exists(path) ? JObject.Parse(File.ReadAllText(path)) : null;
        }

        /// <summary>
        /// Arma el prefab del entorno con el terreno: <c>Terreno</c> (el FBX, con la base 1 cm bajo las zonas, que están a
        /// ras de suelo), sus materiales URP Lit de color plano por nombre, <c>Colliders</c> (las cajas del manifiesto, en ejes
        /// glTF), <c>Suelo</c> (sin malla: solo el collider fino y la <c>TeleportationArea</c> de siempre, sobre el
        /// rectángulo plano del terreno, para que el rayo no deje a nadie dentro de la ladera) y el sol sin sombras.
        /// </summary>
        private static GameObject BuildFromTerreno(JObject t, string art, string folder)
        {
            string fbx = (string)t["fbx"] ?? "Modelos/CampoCompostaje.fbx";
            fbx = Path.GetFileNameWithoutExtension(fbx);
            string mats = folder + "/Materiales";
            EnsureFolders(mats);
            var materials = new Dictionary<string, Material>();
            foreach (var m in (JArray)t["materiales"] ?? new JArray())
            {
                var c = (JArray)m["color"];
                string name = (string)m["nombre"];
                materials[name] = Lit($"{mats}/{name}.mat", new Color((float)c[0], (float)c[1], (float)c[2]),
                    (float?)m["suavidad"] ?? 0.1f);
            }

            var root = new GameObject(RootName);
            try
            {
                var terreno = InstantiateFbx(art, fbx, root.transform);
                terreno.name = TerrenoName;
                terreno.transform.localPosition = new Vector3(0f, -SueloDrop, 0f);
                foreach (var r in terreno.GetComponentsInChildren<Renderer>(true))
                {
                    var arr = r.sharedMaterials;
                    for (int i = 0; i < arr.Length; i++)
                    {
                        string key = arr[i] != null ? arr[i].name.Replace(" (Instance)", "") : "";
                        if (!materials.TryGetValue(key, out var mat))
                            throw new InvalidOperationException($"terreno.json: el FBX trae el material «{key}» y el manifiesto no.");
                        arr[i] = mat;
                    }
                    r.sharedMaterials = arr;
                }
                foreach (var c in terreno.GetComponentsInChildren<Collider>(true)) UnityEngine.Object.DestroyImmediate(c);

                var holder = new GameObject(TerrenoCollidersName);
                holder.transform.SetParent(root.transform, false);
                int n = 0;
                foreach (var c in (JArray)t["colliders"] ?? new JArray())
                {
                    var p = (JArray)c["centro"];
                    var s = (JArray)c["tamano"];
                    var go = new GameObject($"{(string)c["nombre"]}{n++}");
                    go.transform.SetParent(holder.transform, false);
                    go.transform.localPosition = GltfToUnity.Position((float)p[0], (float)p[1], (float)p[2]);
                    go.transform.localRotation = Quaternion.Euler(0f, -((float?)c["giro"] ?? 0f), 0f);
                    var box = go.AddComponent<BoxCollider>();
                    box.size = new Vector3((float)s[0], (float)s[1], (float)s[2]);
                }

                var tele = t["teletransporte"] ?? t["suelo"];
                var tc = (JArray)tele["centro"];
                var ts = (JArray)tele["tamano"];
                var suelo = new GameObject("Suelo");
                suelo.transform.SetParent(root.transform, false);
                suelo.transform.localPosition = GltfToUnity.Position((float)tc[0], (float)tc[1], (float)tc[2]);
                // MakeTeleportable pone la caja de 10 × 10 del plano de Unity: la escala es el tamaño entre diez.
                suelo.transform.localScale = new Vector3((float)ts[0] / 10f, 1f, (float)ts[1] / 10f);
                MakeTeleportable(suelo);

                AddSun(root.transform);
                foreach (var r in root.GetComponentsInChildren<Renderer>(true)) r.shadowCastingMode = ShadowCastingMode.Off;
                return PrefabUtility.SaveAsPrefabAsset(root, folder + "/" + RootName + ".prefab");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        // ── fin terreno 2026-10-31 ──────────────────────────────────────────

        // Sol cálido, sin sombras en tiempo real (el URP del Quest no las tiene).
        private static void AddSun(Transform parent)
        {
            var sol = new GameObject("Sol");
            sol.transform.SetParent(parent, false);
            sol.transform.localRotation = Quaternion.Euler(50f, 150f, 0f);
            var light = sol.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1f, 0.90f, 0.76f);
            light.intensity = 1.1f;
            light.shadows = LightShadows.None;
        }

        // ── Disposición del artista (entorno.json) ───────────────────────────

        /// <summary>
        /// Arma el prefab del entorno desde <c>entorno.json</c>: <c>Planta</c> (la raíz del artista, desplazada <c>raiz.pos</c>) con
        /// el suelo, las piezas por grupo y los colliders declarados; el sol; y, en la carpeta hermana <c>Modelos</c>, un prefab
        /// por cada <c>modelos</c>. Lanza <see cref="InvalidOperationException"/> si la disposición no cuadra con los ficheros.
        /// </summary>
        private static GameObject BuildFromLayout(EntornoDisposicion layout, string sourceDir, string art, string folder)
        {
            var problems = layout.Problems(sourceDir);
            if (problems.Count > 0) throw new InvalidOperationException("entorno.json: " + string.Join(" ", problems));

            string mats = folder + "/Materiales";
            EnsureFolders(mats);
            var materials = new Dictionary<string, Material>();
            foreach (var pair in layout.Materials)
                materials[pair.Key] = LayoutMaterial(mats + "/" + pair.Key + ".mat", pair.Value, art);

            var root = new GameObject(RootName);
            try
            {
                var planta = new GameObject("Planta");
                planta.transform.SetParent(root.transform, false);
                planta.transform.localPosition = Vec3(layout.Root.Pos);

                if (layout.Ground != null)
                {
                    var suelo = GameObject.CreatePrimitive(PrimitiveType.Plane);
                    suelo.name = "Suelo";
                    UnityEngine.Object.DestroyImmediate(suelo.GetComponent<Collider>());
                    suelo.transform.SetParent(planta.transform, false);
                    suelo.transform.localPosition = Vec3(layout.Ground.Center);
                    // El plano de Unity mide 10 × 10: la escala es el tamaño pedido entre diez.
                    suelo.transform.localScale = new Vector3(layout.Ground.Size[0] / 10f, 1f, layout.Ground.Size[1] / 10f);
                    var c = layout.Ground.Color;
                    SetMaterial(suelo, Lit(mats + "/Suelo.mat", new Color(c[0], c[1], c[2]), layout.Ground.Smoothness));
                    MakeTeleportable(suelo);
                }

                var groups = new Dictionary<string, Transform>();
                foreach (var piece in layout.Pieces)
                {
                    var parent = planta.transform;
                    if (!string.IsNullOrEmpty(piece.Group))
                    {
                        if (!groups.TryGetValue(piece.Group, out parent))
                        {
                            var g = new GameObject(piece.Group);
                            g.transform.SetParent(planta.transform, false);
                            groups[piece.Group] = parent = g.transform;
                        }
                    }
                    var inst = InstantiateFbx(art, piece.Fbx, parent);
                    inst.name = piece.Name;
                    inst.transform.localPosition = Vec3(piece.Pos);
                    inst.transform.localRotation = new Quaternion(piece.Rot[0], piece.Rot[1], piece.Rot[2], piece.Rot[3]).normalized;
                    if (piece.Scale != null) inst.transform.localScale = Vec3(piece.Scale);
                    SetMaterial(inst, materials[piece.Material]);
                }

                // Colliders solo donde se pisa: nada de los FBX (sin colliders) ni de las máquinas.
                if (layout.Colliders.Count > 0)
                {
                    var holder = new GameObject("Colliders");
                    holder.transform.SetParent(planta.transform, false);
                    foreach (var c in layout.Colliders)
                    {
                        var go = new GameObject(c.Name);
                        go.transform.SetParent(holder.transform, false);
                        var box = go.AddComponent<BoxCollider>();
                        box.center = Vec3(c.Center);
                        box.size = Vec3(c.Size);
                    }
                }

                AddSun(root.transform);
                foreach (var r in root.GetComponentsInChildren<Renderer>(true)) r.shadowCastingMode = ShadowCastingMode.Off;

                BuildModelPrefabs(layout, art, folder, materials);
                return PrefabUtility.SaveAsPrefabAsset(root, folder + "/" + RootName + ".prefab");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        /// <summary>Lo que baja el suelo bajo el plano de las zonas (que están a ras de suelo) para no taparles el collider.</summary>
        public const float SueloDrop = 0.01f;

        /// <summary>
        /// El suelo se puede pisar con el teletransporte (cuarto recorrido del visor, 2026-10-25: «no sabía cómo
        /// teletransportarme»; en la planta del artista apenas hay recuadros). Una <c>TeleportationArea</c> igual a la de los
        /// recuadros que crea <c>ColocacionImporter</c>: solo la capa de interacción <c>Teleport</c> (la única que ven los rayos
        /// de teletransporte del rig; los rayos de agarre no la ven), orientación según el mundo, proveedor vacío (XRI busca el
        /// del rig al despertar) y teletransporte al soltar. El collider es una caja fina y sólida (XRI descarta los trigger)
        /// cuya cara de arriba es el plano, y el suelo baja <see cref="SueloDrop"/>: las zonas de soltar y los recuadros, a ras
        /// de suelo, quedan por encima y mandan donde se solapan.
        /// </summary>
        private static void MakeTeleportable(GameObject suelo)
        {
            suelo.transform.localPosition -= new Vector3(0f, SueloDrop, 0f);
            var box = suelo.GetComponent<BoxCollider>();
            if (box == null) box = suelo.AddComponent<BoxCollider>();   // sin ??: Unity no devuelve null de C# en el Editor
            box.isTrigger = false;
            box.center = new Vector3(0f, -0.05f, 0f);   // el plano de Unity mide 10 × 10 en su espacio local
            box.size = new Vector3(10f, 0.1f, 10f);
            var area = suelo.GetComponent<TeleportationArea>();
            if (area == null) area = suelo.AddComponent<TeleportationArea>();
            area.interactionLayers = TeleportInteractionLayer.Mask;
            area.matchOrientation = MatchOrientation.WorldSpaceUp;
            area.teleportTrigger = BaseTeleportationInteractable.TeleportTrigger.OnSelectExited;
            area.teleportationProvider = null;
        }

        /// <summary>
        /// Los prefabs envoltorio de los objetos del guion, en <c>&lt;experiencia&gt;/Modelos/&lt;modelo&gt;.prefab</c> (donde los busca
        /// la colocación): raíz con el nombre del modelo, un hijo <c>Ajuste</c> y dentro el FBX con su posición a cero (los FBX
        /// del artista no estaban en el origen: el origen del objeto queda donde el artista tenía el origen del nodo), con la
        /// rotación y la escala que trae el FBX. Sin colliders: el importador de la colocación pone la caja al que se agarra.
        /// </summary>
        private static void BuildModelPrefabs(EntornoDisposicion layout, string art, string folder, Dictionary<string, Material> materials)
        {
            if (layout.Models.Count == 0) return;
            string modelsFolder = folder.Substring(0, folder.LastIndexOf('/')) + "/Modelos";
            EnsureFolders(modelsFolder);
            foreach (var model in layout.Models)
            {
                var root = new GameObject(model.Model);
                try
                {
                    var ajuste = new GameObject("Ajuste");
                    ajuste.transform.SetParent(root.transform, false);
                    if (model.Scale.HasValue) ajuste.transform.localScale = Vector3.one * model.Scale.Value;
                    var inst = InstantiateFbx(art, model.Fbx, ajuste.transform);
                    inst.transform.localPosition = Vector3.zero;
                    SetMaterial(inst, materials[model.Material]);
                    foreach (var r in root.GetComponentsInChildren<Renderer>(true)) r.shadowCastingMode = ShadowCastingMode.Off;
                    PrefabUtility.SaveAsPrefabAsset(root, modelsFolder + "/" + model.Model + ".prefab");
                }
                finally
                {
                    UnityEngine.Object.DestroyImmediate(root);
                }
            }
        }

        private static GameObject InstantiateFbx(string art, string fbx, Transform parent)
        {
            var asset = AssetDatabase.LoadAssetAtPath<GameObject>($"{art}/Modelos/{fbx}.fbx");
            if (asset == null) throw new InvalidOperationException($"No se importó {art}/Modelos/{fbx}.fbx.");
            return (GameObject)PrefabUtility.InstantiatePrefab(asset, parent);
        }

        private static Material LayoutMaterial(string path, EntornoDisposicion.MaterialEntry entry, string art)
        {
            string baseTex = string.IsNullOrEmpty(entry.Base) ? null : art + "/" + entry.Base;
            string normalTex = string.IsNullOrEmpty(entry.Normal) ? null : art + "/" + entry.Normal;
            string msTex = string.IsNullOrEmpty(entry.MetalSmoothness) ? null : art + "/" + entry.MetalSmoothness;
            // El normal se importa como mapa de normales; el metálico/suavidad, en lineal (no es un color).
            if (normalTex != null) ConfigureTexture(normalTex, TextureImporterType.NormalMap, true);
            if (msTex != null) ConfigureTexture(msTex, TextureImporterType.Default, false);
            var color = baseTex != null || entry.Color == null || entry.Color.Length < 3
                ? Color.white
                : new Color(entry.Color[0], entry.Color[1], entry.Color[2]);
            var mat = Lit(path, color, entry.Smoothness ?? 0.3f, baseTex, normalTex, msTex);
            // _Cull de URP Lit: 0 = las dos caras, 2 = solo la de delante (lo normal).
            mat.SetFloat("_Cull", entry.DoubleSided ? 0f : 2f);
            EditorUtility.SetDirty(mat);
            return mat;
        }

        private static void ConfigureTexture(string assetPath, TextureImporterType type, bool srgb)
        {
            if (AssetImporter.GetAtPath(assetPath) is not TextureImporter importer) return;
            bool changed = false;
            if (importer.textureType != type) { importer.textureType = type; changed = true; }
            if (type != TextureImporterType.NormalMap && importer.sRGBTexture != srgb) { importer.sRGBTexture = srgb; changed = true; }
            if (changed) importer.SaveAndReimport();
        }

        private static Vector3 Vec3(float[] v) => new Vector3(v[0], v[1], v[2]);

        // Instancia el FBX (con el giro de su raíz tal cual) dentro de un envoltorio girado y lo corre para que su caja
        // quede centrada en (x, z) glTF y con la base a la altura dada: los FBX del artista no estaban en el origen.
        private static void Place(GameObject parent, string art, string model, string name, float x, float z, float giro,
            Material material, Vector3? scale = null, float baseY = 0f)
        {
            var fbx = AssetDatabase.LoadAssetAtPath<GameObject>($"{art}/Modelos/{model}.fbx");
            if (fbx == null) return;
            var wrapper = new GameObject(name);
            wrapper.transform.SetParent(parent.transform, false);
            var target = GltfToUnity.Position(x, 0f, z);
            wrapper.transform.localPosition = target;
            wrapper.transform.localRotation = Quaternion.Euler(0f, -giro, 0f);
            wrapper.transform.localScale = scale ?? Vector3.one;
            var inst = (GameObject)PrefabUtility.InstantiatePrefab(fbx, wrapper.transform);
            SetMaterial(inst, material);
            var renderers = inst.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) return;
            var b = renderers[0].bounds;
            foreach (var r in renderers) b.Encapsulate(r.bounds);
            var world = parent.transform.TransformPoint(target);
            inst.transform.position += new Vector3(world.x - b.center.x, baseY - b.min.y, world.z - b.center.z);
        }

        private static void SetMaterial(GameObject go, Material material)
        {
            foreach (var r in go.GetComponentsInChildren<Renderer>(true))
            {
                var arr = new Material[r.sharedMaterials.Length];
                for (int i = 0; i < arr.Length; i++) arr[i] = material;
                r.sharedMaterials = arr;
            }
        }

        private static Material Lit(string path, Color color, float smoothness, string texture = null,
            string normal = null, string metalSmoothness = null)
        {
            var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (mat == null)
            {
                mat = new Material(shader);
                AssetDatabase.CreateAsset(mat, path);
            }
            mat.shader = shader;
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
            mat.color = color;
            if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", smoothness);
            var tex = texture != null ? AssetDatabase.LoadAssetAtPath<Texture2D>(texture) : null;
            if (tex != null && mat.HasProperty("_BaseMap")) mat.SetTexture("_BaseMap", tex);

            // Normal y metálico/suavidad (2026-10-25): URP Lit lee el normal de _BumpMap y, con el mapa empaquetado, el
            // metálico del canal R y la suavidad del A (el _Smoothness del material pasa a ser un factor: 1).
            var bump = normal != null ? AssetDatabase.LoadAssetAtPath<Texture2D>(normal) : null;
            if (bump != null && mat.HasProperty("_BumpMap"))
            {
                mat.SetTexture("_BumpMap", bump);
                mat.EnableKeyword("_NORMALMAP");
            }
            var metal = metalSmoothness != null ? AssetDatabase.LoadAssetAtPath<Texture2D>(metalSmoothness) : null;
            if (metal != null && mat.HasProperty("_MetallicGlossMap"))
            {
                mat.SetTexture("_MetallicGlossMap", metal);
                mat.EnableKeyword("_METALLICSPECGLOSSMAP");
                if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", 1f);
            }
            EditorUtility.SetDirty(mat);
            return mat;
        }

        private static void CopyMissing(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (var file in Directory.GetFiles(from))
            {
                // Sin .meta ni .mat del artista: Unity da GUID nuevos y los materiales URP Lit se hacen aquí.
                // Tampoco entorno.json: lo lee el constructor de la propia carpeta de la muestra, no es arte.
                if (file.EndsWith(".meta") || file.EndsWith(".mat") || Path.GetFileName(file) == EntornoDisposicion.FileName
                    || Path.GetFileName(file) == TerrenoFile) continue;
                string dest = Path.Combine(to, Path.GetFileName(file));
                if (!File.Exists(dest)) File.Copy(file, dest);
            }
            foreach (var dir in Directory.GetDirectories(from))
                CopyMissing(dir, Path.Combine(to, Path.GetFileName(dir)));
        }

        private static void EnsureFolders(string assetFolder)
        {
            var parts = assetFolder.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }

        private static string AbsolutePath(string assetPath) =>
            Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? ".", assetPath);
    }
}
