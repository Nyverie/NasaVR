using System;
using System.Collections.Generic;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Valida una colocación contra su guion antes de importar (Documentation~/autoria.md §4.2). Pura, sin Unity: errores que
    /// impiden importar y avisos que lo dejan pasar, con la ruta del hallazgo dentro del fichero (por ejemplo
    /// <c>objetos[pila].pos</c>; si el elemento no tiene id, su índice). Acepta los esquemas 0.1 y 0.2; las zonas `soltar` y
    /// la referencia cruzada con los pasos `llevar` son de la 0.2 (Documentation~/contrato-0.2.md §5).
    /// </summary>
    public static class ColocacionValidator
    {
        public static List<ValidationIssue> Validate(ColocacionDocument doc, GuionDocument guion)
        {
            if (doc == null) throw new ArgumentNullException(nameof(doc));
            if (guion == null) throw new ArgumentNullException(nameof(guion));

            var issues = new List<ValidationIssue>();

            if (doc.Schema != ColocacionDocument.SchemaId && doc.Schema != ColocacionDocument.SchemaId02 && doc.Schema != ColocacionDocument.SchemaId03)
                issues.Add(ValidationIssue.Error("esquema",
                    $"El esquema es '{doc.Schema}' y esta versión del framework lee '{ColocacionDocument.SchemaId}' y '{ColocacionDocument.SchemaId02}'."));

            string guionId = guion.Experience?.Id;
            if (doc.Experience != guionId)
                issues.Add(ValidationIssue.Error("experiencia",
                    $"La colocación es de la experiencia '{doc.Experience}' y el guion es '{guionId}'."));

            if (doc.Start == null)
                issues.Add(ValidationIssue.Error("inicio", "Falta el punto de inicio."));
            else
                CheckPos(issues, "inicio.pos", doc.Start.Pos);

            ValidateAnchors(doc, issues);
            var placed = ValidateObjects(doc, guion, issues);
            var dropZones = ValidateZones(doc, guion, issues);

            // Una zona `soltar` es de la 0.2 (contrato-0.2.md §3): en un fichero que declara 0.1 se lee, pero se avisa.
            if (doc.Schema == ColocacionDocument.SchemaId && dropZones.Count > 0)
                issues.Add(ValidationIssue.Warning("esquema",
                    $"La colocación declara '{ColocacionDocument.SchemaId}' y usa zonas 'soltar', que son de la 0.2 " +
                    $"({string.Join(", ", dropZones)}): usa '{ColocacionDocument.SchemaId02}' en 'esquema'."));

            ValidateDropSteps(guion, dropZones, issues);
            ValidateState03(doc, guion, issues);   // 0.3 lote 1
            GuionValidator.ValidateLockZones(guion, dropZones, issues);   // 0.3 lote 6
            ValidateMeasure(doc, issues);   // 0.3 lote 6

            // Un paso del guion nombra un ancla que la colocación no declara.
            var anchorIds = new HashSet<string>();
            foreach (var a in doc.Anchors ?? new List<ColocacionDocument.AnchorEntry>())
                if (a != null && !string.IsNullOrEmpty(a.Id)) anchorIds.Add(a.Id);
            foreach (var step in guion.Steps ?? new List<GuionDocument.StepEntry>())
            {
                if (step == null || string.IsNullOrEmpty(step.AnchorId)) continue;
                if (!anchorIds.Contains(step.AnchorId))
                    issues.Add(ValidationIssue.Error($"pasos[{Key(step.Id, 0)}].ancla",
                        $"El paso '{step.Id}' usa el ancla '{step.AnchorId}' y la colocación no la declara en 'anclas'."));
            }

            // Objetos del guion que nadie coloca: el importador no los crea, y el paso que los señale no encontrará el destino.
            foreach (var obj in guion.Objects ?? new List<GuionDocument.ObjectEntry>())
            {
                if (obj == null || string.IsNullOrEmpty(obj.Id)) continue;
                if (!placed.Contains(obj.Id))
                    issues.Add(ValidationIssue.Warning($"objetos[{obj.Id}]",
                        $"El objeto '{obj.Id}' del guion no tiene colocación: no aparecerá en la escena."));
            }

            return issues;
        }

        private static void ValidateAnchors(ColocacionDocument doc, List<ValidationIssue> issues)
        {
            var seen = new HashSet<string>();
            var list = doc.Anchors ?? new List<ColocacionDocument.AnchorEntry>();
            for (int i = 0; i < list.Count; i++)
            {
                var a = list[i];
                if (a == null) { issues.Add(ValidationIssue.Error($"anclas[{i}]", "La entrada está vacía.")); continue; }
                string path = $"anclas[{Key(a.Id, i)}]";
                if (string.IsNullOrEmpty(a.Id)) issues.Add(ValidationIssue.Error(path + ".id", "El ancla no tiene id."));
                else if (!seen.Add(a.Id)) issues.Add(ValidationIssue.Error(path + ".id", $"El id de ancla '{a.Id}' está repetido."));
                CheckPos(issues, path + ".pos", a.Pos);
            }
        }

        // Devuelve los ids de objeto colocados (los que existen en el guion), para el aviso de «sin colocación».
        private static HashSet<string> ValidateObjects(ColocacionDocument doc, GuionDocument guion, List<ValidationIssue> issues)
        {
            var seen = new HashSet<string>();
            var placed = new HashSet<string>();
            var list = doc.Objects ?? new List<ColocacionDocument.PlacedObject>();
            for (int i = 0; i < list.Count; i++)
            {
                var o = list[i];
                if (o == null) { issues.Add(ValidationIssue.Error($"objetos[{i}]", "La entrada está vacía.")); continue; }
                string path = $"objetos[{Key(o.Id, i)}]";
                if (string.IsNullOrEmpty(o.Id))
                    issues.Add(ValidationIssue.Error(path + ".id", "El objeto no tiene id."));
                else
                {
                    if (!seen.Add(o.Id))
                        issues.Add(ValidationIssue.Error(path + ".id", $"El id de objeto '{o.Id}' está repetido."));
                    if (guion.FindObject(o.Id) == null)
                        issues.Add(ValidationIssue.Error(path + ".id", $"El objeto '{o.Id}' no existe en 'objetos' del guion."));
                    else
                        placed.Add(o.Id);
                }
                CheckPos(issues, path + ".pos", o.Pos);
                if (!(o.Scale > 0f) || float.IsInfinity(o.Scale))
                    issues.Add(ValidationIssue.Error(path + ".escala", "La escala tiene que ser un número mayor que cero."));
            }
            return placed;
        }

        // Devuelve los ids de las zonas `soltar` declaradas, para el aviso de esquema y la referencia cruzada de los pasos `llevar`.
        private static List<string> ValidateZones(ColocacionDocument doc, GuionDocument guion, List<ValidationIssue> issues)
        {
            var seen = new HashSet<string>();
            var dropZones = new List<string>();
            var list = doc.Zones ?? new List<ColocacionDocument.ZoneEntry>();
            for (int i = 0; i < list.Count; i++)
            {
                var z = list[i];
                if (z == null) { issues.Add(ValidationIssue.Error($"zonas[{i}]", "La entrada está vacía.")); continue; }
                string path = $"zonas[{Key(z.Id, i)}]";
                if (string.IsNullOrEmpty(z.Id)) issues.Add(ValidationIssue.Error(path + ".id", "La zona no tiene id."));
                else if (!seen.Add(z.Id)) issues.Add(ValidationIssue.Error(path + ".id", $"El id de zona '{z.Id}' está repetido."));
                if (z.Kind != "teleport" && z.Kind != "soltar")
                    issues.Add(ValidationIssue.Error(path + ".tipo", $"El tipo de zona '{z.Kind}' no se admite; los tipos son 'teleport' y 'soltar'."));
                CheckPos(issues, path + ".pos", z.Pos);
                if (z.Size == null || z.Size.Length != 2)
                    issues.Add(ValidationIssue.Error(path + ".tamano", "El tamaño tiene que ser dos números: [ancho, largo]."));
                else if (!(z.Size[0] > 0f) || !(z.Size[1] > 0f) || float.IsInfinity(z.Size[0]) || float.IsInfinity(z.Size[1]))
                    issues.Add(ValidationIssue.Error(path + ".tamano", "El ancho y el largo tienen que ser mayores que cero."));

                if (z.Kind == "soltar")
                {
                    if (!string.IsNullOrEmpty(z.Id)) dropZones.Add(z.Id);
                    ValidateDropZone(z, path, guion, issues);
                }
                else if (z.Kind == "teleport")
                {
                    // Campos de la zona `soltar` en una `teleport`: no hacen nada, y quien los escribió creía otra cosa.
                    if (z.Height.HasValue)
                        issues.Add(ValidationIssue.Warning(path + ".alto", "El alto solo vale en una zona 'soltar'; en 'teleport' la altura es fija y se ignora."));
                    if (z.Accepts != null && z.Accepts.Count > 0)
                        issues.Add(ValidationIssue.Warning(path + ".acepta", "'acepta' solo vale en una zona 'soltar'; en 'teleport' se ignora."));
                    if (z.Snap)
                        issues.Add(ValidationIssue.Warning(path + ".imantar", "'imantar' solo vale en una zona 'soltar'; en 'teleport' se ignora."));
                    // UX visor 2026-10-31: mirarHacia tiene que nombrar algo de la colocación.
                    if (!string.IsNullOrEmpty(z.LookAt) && !PlacementHasId(doc, z.LookAt))
                        issues.Add(ValidationIssue.Warning(path + ".mirarHacia", $"'{z.LookAt}' no es un ancla, objeto ni zona de la colocación; la llegada mirará como el giro de la zona."));
                }
                else if (!string.IsNullOrEmpty(z.LookAt))
                    issues.Add(ValidationIssue.Warning(path + ".mirarHacia", "'mirarHacia' solo vale en una zona 'teleport'; se ignora."));   // UX visor 2026-10-31
            }
            return dropZones;
        }

        // UX visor 2026-10-31
        private static bool PlacementHasId(ColocacionDocument doc, string id)
        {
            if (doc.Anchors != null) foreach (var a in doc.Anchors) if (a != null && a.Id == id) return true;
            if (doc.Objects != null) foreach (var o in doc.Objects) if (o != null && o.Id == id) return true;
            if (doc.Zones != null) foreach (var z in doc.Zones) if (z != null && z.Id == id) return true;
            return false;
        }

        // Zona `soltar` (contrato-0.2.md §5): alto mayor que cero y `acepta` con al menos un objeto agarrable del guion.
        private static void ValidateDropZone(ColocacionDocument.ZoneEntry z, string path, GuionDocument guion, List<ValidationIssue> issues)
        {
            if (z.Height.HasValue && (!(z.Height.Value > 0f) || float.IsInfinity(z.Height.Value)))
                issues.Add(ValidationIssue.Error(path + ".alto", "El alto tiene que ser un número mayor que cero."));

            if (z.Accepts == null || z.Accepts.Count == 0)
            {
                issues.Add(ValidationIssue.Error(path + ".acepta",
                    "Una zona 'soltar' tiene que decir qué acepta: al menos un id de objeto agarrable, fuente o herramienta."));
                return;
            }
            for (int j = 0; j < z.Accepts.Count; j++)
            {
                string id = z.Accepts[j];
                var obj = guion.FindObject(id);
                if (obj == null)
                    issues.Add(ValidationIssue.Error($"{path}.acepta[{j}]", $"El objeto '{id}' no existe en 'objetos' del guion."));
                else if (!obj.IsGrabbable)
                    issues.Add(ValidationIssue.Error($"{path}.acepta[{j}]",
                        $"El objeto '{id}' es de tipo '{obj.Kind}' y una zona solo acepta objetos 'agarrable', 'fuente' o 'herramienta'."));
            }
        }

        // Referencia cruzada de los pasos `llevar` (contrato-0.2.md §5): cada zona que nombran tiene que ser una zona `soltar`.
        private static void ValidateDropSteps(GuionDocument guion, List<string> dropZones, List<ValidationIssue> issues)
        {
            var steps = guion.Steps ?? new List<GuionDocument.StepEntry>();
            for (int i = 0; i < steps.Count; i++)
            {
                var step = steps[i];
                if (step == null || step.Kind != "llevar" || step.Condition == null) continue;
                string path = $"pasos[{Key(step.Id, i)}].condicion";

                var zones = step.Condition.Zones ?? new List<string>();
                for (int j = 0; j < zones.Count; j++)
                    if (!dropZones.Contains(zones[j]))
                        issues.Add(ValidationIssue.Error($"{path}.zonas[{j}]",
                            $"El paso '{step.Id}' usa la zona '{zones[j]}' y la colocación no la declara como zona 'soltar' en 'zonas'."));

                var rules = step.Condition.Rules ?? new List<GuionDocument.DropRuleEntry>();
                for (int j = 0; j < rules.Count; j++)
                {
                    var rule = rules[j];
                    if (rule == null || string.IsNullOrEmpty(rule.ZoneId)) continue;   // sin zona = cualquiera
                    if (!dropZones.Contains(rule.ZoneId))
                        issues.Add(ValidationIssue.Error($"{path}.reglas[{j}].zona",
                            $"El paso '{step.Id}' usa la zona '{rule.ZoneId}' en una regla y la colocación no la declara como zona 'soltar' en 'zonas'."));
                }
            }
        }

        // 0.3 lote 6: `medir` (contrato-0.3.md §3, cierre 3): "contacto" o "centro"; otro valor, error. En una zona `teleport` no
        // hace nada (aviso), y en un fichero 0.1 o 0.2 es de la 0.3 (aviso).
        private static void ValidateMeasure(ColocacionDocument doc, List<ValidationIssue> issues)
        {
            var zones = doc.Zones ?? new List<ColocacionDocument.ZoneEntry>();
            for (int i = 0; i < zones.Count; i++)
            {
                var z = zones[i];
                if (z?.Measure == null) continue;
                string path = $"zonas[{Key(z.Id, i)}].medir";
                if (z.Measure != "contacto" && z.Measure != "centro")
                    issues.Add(ValidationIssue.Error(path, $"'medir' vale '{z.Measure}'; los valores son 'contacto' (por defecto) y 'centro'."));
                else if (z.Kind != "soltar")
                    issues.Add(ValidationIssue.Warning(path, "'medir' solo vale en una zona 'soltar'; aquí se ignora."));
            }
            // Un fichero 0.1 o 0.2 que usa 'medir' recibe el aviso de esquema de ValidateState03, junto con lo demás de la 0.3
            // (integración del 0.3, 2026-10-31: un solo aviso).
        }

        private static void CheckPos(List<ValidationIssue> issues, string path, float[] pos)
        {
            if (pos == null || pos.Length != 3)
            {
                issues.Add(ValidationIssue.Error(path, $"La posición tiene que ser tres números [x, y, z]; trae {(pos == null ? "ninguno" : pos.Length.ToString())}."));
                return;
            }
            foreach (float v in pos)
                if (float.IsNaN(v) || float.IsInfinity(v))
                {
                    issues.Add(ValidationIssue.Error(path, "La posición trae un valor que no es un número finito."));
                    return;
                }
        }

        private static string Key(string id, int index) => string.IsNullOrEmpty(id) ? index.ToString() : id;

        #region 0.3 lote 1

        // Contrato 0.3 §2.10: `visibleSi` en objetos y zonas, y `conjuntos` con `posicionSegun`, cruzados con el `estado` del
        // guion. Una colocación 0.1 o 0.2 que los usa recibe un aviso (§3: `xrlabs.colocacion/0.3` solo si los usa).
        private static void ValidateState03(ColocacionDocument doc, GuionDocument guion, List<ValidationIssue> issues)
        {
            var used = new List<string>();
            var objectIds = new HashSet<string>();
            var zoneIds = new HashSet<string>();
            var anchorIds = new HashSet<string>();
            var objectsById = new Dictionary<string, ColocacionDocument.PlacedObject>();

            var objects = doc.Objects ?? new List<ColocacionDocument.PlacedObject>();
            for (int i = 0; i < objects.Count; i++)
            {
                var o = objects[i];
                if (o == null) continue;
                if (!string.IsNullOrEmpty(o.Id)) { objectIds.Add(o.Id); objectsById[o.Id] = o; }
                if (o.VisibleIf == null) continue;
                if (!used.Contains("visibleSi")) used.Add("visibleSi");
                StateAuthoring.ParseConditions(o.VisibleIf, guion, $"objetos[{Key(o.Id, i)}].visibleSi", issues);
            }
            var zones = doc.Zones ?? new List<ColocacionDocument.ZoneEntry>();
            for (int i = 0; i < zones.Count; i++)
            {
                var z = zones[i];
                if (z == null) continue;
                if (!string.IsNullOrEmpty(z.Id)) zoneIds.Add(z.Id);
                if (z.VisibleIf == null) continue;
                if (!used.Contains("visibleSi")) used.Add("visibleSi");
                StateAuthoring.ParseConditions(z.VisibleIf, guion, $"zonas[{Key(z.Id, i)}].visibleSi", issues);
            }
            foreach (var a in doc.Anchors ?? new List<ColocacionDocument.AnchorEntry>())
                if (a != null && !string.IsNullOrEmpty(a.Id)) anchorIds.Add(a.Id);

            var sets = doc.Sets ?? new List<ColocacionDocument.SetEntry>();
            if (sets.Count > 0) used.Add("conjuntos");
            var setIds = new HashSet<string>();
            var owner = new Dictionary<string, string>();   // "objetos:pila" -> id del conjunto
            for (int i = 0; i < sets.Count; i++)
            {
                var set = sets[i];
                string path = $"conjuntos[{Key(set?.Id, i)}]";
                if (set == null) { issues.Add(ValidationIssue.Error(path, "La entrada está vacía.")); continue; }
                if (string.IsNullOrEmpty(set.Id)) issues.Add(ValidationIssue.Error(path + ".id", "El conjunto no tiene id."));
                else if (!setIds.Add(set.Id)) issues.Add(ValidationIssue.Error(path + ".id", $"El id de conjunto '{set.Id}' está repetido."));
                CheckPos(issues, path + ".origen", set.Origin);

                var members = set.Members ?? new ColocacionDocument.SetMembers();
                int count = CheckMembers(members.Objects, "objetos", objectIds, set.Id, path, owner, issues)
                          + CheckMembers(members.Zones, "zonas", zoneIds, set.Id, path, owner, issues)
                          + CheckMembers(members.Anchors, "anclas", anchorIds, set.Id, path, owner, issues);
                if (count == 0) issues.Add(ValidationIssue.Warning(path + ".miembros", "El conjunto no tiene miembros."));

                if (set.VisibleIf != null) StateAuthoring.ParseConditions(set.VisibleIf, guion, path + ".visibleSi", issues);
                if (set.PositionBy != null) CheckPositionBy(set, path + ".posicionSegun", guion, objectsById, issues);
            }

            foreach (var z in zones)   // 0.3 lote 6: 'medir' entra en el mismo aviso
                if (z?.Measure != null) { if (!used.Contains("medir")) used.Add("medir"); break; }
            if (used.Count > 0 && doc.Schema != ColocacionDocument.SchemaId03
                && (doc.Schema == ColocacionDocument.SchemaId || doc.Schema == ColocacionDocument.SchemaId02))
                issues.Add(ValidationIssue.Warning("esquema",
                    $"La colocación declara '{doc.Schema}' y usa cosas de la 0.3 ({string.Join(", ", used)}): " +
                    $"usa '{ColocacionDocument.SchemaId03}' en 'esquema'."));
        }

        private static int CheckMembers(List<string> ids, string kind, HashSet<string> existing, string setId, string path,
            Dictionary<string, string> owner, List<ValidationIssue> issues)
        {
            if (ids == null) return 0;
            int count = 0;
            for (int k = 0; k < ids.Count; k++)
            {
                string id = ids[k];
                string p = $"{path}.miembros.{kind}[{k}]";
                if (string.IsNullOrEmpty(id) || !existing.Contains(id))
                {
                    issues.Add(ValidationIssue.Error(p, $"'{id}' no está en '{kind}' de la colocación."));
                    continue;
                }
                string key = kind + ":" + id;
                if (owner.TryGetValue(key, out var other))
                    issues.Add(ValidationIssue.Error(p, $"'{id}' ya es miembro del conjunto '{other}': un miembro va en un solo conjunto."));
                else owner[key] = setId ?? string.Empty;
                count++;
            }
            return count;
        }

        private static void CheckPositionBy(ColocacionDocument.SetEntry set, string path, GuionDocument guion,
            Dictionary<string, ColocacionDocument.PlacedObject> objectsById, List<ValidationIssue> issues)
        {
            var by = set.PositionBy;
            var v = StateAuthoring.FindVariable(guion, by.Variable);
            if (v == null)
            {
                issues.Add(ValidationIssue.Error(path + ".estado", $"La variable '{by.Variable}' no está declarada en el 'estado' del guion."));
                return;
            }
            if (!v.IsText)
            {
                issues.Add(ValidationIssue.Error(path + ".estado", $"'{by.Variable}' es numérica: 'posicionSegun' pide una variable de texto."));
                return;
            }
            if (by.Offset != null && by.Offset.Length != 3)
                issues.Add(ValidationIssue.Error(path + ".desplazar", "El desplazamiento tiene que ser tres números [x, y, z]."));

            if (by.Places == null || by.Places.Count == 0)
            {
                issues.Add(ValidationIssue.Warning(path + ".lugares", "No hay lugares: el conjunto se queda donde está escrito."));
                return;
            }
            foreach (var pair in by.Places)
            {
                string p = $"{path}.lugares.{pair.Key}";
                if (!v.Values.Contains(pair.Key))
                    issues.Add(ValidationIssue.Error(p, $"'{pair.Key}' no está en los valores de '{by.Variable}' ({string.Join(", ", v.Values)})."));
                var token = pair.Value;
                if (token != null && token.Type == Newtonsoft.Json.Linq.JTokenType.String)
                {
                    if (!objectsById.ContainsKey((string)token))
                        issues.Add(ValidationIssue.Error(p, $"El objeto '{token}' no está en 'objetos' de la colocación."));
                }
                else if (token is Newtonsoft.Json.Linq.JObject obj)
                {
                    float[] pos = null;
                    try { pos = obj["pos"]?.ToObject<float[]>(); } catch (Exception) { pos = null; }
                    CheckPos(issues, p + ".pos", pos);
                }
                else
                    issues.Add(ValidationIssue.Error(p, "Un lugar es el id de un objeto de la colocación o { \"pos\": [x, y, z], \"giro\": g }."));
            }

            WarnLateMove(set, by.Variable, guion, path, issues);
        }

        // Aviso (§2.10): la variable cambia después de que un paso ya usó un miembro (se movería a medio usar).
        private static void WarnLateMove(ColocacionDocument.SetEntry set, string variable, GuionDocument guion, string path,
            List<ValidationIssue> issues)
        {
            var members = new HashSet<string>();
            var m = set.Members ?? new ColocacionDocument.SetMembers();
            foreach (var id in m.Objects ?? new List<string>()) members.Add(id);
            foreach (var id in m.Zones ?? new List<string>()) members.Add(id);
            foreach (var id in m.Anchors ?? new List<string>()) members.Add(id);

            string firstUse = null;
            var steps = guion.Steps ?? new List<GuionDocument.StepEntry>();
            foreach (var step in steps)
            {
                if (step == null) continue;
                if (firstUse != null && WritesVariable(step, variable))
                {
                    issues.Add(ValidationIssue.Warning(path + ".estado",
                        $"El paso '{step.Id}' cambia '{variable}' después de que '{firstUse}' usó un miembro del conjunto '{set.Id}': se movería a medio usar."));
                    return;
                }
                if (firstUse == null && UsesAny(step, members)) firstUse = step.Id;
            }
        }

        private static bool WritesVariable(GuionDocument.StepEntry step, string variable)
        {
            if (step.OnComplete != null && step.OnComplete.ContainsKey(variable)) return true;
            foreach (var o in step.Condition?.Options ?? new List<GuionDocument.ChoiceOptionEntry>())
                if (o?.OnChoose != null && o.OnChoose.ContainsKey(variable)) return true;
            return false;
        }

        private static bool UsesAny(GuionDocument.StepEntry step, HashSet<string> members)
        {
            if (!string.IsNullOrEmpty(step.AnchorId) && members.Contains(step.AnchorId)) return true;
            foreach (var id in step.ActiveTargetIds ?? new List<string>()) if (members.Contains(id)) return true;
            var c = step.Condition;
            if (c == null) return false;
            if (!string.IsNullOrEmpty(c.ObjectId) && members.Contains(c.ObjectId)) return true;
            foreach (var id in c.Objects ?? new List<string>()) if (members.Contains(id)) return true;
            foreach (var id in c.Zones ?? new List<string>()) if (members.Contains(id)) return true;
            return false;
        }

        #endregion
    }
}
