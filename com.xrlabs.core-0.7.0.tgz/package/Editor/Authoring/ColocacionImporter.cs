using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using UnityEngine;
using XRLabs.Coach;
using XRLabs.Core;
using XRLabs.Interactions;
using InteractionLayerMask = UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask;
using MatchOrientation = UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation.MatchOrientation;
using Object = UnityEngine.Object;
using TeleportationArea = UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation.TeleportationArea;
using TeleportationAnchor = UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation.TeleportationAnchor;   // UX visor 2026-10-31

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// La capa de interacción de XRI que separa lo teleportable de lo demás (lote X2, 2026-10-10): la que llevan las
    /// <c>TeleportationArea</c> de las zonas y la única que ven los rayos de teleportación del rig XRI. Es el bit 31, el
    /// índice que usa la muestra Starter Assets de XRI 3.3.1 para «Teleport». La API pública de XRI no deja crear ni nombrar
    /// capas (<c>InteractionLayerSettings</c> es interna), así que el paquete no toca los ajustes del proyecto y fija el
    /// índice: lo que se serializa en prefabs y escenas es la máscara de bits, no el nombre, y la capa funciona aunque el
    /// proyecto no le haya puesto nombre. Si un proyecto la nombra, tiene que ser en el índice 31.
    /// </summary>
    public static class TeleportInteractionLayer
    {
        public const string Name = "Teleport";
        public const int Index = 31;

        /// <summary>La máscara con solo esta capa (<c>1 &lt;&lt; 31</c>).</summary>
        public static InteractionLayerMask Mask => 1 << Index;
    }

    /// <summary>
    /// Convierte una colocación (xrlabs.colocacion/0.1) en objetos de escena bajo un <c>Transform</c> raíz que le pasa quien
    /// llama (Documentation~/autoria.md §4.1). Idempotente por nombre de hijo: <c>Inicio</c>, <c>Ancla_&lt;id&gt;</c>,
    /// <c>Objeto_&lt;id&gt;</c> y <c>Zona_&lt;id&gt;</c>. Si el hijo existe lo actualiza (el mismo objeto, sin duplicar); si no,
    /// lo crea; y los hijos con esos nombres que ya no están en el fichero se borran y el informe lo dice.
    ///
    /// Posición, giro y escala pasan por <see cref="GltfToUnity"/> y se escriben en local respecto a la raíz (con la raíz en
    /// el origen, local y mundo coinciden). Los campos privados del runtime (<c>targetId</c>, <c>anchorId</c>, <c>faceUser</c>,
    /// <c>interactionId</c>) se escriben siempre con <see cref="SerializedObject"/>, como lo haría el Inspector: no se toca el
    /// runtime (D8). No toca nada fuera de la raíz, no guarda la escena y no crea tags.
    ///
    /// Desde la 0.2 (Documentation~/contrato-0.2.md §4 y §5) el tipo del objeto del guion decide su interactuable
    /// (<c>agarrable</c>, <c>fuente</c>, <c>superficie</c>, <c>boton</c>, <c>herramienta</c>, además de <c>hotspot</c>) y una
    /// zona <c>soltar</c> lleva <see cref="DropZone"/> o, con <c>imantar</c>, <see cref="SnapZone"/>. Si el tipo cambia entre
    /// importaciones, el componente que ya no corresponde se quita y el informe lo anota.
    /// </summary>
    public static class ColocacionImporter
    {
        public const string StartName = "Inicio";
        public const string AnchorPrefix = "Ancla_";
        public const string ObjectPrefix = "Objeto_";
        public const string ZonePrefix = "Zona_";
        public const string PlaceholderName = "Placeholder";
        /// <summary>El nombre flotante de un marcador o de una zona (2026-10-17: sin él, la escena sin modelos no se entiende).</summary>
        public const string LabelName = "Etiqueta";
        /// <summary>El recuadro en el suelo de una zona <c>soltar</c>.</summary>
        public const string ZoneFloorName = "Suelo";

        private const float PlaceholderSize = 0.3f;

        // Etiquetas flotantes (2026-10-25, primera prueba en el Quest 3: «tan grandes y pegadas que no entiendo qué es cada
        // cosa»). En TextMeshPro 3D el tamaño 1 es una línea de unos 10 cm; el recuadro de 1,4 × 0,5 m deja dos líneas y lo
        // que no cabe se corta, en vez de desbordar a los lados y montarse sobre la etiqueta del vecino.
        /// <summary>Tamaño de letra de la etiqueta de un marcador.</summary>
        public const float LabelFontSize = 1.0f;
        /// <summary>Tamaño de letra de la etiqueta de una zona <c>soltar</c>: más pequeña que la de los objetos que recibe.</summary>
        public const float ZoneLabelFontSize = 0.8f;
        /// <summary>Ancho (m) del recuadro de una etiqueta: el texto parte en líneas dentro de él.</summary>
        public const float LabelWidth = 1.4f;
        /// <summary>Alto (m) del recuadro de una etiqueta: dos líneas; lo que no cabe se trunca.</summary>
        public const float LabelHeight = 0.5f;
        // Altura de la etiqueta de un marcador sobre su base: el cubo de 0,3 m más 0,2 m de aire (eran 0,15 y se montaba).
        private const float ObjectLabelHeight = PlaceholderSize + 0.2f;
        private const float ZoneLabelHeight = 0.35f;

        // La zona es un suelo, no un muro: una caja baja deja pasar el rayo y el clic de lo que queda detrás.
        private const float ZoneHeight = 0.1f;

        public static ImportReport Import(ColocacionDocument doc, GuionDocument guion, Transform root,
            string assetsRoot = "Assets/Experiencias")
        {
            var report = new ImportReport();
            if (doc == null || guion == null || root == null)
            {
                report.Error("Faltan datos para importar la colocación (documento, guion o raíz de escena).");
                return report;
            }

            // Nombres que el fichero pide; lo que cuelgue de la raíz con estos prefijos y no esté aquí, se borra al final.
            var wanted = new HashSet<string> { StartName };

            FlattenSets03(root);   // 0.3 lote 1: los miembros vuelven a la raíz para importarse por nombre
            ImportStart(doc, root, report);
            foreach (var a in doc.Anchors ?? new List<ColocacionDocument.AnchorEntry>())
                ImportAnchor(a, root, wanted, report);
            foreach (var o in doc.Objects ?? new List<ColocacionDocument.PlacedObject>())
                ImportObject(o, doc, guion, assetsRoot, root, wanted, report);
            foreach (var z in doc.Zones ?? new List<ColocacionDocument.ZoneEntry>())
                ImportZone(z, root, wanted, report);

            ImportState03(doc, guion, root, wanted, report);   // 0.3 lote 1
            RemoveOrphans(root, wanted, report);

            // 2026-10-26: con experiencia.visibilidadPorPaso, la raíz lleva el StepVisibilityController con los tramos de cada
            // objeto y zona (autoria.md §12). Sin la opción no añade nada, y quita el que hubiera de antes.
            StepVisibilityPlanner.Apply(root, guion, report);
            ApplyTeleportGuides(doc, guion, root, report);   // UX visor 2026-10-31

            // La escena se marca como modificada y no se guarda (lo hace la ventana). Una raíz que no se guarda nunca
            // (HideAndDontSave, como las de los tests) no ensucia la escena.
            var scene = root.gameObject.scene;
            if (scene.IsValid() && scene.isLoaded && (root.hideFlags & HideFlags.DontSave) == 0)
                EditorSceneManager.MarkSceneDirty(scene);

            return report;
        }

        // ---------------------------------------------------------------- Inicio

        private static void ImportStart(ColocacionDocument doc, Transform root, ImportReport report)
        {
            if (doc.Start == null) { report.Error("Falta 'inicio': no se creó el punto de inicio."); return; }
            if (!TryPosition(doc.Start.Pos, "inicio.pos", report, out var position)) return;

            var go = GetOrCreate(root, StartName, out bool created);
            Place(go.transform, position, doc.Start.Yaw, 1f);
            var target = GetOrAdd<SceneTarget>(go);
            SetString(report, target, "targetId", "inicio");
            Log(report, created, StartName);
        }

        // ---------------------------------------------------------------- Anclas

        private static void ImportAnchor(ColocacionDocument.AnchorEntry a, Transform root, HashSet<string> wanted, ImportReport report)
        {
            if (a == null || string.IsNullOrEmpty(a.Id)) { report.Error("Hay un ancla sin id: no se importó."); return; }
            string name = AnchorPrefix + a.Id;
            wanted.Add(name);
            if (!TryPosition(a.Pos, $"anclas[{a.Id}].pos", report, out var position)) return;

            var go = GetOrCreate(root, name, out bool created);
            Place(go.transform, position, a.Yaw, 1f);
            var anchor = GetOrAdd<CoachAnchor>(go);
            SetString(report, anchor, "anchorId", a.Id);
            SetBool(report, anchor, "faceUser", a.FaceUser);
            Log(report, created, name);
        }

        // ---------------------------------------------------------------- Objetos

        private static void ImportObject(ColocacionDocument.PlacedObject o, ColocacionDocument doc, GuionDocument guion, string assetsRoot,
            Transform root, HashSet<string> wanted, ImportReport report)
        {
            if (o == null || string.IsNullOrEmpty(o.Id)) { report.Error("Hay un objeto sin id: no se importó."); return; }
            string name = ObjectPrefix + o.Id;
            wanted.Add(name);
            if (!TryPosition(o.Pos, $"objetos[{o.Id}].pos", report, out var position)) return;

            var go = GetOrCreate(root, name, out bool created);
            Place(go.transform, position, o.Yaw, o.Scale > 0f ? o.Scale : 1f);
            var target = GetOrAdd<SceneTarget>(go);
            SetString(report, target, "targetId", o.Id);

            var entry = guion.FindObject(o.Id);
            if (entry == null)
                report.Warn($"{name}: el objeto '{o.Id}' no está en el guion; se coloca sin modelo ni hotspot.");

            var notes = new List<string>();
            EnsureModel(go, entry?.Model, guion.Experience?.Id, assetsRoot, notes, report);
            // Con modelo, el arte habla; sin él, el marcador lleva su nombre del guion para que la escena se entienda.
            if (go.transform.Find(PlaceholderName) != null) EnsureLabel(go.transform, entry?.Name ?? o.Id, ObjectLabelHeight, LabelFontSize);
            else RemoveChild(go.transform, LabelName);

            ApplyKind(go, o.Id, entry, doc, guion, assetsRoot, notes, report);

            if (entry != null) ApplyTag(go, entry, guion, name, report);

            Log(report, created, notes.Count == 0 ? name : $"{name} ({string.Join("; ", notes)})");
        }

        private static void EnsureModel(GameObject go, string model, string experienceId, string assetsRoot,
            List<string> notes, ImportReport report)
        {
            GameObject prefab = FindModelPrefab(model, experienceId, assetsRoot);
            var placeholder = go.transform.Find(PlaceholderName);

            if (prefab != null)
            {
                if (placeholder != null) Object.DestroyImmediate(placeholder.gameObject);
                if (go.transform.Find(prefab.name) != null) return;   // ya está instanciado: no se duplica

                var instance = PrefabUtility.InstantiatePrefab(prefab, go.transform) as GameObject;
                if (instance == null)
                {
                    // La raíz no está en una escena que admita instancias de prefab: se instancia como copia.
                    instance = Object.Instantiate(prefab, go.transform);
                    instance.name = prefab.name;
                    report.Warn($"{go.name}: el modelo '{prefab.name}' se instanció como copia, no como instancia de prefab.");
                }
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                notes.Add($"modelo '{prefab.name}'");
                return;
            }

            if (placeholder == null) CreatePlaceholder(go.transform);
            if (!string.IsNullOrEmpty(model)) notes.Add($"marcador: no hay prefab para el modelo '{model}'");
        }

        private static GameObject FindModelPrefab(string model, string experienceId, string assetsRoot)
        {
            if (string.IsNullOrEmpty(model)) return null;
            // El nombre del modelo se usa como nombre de fichero: sin rutas ni saltos de carpeta.
            if (model.Contains("/") || model.Contains("\\") || model.Contains("..")) return null;

            if (!string.IsNullOrEmpty(experienceId) && !string.IsNullOrEmpty(assetsRoot))
            {
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>($"{assetsRoot}/{experienceId}/Modelos/{model}.prefab");
                if (prefab != null) return prefab;
            }
            return Resources.Load<GameObject>(model);
        }

        // Texto flotante que mira a la cámara (FaceCamera), a <paramref name="height"/> metros sobre el origen del padre.
        // TextMeshPro 3D con la fuente por defecto del proyecto (TMP Essentials). Idempotente: actualiza el texto y reescribe
        // el formato, así que una escena importada antes del 2026-10-25 (letra 2,2, sin partir) queda bien al reimportar.
        private static void EnsureLabel(Transform parent, string text, float height, float fontSize)
        {
            var label = GetOrCreate(parent, LabelName, out _);
            label.transform.localPosition = new Vector3(0f, height, 0f);
            label.transform.localScale = Vector3.one;
            var tmp = GetOrAdd<TMPro.TextMeshPro>(label);
            tmp.rectTransform.sizeDelta = new Vector2(LabelWidth, LabelHeight);
            tmp.fontSize = fontSize;
            tmp.alignment = TMPro.TextAlignmentOptions.Center;
            tmp.textWrappingMode = TMPro.TextWrappingModes.Normal;
            tmp.overflowMode = TMPro.TextOverflowModes.Truncate;
            tmp.fontStyle = TMPro.FontStyles.Bold;
            tmp.color = Color.white;   // sin contorno: tocar outlineWidth instancia el material en edición y ensucia la escena
            tmp.text = text ?? string.Empty;
            GetOrAdd<FaceCamera>(label);
        }

        // Un Quad tumbado del tamaño de la zona, un centímetro sobre el suelo, sin collider (no debe tapar el rayo ni el trigger).
        private static void EnsureZoneFloor(Transform parent, float width, float length)
        {
            var existing = parent.Find(ZoneFloorName);
            GameObject floor;
            if (existing != null) floor = existing.gameObject;
            else
            {
                floor = GameObject.CreatePrimitive(PrimitiveType.Quad);
                floor.name = ZoneFloorName;
                floor.transform.SetParent(parent, false);
            }
            foreach (var collider in floor.GetComponents<Collider>()) Object.DestroyImmediate(collider);
            floor.transform.localPosition = new Vector3(0f, 0.01f, 0f);
            floor.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            floor.transform.localScale = new Vector3(width, length, 1f);
        }

        private static void RemoveChild(Transform parent, string name)
        {
            var child = parent.Find(name);
            if (child != null) Object.DestroyImmediate(child.gameObject);
        }

        /// <summary>«area-acopio» → «Area acopio»: el id de una zona como texto legible (las zonas no llevan nombre en el fichero).</summary>
        public static string Humanize(string id)
        {
            if (string.IsNullOrEmpty(id)) return string.Empty;
            var text = id.Replace('-', ' ').Replace('_', ' ');
            return char.ToUpperInvariant(text[0]) + text.Substring(1);
        }

        // Cubo de 0,3 m con su base en el origen del objeto. El primitivo trae un BoxCollider: se asegura que sea el único.
        private static void CreatePlaceholder(Transform parent)
        {
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = PlaceholderName;
            cube.transform.SetParent(parent, false);
            cube.transform.localPosition = new Vector3(0f, PlaceholderSize * 0.5f, 0f);
            cube.transform.localRotation = Quaternion.identity;
            cube.transform.localScale = Vector3.one * PlaceholderSize;
            var mesh = cube.GetComponent<MeshCollider>();
            if (mesh != null) Object.DestroyImmediate(mesh);
            if (cube.GetComponent<BoxCollider>() == null) cube.AddComponent<BoxCollider>();
        }

        // Devuelve true si tuvo que agregar el collider.
        private static bool EnsureCollider(GameObject go)
        {
            if (go.GetComponentInChildren<Collider>(true) != null) return false;
            AddFittedBox(go, 0f);
            return true;
        }

        // BoxCollider en la raíz del objeto, ajustado a los renderers de su jerarquía (o al marcador si no hay ninguno),
        // con <paramref name="margin"/> metros de más por cada lado.
        private static BoxCollider AddFittedBox(GameObject go, float margin)
        {
            var box = go.AddComponent<BoxCollider>();
            bool any = false;
            Bounds local = default;
            foreach (var r in go.GetComponentsInChildren<Renderer>(true))
            {
                Bounds b = r.bounds;
                for (int i = 0; i < 8; i++)
                {
                    var corner = b.center + Vector3.Scale(b.extents, new Vector3(
                        (i & 1) == 0 ? -1f : 1f, (i & 2) == 0 ? -1f : 1f, (i & 4) == 0 ? -1f : 1f));
                    var p = go.transform.InverseTransformPoint(corner);
                    if (!any) { local = new Bounds(p, Vector3.zero); any = true; }
                    else local.Encapsulate(p);
                }
            }
            if (any)
            {
                box.center = local.center;
                box.size = local.size;
            }
            else
            {
                box.center = new Vector3(0f, PlaceholderSize * 0.5f, 0f);
                box.size = Vector3.one * PlaceholderSize;
            }
            box.size += Vector3.one * (margin * 2f);
            return box;
        }

        // ---------------------------------------------------------------- Tipos de objeto (contrato-0.2.md §4)

        // Los interactuables que este importador crea según el tipo del objeto. Lo que no esté aquí no se toca.
        private static readonly Type[] ManagedInteractables =
        {
            typeof(TouchableHotspot), typeof(GrabbableItem), typeof(SourcePile),
            typeof(ScrubSurface), typeof(HoldButton), typeof(AimTool)
        };

        // XRI llega por RequireComponent; este importador solo lo quita al cambiar de tipo, y lo busca por nombre de tipo.
        private const string XrGrabName = "XRGrabInteractable";
        private const string XrSimpleName = "XRSimpleInteractable";

        // Margen (m) con que se infla el trigger de una superficie para que una herramienta apoyada en ella cuente como dentro.
        private const float ScrubTriggerMargin = 0.04f;

        // 2026-10-25 (auditoría del segundo recorrido: «hay que agacharse hasta el suelo para frotar»): el trigger de una
        // superficie llega al menos de 0,2 a 1,0 m sobre la base del objeto, para que la mano de pie o en cuclillas cuente.
        public const float ScrubHandMinHeight = 0.2f;
        public const float ScrubHandMaxHeight = 1.0f;

        // Lado mínimo (m) desde el que una zona imantada es un área y conserva dónde se soltó cada objeto (SnapZone).
        private const float SnapAreaMinSide = 1f;

        // El interactuable que corresponde a un tipo de objeto, o null si el tipo no lleva (objeto) o no se conoce.
        private static Type InteractableFor(string kind) => kind switch
        {
            "hotspot" => typeof(TouchableHotspot),
            "agarrable" => typeof(GrabbableItem),
            "fuente" => typeof(SourcePile),
            "superficie" => typeof(ScrubSurface),
            "boton" => typeof(HoldButton),
            "herramienta" => typeof(AimTool),
            _ => null
        };

        /// <summary>
        /// True si el objeto <c>herramienta</c> <paramref name="id"/> solo existe para dar su modelo a una o más fuentes
        /// (<c>herramienta</c> de una <c>fuente</c>, contrato-0.2.md §4) y nada más la usa: ningún paso la nombra (objeto de
        /// una condición, <c>herramienta</c> de un <c>apuntar</c>, regla, opción, equivocado, <c>activos</c> o <c>senalar</c>),
        /// ninguna superficie la lista en <c>herramientas</c> y ninguna zona la acepta. En ese caso se coloca de decorado: sin
        /// collider ni interactuable, porque agarrarla no hace nada y confunde con la palada que sí se agarra del montón. Una
        /// herramienta que ninguna fuente nombra se importa agarrable como siempre (D8).
        /// </summary>
        public static bool IsModelOnlyTool(string id, GuionDocument guion, ColocacionDocument doc)
        {
            if (string.IsNullOrEmpty(id) || guion == null) return false;

            bool givesModelToASource = false;
            foreach (var o in guion.Objects ?? new List<GuionDocument.ObjectEntry>())
            {
                if (o == null) continue;
                if (o.Kind == "fuente" && o.Tool == id) givesModelToASource = true;
                if (o.Tools != null && o.Tools.Contains(id)) return false;
            }
            if (!givesModelToASource) return false;

            foreach (var step in guion.Steps ?? new List<GuionDocument.StepEntry>())
            {
                if (step == null) continue;
                if (step.PointAtTargetId == id || (step.ActiveTargetIds != null && step.ActiveTargetIds.Contains(id))) return false;
                var c = step.Condition;
                if (c == null) continue;
                if (c.ObjectId == id || c.Tool == id || (c.Objects != null && c.Objects.Contains(id))) return false;
                foreach (var r in c.Rules ?? new List<GuionDocument.DropRuleEntry>())
                    if (r != null && r.ObjectId == id) return false;
                foreach (var w in c.WrongTargets ?? new List<GuionDocument.WrongTargetEntry>())
                    if (w != null && w.ObjectId == id) return false;
                foreach (var op in c.Options ?? new List<GuionDocument.ChoiceOptionEntry>())
                    if (op != null && op.ObjectId == id) return false;
            }

            foreach (var z in doc?.Zones ?? new List<ColocacionDocument.ZoneEntry>())
                if (z?.Accepts != null && z.Accepts.Contains(id)) return false;
            return true;
        }

        // Pone en el objeto los componentes de su tipo y quita los del tipo anterior (autoria.md §4.1, contrato-0.2.md §4).
        private static void ApplyKind(GameObject go, string id, GuionDocument.ObjectEntry entry, ColocacionDocument doc,
            GuionDocument guion, string assetsRoot, List<string> notes, ImportReport report)
        {
            string kind = entry?.Kind;
            // 2026-10-26 (recorrido del dueño en el Quest 3, experiencia 12: «intento agarrar la pala y no pasa nada»): una
            // herramienta que solo da su modelo a una fuente es decorado, no se agarra.
            bool decor = kind == "herramienta" && IsModelOnlyTool(id, guion, doc);
            if (decor)
            {
                kind = "objeto";
                notes.Add("decorado: ningún paso la usa y solo da su modelo a una fuente, así que no se agarra");
            }
            Type wanted = InteractableFor(kind);

            bool wasInteractive = go.GetComponent<InteractableBase>() != null;
            RemoveStaleComponents(go, kind, wanted, notes);
            // La caja de la raíz la puso este importador para poder agarrarla (EnsureCollider): al volverse decorado se quita.
            if (decor && wasInteractive)
                foreach (var box in go.GetComponents<BoxCollider>()) Object.DestroyImmediate(box);
            if (wanted == null) return;

            // Un campo opcional que no es de este tipo no hace nada: el validador del guion ya avisa.
            switch (kind)
            {
                case "hotspot":
                {
                    var hotspot = EnsureInteractable(go, wanted);   // XRSimpleInteractable llega por RequireComponent
                    SetString(report, hotspot, "interactionId", id);
                    // 2026-10-25, primera prueba en el Quest 3: con triggerOnTouch (por defecto true) el hover del rayo dispara
                    // Touch(), y en COMP-01 y COMP-06 decidir ganaba la opción que el rayo rozara primero (el registro del casco
                    // lo muestra: un hotspot disparado en 0,6 s sin pulsar nada). Sin él hace falta seleccionar, de cerca y de
                    // lejos; con los mandos del rig del paquete, seleccionar es el botón lateral (Select = GripButton en
                    // «XRLabs Input Actions»), no el gatillo. En pantalla FlatInteractionDriver llama a Touch() directamente al
                    // hacer clic y no cambia nada.
                    SetBool(report, hotspot, "triggerOnTouch", false);
                    EnsureColliderNoted(go, notes);
                    break;
                }
                case "agarrable":
                {
                    EnsureGrabbable(go, wanted, id, report);
                    EnsureColliderNoted(go, notes);
                    break;
                }
                case "herramienta":
                {
                    var tool = EnsureGrabbable(go, wanted, id, report);
                    SetBool(report, tool, "requireActivate", true);
                    EnsureColliderNoted(go, notes);
                    break;
                }
                case "fuente":
                {
                    var pile = EnsureInteractable(go, wanted);   // XRSimpleInteractable llega por RequireComponent
                    SetString(report, pile, "interactionId", id);
                    SetString(report, pile, "sourceId", id);
                    ApplyToolPrefab(pile, entry, guion, assetsRoot, notes, report);
                    EnsureColliderNoted(go, notes);
                    break;
                }
                case "superficie":
                {
                    var surface = EnsureInteractable(go, wanted);
                    SetString(report, surface, "interactionId", id);
                    SetFloat(report, surface, "requiredDistance", Mathf.Max(0.01f, entry.Travel ?? 1f));
                    var tools = new List<string>();
                    foreach (var t in entry.Tools ?? new List<string>())
                        if (!string.IsNullOrEmpty(t)) tools.Add(t);
                    // Sin herramientas se frota con las manos; con herramientas, solo con ellas y agarradas.
                    SetStringList(report, surface, "toolIds", tools);
                    SetBool(report, surface, "allowHands", tools.Count == 0);
                    SetBool(report, surface, "requireToolSelected", tools.Count > 0);
                    EnsureScrubTrigger(go, notes, report);
                    break;
                }
                case "boton":
                {
                    var button = EnsureInteractable(go, wanted);   // XRSimpleInteractable llega por RequireComponent
                    SetString(report, button, "interactionId", id);
                    SetFloat(report, button, "holdSeconds", Mathf.Max(0.01f, entry.Seconds ?? 3f));
                    SetEnum(report, button, "holdMode", HoldMode.SelectOrActivate.ToString());
                    SetEnum(report, button, "releaseBehaviour", HoldReleaseBehaviour.Keep.ToString());
                    EnsureColliderNoted(go, notes);
                    break;
                }
            }
        }

        // Quita los componentes de un tipo de objeto que ya no corresponde. Si no quitó ningún interactuable no toca nada más:
        // un componente puesto a mano en el objeto, sin un interactuable nuestro detrás, no es de este importador.
        private static void RemoveStaleComponents(GameObject go, string kind, Type wanted, List<string> notes)
        {
            var removed = new List<string>();
            foreach (var c in go.GetComponents<InteractableBase>())
            {
                if (c == null) continue;
                var type = c.GetType();
                if (type == wanted || Array.IndexOf(ManagedInteractables, type) < 0) continue;
                removed.Add(type.Name);
                Object.DestroyImmediate(c);
            }
            if (removed.Count == 0) return;

            // Los acompañantes se quitan después de los interactuables, que son los que los exigen (RequireComponent).
            bool grab = kind == "agarrable" || kind == "herramienta";
            bool simple = kind == "hotspot" || kind == "fuente" || kind == "boton";
            if (!grab)
            {
                var back = go.GetComponent<ReturnToOrigin>();
                if (back != null) { Object.DestroyImmediate(back); removed.Add(nameof(ReturnToOrigin)); }
            }
            foreach (var c in go.GetComponents<Component>())
            {
                if (c == null) continue;
                string n = c.GetType().Name;
                if ((n == XrGrabName && !grab) || (n == XrSimpleName && !simple))
                {
                    removed.Add(n);
                    Object.DestroyImmediate(c);
                }
            }
            notes.Add($"cambió de tipo (ahora {(string.IsNullOrEmpty(kind) ? "objeto" : kind)}): se quitó {string.Join(", ", removed)}");
        }

        // Busca el interactuable del tipo exacto (un AimTool es además un GrabbableItem: GetComponent<GrabbableItem> lo devolvería) o lo añade.
        private static Component EnsureInteractable(GameObject go, Type wanted)
        {
            foreach (var c in go.GetComponents<InteractableBase>())
                if (c != null && c.GetType() == wanted) return c;
            return go.AddComponent(wanted);
        }

        // GrabbableItem y AimTool: llevan XRGrabInteractable, que exige un Rigidbody (RequireComponent), y vuelven al sitio si se
        // sueltan donde no los aceptan. Un Rigidbody que añade el propio importador queda cinemático y sin gravedad: lo coloca
        // quien coloca, y no tiene que caer si el entorno no trae colliders; el que ya estaba, o el que ajuste el consumidor, no se toca.
        private static Component EnsureGrabbable(GameObject go, Type wanted, string id, ImportReport report)
        {
            bool hadBody = go.GetComponent<Rigidbody>() != null;
            var item = EnsureInteractable(go, wanted);
            SetString(report, item, "interactionId", id);

            var back = GetOrAdd<ReturnToOrigin>(go);
            SetBool(report, back, "returnWhenZoneRejects", true);
            SetBool(report, back, "returnAfterAcceptedDrop", false);

            if (!hadBody)
            {
                var body = go.GetComponent<Rigidbody>();
                if (body != null)
                {
                    body.isKinematic = true;
                    body.useGravity = false;
                }
            }
            return item;
        }

        private static void EnsureColliderNoted(GameObject go, List<string> notes)
        {
            if (EnsureCollider(go)) notes.Add("el modelo no traía collider: se ajustó un BoxCollider a sus renderers");
        }

        // ScrubSurface mide el recorrido de lo que se mueve dentro de su trigger, y Unity entrega OnTriggerEnter al GameObject
        // del collider (o al de su Rigidbody): el trigger tiene que colgar de la propia raíz, que es donde está la superficie.
        private static void EnsureScrubTrigger(GameObject go, List<string> notes, ImportReport report)
        {
            var own = go.GetComponent<Collider>();
            if (own == null)
            {
                own = AddFittedBox(go, ScrubTriggerMargin);
                notes.Add("la superficie necesita un trigger en su raíz: se añadió un BoxCollider ajustado a sus renderers");
            }
            if (!own.isTrigger)
            {
                if (own is MeshCollider mesh && !mesh.convex)
                {
                    report.Warn($"{go.name}: el MeshCollider de la raíz no es convexo y no puede ser trigger; la superficie no medirá el frotado.");
                    return;
                }
                own.isTrigger = true;
            }
            if (own is BoxCollider box) RaiseScrubVolume(go.transform, box);
        }

        // Estira en vertical el trigger de una superficie para que cubra de ScrubHandMinHeight a ScrubHandMaxHeight sobre el
        // origen del objeto (su base), sin encogerlo si el modelo ya es más alto o baja más.
        private static void RaiseScrubVolume(Transform t, BoxCollider box)
        {
            float scale = Mathf.Abs(t.lossyScale.y) > 1e-4f ? Mathf.Abs(t.lossyScale.y) : 1f;
            float bottom = Mathf.Min(box.center.y - box.size.y * 0.5f, ScrubHandMinHeight / scale);
            float top = Mathf.Max(box.center.y + box.size.y * 0.5f, ScrubHandMaxHeight / scale);
            box.size = new Vector3(box.size.x, top - bottom, box.size.z);
            box.center = new Vector3(box.center.x, (top + bottom) * 0.5f, box.center.z);
        }

        // La herramienta que carga la pila es el prefab del modelo del objeto `herramienta` que nombra (contrato-0.2.md §4).
        // Sin prefab queda la de por defecto de SourcePile, y el aviso lo dice si el guion pedía una.
        private static void ApplyToolPrefab(Component pile, GuionDocument.ObjectEntry entry, GuionDocument guion,
            string assetsRoot, List<string> notes, ImportReport report)
        {
            GameObject prefab = null;
            if (!string.IsNullOrEmpty(entry.Tool))
            {
                var toolEntry = guion.FindObject(entry.Tool);
                prefab = FindModelPrefab(toolEntry?.Model, guion.Experience?.Id, assetsRoot);
                if (prefab == null)
                    report.Warn($"{pile.gameObject.name}: no hay prefab para la herramienta '{entry.Tool}'; la pila carga la herramienta por defecto.");
                else
                    notes.Add($"herramienta '{prefab.name}'");
            }
            SetObject(report, pile, "toolPrefab", prefab);
        }

        // El tag se pone si el objeto tiene etiqueta o un paso 'girar' lo usa (autoria.md §4.1). El importador del guion lo
        // crea; aquí no se crea nunca: si no existe, aviso.
        private static void ApplyTag(GameObject go, GuionDocument.ObjectEntry entry, GuionDocument guion, string name, ImportReport report)
        {
            bool needsTag = !string.IsNullOrEmpty(entry.Tag);
            if (!needsTag)
                foreach (var step in guion.Steps ?? new List<GuionDocument.StepEntry>())
                    if (step != null && step.Kind == "girar" && step.Condition != null && step.Condition.ObjectId == entry.Id)
                    {
                        needsTag = true;
                        break;
                    }
            if (!needsTag) return;

            string tag = entry.EffectiveTag;
            if (Array.IndexOf(InternalEditorUtility.tags, tag) >= 0) go.tag = tag;
            else report.Warn($"{name}: el tag '{tag}' no existe en el proyecto; importa el guion primero o créalo en Project Settings.");
        }

        // ---------------------------------------------------------------- Zonas

        private static void ImportZone(ColocacionDocument.ZoneEntry z, Transform root, HashSet<string> wanted, ImportReport report)
        {
            if (z == null || string.IsNullOrEmpty(z.Id)) { report.Error("Hay una zona sin id: no se importó."); return; }
            string name = ZonePrefix + z.Id;
            wanted.Add(name);
            if (!TryPosition(z.Pos, $"zonas[{z.Id}].pos", report, out var position)) return;
            if (z.Size == null || z.Size.Length != 2)
            {
                report.Error($"zonas[{z.Id}].tamano: tiene que ser [ancho, largo]; la zona no se importó.");
                return;
            }

            bool drop = z.Kind == "soltar";
            float height = ZoneHeight;
            if (drop)
            {
                height = z.Height ?? ColocacionDocument.ZoneEntry.DefaultDropHeight;
                if (!(height > 0f) || float.IsInfinity(height))
                {
                    report.Error($"zonas[{z.Id}].alto: tiene que ser un número mayor que cero; la zona no se importó.");
                    return;
                }
                if (z.Accepts == null || z.Accepts.Count == 0)
                {
                    report.Error($"zonas[{z.Id}].acepta: una zona 'soltar' tiene que aceptar al menos un objeto; la zona no se importó.");
                    return;
                }
            }

            var go = GetOrCreate(root, name, out bool created);
            Place(go.transform, position, z.Yaw, 1f);
            var target = GetOrAdd<SceneTarget>(go);
            SetString(report, target, "targetId", z.Id);

            // La zona que cambia de tipo suelta lo anterior (como un objeto): un teleport no lleva DropZone, y un DropZone no es SnapZone.
            var notes = new List<string>();
            Type zoneType = !drop ? null : z.Snap ? typeof(SnapZone) : typeof(DropZone);
            foreach (var old in go.GetComponents<DropZone>())
            {
                if (old == null || old.GetType() == zoneType) continue;
                notes.Add($"se quitó {old.GetType().Name}");
                Object.DestroyImmediate(old);
            }

            // DropZone decide «dentro» por el trigger (OnTriggerEnter/Exit, DropZone.Contains), no por bounds: el collider tiene
            // que ser un BoxCollider trigger en la propia zona, y lo que entra lo detecta por el Rigidbody del objeto que se suelta.
            var box = GetOrAdd<BoxCollider>(go);
            box.size = new Vector3(z.Size[0], height, z.Size[1]);
            box.center = new Vector3(0f, height * 0.5f, 0f);

            if (drop)
            {
                box.isTrigger = true;
                var staleArea = go.GetComponent<TeleportationArea>();
                if (staleArea != null) { notes.Add("se quitó TeleportationArea"); Object.DestroyImmediate(staleArea); }
                RemoveTeleportAnchor(go, notes);   // UX visor 2026-10-31
                var zone = go.GetComponent(zoneType) ?? go.AddComponent(zoneType);
                SetString(report, zone, "zoneId", z.Id);
                SetStringList(report, zone, "acceptedIds", z.Accepts);
                ApplyMeasure(report, zone, z);   // 0.3 lote 6
                if (z.Snap) SetObject(report, zone, "snapPoint", go.transform);
                // 2026-10-25: una zona imantada de un metro o más por lado es un área (el acopio recibe cuatro materiales): cada
                // objeto baja al suelo donde se soltó en vez de apilarse en el centro. El centro de la pila (0,4 m) imanta exacto.
                if (z.Snap) SetBool(report, zone, "keepHorizontalOffset", z.Size[0] >= SnapAreaMinSide && z.Size[1] >= SnapAreaMinSide);
                // 2026-10-17: una zona de soltar sin dibujo no existe para la persona («no sé qué hacer en este paso»).
                EnsureZoneFloor(go.transform, z.Size[0], z.Size[1]);
                EnsureLabel(go.transform, Humanize(z.Id), ZoneLabelHeight, ZoneLabelFontSize);
            }
            else if (z.Kind == "teleport")
            {
                // Lote X2: la zona es una TeleportationArea de XRI. El collider tiene que ser sólido: XRI descarta los
                // colliders trigger de un interactuable al despertar y el rayo de teleportación los ignora. La capa de
                // interacción es solo Teleport (la única que ven los rayos de teleportación del rig) y el proveedor se deja
                // vacío: XRI busca el del rig al despertar. El BoxCollider se agrega antes, para que la TeleportationArea lo
                // encuentre. Reimportar reusa el componente y reescribe los mismos valores.
                box.isTrigger = false;
                ImportTeleportAnchor(go, notes);   // UX visor 2026-10-31: ancla orientada en vez de TeleportationArea
                RemoveChild(go.transform, ZoneFloorName);
                RemoveChild(go.transform, LabelName);
            }
            else
            {
                // Un tipo que no es teleport ni soltar (el validador no lo deja pasar) queda como marca: trigger, sin más.
                box.isTrigger = true;
                var stale = go.GetComponent<TeleportationArea>();
                if (stale != null) Object.DestroyImmediate(stale);
                RemoveTeleportAnchor(go, notes);   // UX visor 2026-10-31
                RemoveChild(go.transform, ZoneFloorName);
                RemoveChild(go.transform, LabelName);
            }
            Log(report, created, notes.Count == 0 ? name : $"{name} ({string.Join("; ", notes)})");
        }

        // UX visor 2026-10-31 ---------------------------------------------------------------- Anclas de teletransporte
        // Documentation~/decisiones-ux-visor.md §3. Cada zona `teleport` es un TeleportationAnchor de XRI con
        // MatchOrientation.TargetUpAndForward y un TeleportGuideAnchor que la señaliza; el punto de llegada (hijo Llegada) mira
        // hacia `mirarHacia`. El suelo libre sigue teletransportable (EntornoBuilder): el ancla solo se suma.

        /// <summary>El hijo de una zona `teleport` que marca la llegada y su orientación.</summary>
        public const string TeleportArrivalName = TeleportGuideAnchor.ArrivalName;

        private static void ImportTeleportAnchor(GameObject go, List<string> notes)
        {
            var staleArea = go.GetComponent<TeleportationArea>();
            if (staleArea != null) { notes.Add("TeleportationArea pasa a TeleportationAnchor"); Object.DestroyImmediate(staleArea); }
            var arrival = go.transform.Find(TeleportArrivalName);
            if (arrival == null)
            {
                arrival = new GameObject(TeleportArrivalName).transform;
                arrival.SetParent(go.transform, false);
            }
            arrival.localPosition = Vector3.zero;
            arrival.localRotation = Quaternion.identity;   // sin mirarHacia, mira como el giro de la zona
            var anchor = GetOrAdd<TeleportationAnchor>(go);
            anchor.interactionLayers = TeleportInteractionLayer.Mask;
            anchor.matchOrientation = MatchOrientation.TargetUpAndForward;
            anchor.teleportAnchorTransform = arrival;
            anchor.teleportationProvider = null;   // XRI busca el del rig al despertar
            var guide = GetOrAdd<TeleportGuideAnchor>(go);
            guide.Arrival = arrival;
        }

        private static void RemoveTeleportAnchor(GameObject go, List<string> notes)
        {
            var guide = go.GetComponent<TeleportGuideAnchor>();
            if (guide != null) Object.DestroyImmediate(guide);
            var anchor = go.GetComponent<TeleportationAnchor>();
            if (anchor != null) { notes.Add("se quitó TeleportationAnchor"); Object.DestroyImmediate(anchor); }
            RemoveChild(go.transform, TeleportArrivalName);
        }

        /// <summary>
        /// A qué mira cada zona `teleport` y para qué pasos es el mejor sitio. Lo que se mira: <c>mirarHacia</c> (id de un
        /// ancla, un objeto o una zona); si falta, el primer objeto o zona que usa el primer paso que nombra la zona (en la
        /// condición, en <c>activos</c> o en <c>senalar</c>); si tampoco, el ancla del coach (la que se llama «coach» o, si no
        /// hay, la primera). Los pasos: los que nombran la zona; si ninguno la nombra, los que usan lo que se mira.
        /// </summary>
        public static void ApplyTeleportGuides(ColocacionDocument doc, GuionDocument guion, Transform root, ImportReport report)
        {
            if (doc?.Zones == null || root == null) return;
            var steps = guion?.Steps ?? new List<GuionDocument.StepEntry>();
            var used = new List<(string StepId, List<string> Ids)>();
            foreach (var step in steps)
                if (step != null && !string.IsNullOrEmpty(step.Id)) used.Add((step.Id, StepVisibilityPlanner.UsedIds(step, guion)));
            var teleportIds = new HashSet<string>();
            foreach (var z in doc.Zones)
                if (z != null && z.Kind == "teleport" && !string.IsNullOrEmpty(z.Id)) teleportIds.Add(z.Id);

            foreach (var z in doc.Zones)
            {
                if (z == null || z.Kind != "teleport" || string.IsNullOrEmpty(z.Id)) continue;
                var zone = root.Find(ZonePrefix + z.Id);
                var guide = zone != null ? zone.GetComponent<TeleportGuideAnchor>() : null;
                if (guide == null) continue;

                string face = z.LookAt;
                if (string.IsNullOrEmpty(face))
                {
                    foreach (var (_, ids) in used)
                    {
                        if (!ids.Contains(z.Id)) continue;
                        face = ids.Find(id => id != z.Id && !teleportIds.Contains(id));
                        if (!string.IsNullOrEmpty(face)) break;
                    }
                }
                bool coachDefault = false;
                if (string.IsNullOrEmpty(face)) { face = DefaultCoachAnchorId(doc); coachDefault = true; }

                var faceTransform = FindPlaced(root, face, coachDefault);
                if (!string.IsNullOrEmpty(z.LookAt) && faceTransform == null)
                    report.Warn($"zonas[{z.Id}].mirarHacia: '{z.LookAt}' no es un ancla, objeto ni zona de la colocación; la llegada mira como el giro de la zona.");
                if (guide.Arrival != null)
                {
                    var direction = faceTransform != null ? faceTransform.position - zone.position : zone.forward;
                    direction.y = 0f;
                    guide.Arrival.rotation = Quaternion.LookRotation(direction.sqrMagnitude > 1e-6f ? direction.normalized : zone.forward, Vector3.up);
                }
                guide.FaceTargetId = faceTransform != null ? face : string.Empty;

                guide.StepIds.Clear();
                foreach (var (stepId, ids) in used)
                    if (ids.Contains(z.Id)) guide.StepIds.Add(stepId);
                if (guide.StepIds.Count == 0 && faceTransform != null)
                    foreach (var (stepId, ids) in used)
                        if (ids.Contains(face)) guide.StepIds.Add(stepId);
                EditorUtility.SetDirty(guide);
            }
        }

        private static string DefaultCoachAnchorId(ColocacionDocument doc)
        {
            if (doc.Anchors == null || doc.Anchors.Count == 0) return null;
            foreach (var a in doc.Anchors)
                if (a != null && !string.IsNullOrEmpty(a.Id) && a.Id.IndexOf("coach", StringComparison.OrdinalIgnoreCase) >= 0) return a.Id;
            return doc.Anchors[0]?.Id;
        }

        // Un id puede ser a la vez ancla y objeto (en la experiencia cero, «pila»): lo que se mira es el objeto o la zona,
        // salvo el ancla del coach por defecto.
        private static Transform FindPlaced(Transform root, string id, bool anchorsFirst)
        {
            if (string.IsNullOrEmpty(id)) return null;
            var anchor = root.Find(AnchorPrefix + id);
            if (anchorsFirst && anchor != null) return anchor;
            var found = root.Find(ObjectPrefix + id);
            if (found == null) found = root.Find(ZonePrefix + id);
            return found != null ? found : anchor;
        }

        // fin UX visor 2026-10-31

        // ---------------------------------------------------------------- Comunes

        private static void RemoveOrphans(Transform root, HashSet<string> wanted, ImportReport report)
        {
            for (int i = root.childCount - 1; i >= 0; i--)
            {
                var child = root.GetChild(i);
                if (!IsManagedName(child.name) || wanted.Contains(child.name)) continue;
                report.Delete(child.name + " (ya no está en la colocación)");
                Object.DestroyImmediate(child.gameObject);
            }
        }

        private static bool IsManagedName(string name) =>
            name == StartName
            || name.StartsWith(AnchorPrefix, StringComparison.Ordinal)
            || name.StartsWith(ObjectPrefix, StringComparison.Ordinal)
            || name.StartsWith(ZonePrefix, StringComparison.Ordinal)
            || name.StartsWith(SetPrefix, StringComparison.Ordinal);   // 0.3 lote 1

        private static GameObject GetOrCreate(Transform root, string name, out bool created)
        {
            var existing = root.Find(name);
            if (existing != null) { created = false; return existing.gameObject; }
            var go = new GameObject(name);
            go.transform.SetParent(root, false);
            created = true;
            return go;
        }

        private static T GetOrAdd<T>(GameObject go) where T : Component
        {
            var c = go.GetComponent<T>();
            return c != null ? c : go.AddComponent<T>();
        }

        private static void Place(Transform t, Vector3 position, float yawDegrees, float scale)
        {
            t.localPosition = position;
            t.localRotation = GltfToUnity.Yaw(yawDegrees);
            t.localScale = Vector3.one * scale;
        }

        private static bool TryPosition(float[] pos, string path, ImportReport report, out Vector3 position)
        {
            position = default;
            if (pos == null || pos.Length != 3)
            {
                report.Error($"{path}: tiene que ser tres números [x, y, z]; no se importó.");
                return false;
            }
            position = GltfToUnity.Position(pos[0], pos[1], pos[2]);
            return true;
        }

        private static void Log(ImportReport report, bool created, string what)
        {
            if (created) report.Create(what);
            else report.Update(what);
        }

        // Escritura de campos privados como lo haría el Inspector (D8: el runtime no cambia).
        private static void SetString(ImportReport report, Component c, string field, string value)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null) { report.Error($"{c.GetType().Name}: no encuentro el campo '{field}'."); return; }
            prop.stringValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void SetBool(ImportReport report, Component c, string field, bool value)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null) { report.Error($"{c.GetType().Name}: no encuentro el campo '{field}'."); return; }
            prop.boolValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void SetFloat(ImportReport report, Component c, string field, float value)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null) { report.Error($"{c.GetType().Name}: no encuentro el campo '{field}'."); return; }
            prop.floatValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // Un enum se escribe por el nombre del valor, no por su número: el orden de declaración puede cambiar.
        // 0.3 lote 6: `medir` de la zona `soltar` (contrato-0.3.md §3) al DropZone. Se escribe siempre, para que quitarlo del
        // fichero vuelva a «contacto».
        private static void ApplyMeasure(ImportReport report, Component zone, ColocacionDocument.ZoneEntry z) =>
            SetEnum(report, zone, "measure", z.Measure == "centro" ? nameof(DropMeasure.Center) : nameof(DropMeasure.Contact));

        private static void SetEnum(ImportReport report, Component c, string field, string valueName)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null) { report.Error($"{c.GetType().Name}: no encuentro el campo '{field}'."); return; }
            int index = prop.propertyType == SerializedPropertyType.Enum ? Array.IndexOf(prop.enumNames, valueName) : -1;
            if (index < 0) { report.Error($"{c.GetType().Name}.{field}: no tiene el valor '{valueName}'."); return; }
            prop.enumValueIndex = index;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // Reescribe la lista entera: la que había se sustituye, así que un valor que ya no está en el fichero desaparece.
        private static void SetStringList(ImportReport report, Component c, string field, IReadOnlyList<string> values)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null || !prop.isArray) { report.Error($"{c.GetType().Name}: no encuentro la lista '{field}'."); return; }
            prop.arraySize = values.Count;
            for (int i = 0; i < values.Count; i++)
                prop.GetArrayElementAtIndex(i).stringValue = values[i];
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // Referencia a otro objeto de Unity (un prefab, un Transform). Null la deja vacía.
        private static void SetObject(ImportReport report, Component c, string field, Object value)
        {
            using var so = new SerializedObject(c);
            var prop = so.FindProperty(field);
            if (prop == null) { report.Error($"{c.GetType().Name}: no encuentro el campo '{field}'."); return; }
            prop.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        #region 0.3 lote 1

        // Contrato 0.3 §2.10: `visibleSi` (StateVisibility) y `conjuntos` (un vacío Conjunto_<id> en `origen`, del que
        // cuelgan sus miembros conservando su pose, con StateLayout y, si lo pide, StateVisibility). Sin estas claves no
        // añade nada y quita lo que hubiera de antes (D8). Idempotente: al empezar, FlattenSets03 devuelve los miembros a la
        // raíz con su pose escrita, se importan por nombre como siempre y aquí se vuelven a colgar.

        /// <summary>Prefijo del vacío de un conjunto.</summary>
        public const string SetPrefix = "Conjunto_";

        private static void FlattenSets03(Transform root)
        {
            for (int i = root.childCount - 1; i >= 0; i--)
            {
                var set = root.GetChild(i);
                if (!set.name.StartsWith(SetPrefix, StringComparison.Ordinal)) continue;
                // El vacío vuelve a su origen para que las poses locales de los miembros sean las escritas.
                var layout = set.GetComponent<StateLayout>();
                if (layout != null)
                {
                    set.localPosition = layout.defaultPosition;
                    set.localRotation = Quaternion.Euler(0f, layout.defaultYaw, 0f);
                }
                for (int k = set.childCount - 1; k >= 0; k--)
                {
                    var member = set.GetChild(k);
                    if (IsManagedName(member.name)) member.SetParent(root, true);
                }
            }
        }

        private static void ImportState03(ColocacionDocument doc, GuionDocument guion, Transform root,
            HashSet<string> wanted, ImportReport report)
        {
            foreach (var o in doc.Objects ?? new List<ColocacionDocument.PlacedObject>())
                if (o != null && !string.IsNullOrEmpty(o.Id))
                    SetVisibility03(root.Find(ObjectPrefix + o.Id), o.VisibleIf, guion, report);
            foreach (var z in doc.Zones ?? new List<ColocacionDocument.ZoneEntry>())
                if (z != null && !string.IsNullOrEmpty(z.Id))
                    SetVisibility03(root.Find(ZonePrefix + z.Id), z.VisibleIf, guion, report);

            foreach (var set in doc.Sets ?? new List<ColocacionDocument.SetEntry>())
            {
                if (set == null || string.IsNullOrEmpty(set.Id)) continue;
                if (!TryPosition(set.Origin, $"conjuntos[{set.Id}].origen", report, out var origin)) continue;
                string name = SetPrefix + set.Id;
                wanted.Add(name);
                var go = GetOrCreate(root, name, out bool created);
                go.transform.localPosition = origin;
                go.transform.localRotation = Quaternion.identity;
                go.transform.localScale = Vector3.one;

                var m = set.Members ?? new ColocacionDocument.SetMembers();
                foreach (var id in m.Objects ?? new List<string>()) Adopt(root, go.transform, ObjectPrefix + id);
                foreach (var id in m.Zones ?? new List<string>()) Adopt(root, go.transform, ZonePrefix + id);
                foreach (var id in m.Anchors ?? new List<string>()) Adopt(root, go.transform, AnchorPrefix + id);

                SetLayout03(go, set, doc, report);
                SetVisibility03(go.transform, set.VisibleIf, guion, report);
                Log(report, created, name);
            }
        }

        private static void Adopt(Transform root, Transform set, string childName)
        {
            var child = root.Find(childName);
            if (child != null) child.SetParent(set, true);   // conserva la pose: se mueven juntos sin cambiar su disposición
        }

        private static void SetVisibility03(Transform target, Dictionary<string, Newtonsoft.Json.Linq.JToken> visibleIf,
            GuionDocument guion, ImportReport report)
        {
            if (target == null) return;
            var existing = target.GetComponent<StateVisibility>();
            if (visibleIf == null || visibleIf.Count == 0)
            {
                if (existing != null) { Object.DestroyImmediate(existing); report.Update(target.name + ": se quitó StateVisibility"); }
                return;
            }
            var c = existing != null ? existing : target.gameObject.AddComponent<StateVisibility>();
            c.conditions = StateAuthoring.ParseConditions(visibleIf, guion, string.Empty, null);
            EditorUtility.SetDirty(c);
            report.Update(target.name + ": StateVisibility (visibleSi)");
        }

        private static void SetLayout03(GameObject go, ColocacionDocument.SetEntry set, ColocacionDocument doc, ImportReport report)
        {
            var existing = go.GetComponent<StateLayout>();
            var by = set.PositionBy;
            if (by == null)
            {
                if (existing != null) Object.DestroyImmediate(existing);
                return;
            }
            var layout = existing != null ? existing : go.AddComponent<StateLayout>();
            layout.variable = by.Variable;
            layout.applyYaw = by.Rotate;
            layout.offset = by.Offset != null && by.Offset.Length == 3
                ? GltfToUnity.Position(by.Offset[0], by.Offset[1], by.Offset[2]) : Vector3.zero;
            layout.defaultPosition = go.transform.localPosition;
            layout.defaultYaw = 0f;
            layout.places = new List<StateLayoutPlace>();
            foreach (var pair in by.Places ?? new Dictionary<string, Newtonsoft.Json.Linq.JToken>())
            {
                if (!TryPlace(pair.Value, doc, out var pos, out var yaw))
                {
                    report.Error($"conjuntos[{set.Id}].posicionSegun.lugares.{pair.Key}: no se encontró el lugar.");
                    continue;
                }
                // En el GLB el giro es alrededor de Y en el otro sentido (GltfToUnity.Yaw): se guarda ya en ejes de Unity.
                layout.places.Add(new StateLayoutPlace { value = pair.Key, position = pos, yaw = -yaw });
            }
            EditorUtility.SetDirty(layout);
            report.Update(go.name + $": StateLayout según '{by.Variable}' ({layout.places.Count} lugares)");
        }

        private static bool TryPlace(Newtonsoft.Json.Linq.JToken token, ColocacionDocument doc, out Vector3 pos, out float yaw)
        {
            pos = default; yaw = 0f;
            float[] p = null;
            if (token != null && token.Type == Newtonsoft.Json.Linq.JTokenType.String)
            {
                string id = (string)token;
                var o = (doc.Objects ?? new List<ColocacionDocument.PlacedObject>()).Find(x => x != null && x.Id == id);
                if (o == null) return false;
                p = o.Pos; yaw = o.Yaw;
            }
            else if (token is Newtonsoft.Json.Linq.JObject obj)
            {
                try { p = obj["pos"]?.ToObject<float[]>(); } catch (Exception) { p = null; }
                yaw = obj["giro"]?.ToObject<float>() ?? 0f;
            }
            if (p == null || p.Length != 3) return false;
            pos = GltfToUnity.Position(p[0], p[1], p[2]);
            return true;
        }

        #endregion
    }
}
