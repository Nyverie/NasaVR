using System.Collections.Generic;
using System.Text;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Lo que hizo una importación (guion o colocación): una línea por asset u objeto creado, actualizado o borrado, los
    /// avisos y los errores. La ventana lo muestra tal cual y los tests lo leen. Documentation~/autoria.md §3.6.
    /// </summary>
    public sealed class ImportReport
    {
        public readonly List<string> Created = new();
        public readonly List<string> Updated = new();
        public readonly List<string> Deleted = new();
        public readonly List<string> Warnings = new();
        public readonly List<string> Errors = new();

        public bool HasErrors => Errors.Count > 0;

        #region 0.3 lote 3: pasos desenrollados de los grupos (contrato-0.3.md §2.4)

        /// <summary>Una línea por paso que sale de desenrollar un grupo: «id ← grupo G, vuelta k».</summary>
        public readonly List<string> Expanded = new();

        public void Expand(string what) => Expanded.Add(what);

        #endregion

        public void Create(string what) => Created.Add(what);
        public void Update(string what) => Updated.Add(what);
        public void Delete(string what) => Deleted.Add(what);
        public void Warn(string message) => Warnings.Add(message);
        public void Error(string message) => Errors.Add(message);

        /// <summary>Resumen en español, con la conclusión primero y una línea por entrada.</summary>
        public string Summary()
        {
            var sb = new StringBuilder();
            sb.Append(HasErrors ? "Importación con errores" : "Importación correcta")
              .Append(": ").Append(Created.Count).Append(" creados, ")
              .Append(Updated.Count).Append(" actualizados, ")
              .Append(Deleted.Count).Append(" borrados, ")
              .Append(Warnings.Count).Append(" avisos.").AppendLine();
            Section(sb, "Errores", Errors);
            Section(sb, "Creados", Created);
            Section(sb, "Actualizados", Updated);
            Section(sb, "Borrados", Deleted);
            Section(sb, "Avisos", Warnings);
            Section(sb, "Desenrollados", Expanded);   // 0.3 lote 3
            return sb.ToString().TrimEnd();
        }

        private static void Section(StringBuilder sb, string title, List<string> items)
        {
            if (items.Count == 0) return;
            sb.Append(title).Append(':').AppendLine();
            foreach (var item in items) sb.Append("   ").Append(item).AppendLine();
        }
    }
}
