using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using XRLabs.Coach.Editor;
using XRLabs.Core;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// «Generar voces que faltan» a un clic (Documentation~/autoria.md §10.2), sobre el horneador que ya existe
    /// (<c>Editor/Voice</c>, D5): calcula qué voces faltan, comprueba que se pueda hornear (clave y voz de cada idioma) y
    /// lanza la tanda de forma asíncrona, como el botón «Generar faltantes» del inspector de LineLibrary. La clave nunca
    /// se lee ni se escribe aquí: solo se pregunta a <see cref="VoiceApiKeys"/> si hay una (D5).
    ///
    /// Con <c>provider</c> nulo se usa el proveedor real que dice <c>VoiceSettings.provider</c>, a través de
    /// <see cref="VoiceBakeSession"/>, y exige clave. Con un <c>provider</c> dado (las pruebas pasan un proveedor falso) se
    /// usa ese aunque no haya clave: como <c>VoiceBakeSession.Start</c> no admite un proveedor, esa tanda la corre este
    /// ejecutor mismo con <see cref="VoiceBaker"/>; <see cref="IsRunning"/> cubre las dos.
    /// </summary>
    public static class VoiceBakeRunner
    {
        private static bool _ownRunning;
        private static bool _lastWasOwn;
        private static LineLibrary _ownLibrary;
        private static BakeProgress _ownProgress;
        private static BakeSummary _ownSummary;
        private static CancellationTokenSource _ownCts;

        /// <summary>Hay una tanda en curso, de <see cref="VoiceBakeSession"/> o de este ejecutor.</summary>
        public static bool IsRunning => VoiceBakeSession.Running || _ownRunning;

        /// <summary>Qué voces faltan: las variantes con texto que se dice y no tienen clip al día (las soloTexto no cuentan).</summary>
        public static BakePlan PlanMissing(LineLibrary library, VoiceSettings settings)
        {
            if (!library || !settings) return new BakePlan();
            return new VoiceBaker(settings, NullProvider.Instance).Plan(library, new BakeScope());
        }

        /// <summary>Cuántas voces del plan son de ese idioma.</summary>
        public static int CountLanguage(BakePlan plan, CoachLanguage language)
        {
            int count = 0;
            if (plan != null)
                foreach (var job in plan.Jobs)
                    if (job.Language == language) count++;
            return count;
        }

        /// <summary>
        /// El VoiceSettings del proyecto; si no hay ninguno lo crea con los valores por defecto en
        /// <see cref="VoiceSettings.DefaultAssetPath"/>, como el botón «Crear VoiceSettings» del inspector.
        /// </summary>
        public static VoiceSettings GetOrCreateSettings() => VoiceSettings.Find() ?? VoiceSettings.CreateDefaultAsset();

        /// <summary>Lanza el horneado de las voces que faltan. Ver <see cref="TryStart(LineLibrary, VoiceSettings, ITtsProvider, Func{VoiceProviderKind, bool}, out string)"/>.</summary>
        public static bool TryStart(LineLibrary library, VoiceSettings settings, ITtsProvider provider, out string message) =>
            TryStart(library, settings, provider, VoiceApiKeys.HasOrNotNeeded, out message);

        /// <summary>
        /// Lanza el horneado de las voces que faltan y devuelve true. Devuelve false, con el motivo en
        /// <paramref name="message"/> y sin tocar la red, si ya hay una tanda, si no falta nada, si
        /// <paramref name="provider"/> es nulo y <paramref name="hasApiKey"/> dice que no hay clave del proveedor de
        /// <paramref name="settings"/>, o si falta el ID de voz de un idioma que hay que generar.
        /// <paramref name="hasApiKey"/> es quien dice si hay clave (la sobrecarga corta pasa <see cref="VoiceApiKeys.Has"/>);
        /// las pruebas pasan una función fija para no depender de las claves de quien las corre.
        /// </summary>
        public static bool TryStart(LineLibrary library, VoiceSettings settings, ITtsProvider provider,
            Func<VoiceProviderKind, bool> hasApiKey, out string message)
        {
            if (!library)
            {
                message = "No hay biblioteca de frases: importa el guion primero.";
                return false;
            }
            if (!settings)
            {
                message = "No hay VoiceSettings: créalo con «Generar voces» o desde Tools/XRLabs/Voice Settings.";
                return false;
            }
            hasApiKey ??= VoiceApiKeys.HasOrNotNeeded;
            if (IsRunning)
            {
                message = "Ya hay un horneado de voz en curso; espera a que termine.";
                return false;
            }

            var plan = PlanMissing(library, settings);
            var decision = Check(settings, plan, provider != null || hasApiKey(settings.provider));
            if (decision != null)
            {
                message = decision;
                return false;
            }

            message = $"Generando {plan.Jobs.Count} voces con {settings.ProviderDisplayName} ({plan.Characters} caracteres). " +
                      "Puedes seguir trabajando; el progreso aparece abajo.";
            if (provider == null)
            {
                _lastWasOwn = false;
                VoiceBakeSession.Start(library, settings, new BakeScope());
            }
            else
            {
                _lastWasOwn = true;
                RunOwn(library, settings, provider);
            }
            return true;
        }

        /// <summary>
        /// Lo que decide si se puede empezar, sin tocar nada: null si se puede; si no, el motivo en claro. Función pura
        /// (el plan, los ajustes y si hay clave), probada sola.
        /// </summary>
        public static string Check(VoiceSettings settings, BakePlan plan, bool hasKeyOrProvider)
        {
            if (plan == null || plan.Jobs.Count == 0)
                return "No falta ninguna voz: todas las frases que se dicen tienen su clip al día.";

            if (!hasKeyOrProvider)
                return $"No hay clave de {settings.ProviderDisplayName}, así que no se generó nada ni se tocó la red. " +
                       "Guárdala en el asset VoiceSettings (Tools/XRLabs/Voice Settings, apartado «Claves de API», o el botón " +
                       $"«Ajustes» del inspector de la biblioteca de frases) o define la variable de entorno " +
                       $"{VoiceApiKeys.EnvVar(settings.provider)} y abre Unity de nuevo.";

            var checkedLanguages = new HashSet<CoachLanguage>();
            foreach (var job in plan.Jobs)
            {
                if (!checkedLanguages.Add(job.Language)) continue;
                if (!string.IsNullOrEmpty(settings.GetVoiceId(job.Language))) continue;
                return $"Falta el ID de voz en {LanguageName(job.Language)} para {settings.ProviderDisplayName}. " +
                       "Ponlo en el asset VoiceSettings (Tools/XRLabs/Voice Settings, apartado «Voz por idioma»).";
            }
            return null;
        }

        public static string LanguageName(CoachLanguage language) =>
            language == CoachLanguage.English ? "inglés" : "español";

        /// <summary>El progreso de la tanda en curso para esa biblioteca, si la hay.</summary>
        public static bool TryGetProgress(LineLibrary library, out BakeProgress progress)
        {
            if (VoiceBakeSession.Running && VoiceBakeSession.Library == library)
            {
                progress = VoiceBakeSession.Progress;
                return true;
            }
            if (_ownRunning && _ownLibrary == library)
            {
                progress = _ownProgress;
                return true;
            }
            progress = default;
            return false;
        }

        /// <summary>Cancela la tanda en curso (la de la sesión o la de este ejecutor).</summary>
        public static void Cancel()
        {
            VoiceBakeSession.Cancel();
            _ownCts?.Cancel();
        }

        /// <summary>El resumen de la última tanda terminada de esa biblioteca, o null.</summary>
        public static BakeSummary LastSummaryFor(LineLibrary library)
        {
            if (_lastWasOwn) return _ownLibrary == library ? _ownSummary : null;
            return VoiceBakeSession.LastSummaryLibrary == library ? VoiceBakeSession.LastSummary : null;
        }

        // La tanda con un proveedor dado: lo mismo que VoiceBakeSession.Start, pero con el proveedor que se pasa.
        private static async void RunOwn(LineLibrary library, VoiceSettings settings, ITtsProvider provider)
        {
            _ownRunning = true;
            _ownLibrary = library;
            _ownSummary = null;
            _ownProgress = new BakeProgress(0, 0, null);
            _ownCts = new CancellationTokenSource();
            try
            {
                var baker = new VoiceBaker(settings, provider);
                var progress = new System.Progress<BakeProgress>(p =>
                {
                    _ownProgress = p;
                    InternalEditorUtility.RepaintAllViews();
                });
                _ownSummary = await baker.BakeAsync(library, new BakeScope(), progress, _ownCts.Token);
            }
            catch (Exception ex)
            {
                var summary = new BakeSummary { Failed = 1 };
                summary.Errors.Add(ex.Message);
                _ownSummary = summary;
                Debug.LogError($"[XRLabs] El horneado de voz falló: {ex.Message}");
            }
            finally
            {
                _ownCts?.Dispose();
                _ownCts = null;
                _ownRunning = false;
                AssetDatabase.SaveAssets();
                InternalEditorUtility.RepaintAllViews();
            }
        }

        // Proveedor que no sintetiza: solo sirve para calcular el plan (como en el inspector de LineLibrary).
        private sealed class NullProvider : ITtsProvider
        {
            public static readonly NullProvider Instance = new();
            public string Id => "none";
            public string DisplayName => "none";

            public Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken) =>
                throw new NotSupportedException();
        }
    }
}
