using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json.Linq;

namespace XRLabs.Authoring.Editor
{
    /// <summary>Un nodo del glTF: su nombre y, si los trae, su traslación [x, y, z] y su rotación [x, y, z, w] (cuaternión).</summary>
    public sealed class GlbNode
    {
        public string Name;
        /// <summary>float[3] en metros y ejes glTF, o null si el nodo no la trae.</summary>
        public float[] Translation;
        /// <summary>float[4] (x, y, z, w), o null si el nodo no la trae.</summary>
        public float[] Rotation;
    }

    /// <summary>
    /// Lector mínimo de GLB 2.0, sin paquetes glTF: cabecera de 12 bytes (magic "glTF", versión, longitud total), después el
    /// primer trozo, que tiene que ser el JSON (longitud, tipo 'JSON', datos). Solo lee <c>nodes[]</c> (nombre, traslación y
    /// rotación); no toca mallas ni binarios. Falla cerrado: si algo no cuadra, lanza <see cref="InvalidDataException"/> con
    /// el motivo, en vez de devolver una lista vacía que se confundiría con «no hay nodos». Documentation~/autoria.md §6.
    /// </summary>
    public static class GlbJson
    {
        private const uint Magic = 0x46546C67;      // "glTF"
        private const uint ChunkJson = 0x4E4F534A;  // "JSON"
        private const int HeaderSize = 12;
        private const int ChunkHeaderSize = 8;

        public static IReadOnlyList<GlbNode> ReadNodes(string path)
        {
            byte[] bytes = File.ReadAllBytes(path);
            string json = ReadJsonChunk(bytes, path);

            JObject root;
            try { root = JObject.Parse(json); }
            catch (Exception e) { throw new InvalidDataException($"{path}: el trozo JSON del GLB no se puede leer ({e.Message})", e); }

            var nodes = new List<GlbNode>();
            if (root["nodes"] is not JArray array) return nodes;
            foreach (var token in array)
            {
                nodes.Add(new GlbNode
                {
                    Name = token?["name"]?.Type == JTokenType.String ? (string)token["name"] : null,
                    Translation = ReadFloats(token?["translation"], 3),
                    Rotation = ReadFloats(token?["rotation"], 4)
                });
            }
            return nodes;
        }

        private static string ReadJsonChunk(byte[] bytes, string path)
        {
            if (bytes.Length < HeaderSize + ChunkHeaderSize)
                throw new InvalidDataException($"{path}: no es un GLB (solo {bytes.Length} bytes, falta la cabecera)");
            if (ReadUInt32(bytes, 0) != Magic)
                throw new InvalidDataException($"{path}: no es un GLB (la cabecera no empieza por 'glTF')");
            uint version = ReadUInt32(bytes, 4);
            if (version != 2)
                throw new InvalidDataException($"{path}: versión de GLB {version} no admitida (solo la 2)");

            uint chunkLength = ReadUInt32(bytes, HeaderSize);
            uint chunkType = ReadUInt32(bytes, HeaderSize + 4);
            if (chunkType != ChunkJson)
                throw new InvalidDataException($"{path}: el primer trozo del GLB no es JSON (tipo 0x{chunkType:X8})");
            long available = bytes.Length - (HeaderSize + ChunkHeaderSize);
            if (chunkLength > available)
                throw new InvalidDataException($"{path}: el GLB está truncado (el trozo JSON dice {chunkLength} bytes y quedan {available})");

            return Encoding.UTF8.GetString(bytes, HeaderSize + ChunkHeaderSize, (int)chunkLength);
        }

        // Little-endian, como manda el formato, sin depender de la máquina.
        private static uint ReadUInt32(byte[] b, int offset) =>
            unchecked((uint)(b[offset] | (b[offset + 1] << 8) | (b[offset + 2] << 16) | (b[offset + 3] << 24)));

        private static float[] ReadFloats(JToken token, int count)
        {
            if (token is not JArray a || a.Count != count) return null;
            var result = new float[count];
            for (int i = 0; i < count; i++)
            {
                if (a[i].Type != JTokenType.Float && a[i].Type != JTokenType.Integer) return null;
                result[i] = (float)a[i];
            }
            return result;
        }
    }
}
