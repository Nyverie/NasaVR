using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using XRLabs.Coach.Editor;
using XRLabs.Core;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// La ventana <c>Tools/XRLabs/Autoría</c> (Documentation~/autoria.md §5): lo único de Unity que ve la persona que
    /// construye la experiencia. Elige el guion.json y la colocacion.json, los valida, los importa y muestra el informe y las
    /// voces que faltan. Desde el lote A2 también prepara la escena (<see cref="ScenePreparer"/>) y genera las voces a un
    /// clic (<see cref="VoiceBakeRunner"/>). No tiene lógica propia: llama a los validadores y a los importadores.
    /// </summary>
    public sealed class AuthoringWindow : EditorWindow
    {
        private const string PlacementRootName = ScenePreparer.PlacementRootName;

        [SerializeField] private string _guionPath = string.Empty;
        [SerializeField] private string _colocacionPath = string.Empty;
        [SerializeField] private string _guionReport = string.Empty;
        [SerializeField] private string _colocacionReport = string.Empty;
        [SerializeField] private bool _guionHasErrors;
        [SerializeField] private bool _colocacionHasErrors;
        [SerializeField] private string _sceneReport = string.Empty;
        [SerializeField] private bool _sceneHasErrors;
        [SerializeField] private Vector2 _scroll;

        private string _voiceLine = string.Empty;
        private string _voiceMessage = string.Empty;
        private bool _voiceMessageIsError;
        private int _missingVoices;
        private bool _voicesWereRunning;
        private LineLibrary _library;
        private bool _guionImported;

        [MenuItem("Tools/XRLabs/Autoría")]
        public static void Open()
        {
            var window = GetWindow<AuthoringWindow>("Autoría");
            window.minSize = new Vector2(460f, 420f);
            window.Show();
        }

        private void OnEnable() => RefreshVoices();

        private void OnFocus() => RefreshVoices();

        // Mientras corre el horneado la ventana se repinta sola (progreso); al terminar, recuenta lo que falta.
        private void OnInspectorUpdate()
        {
            bool running = VoiceBakeRunner.IsRunning;
            if (running || _voicesWereRunning) Repaint();
            if (_voicesWereRunning && !running)
            {
                _voiceMessage = string.Empty;
                RefreshVoices();
            }
            _voicesWereRunning = running;
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            DrawGuionSection();
            EditorGUILayout.Space(10f);
            DrawColocacionSection();
            EditorGUILayout.Space(10f);
            DrawVoicesSection();

            EditorGUILayout.EndScrollView();
        }

        // ── 1. Guion ──────────────────────────────────────────────────────────

        private void DrawGuionSection()
        {
            EditorGUILayout.LabelField("1. Guion", EditorStyles.boldLabel);
            DrawPathField("guion.json", ref _guionPath);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(_guionPath)))
                {
                    if (GUILayout.Button("Validar")) ValidateGuion();
                    using (new EditorGUI.DisabledScope(_guionHasErrors))
                        if (GUILayout.Button("Importar guion")) ImportGuion();
                }

                // Habilitado tras importar sin errores (autoria.md §10.1).
                using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(_guionPath) || _guionHasErrors || !_guionImported))
                    if (GUILayout.Button("Preparar escena")) PrepareScene();
            }
            DrawReport(_guionReport, _guionHasErrors);
            DrawReport(_sceneReport, _sceneHasErrors);
        }

        private void ValidateGuion()
        {
            if (!TryLoadGuion(out var guion, out var error))
            {
                SetGuionReport(error, true);
                return;
            }

            var issues = GuionValidator.Validate(guion);
            SetGuionReport(FormatIssues(issues), ValidationIssue.AnyError(issues));
        }

        private void ImportGuion()
        {
            if (!TryLoadGuion(out var guion, out var error))
            {
                SetGuionReport(error, true);
                return;
            }

            var report = GuionImporter.Import(guion);
            SetGuionReport(report.Summary(), report.HasErrors);
            RefreshVoices();
        }

        // Crea o abre la escena de la experiencia con todo lo que el tutorial pedía a mano (autoria.md §10.1).
        private void PrepareScene()
        {
            if (!TryLoadGuion(out var guion, out var error))
            {
                SetSceneReport(error, true);
                return;
            }

            var report = ScenePreparer.Prepare(guion);
            SetSceneReport(report.Summary(), report.HasErrors);
        }

        private void SetGuionReport(string text, bool hasErrors)
        {
            _guionReport = text;
            _guionHasErrors = hasErrors;
            Repaint();
        }

        private void SetSceneReport(string text, bool hasErrors)
        {
            _sceneReport = text;
            _sceneHasErrors = hasErrors;
            Repaint();
        }

        // ── 2. Colocación ─────────────────────────────────────────────────────

        private void DrawColocacionSection()
        {
            EditorGUILayout.LabelField("2. Colocación", EditorStyles.boldLabel);
            DrawPathField("colocacion.json", ref _colocacionPath);

            var scene = SceneManager.GetActiveScene();
            bool sceneReady = scene.IsValid() && scene.isLoaded && !string.IsNullOrEmpty(scene.path);
            bool guionImported = _guionImported;

            if (!sceneReady)
                EditorGUILayout.HelpBox("Abre y guarda la escena de la experiencia antes de importar la colocación.", MessageType.Info);
            else if (!guionImported)
                EditorGUILayout.HelpBox("Importa primero el guion: la colocación se apoya en sus objetos.", MessageType.Info);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(_colocacionPath) || string.IsNullOrEmpty(_guionPath)))
                {
                    if (GUILayout.Button("Validar")) ValidateColocacion();
                    using (new EditorGUI.DisabledScope(_colocacionHasErrors || !sceneReady || !guionImported))
                        if (GUILayout.Button("Importar colocación")) ImportColocacion();
                }
            }
            DrawReport(_colocacionReport, _colocacionHasErrors);
        }

        private void ValidateColocacion()
        {
            if (!TryLoadGuion(out var guion, out var error) || !TryLoadColocacion(out var colocacion, out error))
            {
                SetColocacionReport(error, true);
                return;
            }

            var issues = ColocacionValidator.Validate(colocacion, guion);
            SetColocacionReport(FormatIssues(issues), ValidationIssue.AnyError(issues));
        }

        private void ImportColocacion()
        {
            if (!TryLoadGuion(out var guion, out var error) || !TryLoadColocacion(out var colocacion, out error))
            {
                SetColocacionReport(error, true);
                return;
            }

            var root = FindOrCreatePlacementRoot();
            var report = ColocacionImporter.Import(colocacion, guion, root, GuionImporter.DefaultAssetsRoot);

            // La persona no tiene que acordarse de guardar la escena (autoria.md §4.1).
            var scene = SceneManager.GetActiveScene();
            if (!report.HasErrors) EditorSceneManager.SaveScene(scene);

            SetColocacionReport(report.Summary(), report.HasErrors);
        }

        private void SetColocacionReport(string text, bool hasErrors)
        {
            _colocacionReport = text;
            _colocacionHasErrors = hasErrors;
            Repaint();
        }

        // La raíz de la colocación en la escena activa: el objeto [Colocacion], que se crea si falta.
        private static Transform FindOrCreatePlacementRoot()
        {
            var scene = SceneManager.GetActiveScene();
            foreach (var go in scene.GetRootGameObjects())
                if (go.name == PlacementRootName) return go.transform;

            var created = new GameObject(PlacementRootName);
            SceneManager.MoveGameObjectToScene(created, scene);
            Undo.RegisterCreatedObjectUndo(created, "Crear [Colocacion]");
            return created.transform;
        }

        // ── 3. Voces ──────────────────────────────────────────────────────────

        private void DrawVoicesSection()
        {
            EditorGUILayout.LabelField("3. Voces", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(string.IsNullOrEmpty(_voiceLine) ? "Importa el guion para ver las voces." : _voiceLine,
                EditorStyles.wordWrappedLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(_library == null))
                {
                    if (GUILayout.Button("Abrir biblioteca de frases"))
                    {
                        Selection.activeObject = _library;
                        EditorGUIUtility.PingObject(_library);
                    }
                }
                if (GUILayout.Button("Ajustes de voz", GUILayout.Width(110f)))
                {
                    var settings = VoiceBakeRunner.GetOrCreateSettings();
                    Selection.activeObject = settings;
                    EditorGUIUtility.PingObject(settings);
                }
            }

            // Un clic: hornea lo que falta con el proveedor de VoiceSettings (D5: la clave en EditorPrefs o en el entorno).
            using (new EditorGUI.DisabledScope(_library == null || VoiceBakeRunner.IsRunning || _missingVoices == 0))
            {
                if (GUILayout.Button($"Generar voces que faltan ({_missingVoices})")) GenerateVoices();
            }

            if (_library != null && VoiceBakeRunner.TryGetProgress(_library, out var progress))
            {
                var rect = EditorGUILayout.GetControlRect(false, 20f);
                string label = $"{progress.Completed}/{progress.Total}" +
                               (string.IsNullOrEmpty(progress.Current) ? string.Empty : " · " + progress.Current);
                EditorGUI.ProgressBar(rect, progress.Fraction, label);
                if (GUILayout.Button("Cancelar")) VoiceBakeRunner.Cancel();
            }
            else if (!string.IsNullOrEmpty(_voiceMessage))
            {
                EditorGUILayout.HelpBox(_voiceMessage, _voiceMessageIsError ? MessageType.Warning : MessageType.Info);
            }
            else if (_library != null && VoiceBakeRunner.LastSummaryFor(_library) is { } summary)
            {
                EditorGUILayout.HelpBox(summary.ToString(), summary.Failed > 0 ? MessageType.Warning : MessageType.Info);
            }
        }

        private void GenerateVoices()
        {
            if (_library == null) return;

            var settings = VoiceBakeRunner.GetOrCreateSettings();
            bool started = VoiceBakeRunner.TryStart(_library, settings, null, out var message);
            _voiceMessage = message;
            _voiceMessageIsError = !started;
            if (!started)
            {
                // Que la persona vea de una vez dónde se pone lo que falta.
                Selection.activeObject = settings;
                EditorGUIUtility.PingObject(settings);
            }
            Repaint();
        }

        // «faltan N voces en <idioma>»: variantes sin clip al día, de frases que se dicen (no soloTexto). El recuento lo
        // da el plan del horneador (VoiceBakeRunner.PlanMissing), el mismo que sigue «Generar voces que faltan».
        private void RefreshVoices()
        {
            _library = null;
            _voiceLine = string.Empty;
            _missingVoices = 0;
            _guionImported = false;

            if (!TryLoadGuion(out var guion, out _)) return;

            var id = guion.Experience.Id;
            if (string.IsNullOrEmpty(id)) return;

            _guionImported = AssetDatabase.LoadAssetAtPath<SimulationSequence>(
                $"{GuionImporter.DefaultAssetsRoot}/{id}/Secuencias/{id}.asset") != null;

            _library = AssetDatabase.LoadAssetAtPath<LineLibrary>($"{GuionImporter.DefaultAssetsRoot}/{id}/Frases/{id}.asset");
            if (_library == null) return;

            // Sin VoiceSettings en el proyecto no se crea ninguno solo por mirar: se calcula con valores por defecto.
            var settings = VoiceSettings.Find();
            bool temporary = settings == null;
            if (temporary) settings = ScriptableObject.CreateInstance<VoiceSettings>();

            try
            {
                var plan = VoiceBakeRunner.PlanMissing(_library, settings);
                _missingVoices = plan.Jobs.Count;

                var parts = new List<string>();
                foreach (var code in GuionValidator.EffectiveLanguages(guion))
                {
                    var language = code == "en" ? CoachLanguage.English : CoachLanguage.Spanish;
                    parts.Add($"faltan {VoiceBakeRunner.CountLanguage(plan, language)} voces en {VoiceBakeRunner.LanguageName(language)}");
                }
                _voiceLine = string.Join("; ", parts) + ".";
            }
            finally
            {
                if (temporary) DestroyImmediate(settings);
            }
            Repaint();
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        private void DrawPathField(string label, ref string path)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                path = EditorGUILayout.TextField(label, path);
                if (GUILayout.Button("Elegir…", GUILayout.Width(70f)))
                {
                    var start = string.IsNullOrEmpty(path) ? Application.dataPath : Path.GetDirectoryName(path);
                    var chosen = EditorUtility.OpenFilePanel(label, start, "json");
                    if (!string.IsNullOrEmpty(chosen))
                    {
                        path = chosen;
                        GUI.FocusControl(null);
                        RefreshVoices();
                    }
                }
            }
        }

        private static void DrawReport(string text, bool hasErrors)
        {
            if (string.IsNullOrEmpty(text)) return;
            EditorGUILayout.HelpBox(text, hasErrors ? MessageType.Error : MessageType.None);
        }

        private bool TryLoadGuion(out GuionDocument guion, out string error)
        {
            guion = null;
            error = string.Empty;
            if (string.IsNullOrEmpty(_guionPath) || !File.Exists(_guionPath))
            {
                error = "No encuentro el guion.json en esa ruta.";
                return false;
            }

            try
            {
                guion = GuionDocument.Load(_guionPath);
                return true;
            }
            catch (Exception ex)
            {
                error = "El guion.json no se puede leer: " + ex.Message;
                return false;
            }
        }

        private bool TryLoadColocacion(out ColocacionDocument colocacion, out string error)
        {
            colocacion = null;
            error = string.Empty;
            if (string.IsNullOrEmpty(_colocacionPath) || !File.Exists(_colocacionPath))
            {
                error = "No encuentro la colocacion.json en esa ruta.";
                return false;
            }

            try
            {
                colocacion = ColocacionDocument.Load(_colocacionPath);
                return true;
            }
            catch (Exception ex)
            {
                error = "La colocacion.json no se puede leer: " + ex.Message;
                return false;
            }
        }

        private static string FormatIssues(List<ValidationIssue> issues)
        {
            int errors = 0;
            foreach (var i in issues) if (i.IsError) errors++;

            var sb = new StringBuilder();
            if (issues.Count == 0) sb.Append("Todo en orden: sin errores ni avisos.");
            else
                sb.Append(errors == 0 ? "Sin errores" : errors + " errores")
                  .Append(", ").Append(issues.Count - errors).Append(" avisos.");
            foreach (var issue in issues) sb.AppendLine().Append("   ").Append(issue);
            return sb.ToString();
        }
    }
}
