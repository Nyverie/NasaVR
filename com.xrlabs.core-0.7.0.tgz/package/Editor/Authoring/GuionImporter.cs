using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using XRLabs.Core;
using XRLabs.Interactions;
using XRLabs.Simulations;
using XRLabs.UI;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Convierte un <see cref="GuionDocument"/> en los assets de una experiencia (Documentation~/autoria.md §3.6):
    /// <c>Pasos/</c>, <c>Condiciones/</c>, <c>Secuencias/</c> y <c>Frases/</c> bajo <c>&lt;assetsRoot&gt;/&lt;id&gt;/</c>, más la
    /// entrada del <see cref="ExperienceSceneMap"/>. Es idempotente: cada asset se busca por su ruta y se actualiza en el
    /// mismo objeto (el GUID no cambia); lo que ya no está en el guion se borra y el informe lo dice. Los campos privados de
    /// las condiciones se escriben con SerializedObject, como lo haría el Inspector, para no tocar el runtime (D8).
    /// Si la validación da errores no toca nada.
    /// </summary>
    public static class GuionImporter
    {
        public const string DefaultAssetsRoot = "Assets/Experiencias";
        public const string DefaultSceneMapPath = "Assets/Resources/ExperienceSceneMap.asset";

        private const float DefaultHintDelay = 10f;
        private const float DefaultMaxAllowedTime = 60f;
        private const float DefaultRotationDegrees = 360f;
        private const float DefaultThreshold = 1f;
        private const float DefaultAimSeconds = 3f;
        private const float DefaultAimGraceSeconds = 1f;

        /// <summary>
        /// Importa el guion. <paramref name="sceneMapPath"/> es la ruta del <see cref="ExperienceSceneMap"/>: el valor por
        /// defecto es el de los proyectos consumidores; los tests pasan una propia para no tocar la del anfitrión.
        /// </summary>
        public static ImportReport Import(GuionDocument doc, string assetsRoot = DefaultAssetsRoot,
            string sceneMapPath = DefaultSceneMapPath)
        {
            var report = new ImportReport();
            doc = GuionExpander.ExpandForImport(doc, report);   // 0.3 lote 3: grupos y bloques → pasos planos

            var issues = GuionValidator.Validate(doc);
            foreach (var issue in issues)
            {
                if (issue.IsError) report.Error(issue.ToString());
                else report.Warn(issue.ToString());
            }
            if (report.HasErrors) return report;

            var run = new Run(doc, report, assetsRoot, sceneMapPath);
            try
            {
                run.PrepareOutsideBatch();

                AssetDatabase.StartAssetEditing();
                try
                {
                    run.WriteAssets();
                }
                finally
                {
                    AssetDatabase.StopAssetEditing();
                }
                AssetDatabase.SaveAssets();
            }
            catch (Exception ex)
            {
                report.Error("La importación se interrumpió: " + ex);
            }
            return report;
        }

        // Una importación en curso: los directorios, el guion y el informe, para no pasarlos a cada función.
        private sealed class Run
        {
            private readonly GuionDocument _doc;
            private readonly ImportReport _report;
            private readonly string _sceneMapPath;
            private readonly string _stepsDir;
            private readonly string _conditionsDir;
            private readonly string _sequencesDir;
            private readonly string _linesDir;

            public Run(GuionDocument doc, ImportReport report, string assetsRoot, string sceneMapPath)
            {
                _doc = doc;
                _report = report;
                _sceneMapPath = sceneMapPath;

                var root = (string.IsNullOrEmpty(assetsRoot) ? DefaultAssetsRoot : assetsRoot).Replace('\\', '/').TrimEnd('/');
                var experienceDir = root + "/" + doc.Experience.Id;
                _stepsDir = experienceDir + "/Pasos";
                _conditionsDir = experienceDir + "/Condiciones";
                _sequencesDir = experienceDir + "/Secuencias";
                _linesDir = experienceDir + "/Frases";
            }

            // ── Antes del lote: carpetas, borrados y tags ─────────────────────
            // Se hace fuera de StartAssetEditing porque borrar y crear en la misma ruta dentro del lote no es fiable.

            public void PrepareOutsideBatch()
            {
                EnsureFolder(_stepsDir);
                EnsureFolder(_conditionsDir);
                EnsureFolder(_sequencesDir);
                EnsureFolder(_linesDir);
                EnsureFolder(Path.GetDirectoryName(_sceneMapPath).Replace('\\', '/'));

                DeleteStaleSteps();
                DeleteStaleConditions();
                EnsureTags();
            }

            private void DeleteStaleSteps()
            {
                var current = new HashSet<string>();
                foreach (var step in _doc.Steps) current.Add(step.Id);

                foreach (var path in ChildAssets(_stepsDir))
                {
                    if (AssetDatabase.LoadAssetAtPath<StepDefinition>(path) == null) continue;
                    if (current.Contains(Path.GetFileNameWithoutExtension(path))) continue;
                    if (AssetDatabase.DeleteAsset(path)) _report.Delete(path + " (el paso ya no está en el guion)");
                }
            }

            private void DeleteStaleConditions()
            {
                var wanted = new Dictionary<string, Type>();
                foreach (var step in _doc.Steps) wanted[step.Id] = ConditionTypeFor(step);

                foreach (var path in ChildAssets(_conditionsDir))
                {
                    var existing = AssetDatabase.LoadAssetAtPath<StepCondition>(path);
                    if (existing == null) continue;

                    wanted.TryGetValue(Path.GetFileNameWithoutExtension(path), out var type);
                    if (type != null && existing.GetType() == type) continue;

                    string why = type == null
                        ? "el paso ya no tiene condición"
                        : $"el paso cambió de tipo: pasa de {existing.GetType().Name} a {type.Name}";
                    if (AssetDatabase.DeleteAsset(path)) _report.Delete($"{path} ({why})");
                }
            }

            // Un tag que pide un paso `girar` y no existe en el proyecto se añade (autoria.md §3.6): la lista de tags de un
            // proyecto nuevo está vacía y RotationTrackingCondition busca por tag.
            private void EnsureTags()
            {
                foreach (var step in _doc.Steps)
                {
                    if (step.Kind != "girar" || step.Condition == null) continue;
                    var tag = _doc.FindObject(step.Condition.ObjectId)?.EffectiveTag;
                    if (string.IsNullOrEmpty(tag)) continue;
                    if (Array.IndexOf(InternalEditorUtility.tags, tag) >= 0) continue;

                    InternalEditorUtility.AddTag(tag);
                    _report.Create($"Tag '{tag}' añadido a los tags del proyecto (lo usa el paso '{step.Id}')");
                }
            }

            // ── Dentro del lote ───────────────────────────────────────────────

            public void WriteAssets()
            {
                var conditions = new Dictionary<string, StepCondition>();
                foreach (var step in _doc.Steps)
                    conditions[step.Id] = WriteCondition(step);

                var steps = new List<StepDefinition>();
                foreach (var step in _doc.Steps)
                    steps.Add(WriteStep(step, conditions[step.Id]));

                WriteLines();
                WriteSequence(steps);
                WriteSceneMapEntry();
            }

            private StepDefinition WriteStep(GuionDocument.StepEntry entry, StepCondition condition)
            {
                var path = $"{_stepsDir}/{entry.Id}.asset";
                var step = Upsert<StepDefinition>(path, out bool isNew);

                step.stepType = entry.IsNarration ? StepType.NonInteractive : StepType.Interaction;
                step.stepId = entry.Id;
                step.titleText = entry.Title ?? string.Empty;
                step.description = entry.Description ?? string.Empty;

                step.introLines = new List<LineRef>();
                if (entry.IntroLines != null)
                    foreach (var id in entry.IntroLines) step.introLines.Add(Ref(id));
                step.instructionLine = Ref(entry.InstructionLine);
                step.hintLine = Ref(entry.HintLine);
                step.successLine = Ref(entry.SuccessLine);
                step.hintDelay = entry.HintDelay ?? DefaultHintDelay;

                step.errorLines = new List<StepErrorLine>();
                if (entry.ErrorLines != null)
                    foreach (var pair in entry.ErrorLines)
                        step.errorLines.Add(new StepErrorLine { key = pair.Key, line = Ref(pair.Value) });
                step.defaultErrorLine = Ref(entry.DefaultErrorLine);
                step.repeatInstructionAfterError = entry.RepeatInstructionAfterError;

                step.countsAsTask = entry.CountsAsTask;
                step.taskLabel = entry.TaskLabel ?? string.Empty;
                step.coachAnchorId = entry.AnchorId ?? string.Empty;
                step.pointAtTargetId = entry.PointAtTargetId ?? string.Empty;
                step.activeTargetIds = new List<string>(entry.ActiveTargetIds ?? new List<string>());
                // 2026-10-17: un «llevar» sin 'activos' resalta lo que se lleva y adónde (las zonas también son SceneTarget);
                // el recorrido mostró que el anillo solo en los objetos no dice adónde van.
                if (step.activeTargetIds.Count == 0 && entry.Kind == "llevar" && entry.Condition != null)
                {
                    foreach (var id in entry.Condition.Objects ?? new List<string>()) if (!string.IsNullOrEmpty(id)) step.activeTargetIds.Add(id);
                    foreach (var id in entry.Condition.Zones ?? new List<string>()) if (!string.IsNullOrEmpty(id)) step.activeTargetIds.Add(id);
                }

                step.maxAllowedTime = entry.MaxAllowedTime ?? DefaultMaxAllowedTime;
                step.scoreOnSuccess = entry.ScoreOnSuccess ?? 0;
                step.penaltyOnError = entry.PenaltyOnError ?? 0;
                step.waitForManualCompletion = entry.WaitForManualCompletion;
                step.completionCondition = condition;
                WriteStepStateLote2(entry, step);
                WriteStepLote5(entry, step);   // 0.3 lote 5

                Commit(step, path, isNew);
                return step;
            }

            // ── Condiciones ───────────────────────────────────────────────────

            private StepCondition WriteCondition(GuionDocument.StepEntry entry)
            {
                var type = ConditionTypeFor(entry);
                if (type == null) return null;

                var path = $"{_conditionsDir}/{entry.Id}.asset";
                var cond = entry.Condition ?? new GuionDocument.ConditionEntry();

                StepCondition asset;
                bool isNew;
                switch (entry.Kind)
                {
                    case "tocar":
                    {
                        var c = Upsert<TouchableHotspotCondition>(path, out isNew);
                        SetString(c, "interactionId", cond.ObjectId);
                        asset = c;
                        break;
                    }
                    case "elegir" when type == typeof(ChoiceByTargetCondition):
                    {
                        var c = Upsert<ChoiceByTargetCondition>(path, out isNew);
                        SetChoiceOptions(c, "options", cond.Options);
                        SetChoiceEffects03(c, "options", cond.Options, _doc);   // 0.3 lote 1
                        SetChoiceByState04(c, cond);   // 0.3 lote 4: segun y errorPorEstado
                        asset = c;
                        break;
                    }
                    case "elegir":
                    {
                        var c = Upsert<KeyChoiceStepCondition>(path, out isNew);
                        // Una señal que el guion no declara queda sin tecla (None): los valores por defecto de la demo
                        // (teclas 2 y 3) harían saltar errores que el guion no pidió.
                        SetKey(c, "correctKey", cond.CorrectKey, KeyCode.None);
                        SetKey(c, "errorKey", cond.Error?.Key, KeyCode.None);
                        SetString(c, "errorKeyId", cond.Error?.SignalKey);
                        SetKey(c, "warningKey", cond.Warning?.Key, KeyCode.None);
                        SetString(c, "warningKeyId", cond.Warning?.SignalKey);
                        asset = c;
                        break;
                    }
                    case "manual":
                    {
                        var c = Upsert<ManualKeyStepCondition>(path, out isNew);
                        SetKey(c, "completeKey", cond.Key, KeyCode.Space);
                        asset = c;
                        break;
                    }
                    case "tiempo":
                    {
                        var c = Upsert<ElapsedTimeStepCondition>(path, out isNew);
                        SetFloat(c, "secondsToComplete", cond.Seconds ?? 3f);
                        asset = c;
                        break;
                    }
                    case "llevar":
                    {
                        var c = Upsert<DropCondition>(path, out isNew);
                        SetStringList(c, "acceptedItemIds", cond.Objects);
                        SetStringList(c, "acceptedZoneIds", cond.Zones);
                        SetInt(c, "requiredCount", cond.Count ?? 1);
                        SetDropRules(c, "rules", cond.Rules);
                        SetString(c, "defaultErrorKey", cond.OutsideKey);
                        WriteDropLote5(c, cond);   // 0.3 lote 5
                        asset = c;
                        break;
                    }
                    case "frotar":
                    {
                        var c = Upsert<ScrubCondition>(path, out isNew);
                        SetString(c, "surfaceId", cond.ObjectId);
                        SetFloat(c, "threshold", cond.Threshold ?? DefaultThreshold);
                        asset = c;
                        break;
                    }
                    case "mantener":
                    {
                        var c = Upsert<HoldCondition>(path, out isNew);
                        SetString(c, "buttonId", cond.ObjectId);
                        SetFloat(c, "threshold", cond.Threshold ?? DefaultThreshold);
                        asset = c;
                        break;
                    }
                    case "apuntar":
                    {
                        var c = Upsert<AimCondition>(path, out isNew);
                        SetString(c, "targetId", cond.ObjectId);
                        SetString(c, "toolId", cond.Tool);
                        SetFloat(c, "secondsRequired", cond.Seconds ?? DefaultAimSeconds);
                        SetWrongTargets(c, "wrongTargets", cond.WrongTargets);
                        asset = c;
                        break;
                    }
                    default: // girar
                    {
                        var c = Upsert<RotationTrackingCondition>(path, out isNew);
                        SetString(c, "targetTag", _doc.FindObject(cond.ObjectId)?.EffectiveTag);
                        SetFloat(c, "requiredAngleDegrees", cond.Degrees ?? DefaultRotationDegrees);
                        asset = c;
                        break;
                    }
                }

                Commit(asset, path, isNew);
                return asset;
            }

            // ── Frases ────────────────────────────────────────────────────────

            private void WriteLines()
            {
                var path = $"{_linesDir}/{_doc.Experience.Id}.asset";
                var library = Upsert<LineLibrary>(path, out bool isNew);
                library.speakerName = string.IsNullOrEmpty(_doc.Coach.Name) ? "Coach" : _doc.Coach.Name;

                var existing = new Dictionary<string, VoiceLine>();
                if (library.lines != null)
                    foreach (var line in library.lines)
                        if (line != null && !string.IsNullOrEmpty(line.id)) existing[line.id] = line;

                var languages = GuionValidator.EffectiveLanguages(_doc);
                var merged = new List<VoiceLine>();
                foreach (var pair in _doc.Lines)
                {
                    existing.TryGetValue(pair.Key, out var line);
                    line ??= new VoiceLine { id = pair.Key };
                    var entry = pair.Value ?? new GuionDocument.LineEntry();

                    line.note = entry.Note ?? string.Empty;
                    line.textOnly = entry.TextOnly;
                    line.variants = MergeVariants(line.variants, entry, languages);
                    merged.Add(line);
                }

                foreach (var id in existing.Keys)
                    if (!_doc.Lines.ContainsKey(id))
                        _report.Delete($"{path}: la frase '{id}' ya no está en el guion (su audio, si había, no se toca)");

                library.lines = merged;
                library.InvalidateCache();
                Commit(library, path, isNew);
            }

            // Texto, dicho y nota se sobrescriben desde el guion; clip y bakeHash de la variante que ya existía se conservan
            // (el horneador decide, por el hash, si el clip sigue valiendo).
            private static List<VoiceLineVariant> MergeVariants(List<VoiceLineVariant> current, GuionDocument.LineEntry entry,
                List<string> languages)
            {
                var result = new List<VoiceLineVariant>();
                foreach (var code in languages)
                {
                    var language = ToLanguage(code);
                    var text = entry.TextFor(code);
                    if (string.IsNullOrEmpty(text)) continue;

                    VoiceLineVariant variant = null;
                    if (current != null)
                        foreach (var v in current)
                            if (v != null && v.language == language) { variant = v; break; }
                    variant ??= new VoiceLineVariant { language = language };

                    variant.text = text;
                    variant.spokenText = entry.SpokenFor(code) ?? string.Empty;
                    result.Add(variant);
                }
                return result;
            }

            // ── Secuencia ─────────────────────────────────────────────────────

            private void WriteSequence(List<StepDefinition> steps)
            {
                var path = $"{_sequencesDir}/{_doc.Experience.Id}.asset";
                var sequence = Upsert<SimulationSequence>(path, out bool isNew);

                sequence.sequenceName = _doc.Experience.Title ?? string.Empty;
                sequence.description = _doc.Experience.Description ?? string.Empty;
                sequence.mode = _doc.Experience.Mode == "evaluacion" ? XRLabs.Core.SimulationMode.Evaluation : XRLabs.Core.SimulationMode.Guided;
                sequence.steps = new List<StepDefinition>(steps);

                sequence.sections = new List<StepSection>();
                foreach (var section in _doc.Sections)
                {
                    int index = _doc.Steps.FindIndex(s => s.Id == section.FromStepId);
                    sequence.sections.Add(new StepSection { sectionName = section.Title, startStepIndex = index });
                }
                WriteState03(sequence);   // 0.3 lote 1
                WriteInitialStateLote2(sequence);   // 0.3 lote 2: después del lote 1, que también escribe initialState
                WriteLocks(sequence);   // 0.3 lote 6
                WriteChooseByState04(sequence);   // 0.3 lote 4: después de WriteState03, que crea stepStateEffects
                WriteIndicators04(sequence);   // 0.3 lote 4
                Commit(sequence, path, isNew);
            }

            // ── 0.3 lote 2 ────────────────────────────────────────────────────
            // contrato-0.3.md §2.1–§2.3: la guarda y los efectos del paso ya resueltos (sin texto que interpretar en
            // ejecución), 'avanzar' como paso NonInteractive sin condición y el estado inicial en la secuencia. Los ids con
            // {variable} se guardan tal cual en el LineRef: el StepSystem los sustituye antes de decirlos y el validador ya
            // exigió cada frase expandida, que WriteLines escribe como cualquier otra.

            private static void WriteStepStateLote2(GuionDocument.StepEntry entry, StepDefinition step)
            {
                step.guard = GuionStateRules.ToConditions(entry.Guard);
                step.onStartEffects = GuionStateRules.ToEffects(entry.OnStart);
                step.onErrorEffects = new List<StepErrorEffects>();
                if (entry.OnError != null)
                    foreach (var pair in entry.OnError)
                        step.onErrorEffects.Add(new StepErrorEffects { key = pair.Key, effects = GuionStateRules.ToEffects(pair.Value) });

                if (entry.IsTimeAdvance)
                {
                    step.stepType = StepType.NonInteractive;
                    step.advanceDays = Math.Max(1, (int)Math.Round(entry.Days ?? 1));
                    step.advanceLabel = entry.Label ?? string.Empty;
                    step.advanceFadeSeconds = Mathf.Clamp(entry.Fade ?? GuionStateRules.DefaultFade, 0f, 5f);
                    step.countsAsTask = false; // no suma tarea ni puntaje (§2.3)
                }
                else
                {
                    step.advanceDays = 0;
                    step.advanceLabel = string.Empty;
                    step.advanceFadeSeconds = GuionStateRules.DefaultFade;
                }
            }

            // El estado inicial, rehecho en cada importación desde 'estado' (más 'dia' si hay un 'avanzar'): lo que se borró
            // del guion no queda en la secuencia. Es un superconjunto de lo que escribe el lote 1, así que puede ir después.
            private void WriteInitialStateLote2(SimulationSequence sequence)
            {
                sequence.initialState = GuionStateRules.ToDefinitions(_doc);
            }

            // 0.3 lote 6: `bloqueos` (contrato-0.3.md §2.8) a la secuencia, para LockEnforcer. Se reescribe entera: un bloqueo que
            // ya no está en el fichero desaparece. Sin bloqueos, la lista queda vacía (como antes).
            private void WriteLocks(SimulationSequence sequence)
            {
                sequence.locks = new List<StepLock>();
                foreach (var l in _doc.Locks ?? new List<GuionDocument.LockEntry>())
                {
                    if (l == null) continue;
                    sequence.locks.Add(new StepLock
                    {
                        zoneId = l.ZoneId ?? string.Empty,
                        objectId = l.ObjectId ?? string.Empty,
                        untilStepId = l.UntilStepId ?? string.Empty,
                        fromStepId = l.FromStepId ?? string.Empty,
                        errorKey = l.ErrorKey ?? string.Empty
                    });
                }
            }

            #region 0.3 lote 4: segun, errorPorEstado e indicadores (contrato-0.3.md §2.5 y §2.9)

            // §2.5: 'segun' y 'errorPorEstado' en la condición y el 'valor' de cada opción. Se escriben siempre (vacíos sin
            // 'segun'), para que re-importar un guion que deja de usarlo no conserve los de antes.
            private static void SetChoiceByState04(UnityEngine.Object target, GuionDocument.ConditionEntry cond)
            {
                var so = new SerializedObject(target);
                Prop(so, "stateVariable").stringValue = cond?.ByState ?? string.Empty;
                var errors = Prop(so, "errorsByState");
                var pairs = new List<KeyValuePair<string, string>>();
                if (!string.IsNullOrEmpty(cond?.ByState) && cond.ErrorsByState != null) pairs.AddRange(cond.ErrorsByState);
                errors.arraySize = pairs.Count;
                for (int i = 0; i < pairs.Count; i++)
                {
                    var e = errors.GetArrayElementAtIndex(i);
                    e.FindPropertyRelative("value").stringValue = pairs[i].Key ?? string.Empty;
                    e.FindPropertyRelative("signalKey").stringValue = pairs[i].Value ?? string.Empty;
                }
                var options = Prop(so, "options");
                int count = cond?.Options?.Count ?? 0;
                for (int i = 0; i < count && i < options.arraySize; i++)
                    options.GetArrayElementAtIndex(i).FindPropertyRelative("stateValue").stringValue =
                        !string.IsNullOrEmpty(cond.ByState) ? cond.Options[i]?.Value ?? string.Empty : string.Empty;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            // §2.5: en un salto, el alElegir que se repite de un 'elegir' con 'segun' es el de la opción del valor de ese
            // momento: se guarda por valor junto a los efectos del paso.
            private void WriteChooseByState04(SimulationSequence sequence)
            {
                if (!StateAuthoring.UsesState(_doc)) return;
                foreach (var step in _doc.Steps)
                {
                    var cond = step?.Condition;
                    if (cond == null || string.IsNullOrEmpty(cond.ByState) || cond.Options == null) continue;
                    var byValue = new List<StateValueEffects>();
                    foreach (var option in cond.Options)
                    {
                        if (option == null || string.IsNullOrEmpty(option.Value)) continue;
                        var effects = StateAuthoring.ParseEffects(option.OnChoose, _doc, step.Id, null);
                        if (effects.Count > 0) byValue.Add(new StateValueEffects { value = option.Value, effects = effects });
                    }
                    var entry = sequence.GetStateEffects(step.Id);
                    if (entry == null)
                    {
                        if (byValue.Count == 0) continue;
                        entry = new StepStateEffects { stepId = step.Id };
                        sequence.stepStateEffects.Add(entry);
                    }
                    entry.chooseBy = cond.ByState;
                    entry.onChooseByValue = byValue;
                }
            }

            // §2.9: los indicadores a la secuencia, con 'desde'/'hasta' que nombran un grupo ya pasados a su primer y su
            // último paso desenrollado. Se reescribe entera: uno que ya no está en el fichero desaparece.
            private void WriteIndicators04(SimulationSequence sequence)
            {
                sequence.indicators = new List<StateIndicator>();
                foreach (var ind in _doc.Indicators ?? new List<GuionDocument.IndicatorEntry>())
                {
                    if (ind == null) continue;
                    var indicator = new StateIndicator
                    {
                        id = ind.Id ?? string.Empty,
                        variable = ind.Variable ?? string.Empty,
                        labelId = ind.Label ?? string.Empty,
                        unit = ind.Unit ?? string.Empty,
                        decimals = ind.Decimals ?? 0,
                        fromStepId = ResolveStep04(ind.FromStepId, last: false),
                        untilStepId = ResolveStep04(ind.UntilStepId, last: true),
                        inReport = ind.InReport
                    };
                    if (ind.Texts != null)
                        foreach (var pair in ind.Texts)
                            indicator.texts.Add(new IndicatorText { value = pair.Key, lineId = pair.Value ?? string.Empty });
                    sequence.indicators.Add(indicator);
                }
            }

            private string ResolveStep04(string id, bool last)
            {
                if (string.IsNullOrEmpty(id)) return string.Empty;
                int index = GuionValidator.StepOrGroupIndex04(_doc, id, last);
                return index >= 0 ? _doc.Steps[index].Id : id;
            }

            #endregion

            // ── ExperienceSceneMap ────────────────────────────────────────────

            private void WriteSceneMapEntry()
            {
                var map = Upsert<ExperienceSceneMap>(_sceneMapPath, out bool isNew);
                var so = new SerializedObject(map);
                var entries = Prop(so, "entries");

                string scene = _doc.Experience.SceneName;
                string key = _doc.Experience.Key ?? string.Empty;

                // Se actualiza la entrada de esa escena o de esa clave; si no hay, se añade. Una clave vacía no empareja:
                // las entradas heredadas de v0.5.1 no la traen.
                int found = -1;
                for (int i = 0; i < entries.arraySize; i++)
                {
                    var e = entries.GetArrayElementAtIndex(i);
                    bool sameScene = e.FindPropertyRelative("sceneName").stringValue == scene;
                    bool sameKey = key.Length > 0 && e.FindPropertyRelative("experienceKey").stringValue == key;
                    if (sameScene || sameKey) { found = i; break; }
                }

                bool added = found < 0;
                if (added)
                {
                    entries.arraySize++;
                    found = entries.arraySize - 1;
                }

                var entry = entries.GetArrayElementAtIndex(found);
                entry.FindPropertyRelative("experienceKey").stringValue = key;
                entry.FindPropertyRelative("experienceId").intValue = _doc.Experience.LegacyId ?? 0;
                entry.FindPropertyRelative("sceneName").stringValue = scene;
                // El título del menú es el del guion (2026-10-25); un guion sin título deja el campo vacío y el menú, el nombre de la escena.
                entry.FindPropertyRelative("title").stringValue = _doc.Experience.Title ?? string.Empty;
                so.ApplyModifiedPropertiesWithoutUndo();

                if (isNew) _report.Create(_sceneMapPath);
                Commit(map, _sceneMapPath, isNew, report: false);
                string what = $"{_sceneMapPath}: entrada de la escena '{scene}'";
                if (added) _report.Create(what);
                else _report.Update(what);
            }

            // ── Utilidades ────────────────────────────────────────────────────

            // El asset de esa ruta, o una instancia nueva si no existe (isNew). El GUID de uno existente no cambia.
            private static T Upsert<T>(string path, out bool isNew) where T : ScriptableObject
            {
                var existing = AssetDatabase.LoadAssetAtPath<T>(path);
                isNew = existing == null;
                return existing != null ? existing : ScriptableObject.CreateInstance<T>();
            }

            private void Commit(UnityEngine.Object asset, string path, bool isNew, bool report = true)
            {
                if (isNew)
                {
                    AssetDatabase.CreateAsset(asset, path);
                    if (report) _report.Create(path);
                }
                else
                {
                    EditorUtility.SetDirty(asset);
                    if (report) _report.Update(path);
                }
            }

            private static LineRef Ref(string id) => new LineRef(string.IsNullOrEmpty(id) ? string.Empty : id);

            private static CoachLanguage ToLanguage(string code) =>
                code == "en" ? CoachLanguage.English : CoachLanguage.Spanish;

            // La StepCondition que genera cada paso (autoria.md §3.4 y contrato-0.2.md §6); null = el paso no lleva
            // condición. «elegir» decide por la condición del paso: con 'opciones' elige objetos y, sin ellas, teclas.
            private static Type ConditionTypeFor(GuionDocument.StepEntry step)
            {
                switch (step.Kind)
                {
                    case "tocar": return typeof(TouchableHotspotCondition);
                    case "elegir":
                        return step.Condition?.Options != null && step.Condition.Options.Count > 0
                            ? typeof(ChoiceByTargetCondition)
                            : typeof(KeyChoiceStepCondition);
                    case "manual": return typeof(ManualKeyStepCondition);
                    case "tiempo": return typeof(ElapsedTimeStepCondition);
                    case "girar": return typeof(RotationTrackingCondition);
                    case "llevar": return typeof(DropCondition);
                    case "frotar": return typeof(ScrubCondition);
                    case "mantener": return typeof(HoldCondition);
                    case "apuntar": return typeof(AimCondition);
                    default: return null;
                }
            }

            // Los assets que están directamente en la carpeta (no en subcarpetas), por ruta.
            private static IEnumerable<string> ChildAssets(string folder)
            {
                if (!AssetDatabase.IsValidFolder(folder)) yield break;
                foreach (var guid in AssetDatabase.FindAssets(string.Empty, new[] { folder }))
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    if (Path.GetDirectoryName(path).Replace('\\', '/') == folder && !AssetDatabase.IsValidFolder(path))
                        yield return path;
                }
            }

            private static void EnsureFolder(string folder)
            {
                if (string.IsNullOrEmpty(folder) || AssetDatabase.IsValidFolder(folder)) return;
                var parent = Path.GetDirectoryName(folder).Replace('\\', '/');
                if (string.IsNullOrEmpty(parent)) return;
                EnsureFolder(parent);
                AssetDatabase.CreateFolder(parent, Path.GetFileName(folder));
            }

            // Los campos privados de las condiciones se escriben como lo haría el Inspector.
            private static SerializedProperty Prop(SerializedObject so, string name) =>
                so.FindProperty(name) ?? throw new InvalidOperationException(
                    $"{so.targetObject.GetType().Name} no tiene el campo serializado '{name}'.");

            private static void SetString(UnityEngine.Object target, string field, string value)
            {
                var so = new SerializedObject(target);
                Prop(so, field).stringValue = value ?? string.Empty;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            private static void SetFloat(UnityEngine.Object target, string field, float value)
            {
                var so = new SerializedObject(target);
                Prop(so, field).floatValue = value;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            private static void SetInt(UnityEngine.Object target, string field, int value)
            {
                var so = new SerializedObject(target);
                Prop(so, field).intValue = value;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            // Un enum se escribe por su VALOR (intValue), no por su índice (enumValueIndex): KeyCode no es contiguo, y un
            // enum que hoy lo es (StepSignalKind, ChoiceOutcome: 0, 1, 2) puede dejar de serlo sin que nada avise.
            private static void SetEnum(SerializedProperty property, int value) => property.intValue = value;

            // Una lista de textos (List<string>) por SerializedProperty: arraySize y un elemento por valor. Una lista nula
            // o vacía deja el campo vacío, que es lo que dice el guion (reimportar sin los ids los borra del asset).
            private static void SetStringList(UnityEngine.Object target, string field, IList<string> values)
            {
                var so = new SerializedObject(target);
                var list = Prop(so, field);
                int count = values?.Count ?? 0;
                list.arraySize = count;
                for (int i = 0; i < count; i++)
                    list.GetArrayElementAtIndex(i).stringValue = values[i] ?? string.Empty;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            // Las listas de structs de las condiciones. Cada elemento se escribe ENTERO: Unity copia el último elemento
            // cuando arraySize crece, y un campo sin escribir heredaría su valor.

            private static void SetDropRules(UnityEngine.Object target, string field, IList<GuionDocument.DropRuleEntry> rules)
            {
                var so = new SerializedObject(target);
                var list = Prop(so, field);
                int count = rules?.Count ?? 0;
                list.arraySize = count;
                for (int i = 0; i < count; i++)
                {
                    var element = list.GetArrayElementAtIndex(i);
                    var rule = rules[i];
                    element.FindPropertyRelative("itemId").stringValue = rule.ObjectId ?? string.Empty;
                    element.FindPropertyRelative("zoneId").stringValue = rule.ZoneId ?? string.Empty;
                    element.FindPropertyRelative("errorKey").stringValue = rule.SignalKey ?? string.Empty;
                    SetEnum(element.FindPropertyRelative("kind"), (int)ToSignalKind(rule.Kind));
                }
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            private static void SetWrongTargets(UnityEngine.Object target, string field, IList<GuionDocument.WrongTargetEntry> wrongs)
            {
                var so = new SerializedObject(target);
                var list = Prop(so, field);
                int count = wrongs?.Count ?? 0;
                list.arraySize = count;
                for (int i = 0; i < count; i++)
                {
                    var element = list.GetArrayElementAtIndex(i);
                    var wrong = wrongs[i];
                    element.FindPropertyRelative("targetId").stringValue = wrong.ObjectId ?? string.Empty;
                    element.FindPropertyRelative("errorKey").stringValue = wrong.SignalKey ?? string.Empty;
                    SetEnum(element.FindPropertyRelative("kind"), (int)ToSignalKind(wrong.Kind));
                    element.FindPropertyRelative("graceSeconds").floatValue = wrong.Grace ?? DefaultAimGraceSeconds;
                }
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            private static void SetChoiceOptions(UnityEngine.Object target, string field, IList<GuionDocument.ChoiceOptionEntry> options)
            {
                var so = new SerializedObject(target);
                var list = Prop(so, field);
                int count = options?.Count ?? 0;
                list.arraySize = count;
                for (int i = 0; i < count; i++)
                {
                    var element = list.GetArrayElementAtIndex(i);
                    var option = options[i];
                    element.FindPropertyRelative("targetId").stringValue = option.ObjectId ?? string.Empty;
                    SetEnum(element.FindPropertyRelative("outcome"), (int)ToChoiceOutcome(option.Outcome));
                    // La opción correcta no lleva clave: se escribe vacía aunque el guion la traiga (el validador avisa).
                    element.FindPropertyRelative("signalKey").stringValue =
                        option.Outcome == "correcta" ? string.Empty : option.SignalKey ?? string.Empty;
                }
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            #region 0.3 lote 5: «Continuar», reacciones, faltantes y zonas distintas (contrato-0.3.md §2.6 y §2.7)

            // 'continuar' del paso y, en un 'llevar', cada reacción como frase en errorLines con la clave «reaccion.<objeto>»
            // (la condición la reporta como info). Sin 'continuar' ni 'reacciones' el paso queda como en 0.2.
            private static void WriteStepLote5(GuionDocument.StepEntry entry, StepDefinition step)
            {
                var cont = entry.Continue;
                step.hasContinue = cont != null;
                step.continueLabel = cont != null ? Ref(string.IsNullOrEmpty(cont.Label) ? GuionDocument.ContinueEntry.DefaultLabel : cont.Label) : default;
                step.continueIncompleteKey = cont?.IncompleteKey ?? string.Empty;

                var reactions = entry.Kind == "llevar" ? entry.Condition?.Reactions : null;
                if (reactions == null) return;
                foreach (var pair in reactions)
                {
                    if (string.IsNullOrEmpty(pair.Key) || string.IsNullOrEmpty(pair.Value)) continue;
                    var key = DropCondition.ReactionKeyPrefix + pair.Key;
                    step.errorLines.RemoveAll(e => e != null && e.key == key);
                    step.errorLines.Add(new StepErrorLine { key = key, line = Ref(pair.Value) });
                }
            }

            // 'faltantes' en el orden de 'objetos' (el primero sin colocar es el que se dice primero), las reacciones y
            // 'distintas'. Reimportar sin ellos los deja vacíos.
            private static void WriteDropLote5(DropCondition c, GuionDocument.ConditionEntry cond)
            {
                var reactionIds = new List<string>();
                if (cond.Reactions != null)
                    foreach (var pair in cond.Reactions)
                        if (!string.IsNullOrEmpty(pair.Key) && !string.IsNullOrEmpty(pair.Value)) reactionIds.Add(pair.Key);
                SetStringList(c, "reactionItemIds", reactionIds);

                var so = new SerializedObject(c);
                var list = Prop(so, "missingKeys");
                var ordered = new List<KeyValuePair<string, string>>();
                if (cond.Missing != null)
                {
                    foreach (var id in cond.Objects ?? new List<string>())
                        if (id != null && cond.Missing.TryGetValue(id, out var key) && !ordered.Exists(p => p.Key == id))
                            ordered.Add(new KeyValuePair<string, string>(id, key));
                    foreach (var pair in cond.Missing)
                        if (!ordered.Exists(p => p.Key == pair.Key)) ordered.Add(pair);
                }
                list.arraySize = ordered.Count;
                for (int i = 0; i < ordered.Count; i++)
                {
                    var element = list.GetArrayElementAtIndex(i);
                    element.FindPropertyRelative("itemId").stringValue = ordered[i].Key ?? string.Empty;
                    element.FindPropertyRelative("errorKey").stringValue = ordered[i].Value ?? string.Empty;
                }
                Prop(so, "distinctZones").boolValue = cond.Distinct == true;
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            #endregion

            #region 0.3 lote 1

            // Contrato 0.3 §2.1: el estado inicial y los efectos de cada paso, ya resueltos, en la SimulationSequence. Sin
            // 'estado' las listas quedan vacías (D8: como antes). El alElegir de la opción correcta se copia aquí para que
            // un salto lo repita (StepSystem, al rehacer el estado de los pasos anteriores al destino).
            private void WriteState03(SimulationSequence sequence)
            {
                sequence.initialState = StateAuthoring.BuildDefinitions(_doc);
                sequence.stepStateEffects = new List<StepStateEffects>();
                if (!StateAuthoring.UsesState(_doc)) return;
                foreach (var step in _doc.Steps)
                {
                    if (step == null) continue;
                    var entry = new StepStateEffects
                    {
                        stepId = step.Id,
                        onComplete = StateAuthoring.ParseEffects(step.OnComplete, _doc, step.Id, null)
                    };
                    foreach (var option in step.Condition?.Options ?? new List<GuionDocument.ChoiceOptionEntry>())
                        if (option != null && option.Outcome == "correcta")
                            entry.onChooseCorrect.AddRange(StateAuthoring.ParseEffects(option.OnChoose, _doc, step.Id, null));
                    if (entry.onComplete.Count > 0 || entry.onChooseCorrect.Count > 0)
                        sequence.stepStateEffects.Add(entry);
                }
            }

            // Contrato 0.3 §2.5: alElegir de cada opción en ChoiceOption.onChoose. Se escribe siempre (vacío sin 'estado').
            private static void SetChoiceEffects03(UnityEngine.Object target, string field,
                IList<GuionDocument.ChoiceOptionEntry> options, GuionDocument doc)
            {
                var so = new SerializedObject(target);
                var list = Prop(so, field);
                int count = options?.Count ?? 0;
                for (int i = 0; i < count && i < list.arraySize; i++)
                {
                    var effects = StateAuthoring.ParseEffects(options[i]?.OnChoose, doc, string.Empty, null);
                    var prop = list.GetArrayElementAtIndex(i).FindPropertyRelative("onChoose");
                    prop.arraySize = effects.Count;
                    for (int k = 0; k < effects.Count; k++)
                    {
                        var e = prop.GetArrayElementAtIndex(k);
                        e.FindPropertyRelative("variable").stringValue = effects[k].variable ?? string.Empty;
                        e.FindPropertyRelative("operation").intValue = (int)effects[k].operation;
                        e.FindPropertyRelative("isNumber").boolValue = effects[k].isNumber;
                        e.FindPropertyRelative("text").stringValue = effects[k].text ?? string.Empty;
                        e.FindPropertyRelative("number").doubleValue = effects[k].number;
                    }
                }
                so.ApplyModifiedPropertiesWithoutUndo();
            }

            #endregion

            // "aviso" → Warning; cualquier otra cosa (y el valor por defecto, vacío) → Error.
            private static StepSignalKind ToSignalKind(string kind) =>
                kind == "aviso" ? StepSignalKind.Warning : StepSignalKind.Error;

            private static ChoiceOutcome ToChoiceOutcome(string outcome)
            {
                switch (outcome)
                {
                    case "correcta": return ChoiceOutcome.Correct;
                    case "aviso": return ChoiceOutcome.Warning;
                    default: return ChoiceOutcome.Error;
                }
            }

            // KeyCode no es una enumeración contigua: se escribe el valor, no el índice.
            private static void SetKey(UnityEngine.Object target, string field, string name, KeyCode fallback)
            {
                var code = KeyNames.ToKeyCode(name, out var parsed) ? parsed : fallback;
                var so = new SerializedObject(target);
                Prop(so, field).intValue = (int)code;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
        }
    }
}
