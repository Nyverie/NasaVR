using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using XRLabs.Coach.Editor;
using XRLabs.Core;

namespace XRLabs.Authoring.Editor
{
    /// <summary>
    /// Las voces que viajan con una muestra del paquete: <c>Samples~/&lt;muestra&gt;/Voces/&lt;es|en&gt;/&lt;id&gt;.wav</c>, con el
    /// mismo nombre de fichero que da <see cref="VoiceBaker.BuildFileStems"/>. Al preparar la muestra se copian a la carpeta
    /// de voces de la experiencia importada (<c>&lt;assetsRoot&gt;/&lt;id&gt;/Voces/&lt;es|en&gt;/</c>, donde las deja el
    /// horneador) y se asignan a las variantes de la biblioteca de frases que aún no tienen clip; un clip que ya estaba
    /// (p. ej. horneado con ElevenLabs en el anfitrión, con <c>bakeHash</c>) no se toca; el que dejó una preparación anterior de
    /// esta misma muestra se refresca si el fichero de la muestra cambió (una frase reescrita no conserva la voz vieja). El <c>bakeHash</c> queda vacío: con VoiceSettings del
    /// proveedor real, esas frases salen «Texto cambiado» y se regeneran. Hoy las de la muestra de compostaje son del
    /// proveedor provisional del sistema (<see cref="MacSayProvider"/>).
    /// </summary>
    public static class SampleVoices
    {
        private static readonly string[] Extensions = { ".wav", ".mp3", ".ogg", ".aif", ".aiff" };

        /// <summary>Copia y asigna las voces de la muestra. Devuelve cuántas variantes recibieron clip.</summary>
        public static int Link(string sampleFolder, GuionDocument guion, string assetsRoot = GuionImporter.DefaultAssetsRoot)
        {
            string sampleVoices = Path.Combine(sampleFolder, VoiceBaker.ExperienceVoicesFolder);
            if (!Directory.Exists(sampleVoices) || guion?.Experience == null) return 0;

            string root = (string.IsNullOrEmpty(assetsRoot) ? GuionImporter.DefaultAssetsRoot : assetsRoot).Replace('\\', '/').TrimEnd('/');
            string experienceDir = $"{root}/{guion.Experience.Id}";
            var library = AssetDatabase.LoadAssetAtPath<LineLibrary>($"{experienceDir}/Frases/{guion.Experience.Id}.asset");
            if (library == null || library.lines == null) return 0;

            var stems = VoiceBaker.BuildFileStems(library);
            int linked = 0;
            foreach (CoachLanguage language in Enum.GetValues(typeof(CoachLanguage)))
            {
                string code = LanguageService.ToCode(language);
                string sourceDir = Path.Combine(sampleVoices, code);
                if (!Directory.Exists(sourceDir)) continue;
                string targetFolder = $"{experienceDir}/{VoiceBaker.ExperienceVoicesFolder}/{code}";

                foreach (var line in library.lines)
                {
                    if (line == null || line.textOnly || !stems.TryGetValue(line, out string stem)) continue;
                    var variant = line.GetVariant(language);
                    if (variant == null) continue;

                    string source = FindSource(sourceDir, stem);
                    if (source == null) continue;

                    string assetPath = $"{targetFolder}/{stem}{Path.GetExtension(source).ToLowerInvariant()}";
                    string absolute = VoiceBaker.AbsolutePath(assetPath);

                    // 2026-10-26: una frase reescrita en la muestra conserva su id, y la escena ya preparada tenía su clip viejo:
                    // se quedaba diciendo la frase de antes. Un clip de esta misma muestra (el mismo nombre en la carpeta de voces
                    // de la experiencia y sin bakeHash) se refresca si el fichero de la muestra cambió; uno horneado con un
                    // proveedor (con bakeHash) o puesto a mano en otro sitio no se toca.
                    string previousPath = null;
                    if (variant.clip != null)
                    {
                        previousPath = AssetDatabase.GetAssetPath(variant.clip);
                        if (!IsSampleClip(variant, previousPath, targetFolder, stem)) continue;
                        if (previousPath == assetPath && File.Exists(absolute) && SameContent(source, absolute)) continue;
                    }

                    VoiceBaker.EnsureFolder(targetFolder);
                    File.Copy(source, absolute, true);
                    AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport);
                    VoiceBaker.ConfigureImporter(assetPath);

                    var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
                    if (clip == null) continue;
                    variant.clip = clip;
                    variant.bakeHash = string.Empty;
                    if (previousPath != null && previousPath != assetPath) AssetDatabase.DeleteAsset(previousPath);   // el de otra extensión
                    linked++;
                }
            }

            if (linked > 0)
            {
                EditorUtility.SetDirty(library);
                AssetDatabase.SaveAssetIfDirty(library);
            }
            return linked;
        }

        // Un clip que Link dejó antes: vive en la carpeta de voces de la experiencia con el nombre de la frase y no tiene bakeHash.
        private static bool IsSampleClip(VoiceLineVariant variant, string clipPath, string targetFolder, string stem) =>
            string.IsNullOrEmpty(variant.bakeHash)
            && !string.IsNullOrEmpty(clipPath)
            && Path.GetDirectoryName(clipPath).Replace('\\', '/') == targetFolder
            && Path.GetFileNameWithoutExtension(clipPath) == stem;

        private static bool SameContent(string a, string b)
        {
            var infoA = new FileInfo(a);
            var infoB = new FileInfo(b);
            if (infoA.Length != infoB.Length) return false;
            byte[] bytesA = File.ReadAllBytes(a);
            byte[] bytesB = File.ReadAllBytes(b);
            for (int i = 0; i < bytesA.Length; i++)
                if (bytesA[i] != bytesB[i]) return false;
            return true;
        }

        private static string FindSource(string dir, string stem)
        {
            foreach (string ext in Extensions)
            {
                string path = Path.Combine(dir, stem + ext);
                if (File.Exists(path)) return path;
            }
            return null;
        }
    }
}
